# -*- coding: utf-8 -*-
"""설정창 (F9 시작 / F8 진행 중 변경): 목표 점수 · 목표 순위 · 시작/종료 시각 · 챔스 승급 대기 · 디스코드/텔레그램 알림  (tkinter)"""
import json
import os
import re

SETTINGS_FILE = 'macro_settings.json'
OLD_TARGET_FILE = 'champions_target.txt'     # 예전 버전 호환
MIN_TARGET, MAX_TARGET = 1, 99999
MIN_RANK, MAX_RANK = 1, 99999


# ───────────── 설정 저장/불러오기 (목표 점수·순위, 웹훅 주소 저장. 종료 시각은 매번 새로) ─────────────
def load_settings(default_target=4500):
    """{'target': 점수 또는 None(없음), 'rank': 순위 또는 None(없음), 'webhook': str}"""
    s = {'target': default_target, 'rank': None, 'webhook': '', 'promo_wait': False,
         'lose_streak': None, 'lose_pause': False, 'daily_report': False}
    try:
        with open(OLD_TARGET_FILE, encoding='utf-8') as f:
            v = parse_target(f.read())
            if v is not None:
                s['target'] = v
    except Exception:
        pass
    try:
        with open(SETTINGS_FILE, encoding='utf-8') as f:
            d = json.load(f)
        if 'target' in d and d['target'] in (None, ''):
            s['target'] = None                      # 목표 점수 없음
        else:
            v = parse_target(d.get('target', ''))
            if v is not None:
                s['target'] = v
        s['rank'] = parse_rank(d.get('rank') or '')
        s['promo_wait'] = bool(d.get('promo_wait', False))
        s['lose_streak'] = parse_streak(d.get('lose_streak') or '')
        s['lose_pause'] = bool(d.get('lose_pause', False))
        s['daily_report'] = bool(d.get('daily_report', False))
        if isinstance(d.get('webhook'), str):
            s['webhook'] = d['webhook'].strip()
    except Exception:
        pass
    return s


def _read_raw():
    try:
        with open(SETTINGS_FILE, encoding='utf-8') as f:
            d = json.load(f)
        return d if isinstance(d, dict) else {}
    except Exception:
        return {}


def _write_raw(d):
    try:
        with open(SETTINGS_FILE, 'w', encoding='utf-8') as f:
            json.dump(d, f, ensure_ascii=False, indent=1)
    except Exception:
        pass


def save_settings(target, webhook, rank=None, promo_wait=None):
    d = _read_raw()                 # 다른 설정(항상 위 등)은 그대로 유지
    d['target'] = target
    d['rank'] = rank
    if promo_wait is not None:
        d['promo_wait'] = bool(promo_wait)
    d['webhook'] = webhook or ''
    _write_raw(d)


def get_option(key, default=None):
    return _read_raw().get(key, default)


def set_option(key, value):
    d = _read_raw()
    d[key] = value
    _write_raw(d)


# ───────────── 입력값 해석 ─────────────
def parse_target(text):
    """'4,600' / ' 4600 ' -> 4600, 숫자가 아니거나 범위 밖이면 None"""
    s = str(text).replace(',', '').strip()
    if not s.isdigit():
        return None
    v = int(s)
    return v if MIN_TARGET <= v <= MAX_TARGET else None


def parse_rank(text):
    """'20' / '20위' -> 20, 빈칸이나 이상한 값 -> None"""
    s = str(text).replace(',', '').replace('위', '').strip()
    if not s.isdigit():
        return None
    v = int(s)
    return v if MIN_RANK <= v <= MAX_RANK else None


def parse_streak(text):
    """'5' / '5연패' -> 5 (2~30), 빈칸·이상한 값 -> None"""
    s = str(text).replace('연패', '').replace('판', '').strip()
    if not s.isdigit():
        return None
    v = int(s)
    return v if 2 <= v <= 30 else None


def parse_max_games(text):
    """빈칸 -> ('ok', None) / '30' -> ('ok', 30) / 이상한 값 -> ('bad', None)"""
    s = str(text).replace(',', '').replace('판', '').strip()
    if s == '':
        return 'ok', None
    if s.isdigit() and 1 <= int(s) <= 9999:
        return 'ok', int(s)
    return 'bad', None


def parse_stop_time(text):
    """빈칸 -> ('ok', None) / '7:00','07:00','0700','7','7시','7시30분' -> ('ok','07:00') / 이상 -> ('bad', None)"""
    s = str(text).strip().replace(' ', '')
    if s == '':
        return 'ok', None
    m = (re.fullmatch(r'(\d{1,2}):(\d{2})', s) or re.fullmatch(r'(\d{1,2})(\d{2})', s)
         or re.fullmatch(r'(\d{1,2})시(?:(\d{1,2})분)?', s) or re.fullmatch(r'(\d{1,2})()', s))
    if not m:
        return 'bad', None
    h = int(m.group(1))
    mi = int(m.group(2)) if m.group(2) else 0
    if not (0 <= h <= 23 and 0 <= mi <= 59):
        return 'bad', None
    return 'ok', '%02d:%02d' % (h, mi)


# ───────────── 설정창 ─────────────
def parse_hours(s):
    """v4.2 돌릴 시간: '2' / '1.5' / '2시간' / '90분' -> 시간(float) / None"""
    s = (s or '').strip().replace(' ', '')
    m = re.fullmatch(r'(\d+(?:\.\d+)?)분', s)
    if m:
        h = float(m.group(1)) / 60
    else:
        m = re.fullmatch(r'(\d+(?:\.\d+)?)(?:시간|h)?', s)
        if not m:
            return None
        h = float(m.group(1))
    return round(h, 3) if 0.1 <= h <= 48 else None


def parse_yield_sec(s):
    s = (s or '').strip().replace('초', '')
    if not s:
        return 3
    try:
        v = int(float(s))
    except ValueError:
        return None
    return v if 1 <= v <= 30 else None


def ask_settings(defaults, focus_click=None, test_send=None, _test_hook=None, mode='start', test_tg=None, master=None):
    """
    defaults: {'target': int|None, 'rank': int|None, 'start_at'/'stop_at': 'HH:MM'|None, 'promo_wait': bool, 'webhook': str}
    mode: 'start' = [시작] (F9) / 'apply' = [적용] (진행 중 F8, 기록 유지) / 'save' = [저장] (멈춰 있을 때 F8)
    반환: {'target'(None=없음), 'rank'(None=없음), 'start_at'/'stop_at'('HH:MM' 또는 None), 'promo_wait', 'webhook'} / 취소=None
    test_send(url) -> (성공여부, 메시지) : '테스트' 버튼용
    """
    import tkinter as tk
    result = {'v': None}
    root = tk.Toplevel(master) if master is not None else tk.Tk()   # v3.0: 매크로 창이 있으면 그 창의 하위 창으로
    root.title({'start': '자동진행 시작', 'apply': '설정 변경 (진행 중 · 기록 유지)', 'save': '설정'}.get(mode, '설정'))
    root.attributes('-topmost', True)
    root.resizable(False, False)
    F = ('Malgun Gothic', 10)
    FB = ('Malgun Gothic', 11, 'bold')
    GRAY = '#666'

    def section(text, pady=(12, 4)):
        tk.Label(frm, text=text, font=FB, anchor='w').grid(row=next_row(), column=0, columnspan=3, sticky='w', pady=pady)

    rows = [0]

    def next_row():
        rows[0] += 1
        return rows[0]

    frm = tk.Frame(root, padx=20, pady=10)
    frm.pack()

    section('정지 조건  (모두 선택 · 비워두면 그 조건 없음)', pady=(4, 2))
    r = next_row()
    tk.Label(frm, text='목표 점수', font=F).grid(row=r, column=0, sticky='w')
    _t = defaults.get('target')
    v_target = tk.StringVar(value='' if _t is None else str(_t))
    e_target = tk.Entry(frm, textvariable=v_target, font=('Malgun Gothic', 14), justify='center', width=8)
    e_target.grid(row=r, column=1, sticky='w', padx=6)
    tk.Label(frm, text='점 이상이 되면 멈춤  (챔피언스 랭킹점수)', font=F, fg=GRAY).grid(row=r, column=2, sticky='w')
    r = next_row()
    tk.Label(frm, text='목표 순위', font=F).grid(row=r, column=0, sticky='w', pady=(4, 0))
    _r = defaults.get('rank')
    v_rank = tk.StringVar(value='' if _r is None else str(_r))
    tk.Entry(frm, textvariable=v_rank, font=('Malgun Gothic', 14), justify='center', width=8).grid(row=r, column=1, sticky='w', padx=6, pady=(4, 0))
    tk.Label(frm, text='위 이내가 되면 멈춤  (예: 20 = 슈퍼 챔피언스 주차)', font=F, fg=GRAY).grid(row=r, column=2, sticky='w', pady=(4, 0))
    r = next_row()
    tk.Checkbutton(frm, text='챔스 승급 대기', font=F, variable=(v_promo := tk.BooleanVar(value=bool(defaults.get('promo_wait'))))
                   ).grid(row=r, column=0, columnspan=2, sticky='w', pady=(4, 0))
    tk.Label(frm, text='슈퍼챌린저에서 다음 판 이기면 챔스 승급이면 멈추고, 자정 지나면 자동 재개', font=F, fg=GRAY
             ).grid(row=r, column=2, sticky='w', pady=(4, 0))
    r = next_row()
    tk.Label(frm, text='연패 경고', font=F).grid(row=r, column=0, sticky='w', pady=(4, 0))
    _ls = defaults.get('lose_streak')
    v_streak = tk.StringVar(value='' if not _ls else str(_ls))
    tk.Entry(frm, textvariable=v_streak, font=('Malgun Gothic', 14), justify='center', width=8).grid(row=r, column=1, sticky='w', padx=6, pady=(4, 0))
    wrap = tk.Frame(frm)
    wrap.grid(row=r, column=2, sticky='w', pady=(4, 0))
    tk.Label(wrap, text='연패면 알림 (예: 5)', font=F, fg=GRAY).pack(side='left')
    v_lpause = tk.BooleanVar(value=bool(defaults.get('lose_pause')))
    tk.Checkbutton(wrap, text='일시정지도', font=F, variable=v_lpause).pack(side='left', padx=(8, 0))

    section('시각  (선택 · 컴퓨터 시계 기준 · 비워두면 없음)')
    r = next_row()
    tk.Label(frm, text='시작 시각', font=F).grid(row=r, column=0, sticky='w')
    v_start = tk.StringVar(value=defaults.get('start_at') or '')
    tk.Entry(frm, textvariable=v_start, font=F, width=8, justify='center').grid(row=r, column=1, sticky='w', padx=6)
    tk.Label(frm, text='이 시각이 되면 자동으로 시작  (예: 00:05 · 비우면 바로 시작)', font=F, fg=GRAY).grid(row=r, column=2, sticky='w')
    r = next_row()
    tk.Label(frm, text='종료 시각', font=F).grid(row=r, column=0, sticky='w', pady=(4, 0))
    v_time = tk.StringVar(value=defaults.get('stop_at') or '')
    tk.Entry(frm, textvariable=v_time, font=F, width=8, justify='center').grid(row=r, column=1, sticky='w', padx=6, pady=(4, 0))
    tk.Label(frm, text='이후엔 새 판 시작 안 함  (예: 07:00)', font=F, fg=GRAY).grid(row=r, column=2, sticky='w', pady=(4, 0))
    # v4.2: 돌릴 시간 · 리피시도 같이 끄기
    r = next_row()
    tk.Label(frm, text='돌릴 시간', font=F).grid(row=r, column=0, sticky='w', pady=(4, 0))
    _rh = defaults.get('run_hours')
    v_hours = tk.StringVar(value='' if not _rh else ('%g' % _rh))
    tk.Entry(frm, textvariable=v_hours, font=F, width=8, justify='center').grid(row=r, column=1, sticky='w', padx=6, pady=(4, 0))
    tk.Label(frm, text='시간 돌리고 이번 판까지 하고 멈춤  (예: 2 · 1.5)', font=F, fg=GRAY).grid(row=r, column=2, sticky='w', pady=(4, 0))
    r = next_row()
    v_repc = tk.BooleanVar(value=bool(defaults.get('repc_off')))
    tk.Checkbutton(frm, text='멈출 때 리피시도 같이 끄기 (원격 모드일 때만: 게임 창 닫기 → 리피시 [종료] → 로그아웃 및 사용종료)',
                   font=F, variable=v_repc, wraplength=540, justify='left').grid(row=r, column=0, columnspan=3, sticky='w', pady=(4, 0))

    section('마우스 양보')
    r = next_row()
    yw = tk.Frame(frm)
    yw.grid(row=r, column=0, columnspan=3, sticky='w')
    v_yield = tk.BooleanVar(value=defaults.get('yield_on', True) is not False)
    tk.Checkbutton(yw, text='내가 마우스·키보드를 쓰는 동안 기다리기 -', font=F, variable=v_yield).pack(side='left')
    v_ysec = tk.StringVar(value=str(defaults.get('yield_sec') or 3))
    tk.Entry(yw, textvariable=v_ysec, font=F, width=4, justify='center').pack(side='left', padx=4)
    tk.Label(yw, text='초 안 쓰면 이어서 (갱신꾼 갱신은 양보 안 함)', font=F, fg=GRAY).pack(side='left')

    section('디스코드 알림  (선택 · 웹훅 주소)')
    r = next_row()
    v_hook = tk.StringVar(value=defaults.get('webhook', '') or '')
    tk.Entry(frm, textvariable=v_hook, font=('Consolas', 9), width=46).grid(row=r, column=0, columnspan=2, sticky='we')
    msg_hook = tk.Label(frm, text='', font=F, fg=GRAY, anchor='w', justify='left', wraplength=440)

    def do_test():
        url = v_hook.get().strip()
        if not url:
            msg_hook.config(text='웹훅 주소를 먼저 넣어주세요', fg='red')
            return
        if test_send is None:
            return
        msg_hook.config(text='보내는 중...', fg=GRAY)
        root.update()
        ok_, m = test_send(url)
        msg_hook.config(text=('✔ ' if ok_ else '✖ ') + m, fg=('#1a8f4c' if ok_ else 'red'))

    tk.Button(frm, text='테스트 전송', font=F, command=do_test).grid(row=r, column=2, sticky='w', padx=6)
    msg_hook.grid(row=next_row(), column=0, columnspan=3, sticky='w')
    r = next_row()
    v_daily = tk.BooleanVar(value=bool(defaults.get('daily_report')))
    tk.Checkbutton(frm, text='하루 결산 리포트 (매일 자정에 전날 기록 요약 + 그래프 전송)', font=F, variable=v_daily
                   ).grid(row=r, column=0, columnspan=3, sticky='w', pady=(4, 0))
    r = next_row()
    tk.Label(frm, text='봇 토큰 (선택 · 디스코드에서 !상태 등 명령)', font=F, fg=GRAY).grid(row=r, column=0, columnspan=3, sticky='w', pady=(6, 0))
    r = next_row()
    v_bot = tk.StringVar(value=defaults.get('bot_token', '') or '')
    tk.Entry(frm, textvariable=v_bot, font=('Consolas', 9), width=46, show='•').grid(row=r, column=0, columnspan=2, sticky='we')

    section('텔레그램 알림·명령  (선택 · @BotFather 에서 만든 봇 토큰)')
    r = next_row()
    v_tg = tk.StringVar(value=defaults.get('tg_token', '') or '')
    tk.Entry(frm, textvariable=v_tg, font=('Consolas', 9), width=46, show='•').grid(row=r, column=0, columnspan=2, sticky='we')
    msg_tg = tk.Label(frm, text='토큰을 넣고 텔레그램에서 내 봇에게 /start 를 보낸 뒤 [테스트]', font=F, fg=GRAY, anchor='w',
                      justify='left', wraplength=440)

    def do_test_tg():
        tok = v_tg.get().strip()
        if not tok:
            msg_tg.config(text='텔레그램 봇 토큰을 먼저 넣어주세요', fg='red')
            return
        if test_tg is None:
            return
        msg_tg.config(text='확인 중...', fg=GRAY)
        root.update()
        try:
            ok_, m = test_tg(tok)
        except Exception as e:
            ok_, m = False, str(e)
        msg_tg.config(text=('✔ ' if ok_ else '✖ ') + m, fg=('#1a8f4c' if ok_ else 'red'))

    tk.Button(frm, text='테스트', font=F, command=do_test_tg).grid(row=r, column=2, sticky='w', padx=6)
    msg_tg.grid(row=next_row(), column=0, columnspan=3, sticky='w')

    section('매크로 창')
    r = next_row()
    v_gui = tk.BooleanVar(value=defaults.get('ui_mode', 'gui') != 'console')
    tk.Checkbutton(frm, text='버튼식 매크로 창 쓰기 (끄면 예전 글자 창 · 다음에 켤 때부터 적용)', font=F, variable=v_gui
                   ).grid(row=r, column=0, columnspan=3, sticky='w')
    r = next_row()
    v_admin = tk.BooleanVar(value=defaults.get('run_as_admin', True) is not False)
    tk.Checkbutton(frm, text='켤 때 관리자 권한으로 켜기 (게임이 클릭을 받으려면 필요 · 다음에 켤 때부터 적용)', font=F,
                   variable=v_admin).grid(row=r, column=0, columnspan=3, sticky='w')

    ok_text = {'start': '시작', 'apply': '적용', 'save': '저장'}.get(mode, '확인')
    msg = tk.Label(frm, text='Enter = %s   /   Esc = 취소' % ok_text, font=F, fg='#777')
    msg.grid(row=next_row(), column=0, columnspan=3, pady=(12, 4))
    btns = tk.Frame(frm)
    btns.grid(row=next_row(), column=0, columnspan=3, pady=(0, 6))

    def ok(*_):
        t = None
        if v_target.get().strip():
            t = parse_target(v_target.get())
            if t is None:
                msg.config(text='목표 점수는 숫자로 입력하거나 비워두세요 (예: 4500)', fg='red')
                return
        rk = None
        if v_rank.get().strip():
            rk = parse_rank(v_rank.get())
            if rk is None:
                msg.config(text='목표 순위는 숫자로 입력하거나 비워두세요 (예: 20)', fg='red')
                return
        ls = None
        if v_streak.get().strip():
            ls = parse_streak(v_streak.get())
            if ls is None:
                msg.config(text='연패 경고는 2~30 사이 숫자로 입력하거나 비워두세요 (예: 5)', fg='red')
                return
        st_s, start_at = parse_stop_time(v_start.get())
        if st_s != 'ok':
            msg.config(text='시작 시각은 00:05 처럼 입력하거나 비워두세요', fg='red')
            return
        st_t, stop_at = parse_stop_time(v_time.get())
        if st_t != 'ok':
            msg.config(text='종료 시각은 07:00 처럼 입력하거나 비워두세요', fg='red')
            return
        rh = None
        if v_hours.get().strip():
            rh = parse_hours(v_hours.get())
            if rh is None:
                msg.config(text='돌릴 시간은 0.1~48 사이 숫자로 입력하거나 비워두세요 (예: 2)', fg='red')
                return
        ys = parse_yield_sec(v_ysec.get())
        if ys is None:
            msg.config(text='양보 시간은 1~30초 사이 숫자로 입력하세요 (예: 3)', fg='red')
            return
        result['v'] = {'target': t, 'rank': rk, 'start_at': start_at, 'stop_at': stop_at,
                       'run_hours': rh, 'repc_off': bool(v_repc.get()), 'yield_on': bool(v_yield.get()), 'yield_sec': ys,
                       'promo_wait': bool(v_promo.get()), 'webhook': v_hook.get().strip(), 'bot_token': v_bot.get().strip(),
                       'tg_token': v_tg.get().strip(),
                       'lose_streak': ls, 'lose_pause': bool(v_lpause.get()), 'daily_report': bool(v_daily.get()),
                       'ui_mode': 'gui' if v_gui.get() else 'console', 'run_as_admin': bool(v_admin.get())}
        root.destroy()

    def cancel(*_):
        root.destroy()

    tk.Button(btns, text=ok_text, width=9, font=F, command=ok).pack(side='left', padx=6)
    tk.Button(btns, text='취소', width=9, font=F, command=cancel).pack(side='left', padx=6)
    root.bind('<Return>', ok)
    root.bind('<KP_Enter>', ok)
    root.bind('<Escape>', cancel)
    root.protocol('WM_DELETE_WINDOW', cancel)

    root.update_idletasks()
    w, h = root.winfo_reqwidth(), root.winfo_reqheight()
    sw, sh = root.winfo_screenwidth(), root.winfo_screenheight()
    root.geometry('+%d+%d' % ((sw - w) // 2, max(0, (sh - h) // 3)))

    def grab_focus():
        try:
            root.lift()
            root.focus_force()
            e_target.focus_force()
            e_target.select_range(0, 'end')
            if focus_click is not None:
                root.update_idletasks()
                x = e_target.winfo_rootx() + e_target.winfo_width() // 2
                y = e_target.winfo_rooty() + e_target.winfo_height() // 2
                focus_click(x, y)
                root.after(80, lambda: e_target.select_range(0, 'end'))
        except Exception:
            pass

    root.after(150, grab_focus)
    if _test_hook is not None:
        root.after(400, lambda: _test_hook(root, {'target': v_target, 'rank': v_rank, 'time': v_time, 'start': v_start, 'promo': v_promo, 'streak': v_streak, 'lpause': v_lpause, 'daily': v_daily,
                                                  'hook': v_hook, 'tg': v_tg, 'msg_tg': msg_tg, 'test_tg': do_test_tg},
                                                  ok, cancel, msg, msg_hook, do_test))
    if master is not None:
        root.grab_set()
        master.wait_window(root)
    else:
        root.mainloop()
    return result['v']
