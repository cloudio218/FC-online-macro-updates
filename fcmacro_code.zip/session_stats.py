# -*- coding: utf-8 -*-
"""
이번 세션 통계: 승/무/패, 판당 평균 점수 변화, 판당 소요 시간, 목표 도달 예상
 - 각 판의 결과 = 다음 판 '진행 직전 점수' - 이번 판 '진행 직전 점수'
   (+면 승, 0이면 무, -면 패). 마지막 판은 다음 점수를 볼 때까지 결과 미정.
"""
import math

MIN_RESULTS_FOR_ETA = 3


def compute(history, target, final_score=None):
    """
    history: [[게임번호, 점수, 'HH:MM:SS', 순위, epoch초], ...] (시작 순서)
    final_score: 정지 시점에 읽은 점수(있으면 마지막 판 결과까지 확정)
    """
    scores = [h[1] for h in history]          # 못 읽은 판은 None
    times = [h[4] for h in history if len(h) > 4 and h[4]]
    if final_score is not None:
        scores = scores + [final_score]
    deltas = [b - a for a, b in zip(scores, scores[1:]) if a is not None and b is not None]
    known = [v for v in scores if v is not None]
    res = [h[7] for h in history if len(h) > 7 and h[7]]      # 기록된 결과 (결과 칸 / 점수 변화)
    if res or any(len(h) > 7 for h in history):
        w, d0, l = res.count('승'), res.count('무'), res.count('패')
    else:
        w = sum(1 for d in deltas if d > 0)
        d0 = sum(1 for d in deltas if d == 0)
        l = sum(1 for d in deltas if d < 0)
    st = {'games': len(history), 'results': w + d0 + l, 'win': w, 'draw': d0, 'loss': l, 'n_deltas': len(deltas),
          'avg_gain': (sum(deltas) / len(deltas)) if deltas else None,
          'avg_min': ((times[-1] - times[0]) / 60.0 / (len(times) - 1)) if len(times) >= 2 else None,
          'current': known[-1] if known else None,
          'eta_games': None, 'eta_min': None, 'eta_note': ''}
    if target is None:
        st['eta_note'] = '목표 점수 없음'
    elif st['current'] is not None and st['current'] >= target:
        st['eta_note'] = '목표 도달'
    elif len(deltas) < MIN_RESULTS_FOR_ETA:
        st['eta_note'] = '예상 계산 중 (%d판 이상 필요)' % (MIN_RESULTS_FOR_ETA + 1)
    elif st['avg_gain'] <= 0:
        st['eta_note'] = '지금 페이스로는 목표 도달이 어려움'
    elif st['current'] is not None:
        g = int(math.ceil((target - st['current']) / st['avg_gain']))
        st['eta_games'] = g
        if st['avg_min']:
            st['eta_min'] = g * st['avg_min']
    return st


def fmt_minutes(m):
    m = int(round(m))
    return ('%d시간 %d분' % (m // 60, m % 60)) if m >= 60 else ('%d분' % m)


def summary_line(st):
    """한 줄 요약 (콘솔/디스코드 공용)"""
    if not st['games']:
        return '아직 진행한 판 없음'
    s = '%d판' % st['games']
    if st['results']:
        s += ' · %d승 %d무 %d패 (승률 %d%%)' % (st['win'], st['draw'], st['loss'], round(st['win'] * 100 / st['results']))
    if st['avg_gain'] is not None:
        s += ' · 판당 %+.1f점' % st['avg_gain']
    if st['avg_min'] and st['avg_min'] >= 1:
        s += ' · 판당 약 %d분' % round(st['avg_min'])
    return s


def eta_line(st, target):
    if target is None:
        return '목표 점수 없음'
    if st['eta_games'] is not None:
        s = '목표 %s점까지 약 %d판' % (format(target, ','), st['eta_games'])
        if st['eta_min'] is not None:
            s += ' (약 %s)' % fmt_minutes(st['eta_min'])
        return s
    return '목표 %s점: %s' % (format(target, ','), st['eta_note'])


def streak_text(results):
    """['승','패','승','승'] -> '현재 2연승' (무승부는 '현재 무승부')"""
    if not results:
        return ''
    last = results[-1]
    n = 0
    for r in reversed(results):
        if r != last:
            break
        n += 1
    if last == '무':
        return '현재 %d연속 무승부' % n if n > 1 else '직전 무승부'
    return '현재 %d연%s' % (n, last)
