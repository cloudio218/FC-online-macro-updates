# -*- coding: utf-8 -*-
"""v4.0 화면 캡처 (mss 대신) - 실행기(exe)에 mss 라이브러리가 없어서 Windows GDI 로 직접 찍음.

갱신꾼 엔진이 쓰는 부분만 같은 모양으로:
  with mss() as sct:  sct.monitors[0]  /  shot = sct.grab({'left','top','width','height'})
  shot.size (w, h) · shot.bgra (bytes, BGRA) · np.asarray(shot) -> H x W x 4 (BGRA)
"""
import ctypes
import sys

if sys.platform == 'win32':
    from ctypes import wintypes as _wt
    _u32 = ctypes.windll.user32
    _g32 = ctypes.windll.gdi32

    class _BIH(ctypes.Structure):
        _fields_ = [('biSize', _wt.DWORD), ('biWidth', _wt.LONG), ('biHeight', _wt.LONG), ('biPlanes', _wt.WORD),
                    ('biBitCount', _wt.WORD), ('biCompression', _wt.DWORD), ('biSizeImage', _wt.DWORD),
                    ('biXPelsPerMeter', _wt.LONG), ('biYPelsPerMeter', _wt.LONG), ('biClrUsed', _wt.DWORD),
                    ('biClrImportant', _wt.DWORD)]

    class _BI(ctypes.Structure):
        _fields_ = [('bmiHeader', _BIH), ('bmiColors', _wt.DWORD * 3)]

    _g32.CreateCompatibleBitmap.restype = _wt.HBITMAP
    _g32.CreateCompatibleDC.restype = _wt.HDC
    _g32.SelectObject.restype = _wt.HGDIOBJ
    _u32.GetWindowDC.restype = _wt.HDC
    _SRCCOPY, _CAPTUREBLT = 0x00CC0020, 0x40000000


class ScreenShot:
    def __init__(self, raw, w, h, left=0, top=0):
        self.raw = raw
        self.width, self.height = w, h
        self.left, self.top = left, top

    @property
    def size(self):
        return self.width, self.height

    @property
    def bgra(self):
        return bytes(self.raw)

    @property
    def __array_interface__(self):
        return {'version': 3, 'shape': (self.height, self.width, 4), 'typestr': '|u1', 'data': bytes(self.raw)}


class mss:
    """mss.mss() 와 같은 쓰임새 (with 문 · monitors · grab)"""

    def __init__(self):
        if sys.platform != 'win32':
            raise OSError('Windows 전용')
        self._dc = _u32.GetWindowDC(0)
        self._mdc = _g32.CreateCompatibleDC(self._dc)
        self._bmp = None
        self._bsize = (0, 0)

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.close()

    def close(self):
        if self._bmp:
            _g32.DeleteObject(self._bmp)
            self._bmp = None
        if self._mdc:
            _g32.DeleteDC(self._mdc)
            self._mdc = None
        if self._dc:
            _u32.ReleaseDC(0, self._dc)
            self._dc = None

    @property
    def monitors(self):
        sm = _u32.GetSystemMetrics
        allm = {'left': sm(76), 'top': sm(77), 'width': sm(78), 'height': sm(79)}      # 가상 화면 전체
        prim = {'left': 0, 'top': 0, 'width': sm(0), 'height': sm(1)}
        return [allm, prim]

    def grab(self, mon):
        if isinstance(mon, (tuple, list)):
            l, t, r, b = mon
            mon = {'left': l, 'top': t, 'width': r - l, 'height': b - t}
        l, t, w, h = int(mon['left']), int(mon['top']), max(1, int(mon['width'])), max(1, int(mon['height']))
        if self._bsize != (w, h):
            if self._bmp:
                _g32.DeleteObject(self._bmp)
            self._bmp = _g32.CreateCompatibleBitmap(self._dc, w, h)
            self._bsize = (w, h)
        _g32.SelectObject(self._mdc, self._bmp)
        _g32.BitBlt(self._mdc, 0, 0, w, h, self._dc, l, t, _SRCCOPY | _CAPTUREBLT)
        bi = _BI()
        bi.bmiHeader.biSize = ctypes.sizeof(_BIH)
        bi.bmiHeader.biWidth = w
        bi.bmiHeader.biHeight = -h                       # 위에서 아래로
        bi.bmiHeader.biPlanes = 1
        bi.bmiHeader.biBitCount = 32
        buf = ctypes.create_string_buffer(w * h * 4)
        _g32.GetDIBits(self._mdc, self._bmp, 0, h, buf, ctypes.byref(bi), 0)
        return ScreenShot(buf.raw, w, h, l, t)
