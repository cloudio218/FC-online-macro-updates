# -*- coding: utf-8 -*-
"""v4.0 화면 캡처 (mss 대신) - 실행기(exe)에 mss 라이브러리가 없어서 Windows GDI 로 직접 찍음.

갱신꾼 엔진이 쓰는 부분만 같은 모양으로:
  with mss() as sct:  sct.monitors[0]  /  shot = sct.grab({'left','top','width','height'})
  shot.size (w, h) · shot.bgra (bytes, BGRA) · np.asarray(shot) -> H x W x 4 (BGRA)
"""
import ctypes
import sys

if sys.platform == 'win32':
    from ctypes import wintypes as _wt
    # v4.0.1: 64비트에서 핸들(HDC 등)이 커서 형식을 안 정하면 'int too long to convert' 오류.
    #   다른 코드(pyautogui 등)가 쓰는 함수에 영향이 없게 따로 불러서 형식을 정함
    _u32 = ctypes.WinDLL('user32')
    _g32 = ctypes.WinDLL('gdi32')

    class _BIH(ctypes.Structure):
        _fields_ = [('biSize', _wt.DWORD), ('biWidth', _wt.LONG), ('biHeight', _wt.LONG), ('biPlanes', _wt.WORD),
                    ('biBitCount', _wt.WORD), ('biCompression', _wt.DWORD), ('biSizeImage', _wt.DWORD),
                    ('biXPelsPerMeter', _wt.LONG), ('biYPelsPerMeter', _wt.LONG), ('biClrUsed', _wt.DWORD),
                    ('biClrImportant', _wt.DWORD)]

    class _BI(ctypes.Structure):
        _fields_ = [('bmiHeader', _BIH), ('bmiColors', _wt.DWORD * 3)]

    _u32.GetWindowDC.argtypes = [_wt.HWND]
    _u32.GetWindowDC.restype = _wt.HDC
    _u32.ReleaseDC.argtypes = [_wt.HWND, _wt.HDC]
    _u32.ReleaseDC.restype = ctypes.c_int
    _u32.GetSystemMetrics.argtypes = [ctypes.c_int]
    _u32.GetSystemMetrics.restype = ctypes.c_int
    _g32.CreateCompatibleDC.argtypes = [_wt.HDC]
    _g32.CreateCompatibleDC.restype = _wt.HDC
    _g32.CreateCompatibleBitmap.argtypes = [_wt.HDC, ctypes.c_int, ctypes.c_int]
    _g32.CreateCompatibleBitmap.restype = _wt.HBITMAP
    _g32.SelectObject.argtypes = [_wt.HDC, _wt.HGDIOBJ]
    _g32.SelectObject.restype = _wt.HGDIOBJ
    _g32.BitBlt.argtypes = [_wt.HDC, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, _wt.HDC,
                            ctypes.c_int, ctypes.c_int, _wt.DWORD]
    _g32.BitBlt.restype = _wt.BOOL
    _g32.GetDIBits.argtypes = [_wt.HDC, _wt.HBITMAP, _wt.UINT, _wt.UINT, ctypes.c_void_p, ctypes.c_void_p, _wt.UINT]
    _g32.GetDIBits.restype = ctypes.c_int
    _g32.DeleteObject.argtypes = [_wt.HGDIOBJ]
    _g32.DeleteObject.restype = _wt.BOOL
    _g32.DeleteDC.argtypes = [_wt.HDC]
    _g32.DeleteDC.restype = _wt.BOOL
    _SRCCOPY, _CAPTUREBLT = 0x00CC0020, 0x40000000


class ScreenShot:
    def __init__(self, raw, w, h, left=0, top=0):
        self.raw = raw
        self.width, self.height = w, h
        self.left, self.top = left, top

    @property
    def size(self):
        return self.width, self.height

    @property
    def bgra(self):
        return bytes(self.raw)

    @property
    def __array_interface__(self):
        return {'version': 3, 'shape': (self.height, self.width, 4), 'typestr': '|u1', 'data': bytes(self.raw)}


class mss:
    """mss.mss() 와 같은 쓰임새 (with 문 · monitors · grab)"""

    def __init__(self):
        self._dc = self._mdc = self._bmp = None
        self._bsize = (0, 0)
        self._pil = sys.platform != 'win32'
        if not self._pil:
            try:
                self._dc = _u32.GetWindowDC(None)
                if not self._dc:
                    raise OSError('GetWindowDC')
                self._mdc = _g32.CreateCompatibleDC(self._dc)
                if not self._mdc:
                    raise OSError('CreateCompatibleDC')
            except Exception:                        # GDI 가 안 되면 PIL ImageGrab 으로 (조금 느림)
                self.close()
                self._pil = True

    def __enter__(self):
        return self

    def __exit__(self, *a):
        try:
            self.close()
        except Exception:
            pass

    def close(self):
        for name, fn in (('_bmp', lambda h: _g32.DeleteObject(h)), ('_mdc', lambda h: _g32.DeleteDC(h)),
                         ('_dc', lambda h: _u32.ReleaseDC(None, h))):
            h = getattr(self, name, None)
            setattr(self, name, None)
            if h:
                try:
                    fn(h)
                except Exception:
                    pass

    @property
    def monitors(self):
        if sys.platform != 'win32':
            return [{'left': 0, 'top': 0, 'width': 1920, 'height': 1080}] * 2
        sm = _u32.GetSystemMetrics
        allm = {'left': sm(76), 'top': sm(77), 'width': sm(78), 'height': sm(79)}      # 가상 화면 전체
        prim = {'left': 0, 'top': 0, 'width': sm(0), 'height': sm(1)}
        return [allm, prim]

    def grab(self, mon):
        if isinstance(mon, (tuple, list)):
            l, t, r, b = mon
            mon = {'left': l, 'top': t, 'width': r - l, 'height': b - t}
        l, t, w, h = int(mon['left']), int(mon['top']), max(1, int(mon['width'])), max(1, int(mon['height']))
        if self._pil:
            return self._grab_pil(l, t, w, h)
        try:
            return self._grab_gdi(l, t, w, h)
        except Exception:
            self.close()
            self._pil = True
            return self._grab_pil(l, t, w, h)

    @staticmethod
    def _grab_pil(l, t, w, h):
        from PIL import ImageGrab
        im = ImageGrab.grab(bbox=(l, t, l + w, t + h), all_screens=True).convert('RGB')
        if im.size != (w, h):
            im = im.resize((w, h))
        r, g, b = im.split()
        from PIL import Image
        raw = Image.merge('RGBA', (b, g, r, Image.new('L', im.size, 255))).tobytes()
        return ScreenShot(raw, w, h, l, t)

    def _grab_gdi(self, l, t, w, h):
        if self._bsize != (w, h):
            if self._bmp:
                _g32.DeleteObject(self._bmp)
            self._bmp = _g32.CreateCompatibleBitmap(self._dc, w, h)
            self._bsize = (w, h)
        _g32.SelectObject(self._mdc, self._bmp)
        _g32.BitBlt(self._mdc, 0, 0, w, h, self._dc, l, t, _SRCCOPY | _CAPTUREBLT)
        bi = _BI()
        bi.bmiHeader.biSize = ctypes.sizeof(_BIH)
        bi.bmiHeader.biWidth = w
        bi.bmiHeader.biHeight = -h                       # 위에서 아래로
        bi.bmiHeader.biPlanes = 1
        bi.bmiHeader.biBitCount = 32
        buf = ctypes.create_string_buffer(w * h * 4)
        _g32.GetDIBits(self._mdc, self._bmp, 0, h, buf, ctypes.byref(bi), 0)
        return ScreenShot(buf.raw, w, h, l, t)
