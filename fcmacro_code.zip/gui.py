# -*- coding: utf-8 -*-
"""
v3.0 매크로 창 (tkinter). 매크로 본체(fifa_macro)는 그대로 돌고, 이 창은 0.5초마다 상태를 읽어서 보여 주기만 함.
 - 버튼 = 단축키와 같은 기능 (버튼 아래 작은 글씨 = 지금 설정된 단축키)
 - 다른 스레드에서 창 작업이 필요하면 call_in_ui(fn) 으로 이 창의 스레드에서 실행 (tkinter 는 만든 스레드에서만 써야 함)
 - 문자는 기본 다국어 평면(BMP)만 씀: Tk 는 그림문자(📌 등)를 제대로 못 그려서 ◎ ⚙ ▶ ❚❚ ■ ⚑ 같은 기호 사용
"""
import queue
import re
import threading
import time
import tkinter as tk
from tkinter import ttk

BG = '#16161d'; CARD = '#20202a'; CARD2 = '#262633'; LINE = '#33334a'; FG = '#e8e8f0'; DIM = '#8d8da3'
GREEN = '#3ecf8e'; RED = '#ff5d6c'; YEL = '#ffc857'; CYAN = '#4fd1e0'; GRAY = '#4a4a5c'
KIND_FG = {'run': GREEN, 'ok': GREEN, 'done': GREEN, 'warn': YEL, 'stop': RED, 'info': CYAN, 'idle': DIM}
FONT = 'Malgun Gothic'
_NON_BMP = re.compile('[\U00010000-\U0010FFFF️]')

_root = None
SCALE = 1.0                  # 화면 배율 (Windows 125% 등이면 1.25) - 픽셀 값에 곱함
_q = queue.Queue()
_api = None
UI_THREAD = None


def px(n):
    return int(round(n * SCALE))


def clean(s):
    """Tk 가 못 그리는 그림문자 제거"""
    return _NON_BMP.sub('', '' if s is None else str(s)).strip()


def active():
    return _root is not None


def call_in_ui(fn, wait=True, timeout=None):
    """fn 을 창 스레드에서 실행 (wait=True 면 끝날 때까지 기다렸다 결과 반환). 창이 없으면 그냥 실행"""
    if _root is None or threading.current_thread() is UI_THREAD:
        return fn()
    if not wait:
        _q.put((fn, None, None))
        return None
    ev = threading.Event()
    box = {}
    _q.put((fn, ev, box))
    ev.wait(timeout)
    if 'err' in box:
        raise box['err']
    return box.get('val')


def _pump():
    if _root is not None:
        _root.after(50, _pump)          # 먼저 다음 차례 예약 (작업 안에서 창이 열려 기다리는 동안에도 다른 작업 처리)
    try:
        while True:
            fn, ev, box = _q.get_nowait()
            try:
                v = fn()
                if box is not None:
                    box['val'] = v
            except Exception as e:      # noqa: BLE001
                if box is not None:
                    box['err'] = e
                elif _api:
                    _api['log_error']('창 작업')
            finally:
                if ev is not None:
                    ev.set()
    except queue.Empty:
        pass


_HWND = [None]


def hwnd():
    """창의 Windows 핸들 (항상 위 / 위치 저장에 사용). 다른 스레드에서도 부르므로 창이 뜰 때 한 번 읽어 둔 값"""
    return _HWND[0] if _root is not None else None


def _read_hwnd():
    try:
        _HWND[0] = int(_root.wm_frame(), 16)
    except Exception:
        _HWND[0] = None


# ── 작은 부품 ─────────────────────────────────────
class Btn(tk.Frame):
    """버튼 (글자 + 아래 작은 단축키 글씨). 누르면 action(id)"""

    def __init__(self, master, aid, on_click):
        super().__init__(master, bg=CARD2, highlightthickness=1, highlightbackground=LINE, cursor='hand2')
        self.aid, self.on_click = aid, on_click
        self.t = tk.Label(self, text='', font=(FONT, 10, 'bold'), fg=FG, bg=CARD2)
        self.t.pack(pady=(6, 0))
        self.k = tk.Label(self, text='', font=(FONT, 8), fg=DIM, bg=CARD2)
        self.k.pack(pady=(0, 4))
        self._bg = CARD2
        self._state = None
        for w in (self, self.t, self.k):
            w.bind('<Button-1>', self._click)
            w.bind('<Enter>', lambda e: self._hover(True))
            w.bind('<Leave>', lambda e: self._hover(False))

    def _click(self, _e):
        self.on_click(self.aid)

    def _hover(self, on):
        c = '#34344a' if on else self._bg
        for w in (self, self.t, self.k):
            w.config(bg=c)

    def set(self, text, key, bg=CARD2, fg=FG, border=LINE):
        st = (text, key, bg, fg, border)
        if st == self._state:
            return
        self._state = st
        self._bg = bg
        self.config(bg=bg, highlightbackground=border)
        self.t.config(text=text, fg=fg, bg=bg)
        self.k.config(text=key or ' ', bg=bg)


def _card(parent, **pack):
    f = tk.Frame(parent, bg=CARD, padx=12, pady=9)
    f.pack(fill='x', padx=10, pady=(0, 7), **pack)
    return f


def _lbl(parent, text='', size=9, fg=FG, bold=False, bg=CARD, **kw):
    return tk.Label(parent, text=text, font=(FONT, size, 'bold') if bold else (FONT, size), fg=fg, bg=bg, **kw)


class _Setter:
    """같은 값이면 위젯을 다시 그리지 않음 (깜빡임 방지)"""

    def __init__(self):
        self.last = {}

    def __call__(self, key, widget, **cfg):
        if self.last.get(key) == cfg:
            return
        self.last[key] = cfg
        widget.config(**cfg)


# ── 메인 창 ─────────────────────────────────────
class MacroWindow:
    COLS = (('no', '회차', 46, 'center'), ('score', '점수', 66, 'e'), ('rank', '순위', 76, 'e'),
            ('time', '시작', 58, 'center'), ('res', '결과', 66, 'center'), ('opp', '상대', 92, 'center'))

    def __init__(self, root, api):
        self.root, self.api = root, api
        self.set = _Setter()
        self.panel_open = False
        self._rows_key = None
        self._flow_key = None
        self._check_seen = 0.0
        self._panel_key = None
        root.configure(bg=BG)
        root.minsize(px(420), px(600))

        # 아래쪽(버튼·바닥글)을 먼저 붙여서 창이 작아도 버튼은 항상 보이게
        foot = tk.Frame(root, bg=BG, padx=14)
        foot.pack(side='bottom', fill='x', pady=(0, 7))
        self.w_foot = _lbl(foot, '', 8, DIM, bg=BG, cursor='hand2', anchor='w')
        self.w_foot.pack(side='left', fill='x')
        self.w_foot.bind('<Button-1>', lambda e: api['action']('folder'))

        bt = tk.Frame(root, bg=BG, padx=7)
        bt.pack(side='bottom', fill='x', pady=(0, 4))
        for i in range(3):
            bt.grid_columnconfigure(i, weight=1, uniform='b')
        self.btns = {}
        order = ['topmost', 'check', 'settings', 'start', 'pause', 'chart', 'stop', 'lastgame', 'layout',
                 'hotkeys', 'today', 'formation']
        for n, aid in enumerate(order):
            b = Btn(bt, aid, self._press)
            b.grid(row=n // 3, column=n % 3, sticky='nsew', padx=3, pady=3)
            self.btns[aid] = b

        # 알림 · 점검 (접기/펼치기)
        self.panel = tk.Frame(root, bg=CARD, padx=12, pady=8)
        self.panel.pack(side='bottom', fill='x', padx=10, pady=(0, 7))
        ph = tk.Frame(self.panel, bg=CARD, cursor='hand2')
        ph.pack(fill='x')
        self.w_ptitle = _lbl(ph, '▸ 알림 · 점검', 10, FG, True, cursor='hand2')
        self.w_ptitle.pack(side='left')
        self.w_psum = _lbl(ph, '', 9, GREEN, cursor='hand2')
        self.w_psum.pack(side='right')
        for w in (ph, self.w_ptitle, self.w_psum):
            w.bind('<Button-1>', lambda e: self.toggle_panel())
        self.pbody = tk.Frame(self.panel, bg=CARD)
        self.ptext = tk.Text(self.pbody, bg=CARD, fg=FG, font=(FONT, 9), relief='flat', height=6, wrap='word',
                             highlightthickness=0, padx=0, pady=2, cursor='arrow', spacing1=1, spacing3=1)
        self.psb = ttk.Scrollbar(self.pbody, orient='vertical', command=self.ptext.yview, style='M.Vertical.TScrollbar')
        self.ptext.configure(yscrollcommand=self.psb.set)
        self.ptext.pack(side='left', fill='both', expand=True)
        for tag, color in (('ok', GREEN), ('bad', RED), ('dim', DIM), ('txt', FG)):
            self.ptext.tag_configure(tag, foreground=color)
        self.ptext.tag_configure('mark', font=(FONT, 9, 'bold'))

        # 맨 위: 제목
        top = tk.Frame(root, bg=BG, padx=12, pady=8)
        top.pack(fill='x')
        _lbl(top, 'FC온라인 감독모드 매크로', 12, FG, True, bg=BG).pack(side='left')
        self.w_ver = _lbl(top, '', 8, DIM, bg=BG)
        self.w_ver.pack(side='left', padx=6, pady=(4, 0))
        self.w_pin = _lbl(top, '', 9, CYAN, bg=BG, cursor='hand2')
        self.w_pin.pack(side='right')
        self.w_pin.bind('<Button-1>', lambda e: api['action']('topmost'))

        # 상태
        st = _card(root)
        r = tk.Frame(st, bg=CARD)
        r.pack(fill='x')
        self.w_state = _lbl(r, '', 11, GREEN, True)
        self.w_state.pack(side='left')
        self.w_mode = _lbl(r, '', 9, DIM)
        self.w_mode.pack(side='right')
        self.w_banner = tk.Label(st, text='', font=(FONT, 9), fg=YEL, bg='#3a3020', anchor='w', justify='left',
                                 wraplength=px(410), padx=8, pady=5)
        self.w_status = _lbl(st, '', 9, DIM, anchor='w', justify='left', wraplength=px(420))
        self.w_status.pack(fill='x', pady=(4, 0))
        self.w_error = _lbl(st, '', 9, YEL, anchor='w', justify='left', wraplength=px(420))

        # 큰 숫자
        nc = _card(root)
        g = tk.Frame(nc, bg=CARD)
        g.pack(fill='x')
        self.big = {}
        for i, (key, title) in enumerate((('score', '랭킹점수'), ('rank', '순위'), ('fc', 'FC'))):
            c = tk.Frame(g, bg=CARD)
            c.grid(row=0, column=i, sticky='w', padx=(0, 24))
            _lbl(c, title, 9, DIM).pack(anchor='w')
            v = _lbl(c, '-', 20 if i == 0 else 15, FG if key != 'fc' else YEL, True)
            v.pack(anchor='w')
            s = _lbl(c, '', 9, DIM)
            s.pack(anchor='w')
            self.big[key] = (v, s)
        self.w_cond = _lbl(nc, '', 9, DIM, anchor='w', justify='left', wraplength=px(420))
        self.w_cond.pack(fill='x', pady=(6, 0))
        self.w_eta = _lbl(nc, '', 9, '#c58cff', anchor='w', justify='left', wraplength=px(420))

        # 통계 + 흐름
        sc = _card(root)
        self.w_now = self._stat_row(sc, '이번')
        self.w_today = self._stat_row(sc, '오늘')
        fl = tk.Frame(sc, bg=CARD)
        fl.pack(fill='x', pady=(6, 0))
        _lbl(fl, '흐름', 9, DIM, True, width=4, anchor='w').pack(side='left')
        self.w_flow = tk.Frame(fl, bg=CARD)
        self.w_flow.pack(side='left')
        self.w_streak = _lbl(sc, '', 8, DIM, anchor='e')
        self.w_streak.pack(fill='x', pady=(3, 0))

        # 최근 기록 (남는 공간 전부 · 스크롤)
        tc = tk.Frame(root, bg=CARD, padx=12, pady=9)
        tc.pack(fill='both', expand=True, padx=10, pady=(0, 7))
        self.tc = tc
        self._plines = 0                     # 지금 펼친 점검 글 줄 수
        root.bind('<Configure>', lambda e: (self._fit_panel() if e.widget is root else None))
        h = tk.Frame(tc, bg=CARD)
        h.pack(fill='x', pady=(0, 5))
        _lbl(h, '최근 기록', 10, FG, True).pack(side='left')
        self.w_tnote = _lbl(h, '', 8, DIM)
        self.w_tnote.pack(side='right')
        stl = ttk.Style(root)
        try:
            stl.theme_use('clam')
        except tk.TclError:
            pass
        stl.configure('M.Treeview', background=CARD2, fieldbackground=CARD2, foreground=FG, rowheight=px(23),
                      font=(FONT, 9), borderwidth=0)
        stl.configure('M.Treeview.Heading', background=CARD, foreground=DIM, font=(FONT, 9), relief='flat', borderwidth=0)
        stl.map('M.Treeview', background=[('selected', '#34344a')], foreground=[('selected', FG)])
        stl.layout('M.Treeview', [('M.Treeview.treearea', {'sticky': 'nswe'})])      # 흰 테두리 없애기
        stl.map('M.Treeview.Heading', background=[('active', CARD)])
        stl.configure('M.Vertical.TScrollbar', background=GRAY, troughcolor='#1b1b24', bordercolor='#1b1b24',
                      arrowcolor=DIM, gripcount=0)
        tf = tk.Frame(tc, bg=CARD)
        tf.pack(fill='both', expand=True)
        self.tv = ttk.Treeview(tf, columns=[c[0] for c in self.COLS], show='headings', height=8, style='M.Treeview')
        for c, t, w, a in self.COLS:
            self.tv.heading(c, text=t)
            self.tv.column(c, width=px(w), anchor=a, stretch=(c == 'opp'))
        sb = ttk.Scrollbar(tf, orient='vertical', command=self.tv.yview, style='M.Vertical.TScrollbar')
        self.tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self.tv.pack(side='left', fill='both', expand=True)
        for tag, color in (('w', GREEN), ('l', RED), ('d', '#b9b9cc'), ('p', CYAN), ('s', DIM), ('o', FG)):
            self.tv.tag_configure(tag, foreground=color)

        root.protocol('WM_DELETE_WINDOW', lambda: api['action']('quit'))
        self.refresh()

    def _stat_row(self, parent, title):
        r = tk.Frame(parent, bg=CARD)
        r.pack(fill='x', pady=1)
        _lbl(r, title, 9, DIM, True, width=4, anchor='w').pack(side='left')
        w = _lbl(r, '', 9, FG, anchor='w', justify='left', wraplength=px(380))
        w.pack(side='left', fill='x')
        return w

    def _press(self, aid):
        self.api['action'](aid)

    def toggle_panel(self, force=None):
        self.panel_open = (not self.panel_open) if force is None else force
        if self.panel_open:
            self.ptext.config(height=2)          # 작게 펼친 뒤 남는 공간에 맞춰 늘림
            self._plines = 2
            self.pbody.pack(fill='x', pady=(6, 0))
        else:
            self.pbody.pack_forget()
            self._plines = 0
        self._panel_key = None
        self.refresh_panel(self.api['snapshot']())

    # ── 0.5초마다 ─────────────────────────────
    def refresh(self):
        try:
            s = self.api['snapshot']()
            self._apply(s)
        except Exception:
            self.api['log_error']('매크로 창 표시')
        self.root.after(500, self.refresh)

    def _apply(self, s):
        S = self.set
        if self.root.title() != s['title']:
            self.root.title(s['title'])
        S('ver', self.w_ver, text=s['version'])
        S('pin', self.w_pin, text='◎ 항상 위 켜짐' if s['topmost'] else '○ 항상 위 꺼짐', fg=CYAN if s['topmost'] else DIM)
        S('state', self.w_state, text=clean(s['state_text']), fg=KIND_FG.get(s['state'], FG))
        S('mode', self.w_mode, text=s['mode'])
        if s['banner']:
            S('banner', self.w_banner, text=clean(s['banner']))
            if not self.w_banner.winfo_ismapped():
                nxt = next((w for w in (self.w_status, self.w_error) if w.winfo_ismapped()), None)
                self.w_banner.pack(fill='x', pady=(6, 0), before=nxt)
        elif self.w_banner.winfo_ismapped():
            self.w_banner.pack_forget()
        if s['status'][0]:
            S('status', self.w_status, text=clean(s['status'][0]), fg=KIND_FG.get(s['status'][1], DIM))
            if not self.w_status.winfo_ismapped():
                self.w_status.pack(fill='x', pady=(4, 0), before=self.w_error if self.w_error.winfo_ismapped() else None)
        elif self.w_status.winfo_ismapped():
            self.w_status.pack_forget()
        if s['error']:
            S('error', self.w_error, text='! ' + clean(s['error']))
            if not self.w_error.winfo_ismapped():
                self.w_error.pack(fill='x', pady=(3, 0))
        elif self.w_error.winfo_ismapped():
            self.w_error.pack_forget()
        for key in ('score', 'rank', 'fc'):
            v, sub = self.big[key]
            val, subtext, subcolor = s['big'][key]
            S('big_' + key, v, text=val)
            S('bigs_' + key, sub, text=subtext, fg={'up': GREEN, 'down': RED}.get(subcolor, DIM))
        S('cond', self.w_cond, text=clean(s['cond']))
        if s['eta']:
            S('eta', self.w_eta, text=clean(s['eta']))
            if not self.w_eta.winfo_ismapped():
                self.w_eta.pack(fill='x', pady=(2, 0))
        elif self.w_eta.winfo_ismapped():
            self.w_eta.pack_forget()
        S('now', self.w_now, text=clean(s['now']))
        S('today', self.w_today, text=clean(s['today']) or '아직 기록 없음')
        if s['flow'] != self._flow_key:
            self._flow_key = list(s['flow'])
            for w in self.w_flow.winfo_children():
                w.destroy()
            for r in s['flow']:
                c = {'승': GREEN, '패': RED}.get(r, GRAY)
                tk.Label(self.w_flow, text=r, font=(FONT, 8, 'bold'), fg='#111' if r != '무' else FG, bg=c,
                         width=2).pack(side='left', padx=1)
        S('streak', self.w_streak, text=s['streak'])
        # 표
        if s['rows_key'] != self._rows_key:
            first = self._rows_key is None or (s['rows'] and self._rows_key and s['rows_key'][0] != self._rows_key[0])
            self._rows_key = s['rows_key']
            y = self.tv.yview()[0]
            self.tv.delete(*self.tv.get_children())
            for row in s['rows']:
                self.tv.insert('', 'end', values=row['values'], tags=(row['tag'],))
            if first:
                self.tv.yview_moveto(0)              # 새 판이 생기면 맨 위로
            else:
                self.tv.yview_moveto(y)
        S('tnote', self.w_tnote, text=s['rows_note'])
        # 버튼
        for aid, b in self.btns.items():
            b.set(*s['buttons'][aid])
        S('foot', self.w_foot, text='기록 폴더: ' + s['data_dir'])
        # F7 을 누르면 펼침
        if s['check_time'] and s['check_time'] != self._check_seen:
            self._check_seen = s['check_time']
            if s['check_auto_open'] and not self.panel_open:
                self.toggle_panel(True)
                return
        self.refresh_panel(s)

    def refresh_panel(self, s):
        S = self.set
        parts = []
        worst = True
        for name, ok in s['panel_sum']:
            parts.append('%s %s' % (name, {True: '✔', False: '✖', None: '–'}[ok]))
            if ok is False:
                worst = False
        S('ptitle', self.w_ptitle, text=('▾' if self.panel_open else '▸') + ' 알림 · 점검')
        S('psum', self.w_psum, text=' · '.join(parts), fg=GREEN if worst else RED)
        if not self.panel_open:
            return
        key = tuple(s['panel_lines'])
        if key == self._panel_key:
            return
        self._panel_key = key
        # 글 상자 (최대 7줄 높이, 넘치면 스크롤) - 펼쳐도 최근 기록 표가 사라지지 않게
        t = self.ptext
        t.config(state='normal')
        t.delete('1.0', 'end')
        for i, (ok, text) in enumerate(s['panel_lines']):
            mark, tag = {True: ('✔ ', 'ok'), False: ('✖ ', 'bad')}.get(ok, ('·  ', 'dim'))
            t.insert('end', mark, (tag, 'mark'))
            t.insert('end', clean(text) + ('\n' if i < len(s['panel_lines']) - 1 else ''), 'txt' if ok is not None else 'dim')
        t.config(state='disabled')
        self._pn = len(s['panel_lines'])
        self._fit_panel()

    LINE_PX = 19
    TABLE_MIN_PX = 112                       # 펼쳐도 최근 기록 표는 제목 + 2줄은 남김

    def _fit_panel(self):
        """펼친 점검 글 높이를 남는 공간에 맞춤 (창 크기는 그대로, 최근 기록 표가 줄어듦)"""
        if not self.panel_open:
            return
        self.root.update_idletasks()
        n = getattr(self, '_pn', 0)
        try:
            from tkinter import font as tkfont
            lp = tkfont.Font(font=self.ptext['font']).metrics('linespace') + 2
        except Exception:
            lp = self.LINE_PX
        cur = self.ptext.winfo_height() if self.ptext.winfo_ismapped() else 0
        free = self.tc.winfo_height() + cur - 6
        fit = max(2, min(9, n, (free - px(self.TABLE_MIN_PX)) // lp))
        if fit != self._plines:
            self._plines = fit
            self.ptext.config(height=fit)
        if n > fit:
            if not self.psb.winfo_ismapped():
                self.psb.pack(side='right', fill='y', before=self.ptext)
        elif self.psb.winfo_ismapped():
            self.psb.pack_forget()


# ── 팝업 ───────────────────────────────────────
def show_text(title, lines, mono=False):
    """글 보기 창 (오늘 결산 / 포메이션 등) - 창 스레드에서 호출"""
    w = tk.Toplevel(_root)
    w.title(clean(title))
    w.configure(bg=BG)
    w.transient(_root)
    _lbl(w, clean(title), 11, FG, True, bg=BG).pack(anchor='w', padx=14, pady=(12, 6))
    t = tk.Text(w, bg=CARD, fg=FG, font=('Consolas', 10) if mono else (FONT, 10), relief='flat', padx=10, pady=8,
                width=56, height=min(24, max(6, len(lines) + 1)), wrap='word', highlightthickness=0)
    t.insert('end', '\n'.join(clean(x) if x.strip() != '```' else '' for x in lines).strip())
    t.config(state='disabled')
    t.pack(fill='both', expand=True, padx=14)
    tk.Button(w, text='닫기', font=(FONT, 9), command=w.destroy, width=10).pack(pady=10)
    w.update_idletasks()
    try:
        x = _root.winfo_rootx() + 20
        y = _root.winfo_rooty() + 80
        w.geometry('+%d+%d' % (x, y))
    except Exception:
        pass
    return w


def show_table(title, headers, rows, note=''):
    """표 보기 창 (포메이션 등) - 한글이 섞여도 칸이 맞게 표로"""
    w = tk.Toplevel(_root)
    w.title(clean(title))
    w.configure(bg=BG)
    w.transient(_root)
    _lbl(w, clean(title), 11, FG, True, bg=BG).pack(anchor='w', padx=14, pady=(12, 6))
    f = tk.Frame(w, bg=CARD)
    f.pack(fill='both', expand=True, padx=14)
    tv = ttk.Treeview(f, columns=list(range(len(headers))), show='headings', height=min(15, max(4, len(rows))),
                      style='M.Treeview')
    for i, h in enumerate(headers):
        tv.heading(i, text=h)
        tv.column(i, width=110 if i == 0 else 64, anchor='w' if i == 0 else 'center', stretch=False)
    for r in rows:
        tv.insert('', 'end', values=[clean(x) for x in r])
    sb = ttk.Scrollbar(f, orient='vertical', command=tv.yview, style='M.Vertical.TScrollbar')
    tv.configure(yscrollcommand=sb.set)
    sb.pack(side='right', fill='y')
    tv.pack(side='left', fill='both', expand=True)
    if note:
        _lbl(w, clean(note), 9, DIM, bg=BG).pack(anchor='w', padx=14, pady=(6, 0))
    tk.Button(w, text='닫기', font=(FONT, 9), command=w.destroy, width=10).pack(pady=10)
    try:
        w.geometry('+%d+%d' % (_root.winfo_rootx() + 20, _root.winfo_rooty() + 80))
    except Exception:
        pass
    return w


def ask(title, text, kind='yesno'):
    """확인 질문 (창 스레드에서) -> True/False/None"""
    from tkinter import messagebox
    if kind == 'yesnocancel':
        return messagebox.askyesnocancel(title, text, parent=_root)
    if kind == 'info':
        messagebox.showinfo(title, text, parent=_root)
        return True
    return messagebox.askyesno(title, text, parent=_root)


# ── 단축키 설정 창 ───────────────────────────────
_KEYSYM = {'Prior': 'page up', 'Next': 'page down', 'Home': 'home', 'End': 'end', 'Insert': 'insert',
           'Delete': 'delete', 'Up': 'up', 'Down': 'down', 'Left': 'left', 'Right': 'right', 'Pause': 'pause',
           'Scroll_Lock': 'scroll lock', 'Tab': 'tab', 'BackSpace': 'backspace', 'minus': '-', 'equal': '=',
           'comma': ',', 'period': '.', 'slash': '/', 'semicolon': ';', 'apostrophe': "'", 'bracketleft': '[',
           'bracketright': ']', 'backslash': '\\', 'grave': '`'}
_MODS = ('Control_L', 'Control_R', 'Shift_L', 'Shift_R', 'Alt_L', 'Alt_R', 'Meta_L', 'Meta_R', 'Win_L', 'Win_R',
         'Super_L', 'Super_R', 'Caps_Lock', 'Num_Lock', 'Hangul', 'Hangul_Hanja')
FORBIDDEN = {'s', 'esc', 'escape', 'space', 'enter', 'return'}
PLAIN_OK = {'f%d' % i for i in range(1, 13)} | {'pause', 'scroll lock', 'insert'}


def key_label(k):
    """'ctrl+f12' -> 'Ctrl + F12'"""
    if not k:
        return '없음'
    out = []
    for p in k.split('+'):
        p = p.strip()
        if re.fullmatch(r'f\d{1,2}', p):
            out.append(p.upper())
        elif p in ('ctrl', 'alt', 'shift'):
            out.append(p.capitalize())
        elif len(p) == 1:
            out.append(p.upper())
        else:
            out.append(p.title())
    return ' + '.join(out)


def event_to_key(e):
    """tkinter 키 이벤트 -> keyboard 라이브러리 이름 ('ctrl+f12') / None(수정키만) / ('err', 이유)"""
    ks = e.keysym
    if ks in _MODS:
        return None
    if re.fullmatch(r'F\d{1,2}', ks):
        main = ks.lower()
    elif ks in _KEYSYM:
        main = _KEYSYM[ks]
    elif len(ks) == 1 and ks.isprintable():
        main = ks.lower()
    elif ks in ('Escape', 'space', 'Return', 'KP_Enter'):
        main = {'Escape': 'esc', 'space': 'space', 'Return': 'enter', 'KP_Enter': 'enter'}[ks]
    else:
        return ('err', '이 키는 쓸 수 없어요 (%s)' % ks)
    st = e.state
    mods = []
    if st & 0x0004:
        mods.append('ctrl')
    if st & 0x20000 or st & 0x0008:
        mods.append('alt')
    if st & 0x0001:
        mods.append('shift')
    if not mods:
        if main in FORBIDDEN:
            return ('err', '%s 는 매크로가 게임에 직접 누르는 키라서 쓸 수 없어요' % key_label(main))
        if main not in PLAIN_OK:
            return ('err', '%s 하나만은 안 돼요 - F1~F12 이거나 Ctrl·Alt·Shift 와 같이 눌러 주세요' % key_label(main))
    return '+'.join(mods + [main])


def hotkey_dialog(actions, bindings, defaults, on_save, console=False, on_console=None):
    """actions: [(id, 이름)], bindings: {id: 'f6'...}, on_save(new_bindings) -> (성공, 메시지)"""
    w = tk.Toplevel(_root)
    w.title('단축키 설정')
    w.configure(bg='#f3f3f5')
    w.transient(_root)
    w.grab_set()
    cur = dict(bindings)
    rec = {'id': None}
    F = (FONT, 9)
    tk.Label(w, text='단축키 바꾸기', font=(FONT, 11, 'bold'), bg='#f3f3f5').pack(anchor='w', padx=14, pady=(12, 2))
    tk.Label(w, text='바꿀 칸을 누르고 원하는 키를 누르세요 (F1~F12, 또는 Ctrl·Alt·Shift + 키)\n'
                     'S · ESC · Space · Enter 는 매크로가 게임에 직접 누르는 키라서 혼자는 쓸 수 없어요.  ✕ = 단축키 없음',
             font=(FONT, 8), fg='#666', bg='#f3f3f5', justify='left').pack(anchor='w', padx=14)
    tb = tk.Frame(w, bg='#ffffff', highlightthickness=1, highlightbackground='#d8d8de')
    tb.pack(fill='x', padx=14, pady=8)
    keyw = {}
    msg = tk.Label(w, text='', font=(FONT, 8), fg='#d33', bg='#f3f3f5', justify='left', wraplength=px(420))

    def show(aid):
        b = keyw[aid]
        if rec['id'] == aid:
            b.config(text='키를 누르세요…', fg='#2b7de9', bg='#eaf2ff')
        else:
            k = cur.get(aid) or ''
            b.config(text=key_label(k), fg='#222' if k else '#aaa', bg='#fafafa')

    def start(aid):
        prev = rec['id']
        rec['id'] = aid
        if prev and prev != aid:
            show(prev)
        show(aid)
        msg.config(text='')
        w.focus_force()

    def clear(aid):
        cur[aid] = ''
        if rec['id'] == aid:
            rec['id'] = None
        show(aid)

    for n, (aid, name) in enumerate(actions):
        tk.Label(tb, text=clean(name), font=F, bg='#ffffff', anchor='w', width=18).grid(row=n, column=0, sticky='w', padx=(10, 4), pady=3)
        b = tk.Label(tb, text='', font=('Consolas', 9), bg='#fafafa', relief='solid', bd=1, width=16, anchor='w',
                     padx=6, cursor='hand2')
        b.grid(row=n, column=1, sticky='w', pady=3)
        b.bind('<Button-1>', lambda e, a=aid: start(a))
        keyw[aid] = b
        x = tk.Label(tb, text='✕', font=F, fg='#2b7de9', bg='#ffffff', cursor='hand2')
        x.grid(row=n, column=2, padx=10)
        x.bind('<Button-1>', lambda e, a=aid: clear(a))
        show(aid)
    msg.pack(anchor='w', padx=14)
    v_con = tk.BooleanVar(value=bool(console))
    if on_console is not None:
        tk.Checkbutton(w, text='문제가 있을 때만: 다음에 켤 때부터 예전 글자 창으로 쓰기 (버튼 창 끄기)', variable=v_con,
                       font=(FONT, 8), bg='#f3f3f5', activebackground='#f3f3f5', fg='#555').pack(anchor='w', padx=10, pady=(4, 0))

    def on_key(e):
        aid = rec['id']
        if aid is None:
            return 'break'
        k = event_to_key(e)
        if k is None:
            return 'break'
        if isinstance(k, tuple):
            msg.config(text=k[1])
            return 'break'
        other = next((a for a, kk in cur.items() if kk == k and a != aid), None)
        if other:
            msg.config(text='%s 는 \'%s\'에서 쓰는 중이에요 - 그쪽 ✕ 로 먼저 지워 주세요' % (key_label(k), dict(actions)[other]))
            return 'break'
        cur[aid] = k
        rec['id'] = None
        show(aid)
        msg.config(text='')
        return 'break'

    w.bind('<KeyPress>', on_key)
    bb = tk.Frame(w, bg='#f3f3f5')
    bb.pack(fill='x', padx=14, pady=(4, 12))

    def do_default():
        cur.clear()
        cur.update(defaults)
        rec['id'] = None
        for a, _n in actions:
            show(a)
        msg.config(text='기본값으로 바꿨어요 - [저장]을 눌러야 적용돼요', fg='#2b7de9')

    def do_save():
        ok, m = on_save(dict(cur))
        if ok and on_console is not None:
            on_console(bool(v_con.get()))
        if ok:
            w.destroy()
        else:
            msg.config(text=m, fg='#d33')

    tk.Button(bb, text='저장', font=F, width=8, bg='#2b7de9', fg='white', command=do_save).pack(side='right')
    tk.Button(bb, text='취소', font=F, width=8, command=w.destroy).pack(side='right', padx=6)
    tk.Button(bb, text='기본값으로', font=F, width=10, command=do_default).pack(side='right')
    w.update_idletasks()
    try:
        w.geometry('+%d+%d' % (_root.winfo_rootx() + 10, _root.winfo_rooty() + 60))
    except Exception:
        pass
    w.focus_force()
    return w


# ── 시작 ───────────────────────────────────────
def run(api, geometry='470x980', on_ready=None):
    """창을 만들고 이 스레드(메인)에서 계속 돌림. 창을 만들지 못하면 예외"""
    global _root, _api, UI_THREAD
    _api = api
    UI_THREAD = threading.current_thread()
    global SCALE
    root = tk.Tk()
    _root = root
    try:
        SCALE = max(1.0, min(2.5, root.winfo_fpixels('1i') / 96.0))   # Windows 배율 (100% = 1.0)
    except Exception:
        SCALE = 1.0
    m = re.fullmatch(r'(\d+)x(\d+)(.*)', geometry)
    if m:
        w, h = px(int(m.group(1))), px(int(m.group(2)))
        h = min(h, root.winfo_screenheight() - px(60))           # 작업표시줄 빼고 화면 안에
        geometry = '%dx%d%s' % (w, h, m.group(3))
    root.geometry(geometry)
    try:
        ico = api.get('icon')
        if ico:
            img = tk.PhotoImage(file=ico)
            root.iconphoto(True, img)
            root._icon = img
    except Exception:
        pass
    MacroWindow(root, api)
    root.after(50, _pump)
    root.update_idletasks()
    _read_hwnd()
    if on_ready:
        root.after(300, on_ready)
    try:
        root.mainloop()
    finally:
        _root = None
