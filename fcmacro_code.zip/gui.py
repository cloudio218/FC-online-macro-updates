# -*- coding: utf-8 -*-
"""
v3.0 매크로 창 (tkinter). 매크로 본체(fifa_macro)는 그대로 돌고, 이 창은 0.5초마다 상태를 읽어서 보여 주기만 함.
 - 버튼 = 단축키와 같은 기능 (버튼 아래 작은 글씨 = 지금 설정된 단축키)
 - 다른 스레드에서 창 작업이 필요하면 call_in_ui(fn) 으로 이 창의 스레드에서 실행 (tkinter 는 만든 스레드에서만 써야 함)
 - 문자는 기본 다국어 평면(BMP)만 씀: Tk 는 그림문자(📌 등)를 제대로 못 그려서 ◎ ⚙ ▶ ❚❚ ■ ⚑ 같은 기호 사용
"""
import queue
import re
import threading
import time
import tkinter as tk
from tkinter import ttk

BG = '#16161d'; CARD = '#20202a'; CARD2 = '#262633'; LINE = '#33334a'; FG = '#e8e8f0'; DIM = '#8d8da3'
GREEN = '#3ecf8e'; RED = '#ff5d6c'; YEL = '#ffc857'; CYAN = '#4fd1e0'; GRAY = '#4a4a5c'
ORANGE = '#ff8a3d'; BLUE = '#3d8bff'
KIND_FG = {'run': GREEN, 'ok': GREEN, 'done': GREEN, 'warn': YEL, 'stop': RED, 'info': CYAN, 'idle': DIM}
FONT = 'Malgun Gothic'
_NON_BMP = re.compile('[\U00010000-\U0010FFFF️]')

_root = None
SCALE = 1.0                  # 화면 배율 (Windows 125% 등이면 1.25) - 픽셀 값에 곱함
_q = queue.Queue()
_api = None
UI_THREAD = None


def px(n):
    return int(round(n * SCALE))


def clean(s):
    """Tk 가 못 그리는 그림문자 제거"""
    return _NON_BMP.sub('', '' if s is None else str(s)).strip()


def active():
    return _root is not None


def call_in_ui(fn, wait=True, timeout=None):
    """fn 을 창 스레드에서 실행 (wait=True 면 끝날 때까지 기다렸다 결과 반환). 창이 없으면 그냥 실행"""
    if _root is None or threading.current_thread() is UI_THREAD:
        return fn()
    if not wait:
        _q.put((fn, None, None))
        return None
    ev = threading.Event()
    box = {}
    _q.put((fn, ev, box))
    ev.wait(timeout)
    if 'err' in box:
        raise box['err']
    return box.get('val')


def _pump():
    if _root is not None:
        _root.after(50, _pump)          # 먼저 다음 차례 예약 (작업 안에서 창이 열려 기다리는 동안에도 다른 작업 처리)
    try:
        while True:
            fn, ev, box = _q.get_nowait()
            try:
                v = fn()
                if box is not None:
                    box['val'] = v
            except Exception as e:      # noqa: BLE001
                if box is not None:
                    box['err'] = e
                elif _api:
                    _api['log_error']('창 작업')
            finally:
                if ev is not None:
                    ev.set()
    except queue.Empty:
        pass


_HWND = [None]


def hwnd():
    """창의 Windows 핸들 (항상 위 / 위치 저장에 사용). 다른 스레드에서도 부르므로 창이 뜰 때 한 번 읽어 둔 값"""
    return _HWND[0] if _root is not None else None


def _read_hwnd():
    try:
        _HWND[0] = int(_root.wm_frame(), 16)
    except Exception:
        _HWND[0] = None


# ── 작은 부품 ─────────────────────────────────────
class Btn(tk.Frame):
    """버튼 (글자 + 아래 작은 단축키 글씨). 누르면 action(id)"""

    def __init__(self, master, aid, on_click):
        super().__init__(master, bg=CARD2, highlightthickness=1, highlightbackground=LINE, cursor='hand2')
        self.aid, self.on_click = aid, on_click
        # v3.3.1: 한 줄로 (글자 + 옆에 작은 단축키) - 최근 기록 표 자리를 넓히려고 높이를 줄임
        self.inner = tk.Frame(self, bg=CARD2)
        self.inner.pack(pady=4)
        self.t = tk.Label(self.inner, text='', font=(FONT, 9, 'bold'), fg=FG, bg=CARD2)
        self.t.pack(side='left')
        self.k = tk.Label(self.inner, text='', font=(FONT, 7), fg=DIM, bg=CARD2)
        self.k.pack(side='left', padx=(4, 0))
        self._bg = CARD2
        self._state = None
        self.big = False
        for w in (self, self.inner, self.t, self.k):
            w.bind('<Button-1>', self._click)
            w.bind('<Enter>', lambda e: self._hover(True))
            w.bind('<Leave>', lambda e: self._hover(False))

    def _click(self, _e):
        self.on_click(self.aid)

    def _hover(self, on):
        c = '#34344a' if on else self._bg
        for w in (self, self.inner, self.t, self.k):
            w.config(bg=c)

    def set_big(self, on):
        """v3.4: 아래 손잡이를 올리면 큰 버튼 (글자 크게 + 아래 줄에 단축키)"""
        if on == self.big:
            return
        self.big = on
        self.t.pack_forget(); self.k.pack_forget()
        if on:
            self.inner.pack_configure(pady=px(4))
            self.t.config(font=(FONT, 10, 'bold'))
            self.k.config(font=(FONT, 7))
            self.t.pack(side='top')
            self.k.pack(side='top')
        else:
            self.inner.pack_configure(pady=4)
            self.t.config(font=(FONT, 9, 'bold'))
            self.k.config(font=(FONT, 7))
            self.t.pack(side='left')
            self.k.pack(side='left', padx=(4, 0))
        st, self._state = self._state, None
        if st:
            self.set(*st)

    def set(self, text, key, bg=CARD2, fg=FG, border=LINE, big=None):
        st = (text, key, bg, fg, border, big)
        if st == self._state:
            return
        self._state = st
        self._bg = bg
        if self.big and big:                    # 큰 버튼일 때 쓰는 긴 글자 / 아래 줄
            text, key = big
        self.config(bg=bg, highlightbackground=border)
        self.inner.config(bg=bg)
        self.t.config(text=text, fg=fg, bg=bg)
        self.k.config(text=key or '', bg=bg)


class Grip(tk.Canvas):
    """v3.4 칸 사이 손잡이: 평소엔 어두운 점 3개, 마우스 올리면 청록 + 얇은 선. 끌면 on_drag(dy), 더블클릭 on_reset()"""

    def __init__(self, master, on_press, on_drag, on_reset):
        super().__init__(master, bg=BG, height=px(8), highlightthickness=0, bd=0, cursor='sb_v_double_arrow')
        self._hot = False
        self._y0 = None
        self._dbl = False
        self.on_press, self.on_drag, self.on_reset = on_press, on_drag, on_reset
        self.bind('<Configure>', lambda e: self._draw())
        self.bind('<Enter>', lambda e: self._hover(True))
        self.bind('<Leave>', lambda e: self._hover(self._y0 is not None))
        self.bind('<ButtonPress-1>', lambda e: self._press(e, False))
        self.bind('<Double-Button-1>', lambda e: self._press(e, True))
        self.bind('<B1-Motion>', self._motion)
        self.bind('<ButtonRelease-1>', self._release)

    def _press(self, e, dbl):
        self._y0 = e.y_root
        self._dbl = dbl
        self.on_press()

    def _motion(self, e):
        if self._y0 is None:
            return
        dy = e.y_root - self._y0
        if abs(dy) > 3:
            self._dbl = False
        self.on_drag(dy)

    def _release(self, e):
        if self._dbl and self._y0 is not None:
            self.on_reset()
        self._y0 = None
        self._dbl = False
        x, y = self.winfo_pointerxy()
        inside = (self.winfo_rootx() <= x < self.winfo_rootx() + self.winfo_width() and
                  self.winfo_rooty() <= y < self.winfo_rooty() + self.winfo_height())
        self._hover(inside)

    def _hover(self, on):
        if on != self._hot:
            self._hot = on
            self._draw()

    def _draw(self):
        try:
            self.delete('all')
            w, h = self.winfo_width(), self.winfo_height()
            if w <= 1:
                return
            cx, cy = w // 2, h // 2
            col = CYAN if self._hot else GRAY
            if self._hot:
                self.create_line(px(14), cy, w - px(14), cy, fill='#28464f')
            r = max(1.5, px(1.6))
            for k in (-px(8), 0, px(8)):
                self.create_oval(cx + k - r, cy - r, cx + k + r, cy + r, fill=col, outline=col)
        except tk.TclError:
            pass


def _card(parent, **pack):
    f = tk.Frame(parent, bg=CARD, padx=12, pady=7)
    f.pack(fill='x', padx=10, pady=(0, 6), **pack)
    return f


def _lbl(parent, text='', size=9, fg=FG, bold=False, bg=CARD, **kw):
    return tk.Label(parent, text=text, font=(FONT, size, 'bold') if bold else (FONT, size), fg=fg, bg=bg, **kw)


class _Setter:
    """같은 값이면 위젯을 다시 그리지 않음 (깜빡임 방지)"""

    def __init__(self):
        self.last = {}

    def __call__(self, key, widget, **cfg):
        if self.last.get(key) == cfg:
            return
        self.last[key] = cfg
        widget.config(**cfg)


# ── 메인 창 ─────────────────────────────────────
class MacroWindow:
    COLS = (('no', '회차', 40, 'center'), ('score', '점수', 54, 'e'), ('rank', '순위', 66, 'e'),
            ('time', '시작', 46, 'center'), ('res', '결과', 56, 'center'), ('opp', '상대', 70, 'center'),
            ('tac', '전술', 80, 'w'))
    COLS_NO_TAC = ('no', 'score', 'rank', 'time', 'res', 'opp')

    def __init__(self, root, api):
        self.root, self.api = root, api
        self.set = _Setter()
        self.panel_open = False
        self._rows_key = None
        self._flow_key = None
        self._check_seen = 0.0
        self._panel_key = None
        root.configure(bg=BG)
        root.minsize(px(420), px(600))

        # 아래쪽(버튼·바닥글)을 먼저 붙여서 창이 작아도 버튼은 항상 보이게
        foot = tk.Frame(root, bg=BG, padx=14)
        foot.pack(side='bottom', fill='x', pady=(0, 7))
        self.w_foot = _lbl(foot, '', 8, DIM, bg=BG, cursor='hand2', anchor='w')
        self.w_foot.pack(side='left', fill='x')
        self.w_foot.bind('<Button-1>', lambda e: api['action']('folder'))

        bt = tk.Frame(root, bg=BG, padx=7)
        bt.pack(side='bottom', fill='x', pady=(0, 4))
        self.bt = bt
        self.btns = {}
        self.BTN_ORDER = ['topmost', 'check', 'settings', 'start', 'pause', 'chart', 'stop', 'lastgame', 'tactics',
                          'hotkeys', 'today', 'formation']  # v3.2: 창 배치 저장 -> 맨 위 작은 글씨, 그 자리에 전술 자동 변경
        for aid in self.BTN_ORDER:
            self.btns[aid] = Btn(bt, aid, self._press)
        self._big_btn = None
        self._gcap = None
        # v3.4: 칸 크기 손잡이 (위: 시간대 1줄/2줄, 아래: 버튼 작게/크게) - 위치는 기억
        ui = {}
        try:
            ui = dict(api['ui_get']()) if api.get('ui_get') else {}
        except Exception:
            ui = {}
        self._time_rows = 2 if ui.get('time_rows') == 2 else 1
        self._pref = {'rows': self._time_rows, 'big': bool(ui.get('big_btn'))}   # 사용자가 고른 모양 (저장)
        self._fit_job = None
        self._set_big(self._pref['big'])

        # 알림 · 점검 (접기/펼치기)
        self.panel = tk.Frame(root, bg=CARD, padx=12, pady=8)
        self.panel.pack(side='bottom', fill='x', padx=10, pady=(0, 7))
        ph = tk.Frame(self.panel, bg=CARD, cursor='hand2')
        ph.pack(fill='x')
        self.w_ptitle = _lbl(ph, '▸ 알림 · 점검', 10, FG, True, cursor='hand2')
        self.w_ptitle.pack(side='left')
        self.w_psum = _lbl(ph, '', 9, GREEN, cursor='hand2')
        self.w_psum.pack(side='right')
        for w in (ph, self.w_ptitle, self.w_psum):
            w.bind('<Button-1>', lambda e: self.toggle_panel())
        self.pbody = tk.Frame(self.panel, bg=CARD)
        self.ptext = tk.Text(self.pbody, bg=CARD, fg=FG, font=(FONT, 9), relief='flat', height=6, wrap='word',
                             highlightthickness=0, padx=0, pady=2, cursor='arrow', spacing1=1, spacing3=1)
        self.psb = ttk.Scrollbar(self.pbody, orient='vertical', command=self.ptext.yview, style='M.Vertical.TScrollbar')
        self.ptext.configure(yscrollcommand=self.psb.set)
        self.ptext.pack(side='left', fill='both', expand=True)
        for tag, color in (('ok', GREEN), ('bad', RED), ('dim', DIM), ('txt', FG)):
            self.ptext.tag_configure(tag, foreground=color)
        self.ptext.tag_configure('mark', font=(FONT, 9, 'bold'))
        self.grip_bot = Grip(root, lambda: self._grip_press('bot'), lambda dy: self._grip_drag('bot', dy),
                             lambda: self._grip_reset('bot'))
        self.grip_bot.pack(side='bottom', fill='x', padx=10, pady=(0, 1))

        # 맨 위: 제목
        top = tk.Frame(root, bg=BG, padx=12, pady=8)
        top.pack(fill='x')
        _lbl(top, 'FC온라인 감독모드 매크로', 12, FG, True, bg=BG).pack(side='left')
        self.w_ver = _lbl(top, '', 8, DIM, bg=BG)
        self.w_ver.pack(side='left', padx=6, pady=(4, 0))
        self.w_pin = _lbl(top, '', 9, CYAN, bg=BG, cursor='hand2')
        self.w_pin.pack(side='right')
        self.w_pin.bind('<Button-1>', lambda e: api['action']('topmost'))
        self.w_lay = _lbl(top, '▣ 배치 저장', 9, DIM, bg=BG, cursor='hand2')
        self.w_lay.pack(side='right', padx=(0, 12))
        self.w_lay.bind('<Button-1>', lambda e: api['action']('layout'))
        self.w_lay.bind('<Enter>', lambda e: self.w_lay.config(fg=FG))
        self.w_lay.bind('<Leave>', lambda e: self.w_lay.config(fg=DIM))

        # 상태
        st = _card(root)
        r = tk.Frame(st, bg=CARD)
        r.pack(fill='x')
        self.w_state = _lbl(r, '', 11, GREEN, True)
        self.w_state.pack(side='left')
        self.w_mode = _lbl(r, '', 9, DIM)
        self.w_mode.pack(side='right')
        self.w_banner = tk.Label(st, text='', font=(FONT, 9), fg=YEL, bg='#3a3020', anchor='w', justify='left',
                                 wraplength=px(410), padx=8, pady=5)
        self.w_status = _lbl(st, '', 9, DIM, anchor='w', justify='left', wraplength=px(420))
        self.w_status.pack(fill='x', pady=(4, 0))
        # v3.3: 쉬는 중 주황 띠 + [지금 계속]
        self.w_rban = tk.Frame(st, bg='#3a2e1f', padx=8, pady=6)
        self.w_rbtxt = tk.Label(self.w_rban, text='', font=(FONT, 9), fg=ORANGE, bg='#3a2e1f', justify='left', anchor='w')
        self.w_rbtxt.pack(side='left', fill='x', expand=True)
        rb = tk.Label(self.w_rban, text='지금 계속', font=(FONT, 9, 'bold'), fg='#111', bg=ORANGE, padx=8, pady=3, cursor='hand2')
        rb.pack(side='right')
        rb.bind('<Button-1>', lambda e: api['action']('rest_continue'))
        self.w_error = _lbl(st, '', 9, YEL, anchor='w', justify='left', wraplength=px(420))

        # 큰 숫자
        nc = _card(root)
        self.nc = nc
        # v3.2: 오른쪽에 지금 티어 엠블럼 (게임 로비에서 잘라 배경을 지운 그림) + 티어 이름
        ef = tk.Frame(nc, bg=CARD)
        ef.pack(side='right', padx=(6, 0))
        self.w_emb = tk.Label(ef, bg=CARD, bd=0)
        self.w_emb.pack()
        self.w_tier = _lbl(ef, '', 9, CYAN, True)
        self.w_tier.pack(pady=(2, 0))
        self._emb_key = None
        self._emb_img = None
        g = tk.Frame(nc, bg=CARD)
        g.pack(fill='x')
        self.big = {}
        for i, (key, title) in enumerate((('score', '랭킹점수'), ('rank', '순위'), ('fc', 'FC'))):
            c = tk.Frame(g, bg=CARD)
            c.grid(row=0, column=i, sticky='w', padx=(0, 24))
            _lbl(c, title, 9, DIM).pack(anchor='w')
            v = _lbl(c, '-', 20 if i == 0 else 15, FG if key != 'fc' else YEL, True)
            v.pack(anchor='w')
            s = _lbl(c, '', 9, DIM)
            s.pack(anchor='w')
            self.big[key] = (v, s)
        self.w_cond = _lbl(nc, '', 9, DIM, anchor='w', justify='left', wraplength=px(320))   # v3.3.1: 안 보임 (상태 칸에 있음)
        self.w_eta = _lbl(nc, '', 9, '#c58cff', anchor='w', justify='left', wraplength=px(320))

        # v3.2: 승강전 (챔스 아래 티어 10판) - 챔스면 숨김
        pc = tk.Frame(root, bg=CARD, padx=12, pady=5)
        self.pc = pc
        ph2 = tk.Frame(pc, bg=CARD)
        ph2.pack(fill='x')
        _lbl(ph2, '승강전', 10, FG, True).pack(side='left')
        self.w_pinfo = _lbl(ph2, '', 9, DIM)
        self.w_pinfo.pack(side='left', padx=(6, 0))
        self.w_phead = _lbl(ph2, '', 9, GREEN, True)
        self.w_phead.pack(side='right')
        self.w_pbar = tk.Canvas(pc, bg=CARD, height=px(30), highlightthickness=0, bd=0)
        self.w_pbar.pack(fill='x', pady=(3, 0))
        self.w_pbar.bind('<Configure>', lambda e: self._draw_promo())
        self.w_phint = _lbl(pc, '', 8, YEL, anchor='w')          # 갈림길일 때만 보임
        self._promo = None

        # 통계 + 흐름
        sc = _card(root)
        self.w_now = self._stat_row(sc, '이번')
        self.w_today = self._stat_row(sc, '오늘')
        self.w_tac = self._stat_row(sc, '전술')
        self.w_tac.config(fg=CYAN)
        self.w_tacrow = self.w_tac.master

        # v3.3: 시간대별 승률 (2시간 x 12칸) - 칸을 누르면 쉼/계속, 머리줄 누르면 접기·펴기
        rc = _card(root)
        rc.pack_configure(pady=0)
        self.rc = rc
        rh = tk.Frame(rc, bg=CARD, cursor='hand2')
        rh.pack(fill='x')
        self.w_rarrow = _lbl(rh, '▾ 시간대별 승률', 10, FG, True, cursor='hand2')
        self.w_rarrow.pack(side='left')
        self.w_rinfo = _lbl(rh, '', 8, DIM, cursor='hand2')
        self.w_rinfo.pack(side='left', padx=(6, 0))
        gear = _lbl(rh, '⚙', 11, DIM, cursor='hand2')
        gear.pack(side='right')
        gear.bind('<Button-1>', lambda e: api['action']('rest_settings'))
        for w in (rh, self.w_rarrow, self.w_rinfo):
            w.bind('<Button-1>', lambda e: self._toggle_rest())
        self.w_rgrid = tk.Frame(rc, bg=CARD)
        self.w_rgrid.pack(fill='x', pady=(5, 0))
        self.w_rnext = _lbl(rc, '', 8, ORANGE, anchor='w')
        self.w_rnext.pack(fill='x', pady=(3, 0))
        self._rcells = []
        for i in range(12):                                    # v3.3.1: 한 줄 12칸 / v3.4: 2줄 6칸도
            c = tk.Frame(self.w_rgrid, bg=CARD2, highlightthickness=1, highlightbackground=LINE, cursor='hand2')
            a = _lbl(c, '', 7, DIM, bg=CARD2, cursor='hand2')          # '16✖'
            a.pack(pady=(1, 0))
            b = _lbl(c, '', 8, FG, True, bg=CARD2, cursor='hand2')     # '28'
            b.pack(pady=(0, 1))
            m = None
            for w in (c, a, b):
                w.bind('<Button-1>', lambda e, i=i: api['action']('rest_cell:%d' % i))
            self._rcells.append((c, a, b, m))
        self._layout_rgrid()
        self._rest_open = True
        self._rest_key = None
        if api.get('rest_open') is not None and not api['rest_open']():
            self._toggle_rest()

        self.grip_top = Grip(root, lambda: self._grip_press('top'), lambda dy: self._grip_drag('top', dy),
                             lambda: self._grip_reset('top'))
        self.grip_top.pack(fill='x', padx=10, pady=(0, 1))

        # 최근 기록 (남는 공간 전부 · 스크롤)
        tc = tk.Frame(root, bg=CARD, padx=12, pady=9)
        tc.pack(fill='both', expand=True, padx=10, pady=(0, 0))
        self.tc = tc
        self._plines = 0                     # 지금 펼친 점검 글 줄 수
        root.bind('<Configure>', lambda e: ((self._fit_panel(), self._fit_later()) if e.widget is root else None))
        h = tk.Frame(tc, bg=CARD)
        h.pack(fill='x', pady=(0, 5))
        _lbl(h, '최근 기록', 10, FG, True).pack(side='left')
        # v3.3.1: 최근 10판 승패를 제목 옆에 (왼쪽 = 오래된 판, 오른쪽 = 방금 끝난 판)
        self.FLOW_N = 10
        self.w_flow = tk.Canvas(h, bg=CARD, width=self.FLOW_N * (px(17) + px(2)), height=px(17), highlightthickness=0, bd=0)
        self.w_flow.pack(side='left', padx=(8, 0))
        self.w_flow.bind('<Configure>', lambda e: self._draw_flow())
        self.w_streak = _lbl(h, '', 8, DIM)
        self.w_streak.pack(side='left', padx=(6, 0))
        self.w_tnote = _lbl(h, '', 8, DIM)          # (안 씀 - 예전 안내 글, 자리만)
        stl = ttk.Style(root)
        try:
            stl.theme_use('clam')
        except tk.TclError:
            pass
        stl.configure('M.Treeview', background=CARD2, fieldbackground=CARD2, foreground=FG, rowheight=px(23),
                      font=(FONT, 9), borderwidth=0)
        stl.configure('M.Treeview.Heading', background=CARD, foreground=DIM, font=(FONT, 9), relief='flat', borderwidth=0)
        stl.map('M.Treeview', background=[('selected', '#34344a')], foreground=[('selected', FG)])
        stl.layout('M.Treeview', [('M.Treeview.treearea', {'sticky': 'nswe'})])      # 흰 테두리 없애기
        stl.map('M.Treeview.Heading', background=[('active', CARD)])
        stl.configure('M.Vertical.TScrollbar', background=GRAY, troughcolor='#1b1b24', bordercolor='#1b1b24',
                      arrowcolor=DIM, gripcount=0)
        tf = tk.Frame(tc, bg=CARD)
        tf.pack(fill='both', expand=True)
        self.tv = ttk.Treeview(tf, columns=[c[0] for c in self.COLS], show='headings', height=8, style='M.Treeview')
        for c, t, w, a in self.COLS:
            self.tv.heading(c, text=t)
            self.tv.column(c, width=px(w), anchor=a, stretch=(c in ('opp', 'tac')))
        self._tac_cols = None
        sb = ttk.Scrollbar(tf, orient='vertical', command=self.tv.yview, style='M.Vertical.TScrollbar')
        self.tv.configure(yscrollcommand=sb.set)
        sb.pack(side='right', fill='y')
        self.tv.pack(side='left', fill='both', expand=True)
        for tag, color in (('w', GREEN), ('l', RED), ('d', '#b9b9cc'), ('p', CYAN), ('s', DIM), ('o', FG)):
            self.tv.tag_configure(tag, foreground=color)

        root.protocol('WM_DELETE_WINDOW', lambda: api['action']('quit'))
        self.refresh()

    def _draw_flow(self):
        """최근 20판 흐름: 왼쪽=오래된 판, 오른쪽=최신 판. 칸 크기는 폭에 맞춰 줄임 (최신 판이 잘리지 않게)"""
        cv = self.w_flow
        flow = list(self._flow_key or [])[-self.FLOW_N:]
        try:
            cv.delete('all')
            w = cv.winfo_width()
            if w <= 1 or not flow:
                return
            gap = max(1, px(2))
            cell = min(px(17), (w - gap) // self.FLOW_N - gap)  # 10칸이 항상 들어가는 크기
            cell = max(cell, 6)
            h = cell
            cv.configure(height=h)
            fs = max(6, int(cell * 0.45 / max(SCALE, 0.5)))      # 칸이 작아지면 글자도 작게
            x = 0
            for r in flow:
                c = {'승': GREEN, '패': RED}.get(r, GRAY)
                cv.create_rectangle(x, 0, x + cell, h, fill=c, outline=c)
                if cell >= 12:
                    cv.create_text(x + cell / 2, h / 2, text=r, font=(FONT, fs, 'bold'),
                                   fill='#111' if r != '무' else FG)
                x += cell + gap
        except tk.TclError:
            pass

    # ── v3.4 손잡이 ─────────────────────────────
    STEP = 26                                # 이만큼 끌 때마다 한 단계씩 (한 번에 바뀜)

    def _layout_rgrid(self):
        """시간대 칸: 1줄(12칸, 작은 글씨) / 2줄(6칸 x 2, '16시' + '28%' 크게)"""
        two = self._time_rows == 2
        cols = 6 if two else 12
        for i in range(12):
            self.w_rgrid.grid_columnconfigure(i, weight=1 if i < cols else 0, uniform='rc' if i < cols else '')
        for i, (c, a, b, m) in enumerate(self._rcells):
            c.grid(row=i // cols, column=i % cols, sticky='nsew', padx=px(3) if two else 1, pady=px(2) if two else 1)
            a.config(font=(FONT, 8 if two else 7))
            b.config(font=(FONT, 11 if two else 8, 'bold'))
            a.pack_configure(pady=(px(3), 0) if two else (1, 0))
            b.pack_configure(pady=(0, px(3)) if two else (0, 1))
        self._rest_key = None
        if getattr(self, '_last_rest', None):          # 끄는 즉시 글자도 바꿈 (0.5초 기다리지 않게)
            self._apply_rest(self._last_rest)

    def _set_big(self, on):
        if on == self._big_btn:
            return
        self._big_btn = on
        cols = 3 if on else 4                  # 큰 버튼 4줄 x 3칸 / 작은 버튼 3줄 x 4칸
        for i in range(4):
            self.bt.grid_columnconfigure(i, weight=1 if i < cols else 0, uniform='b' if i < cols else '')
        for n, aid in enumerate(self.BTN_ORDER):
            b = self.btns[aid]
            b.set_big(on)
            b.grid(row=n // cols, column=n % cols, sticky='nsew', padx=2, pady=2)

    def _save_ui(self):
        try:
            if self.api.get('ui_set'):
                self.api['ui_set']({'time_rows': self._pref['rows'], 'big_btn': bool(self._pref['big'])})
        except Exception:
            pass

    def _top_level(self):
        return 0 if not self._rest_open else self._time_rows       # 0 접힘 / 1 한 줄 / 2 두 줄

    def _set_top_level(self, lv):
        if lv == 0:
            if self._rest_open:
                self._toggle_rest()
            return
        if self._time_rows != lv:
            self._time_rows = lv
            self._layout_rgrid()
        if not self._rest_open:
            self._toggle_rest()

    def _table_ok(self):
        """최근 기록 표가 최소 3줄은 보이는지"""
        self.root.update_idletasks()
        if not self.root.winfo_ismapped():                       # 창이 아직 안 떴으면 판단 안 함
            return True
        if not self.tv.winfo_ismapped():                         # 자리가 없어 표가 아예 안 보임
            return False
        return self.tv.winfo_height() >= px(23) * 4 - 2              # 머리줄 + 3줄

    def _fit_layout(self, only=None):
        """고른 모양(pref)대로 보여 주되, 최근 기록 표가 3줄보다 작아지면 한 단계씩 줄여서 보여 줌
        (줄이는 순서: 큰 버튼 -> 시간대 2줄. 저장한 모양은 그대로라 창을 키우면 다시 돌아옴)
        only='top'/'bot': 끄는 중인 쪽만 줄임 (다른 쪽은 건드리지 않음)"""
        self._fit_job = None
        rows = self._pref['rows']
        big = self._pref['big']
        self._set_big(big)
        if self._rest_open:
            self._set_top_level(rows)
        order = [only] if only else ['bot', 'top']
        for wh in order:
            while not self._table_ok():
                if wh == 'bot' and self._big_btn:
                    self._set_big(False)
                elif wh == 'top' and self._rest_open and self._time_rows == 2:
                    self._set_top_level(1)
                else:
                    break
        if self.panel_open:
            self._fit_panel()

    def _fit_later(self):
        if self._fit_job is None:
            self._fit_job = self.root.after(200, self._fit_layout)

    def _grip_press(self, which):
        self._g0 = self._top_level() if which == 'top' else int(bool(self._big_btn))
        self._gcap = None

    def _grip_drag(self, which, dy):
        step = px(self.STEP)
        if which == 'top':                      # 아래로 끌면 시간대 칸이 커짐 (접힘 -> 1줄 -> 2줄)
            want = max(0, min(2, self._g0 + int(dy / step)))
            if self._gcap is not None:
                want = min(want, self._gcap)
            if want == self._top_level():
                return
            if want == 0:
                self._set_top_level(0)
            else:
                self._pref['rows'] = want
                if not self._rest_open:
                    self._toggle_rest()
                self._fit_layout(only='top')
                if self._top_level() < want:            # 표가 3줄 아래로 줄어서 막힘
                    self._gcap = self._top_level()
                    self._pref['rows'] = max(1, self._top_level())
        else:                                   # 위로 끌면 버튼이 커짐
            want = max(0, min(1, self._g0 + int(-dy / step)))
            if self._gcap is not None:
                want = min(want, self._gcap)
            if want == int(bool(self._big_btn)):
                return
            self._pref['big'] = bool(want)
            self._fit_layout(only='bot')
            if want and not self._big_btn:
                self._gcap = 0
                self._pref['big'] = False
        self._save_ui()

    def _grip_reset(self, which):
        if which == 'top':
            self._pref['rows'] = 1
            if not self._rest_open:
                self._toggle_rest()
        else:
            self._pref['big'] = False
        self._fit_layout()
        self._save_ui()

    def _toggle_rest(self):
        self._rest_open = not self._rest_open
        if self._rest_open:
            self.w_rgrid.pack(fill='x', pady=(5, 0), before=self.w_rnext)
        else:
            self.w_rgrid.pack_forget()
        self._rest_key = None
        if getattr(self, '_fit_job', 0) is None:
            self._fit_later()
        if self.api.get('rest_open_set'):
            self.api['rest_open_set'](self._rest_open)

    def _apply_rest(self, r):
        if not r:
            return
        self._last_rest = r
        key = repr((r['cells'], r['avg'], r['enabled'], r['line'], self._rest_open, self._time_rows))
        if key == self._rest_key:
            return
        self._rest_key = key
        self.w_rarrow.config(text=('▾ ' if self._rest_open else '▸ ') + '시간대별 승률')
        avg = ('평균 %d%%' % round(r['avg'])) if r['avg'] is not None else '기록 없음'
        self.w_rinfo.config(text='최근 %d일 · %s%s' % (r['days'], avg, '' if r['enabled'] else ' · 쉬는 시간 꺼짐'))
        self.w_rnext.config(text=r['line'] if r['enabled'] else '', fg=ORANGE)
        for (c, a, b, m), cell in zip(self._rcells, r['cells']):
            k = cell['kind']
            off = k.startswith('off_')
            k2 = k[4:] if off else k
            bg = CARD2 if off else {'rest': '#3a2228', 'auto': '#3a2e1f'}.get(k2, CARD2)
            hl = CYAN if cell['now'] else (LINE if off else {'rest': RED, 'auto': ORANGE}.get(k2, LINE))
            c.config(bg=bg, highlightbackground=hl, highlightthickness=2 if cell['now'] else 1)
            rate = cell['rate']
            avgv = r['avg'] or 0
            col = DIM if rate is None else (RED if rate < avgv - 5 else (GREEN if rate > avgv + 5 else FG))
            mk = {'rest': ('✖', RED), 'auto': ('◐', ORANGE), 'never': ('−', FG)}.get(k2)
            two = self._time_rows == 2
            a.config(text=cell['label'] + ('시 ' if two else '') + (mk[0] if mk else ''), bg=bg, fg=(DIM if off or not mk else mk[1]))
            b.config(text=('%d%s' % (round(rate), '%' if two else '')) if rate is not None else '-', fg=col, bg=bg)

    def _draw_promo(self):
        """승강전 막대: 0~30점, 파란 = 지금 승점, 주황 = 잔류선, 초록 = 승급선, 흰 = 남은 판 다 이기면"""
        p = self._promo
        cv = self.w_pbar
        try:
            cv.delete('all')
            W = cv.winfo_width()
            if W <= 1 or not p:
                return
            top, bh = px(2), px(13)
            X = lambda v: int(min(30, max(0, v)) * (W - 2) / 30)          # noqa: E731
            cv.create_rectangle(0, top, W - 1, top + bh, fill='#2c2c3a', outline='')
            if p['pts']:
                cv.create_rectangle(0, top, X(p['pts']), top + bh, fill=BLUE, outline='')
            cv.create_text(px(6), top + bh / 2, text='%d점' % p['pts'], anchor='w', fill='white', font=(FONT, 9, 'bold'))
            marks = [(p.get('red'), ORANGE, '잔류 %s'), (p.get('green'), GREEN, '승급 %s'), (p.get('max'), '#c8c8d8', '최대 %s')]
            used = []
            for v, col, lab in marks:
                if v is None:
                    continue
                x = X(v)
                cv.create_line(x, top - px(2), x, top + bh + px(2), fill=col, width=2)
                tx = min(max(x, px(18)), W - px(18))
                while any(abs(tx - u) < px(44) for u in used):
                    tx += px(44)
                used.append(tx)
                cv.create_text(tx, top + bh + px(9), text=lab % v, fill=col, font=(FONT, 8))
        except tk.TclError:
            pass

    def _stat_row(self, parent, title):
        r = tk.Frame(parent, bg=CARD)
        r.pack(fill='x', pady=1)
        _lbl(r, title, 9, DIM, True, width=4, anchor='w').pack(side='left')
        w = _lbl(r, '', 9, FG, anchor='w', justify='left', wraplength=px(380))
        w.pack(side='left', fill='x')
        return w

    def _press(self, aid):
        self.api['action'](aid)

    def toggle_panel(self, force=None):
        self.panel_open = (not self.panel_open) if force is None else force
        if self.panel_open:
            self.ptext.config(height=2)          # 작게 펼친 뒤 남는 공간에 맞춰 늘림
            self._plines = 2
            self.pbody.pack(fill='x', pady=(6, 0))
        else:
            self.pbody.pack_forget()
            self._plines = 0
        self._panel_key = None
        self.refresh_panel(self.api['snapshot']())

    # ── 0.5초마다 ─────────────────────────────
    def refresh(self):
        try:
            s = self.api['snapshot']()
            self._apply(s)
        except Exception:
            self.api['log_error']('매크로 창 표시')
        self.root.after(500, self.refresh)

    def _apply(self, s):
        S = self.set
        if self.root.title() != s['title']:
            self.root.title(s['title'])
        S('ver', self.w_ver, text=s['version'].split(' (')[0])          # v3.3.1: 날짜는 빼고 (맨 위 자리 부족)
        S('pin', self.w_pin, text='◎ 항상 위 켜짐' if s['topmost'] else '○ 항상 위 꺼짐', fg=CYAN if s['topmost'] else DIM)
        S('state', self.w_state, text=clean(s['state_text']), fg=KIND_FG.get(s['state'], FG))
        S('mode', self.w_mode, text=s['mode'])
        if s['banner']:
            S('banner', self.w_banner, text=clean(s['banner']))
            if not self.w_banner.winfo_ismapped():
                nxt = next((w for w in (self.w_status, self.w_error) if w.winfo_ismapped()), None)
                self.w_banner.pack(fill='x', pady=(6, 0), before=nxt)
        elif self.w_banner.winfo_ismapped():
            self.w_banner.pack_forget()
        if s['status'][0]:
            S('status', self.w_status, text=clean(s['status'][0]), fg=KIND_FG.get(s['status'][1], DIM))
            if not self.w_status.winfo_ismapped():
                self.w_status.pack(fill='x', pady=(4, 0), before=self.w_error if self.w_error.winfo_ismapped() else None)
        elif self.w_status.winfo_ismapped():
            self.w_status.pack_forget()
        if s['error']:
            S('error', self.w_error, text='! ' + clean(s['error']))
            if not self.w_error.winfo_ismapped():
                self.w_error.pack(fill='x', pady=(3, 0))
        elif self.w_error.winfo_ismapped():
            self.w_error.pack_forget()
        for key in ('score', 'rank', 'fc'):
            v, sub = self.big[key]
            val, subtext, subcolor = s['big'][key]
            S('big_' + key, v, text=val)
            S('bigs_' + key, sub, text=subtext, fg={'up': GREEN, 'down': RED}.get(subcolor, DIM))
        S('cond', self.w_cond, text=clean(s['cond']))
        # 티어 엠블럼
        ek = (s.get('emblem'), s.get('tier'))
        if ek != self._emb_key:
            self._emb_key = ek
            try:
                self._emb_img = tk.PhotoImage(data=s['emblem']) if s.get('emblem') else None
            except tk.TclError:
                self._emb_img = None
            self.w_emb.config(image=self._emb_img or '', width=px(84) if self._emb_img else 0, height=px(84) if self._emb_img else 0)
            t = s.get('tier') or ''
            self.w_tier.config(text=t, fg='#d58cff' if t.startswith('챔피언스') else CYAN)
        # 승강전
        pr = s.get('promo')
        if pr:
            done = sum(1 for r in (pr['strip'] or []))
            w_, d_, l_ = [(pr['strip'] or []).count(k) for k in ('승', '무', '패')]
            S('pinfo', self.w_pinfo, text='%d/10판 · %d승 %d무 %d패' % (done, w_, d_, l_))
            S('phead', self.w_phead, text=pr['head'], fg=RED if '강등' in pr['head'] else (DIM if '불가' in pr['head'] else GREEN))
            S('phint', self.w_phint, text=pr['hint'])
            if pr['hint'] and not self.w_phint.winfo_ismapped():
                self.w_phint.pack(fill='x')
            elif not pr['hint'] and self.w_phint.winfo_ismapped():
                self.w_phint.pack_forget()
            if pr != self._promo:
                self._promo = dict(pr)
                self._draw_promo()
            if not self.pc.winfo_ismapped():
                self.pc.pack(fill='x', padx=10, pady=(0, 7), after=self.nc)
        elif self.pc.winfo_ismapped():
            self.pc.pack_forget()
            self._promo = None
        # 전술 줄
        if s.get('tac_line'):
            S('tac', self.w_tac, text=clean(s['tac_line']))
            if not self.w_tacrow.winfo_ismapped():
                self.w_tacrow.pack(fill='x', pady=1, after=self.w_today.master)
        elif self.w_tacrow.winfo_ismapped():
            self.w_tacrow.pack_forget()
        if s.get('tac_cols') != self._tac_cols:
            self._tac_cols = s.get('tac_cols')
            self.tv['displaycolumns'] = [c[0] for c in self.COLS] if self._tac_cols else list(self.COLS_NO_TAC)
            self.tv.column('opp', width=px(70 if self._tac_cols else 150))
        # v3.3 쉬는 시간
        rs = s.get('rest')
        self._apply_rest(rs)
        if rs and rs.get('banner'):
            self.w_rbtxt.config(text=clean(rs['banner']))
            if not self.w_rban.winfo_ismapped():
                kw = {'after': self.w_status} if self.w_status.winfo_ismapped() else {}
                self.w_rban.pack(fill='x', pady=(6, 0), **kw)
        elif self.w_rban.winfo_ismapped():
            self.w_rban.pack_forget()
        if s['eta']:
            S('eta', self.w_eta, text=clean(s['eta']))
            if not self.w_eta.winfo_ismapped():
                self.w_eta.pack(fill='x', pady=(4, 0))
        elif self.w_eta.winfo_ismapped():
            self.w_eta.pack_forget()
        S('now', self.w_now, text=clean(s['now']))
        S('today', self.w_today, text=clean(s['today']) or '아직 기록 없음')
        if s['flow'] != self._flow_key:
            self._flow_key = list(s['flow'])
            self._draw_flow()
        S('streak', self.w_streak, text=s['streak'])
        # 표
        if s['rows_key'] != self._rows_key:
            first = self._rows_key is None or (s['rows'] and self._rows_key and s['rows_key'][0] != self._rows_key[0])
            self._rows_key = s['rows_key']
            y = self.tv.yview()[0]
            self.tv.delete(*self.tv.get_children())
            for row in s['rows']:
                self.tv.insert('', 'end', values=row['values'], tags=(row['tag'],))
            if first:
                self.tv.yview_moveto(0)              # 새 판이 생기면 맨 위로
            else:
                self.tv.yview_moveto(y)
        S('tnote', self.w_tnote, text=s['rows_note'])
        # 버튼
        for aid, b in self.btns.items():
            b.set(*s['buttons'][aid])
        S('foot', self.w_foot, text='기록 폴더: ' + s['data_dir'])
        # F7 을 누르면 펼침
        if s['check_time'] and s['check_time'] != self._check_seen:
            self._check_seen = s['check_time']
            if s['check_auto_open'] and not self.panel_open:
                self.toggle_panel(True)
                return
        self.refresh_panel(s)

    def refresh_panel(self, s):
        S = self.set
        parts = []
        worst = True
        for name, ok in s['panel_sum']:
            parts.append('%s %s' % (name, {True: '✔', False: '✖', None: '–'}[ok]))
            if ok is False:
                worst = False
        S('ptitle', self.w_ptitle, text=('▾' if self.panel_open else '▸') + ' 알림 · 점검')
        S('psum', self.w_psum, text=' · '.join(parts), fg=GREEN if worst else RED)
        if not self.panel_open:
            return
        key = tuple(s['panel_lines'])
        if key == self._panel_key:
            return
        self._panel_key = key
        # 글 상자 (최대 7줄 높이, 넘치면 스크롤) - 펼쳐도 최근 기록 표가 사라지지 않게
        t = self.ptext
        t.config(state='normal')
        t.delete('1.0', 'end')
        for i, (ok, text) in enumerate(s['panel_lines']):
            mark, tag = {True: ('✔ ', 'ok'), False: ('✖ ', 'bad')}.get(ok, ('·  ', 'dim'))
            t.insert('end', mark, (tag, 'mark'))
            t.insert('end', clean(text) + ('\n' if i < len(s['panel_lines']) - 1 else ''), 'txt' if ok is not None else 'dim')
        t.config(state='disabled')
        self._pn = len(s['panel_lines'])
        self._fit_panel()

    LINE_PX = 19
    TABLE_MIN_PX = 112                       # 펼쳐도 최근 기록 표는 제목 + 2줄은 남김

    def _fit_panel(self):
        """펼친 점검 글 높이를 남는 공간에 맞춤 (창 크기는 그대로, 최근 기록 표가 줄어듦)"""
        if not self.panel_open:
            return
        self.root.update_idletasks()
        n = getattr(self, '_pn', 0)
        try:
            from tkinter import font as tkfont
            lp = tkfont.Font(font=self.ptext['font']).metrics('linespace') + 2
        except Exception:
            lp = self.LINE_PX
        cur = self.ptext.winfo_height() if self.ptext.winfo_ismapped() else 0
        free = self.tc.winfo_height() + cur - 6
        fit = max(2, min(9, n, (free - px(self.TABLE_MIN_PX)) // lp))
        if fit != self._plines:
            self._plines = fit
            self.ptext.config(height=fit)
        if n > fit:
            if not self.psb.winfo_ismapped():
                self.psb.pack(side='right', fill='y', before=self.ptext)
        elif self.psb.winfo_ismapped():
            self.psb.pack_forget()


# ── 팝업 ───────────────────────────────────────
def show_text(title, lines, mono=False):
    """글 보기 창 (오늘 결산 / 포메이션 등) - 창 스레드에서 호출"""
    w = tk.Toplevel(_root)
    w.title(clean(title))
    w.configure(bg=BG)
    w.transient(_root)
    _lbl(w, clean(title), 11, FG, True, bg=BG).pack(anchor='w', padx=14, pady=(12, 6))
    t = tk.Text(w, bg=CARD, fg=FG, font=('Consolas', 10) if mono else (FONT, 10), relief='flat', padx=10, pady=8,
                width=56, height=min(24, max(6, len(lines) + 1)), wrap='word', highlightthickness=0)
    t.insert('end', '\n'.join(clean(x) if x.strip() != '```' else '' for x in lines).strip())
    t.config(state='disabled')
    t.pack(fill='both', expand=True, padx=14)
    tk.Button(w, text='닫기', font=(FONT, 9), command=w.destroy, width=10).pack(pady=10)
    w.update_idletasks()
    try:
        x = _root.winfo_rootx() + 20
        y = _root.winfo_rooty() + 80
        w.geometry('+%d+%d' % (x, y))
    except Exception:
        pass
    return w


def show_table(title, headers, rows, note=''):
    """표 보기 창 (포메이션 등) - 한글이 섞여도 칸이 맞게 표로"""
    w = tk.Toplevel(_root)
    w.title(clean(title))
    w.configure(bg=BG)
    w.transient(_root)
    _lbl(w, clean(title), 11, FG, True, bg=BG).pack(anchor='w', padx=14, pady=(12, 6))
    f = tk.Frame(w, bg=CARD)
    f.pack(fill='both', expand=True, padx=14)
    tv = ttk.Treeview(f, columns=list(range(len(headers))), show='headings', height=min(15, max(4, len(rows))),
                      style='M.Treeview')
    for i, h in enumerate(headers):
        tv.heading(i, text=h)
        tv.column(i, width=110 if i == 0 else 64, anchor='w' if i == 0 else 'center', stretch=False)
    for r in rows:
        tv.insert('', 'end', values=[clean(x) for x in r])
    sb = ttk.Scrollbar(f, orient='vertical', command=tv.yview, style='M.Vertical.TScrollbar')
    tv.configure(yscrollcommand=sb.set)
    sb.pack(side='right', fill='y')
    tv.pack(side='left', fill='both', expand=True)
    if note:
        _lbl(w, clean(note), 9, DIM, bg=BG).pack(anchor='w', padx=14, pady=(6, 0))
    tk.Button(w, text='닫기', font=(FONT, 9), command=w.destroy, width=10).pack(pady=10)
    try:
        w.geometry('+%d+%d' % (_root.winfo_rootx() + 20, _root.winfo_rooty() + 80))
    except Exception:
        pass
    return w


def ask(title, text, kind='yesno'):
    """확인 질문 (창 스레드에서) -> True/False/None"""
    from tkinter import messagebox
    if kind == 'yesnocancel':
        return messagebox.askyesnocancel(title, text, parent=_root)
    if kind == 'info':
        messagebox.showinfo(title, text, parent=_root)
        return True
    return messagebox.askyesno(title, text, parent=_root)


# ── 단축키 설정 창 ───────────────────────────────
_KEYSYM = {'Prior': 'page up', 'Next': 'page down', 'Home': 'home', 'End': 'end', 'Insert': 'insert',
           'Delete': 'delete', 'Up': 'up', 'Down': 'down', 'Left': 'left', 'Right': 'right', 'Pause': 'pause',
           'Scroll_Lock': 'scroll lock', 'Tab': 'tab', 'BackSpace': 'backspace', 'minus': '-', 'equal': '=',
           'comma': ',', 'period': '.', 'slash': '/', 'semicolon': ';', 'apostrophe': "'", 'bracketleft': '[',
           'bracketright': ']', 'backslash': '\\', 'grave': '`'}
_MODS = ('Control_L', 'Control_R', 'Shift_L', 'Shift_R', 'Alt_L', 'Alt_R', 'Meta_L', 'Meta_R', 'Win_L', 'Win_R',
         'Super_L', 'Super_R', 'Caps_Lock', 'Num_Lock', 'Hangul', 'Hangul_Hanja')
FORBIDDEN = {'s', 'esc', 'escape', 'space', 'enter', 'return'}
PLAIN_OK = {'f%d' % i for i in range(1, 13)} | {'pause', 'scroll lock', 'insert'}


def key_label(k):
    """'ctrl+f12' -> 'Ctrl + F12'"""
    if not k:
        return '없음'
    out = []
    for p in k.split('+'):
        p = p.strip()
        if re.fullmatch(r'f\d{1,2}', p):
            out.append(p.upper())
        elif p in ('ctrl', 'alt', 'shift'):
            out.append(p.capitalize())
        elif len(p) == 1:
            out.append(p.upper())
        else:
            out.append(p.title())
    return ' + '.join(out)


def event_to_key(e):
    """tkinter 키 이벤트 -> keyboard 라이브러리 이름 ('ctrl+f12') / None(수정키만) / ('err', 이유)"""
    ks = e.keysym
    if ks in _MODS:
        return None
    if re.fullmatch(r'F\d{1,2}', ks):
        main = ks.lower()
    elif ks in _KEYSYM:
        main = _KEYSYM[ks]
    elif len(ks) == 1 and ks.isprintable():
        main = ks.lower()
    elif ks in ('Escape', 'space', 'Return', 'KP_Enter'):
        main = {'Escape': 'esc', 'space': 'space', 'Return': 'enter', 'KP_Enter': 'enter'}[ks]
    else:
        return ('err', '이 키는 쓸 수 없어요 (%s)' % ks)
    st = e.state
    mods = []
    if st & 0x0004:
        mods.append('ctrl')
    if st & 0x20000 or st & 0x0008:
        mods.append('alt')
    if st & 0x0001:
        mods.append('shift')
    if not mods:
        if main in FORBIDDEN:
            return ('err', '%s 는 매크로가 게임에 직접 누르는 키라서 쓸 수 없어요' % key_label(main))
        if main not in PLAIN_OK:
            return ('err', '%s 하나만은 안 돼요 - F1~F12 이거나 Ctrl·Alt·Shift 와 같이 눌러 주세요' % key_label(main))
    return '+'.join(mods + [main])


def hotkey_dialog(actions, bindings, defaults, on_save, console=False, on_console=None):
    """actions: [(id, 이름)], bindings: {id: 'f6'...}, on_save(new_bindings) -> (성공, 메시지)"""
    w = tk.Toplevel(_root)
    w.title('단축키 설정')
    w.configure(bg='#f3f3f5')
    w.transient(_root)
    w.grab_set()
    cur = dict(bindings)
    rec = {'id': None}
    F = (FONT, 9)
    tk.Label(w, text='단축키 바꾸기', font=(FONT, 11, 'bold'), bg='#f3f3f5').pack(anchor='w', padx=14, pady=(12, 2))
    tk.Label(w, text='바꿀 칸을 누르고 원하는 키를 누르세요 (F1~F12, 또는 Ctrl·Alt·Shift + 키)\n'
                     'S · ESC · Space · Enter 는 매크로가 게임에 직접 누르는 키라서 혼자는 쓸 수 없어요.  ✕ = 단축키 없음',
             font=(FONT, 8), fg='#666', bg='#f3f3f5', justify='left').pack(anchor='w', padx=14)
    tb = tk.Frame(w, bg='#ffffff', highlightthickness=1, highlightbackground='#d8d8de')
    tb.pack(fill='x', padx=14, pady=8)
    keyw = {}
    msg = tk.Label(w, text='', font=(FONT, 8), fg='#d33', bg='#f3f3f5', justify='left', wraplength=px(420))

    def show(aid):
        b = keyw[aid]
        if rec['id'] == aid:
            b.config(text='키를 누르세요…', fg='#2b7de9', bg='#eaf2ff')
        else:
            k = cur.get(aid) or ''
            b.config(text=key_label(k), fg='#222' if k else '#aaa', bg='#fafafa')

    def start(aid):
        prev = rec['id']
        rec['id'] = aid
        if prev and prev != aid:
            show(prev)
        show(aid)
        msg.config(text='')
        w.focus_force()

    def clear(aid):
        cur[aid] = ''
        if rec['id'] == aid:
            rec['id'] = None
        show(aid)

    for n, (aid, name) in enumerate(actions):
        tk.Label(tb, text=clean(name), font=F, bg='#ffffff', anchor='w', width=18).grid(row=n, column=0, sticky='w', padx=(10, 4), pady=3)
        b = tk.Label(tb, text='', font=('Consolas', 9), bg='#fafafa', relief='solid', bd=1, width=16, anchor='w',
                     padx=6, cursor='hand2')
        b.grid(row=n, column=1, sticky='w', pady=3)
        b.bind('<Button-1>', lambda e, a=aid: start(a))
        keyw[aid] = b
        x = tk.Label(tb, text='✕', font=F, fg='#2b7de9', bg='#ffffff', cursor='hand2')
        x.grid(row=n, column=2, padx=10)
        x.bind('<Button-1>', lambda e, a=aid: clear(a))
        show(aid)
    msg.pack(anchor='w', padx=14)
    v_con = tk.BooleanVar(value=bool(console))
    if on_console is not None:
        tk.Checkbutton(w, text='문제가 있을 때만: 다음에 켤 때부터 예전 글자 창으로 쓰기 (버튼 창 끄기)', variable=v_con,
                       font=(FONT, 8), bg='#f3f3f5', activebackground='#f3f3f5', fg='#555').pack(anchor='w', padx=10, pady=(4, 0))

    def on_key(e):
        aid = rec['id']
        if aid is None:
            return 'break'
        k = event_to_key(e)
        if k is None:
            return 'break'
        if isinstance(k, tuple):
            msg.config(text=k[1])
            return 'break'
        other = next((a for a, kk in cur.items() if kk == k and a != aid), None)
        if other:
            msg.config(text='%s 는 \'%s\'에서 쓰는 중이에요 - 그쪽 ✕ 로 먼저 지워 주세요' % (key_label(k), dict(actions)[other]))
            return 'break'
        cur[aid] = k
        rec['id'] = None
        show(aid)
        msg.config(text='')
        return 'break'

    w.bind('<KeyPress>', on_key)
    bb = tk.Frame(w, bg='#f3f3f5')
    bb.pack(fill='x', padx=14, pady=(4, 12))

    def do_default():
        cur.clear()
        cur.update(defaults)
        rec['id'] = None
        for a, _n in actions:
            show(a)
        msg.config(text='기본값으로 바꿨어요 - [저장]을 눌러야 적용돼요', fg='#2b7de9')

    def do_save():
        ok, m = on_save(dict(cur))
        if ok and on_console is not None:
            on_console(bool(v_con.get()))
        if ok:
            w.destroy()
        else:
            msg.config(text=m, fg='#d33')

    tk.Button(bb, text='저장', font=F, width=8, bg='#2b7de9', fg='white', command=do_save).pack(side='right')
    tk.Button(bb, text='취소', font=F, width=8, command=w.destroy).pack(side='right', padx=6)
    tk.Button(bb, text='기본값으로', font=F, width=10, command=do_default).pack(side='right')
    w.update_idletasks()
    try:
        w.geometry('+%d+%d' % (_root.winfo_rootx() + 10, _root.winfo_rooty() + 60))
    except Exception:
        pass
    w.focus_force()
    return w


# ── 시작 ───────────────────────────────────────
def run(api, geometry='470x980', on_ready=None):
    """창을 만들고 이 스레드(메인)에서 계속 돌림. 창을 만들지 못하면 예외"""
    global _root, _api, UI_THREAD
    _api = api
    UI_THREAD = threading.current_thread()
    global SCALE
    root = tk.Tk()
    _root = root
    try:
        SCALE = max(1.0, min(2.5, root.winfo_fpixels('1i') / 96.0))   # Windows 배율 (100% = 1.0)
    except Exception:
        SCALE = 1.0
    m = re.fullmatch(r'(\d+)x(\d+)(.*)', geometry)
    if m:
        w, h = px(int(m.group(1))), px(int(m.group(2)))
        h = min(h, root.winfo_screenheight() - px(60))           # 작업표시줄 빼고 화면 안에
        geometry = '%dx%d%s' % (w, h, m.group(3))
    root.geometry(geometry)
    try:
        ico = api.get('icon')
        if ico:
            img = tk.PhotoImage(file=ico)
            root.iconphoto(True, img)
            root._icon = img
    except Exception:
        pass
    MacroWindow(root, api)
    root.after(50, _pump)
    root.update_idletasks()
    _read_hwnd()
    if on_ready:
        root.after(300, on_ready)
    try:
        root.mainloop()
    finally:
        _root = None


# ── v3.2 전술 자동 변경 창 ───────────────────────────
_tac_win = [None]
MARKS = ['①', '②', '③']


def _small_btn(parent, text, cmd, bg=CARD2, fg=FG):
    b = tk.Label(parent, text=text, font=(FONT, 8), fg=fg, bg=bg, padx=8, pady=2, cursor='hand2')
    b.bind('<Button-1>', lambda e: cmd())
    b.bind('<Enter>', lambda e: b.config(bg='#34344a'))
    b.bind('<Leave>', lambda e: b.config(bg=bg))
    return b


def tactics_dialog(snap, api):
    """전술 자동 변경 창 (창 스레드에서). snap() -> 상태, api(명령, ...) -> 매크로"""
    if _tac_win[0] is not None:
        try:
            _tac_win[0].lift()
            _tac_win[0].focus_force()
            return _tac_win[0]
        except tk.TclError:
            _tac_win[0] = None
    d = snap()
    w = tk.Toplevel(_root)
    _tac_win[0] = w
    w.title('전술 자동 변경')
    w.configure(bg=BG)
    w.transient(_root)
    w.resizable(False, False)
    st = {'img': [None] * 3, 'img_key': [None] * 3, 'reg_win': None, 'reg_was': None, 'closed': False}
    cfg = dict(d['settings'])

    hd = tk.Frame(w, bg=BG, padx=14, pady=10)
    hd.pack(fill='x')
    _lbl(hd, '⇄ 전술 자동 변경', 12, FG, True, bg=BG).pack(side='left')
    sw = tk.Label(hd, text='', font=(FONT, 9, 'bold'), padx=10, pady=3, cursor='hand2')
    sw.pack(side='right')
    v_on = tk.BooleanVar(value=bool(cfg.get('enabled')))

    def paint_switch():
        on = v_on.get()
        sw.config(text='● 자동 변경 켜짐' if on else '○ 자동 변경 꺼짐', bg='#1f3a2c' if on else CARD2, fg=GREEN if on else DIM)
    sw.bind('<Button-1>', lambda e: (v_on.set(not v_on.get()), paint_switch()))
    paint_switch()

    now = tk.Frame(w, bg=CARD, padx=12, pady=9)
    now.pack(fill='x', padx=12, pady=(0, 6))
    _lbl(now, '지금 쓰는 전술', 9, DIM).pack(anchor='w')
    w_line = _lbl(now, '', 10, FG, True, anchor='w', justify='left', wraplength=px(500))
    w_line.pack(fill='x', pady=(2, 0))
    w_msg = _lbl(now, '', 9, CYAN, anchor='w', justify='left', wraplength=px(500))
    w_msg.pack(fill='x', pady=(2, 0))

    _lbl(w, '  전술 (최대 3개) - 게임 스쿼드 화면의 [전술 ▼] 목록에서 고른 것', 9, DIM, True, bg=BG).pack(anchor='w', padx=12, pady=(2, 4))
    rows = []
    for i in range(3):
        c = tk.Frame(w, bg=CARD, padx=12, pady=8, highlightthickness=2, highlightbackground=CARD)
        c.pack(fill='x', padx=12, pady=(0, 6))
        r1 = tk.Frame(c, bg=CARD)
        r1.pack(fill='x')
        mk = _lbl(r1, MARKS[i], 13, DIM, True)
        mk.pack(side='left')
        im = tk.Label(r1, bg=CARD, bd=0)
        im.pack(side='left', padx=8)
        nm = tk.Entry(r1, font=(FONT, 10), width=10, bg=CARD2, fg=FG, insertbackground=FG, relief='flat')
        nm.pack(side='left')
        tag = _lbl(r1, '', 9, CYAN, True)
        tag.pack(side='right')
        empty = _lbl(r1, '비어 있음', 10, DIM, True)
        r2 = tk.Frame(c, bg=CARD)
        r2.pack(fill='x', pady=(5, 0))
        stat = _lbl(r2, '', 9, DIM)
        stat.pack(side='left')
        bx = tk.Frame(r2, bg=CARD)
        bx.pack(side='right')
        rows.append({'c': c, 'mk': mk, 'im': im, 'nm': nm, 'tag': tag, 'stat': stat, 'bx': bx, 'r1': r1, 'r2': r2,
                     'empty': empty, 'state': 'init'})

    rl = tk.Frame(w, bg=CARD, padx=12, pady=9)
    rl.pack(fill='x', padx=12, pady=(0, 6))
    _lbl(rl, '바꾸는 기준', 10, FG, True).pack(anchor='w', pady=(0, 4))
    ent = {}

    def opt_row(parts, var=None):
        f = tk.Frame(rl, bg=CARD)
        f.pack(fill='x', pady=2)
        if var is not None:
            tk.Checkbutton(f, variable=var, bg=CARD, activebackground=CARD, selectcolor=CARD2, fg=FG, bd=0,
                           highlightthickness=0).pack(side='left')
        for t in parts:
            if t.startswith('['):
                k = t[1:-1]
                e = tk.Entry(f, font=(FONT, 10, 'bold'), width=4, bg=CARD2, fg=YEL, justify='center', relief='flat',
                             insertbackground=FG)
                e.insert(0, str(cfg.get(k, '')))
                e.pack(side='left', padx=3)
                ent[k] = e
            else:
                _lbl(f, t, 9).pack(side='left')
        return f
    opt_row(['최근', '[min_games]', '판 승률이', '[rate]', '% 미만이면 다음 전술로  (한 전술로 그 판수를 채운 뒤부터)'])
    v_streak = tk.BooleanVar(value=bool(cfg.get('streak_on')))
    opt_row(['판수와 상관없이', '[streak]', '연패면 바로 다음 전술로'], v_streak)
    v_lock = tk.BooleanVar(value=bool(cfg.get('lock_on')))
    opt_row(['모든 전술이 기준 미만이면 승률이 가장 좋았던 전술로 고정'], v_lock)
    opt_row(['    └ 고정한 뒤', '[unlock_after]', '판이 지나면 처음부터 다시 평가'])
    f = tk.Frame(rl, bg=CARD)
    f.pack(fill='x', pady=2)
    _lbl(f, '    └ 고정 중 연패면:', 9).pack(side='left')
    v_ls = tk.StringVar(value=cfg.get('lock_streak') or 'alert')
    for val, t in (('alert', '알림만'), ('switch', '고정 풀고 다음 전술로')):
        tk.Radiobutton(f, text=t, value=val, variable=v_ls, font=(FONT, 9), bg=CARD, fg=FG, activebackground=CARD,
                       activeforeground=FG, selectcolor=CARD2, highlightthickness=0).pack(side='left', padx=(6, 0))
    _lbl(rl, '· 연속 진행 중에는 바꾸지 않고, 끝난 뒤 첫 [진행] 때 바꿉니다\n· 순서: ① → ② → ③ → ① … (등록된 전술만)\n'
             '· 게임에서 등록 안 된 전술로 직접 바꿔 두면 자동 변경을 멈춥니다', 8, DIM, justify='left').pack(anchor='w', pady=(6, 0))

    lg = tk.Frame(w, bg=CARD, padx=12, pady=9)
    lg.pack(fill='x', padx=12, pady=(0, 6))
    _lbl(lg, '최근 변경', 10, FG, True).pack(anchor='w', pady=(0, 3))
    w_log = _lbl(lg, '', 9, DIM, anchor='w', justify='left')
    w_log.pack(fill='x')

    ft = tk.Frame(w, bg=BG, pady=8)
    ft.pack(fill='x')
    w_err = _lbl(ft, '', 9, RED, bg=BG)
    w_err.pack(side='left', padx=14)

    def save():
        new = {'enabled': bool(v_on.get()), 'streak_on': bool(v_streak.get()), 'lock_on': bool(v_lock.get()),
               'lock_streak': v_ls.get()}
        lim = {'min_games': (5, 500), 'rate': (1, 99), 'streak': (2, 30), 'unlock_after': (10, 2000)}
        for k, (lo, hi) in lim.items():
            try:
                v = int(ent[k].get().strip())
            except ValueError:
                w_err.config(text='숫자를 확인해 주세요')
                return False
            if not lo <= v <= hi:
                w_err.config(text='%s: %d ~ %d 사이로' % ({'min_games': '최소 판수', 'rate': '승률', 'streak': '연패',
                                                         'unlock_after': '고정 해제 판수'}[k], lo, hi))
                return False
            new[k] = v
        for i, r in enumerate(rows):
            if r['state'] not in (None, 'init'):
                api('rename', i, r['nm'].get().strip())
        api('settings', new)
        w_err.config(text='저장했어요', fg=GREEN)
        return True

    def close():
        st['closed'] = True
        if st['reg_win'] is not None:
            api('cancel_reg')
        _tac_win[0] = None
        w.destroy()
    _small_btn(ft, '닫기', close).pack(side='right', padx=(0, 12), ipadx=12, ipady=3)
    _small_btn(ft, '저장', save, '#1f3a2c', GREEN).pack(side='right', padx=(0, 6), ipadx=12, ipady=3)
    w.protocol('WM_DELETE_WINDOW', close)

    def confirm_delete(i):
        from tkinter import messagebox
        if messagebox.askyesno('전술 삭제', '%s 전술을 지울까요? (이 전술의 기록은 기록 파일에 남아 있어요)' % MARKS[i], parent=w):
            api('delete', i)

    def reg_window(i):
        q = tk.Toplevel(w)
        q.title('전술 등록')
        q.configure(bg=BG)
        q.transient(w)
        c = tk.Frame(q, bg=CARD, padx=16, pady=14)
        c.pack(fill='both', expand=True, padx=10, pady=10)
        _lbl(c, '%s 전술 등록' % MARKS[i], 12, FG, True).pack(anchor='w')
        _lbl(c, '매크로는 일시정지 상태입니다.\n\n1) 게임 스쿼드 화면에서  [전술 ▼]  목록을 여세요\n2) 등록할 전술을 마우스로 클릭하세요\n\n'
                '클릭한 자리와, 고른 뒤 전술 칸 모습을 기억합니다.', 10, justify='left').pack(anchor='w', pady=(8, 8))
        rr = tk.Frame(c, bg=CARD)
        rr.pack(fill='x')
        lab = _lbl(rr, '기다리는 중...', 9, YEL, True)
        lab.pack(side='left')
        _small_btn(rr, '취소', lambda: api('cancel_reg')).pack(side='right', ipadx=8)
        q.protocol('WM_DELETE_WINDOW', lambda: api('cancel_reg'))
        try:
            q.geometry('+%d+%d' % (w.winfo_rootx() + 40, w.winfo_rooty() + 120))
        except Exception:
            pass
        q.lab = lab
        q.t0 = time.time()
        return q

    def start_reg(i):
        if st['reg_win'] is not None:
            return
        api('register', i)
        st['reg_win'] = reg_window(i)
        st['reg_was'] = i

    def refresh():
        if st['closed']:
            return
        try:
            d = snap()
        except Exception:
            w.after(800, refresh)
            return
        w_line.config(text=clean(d['line']))
        msg = d['msg'] if (d['msg'] and d['reg'] is None and st['reg_was'] is not None) else ''
        if d.get('pending') is not None:
            msg = (msg + '  ' if msg else '') + '다음 스쿼드 화면에서 %s(으)로 바꿉니다' % MARKS[d['pending']]
        w_msg.config(text=clean(msg))
        for i, (r, sl) in enumerate(zip(rows, d['slots'])):
            key = None if sl is None else (sl['name'], sl['stat'], sl['tag'], sl['cur'], sl['id'])
            if key == r['state'] and not (sl and st['img_key'][i] != sl['id']):
                continue
            r['state'] = key
            for ch in r['bx'].winfo_children():
                ch.destroy()
            if sl is None:
                for wd in (r['im'], r['nm'], r['tag'], r['r2']):
                    wd.pack_forget()
                r['empty'].pack(side='left', padx=(8, 0))
                _small_btn(r['r1'], '+ 전술 등록', lambda i=i: start_reg(i), '#1f3236', CYAN).pack(side='right')
                r['mk'].config(fg=DIM)
                r['c'].config(highlightbackground=CARD)
                continue
            r['empty'].pack_forget()
            for ch in r['r1'].winfo_children():
                if isinstance(ch, tk.Label) and ch.cget('text') == '+ 전술 등록':
                    ch.destroy()
            r['im'].pack(side='left', padx=8, after=r['mk'])
            r['nm'].pack(side='left', after=r['im'])
            r['tag'].pack(side='right')
            r['r2'].pack(fill='x', pady=(5, 0))
            if st['img_key'][i] != sl['id']:
                st['img_key'][i] = sl['id']
                try:
                    st['img'][i] = tk.PhotoImage(data=sl['png']) if sl.get('png') else None
                except tk.TclError:
                    st['img'][i] = None
                r['im'].config(image=st['img'][i] or '', text='' if st['img'][i] else '(그림 없음)', fg=DIM)
            if r['nm'].get() != sl['name'] and w.focus_get() is not r['nm']:
                r['nm'].delete(0, 'end')
                r['nm'].insert(0, sl['name'])
            tg = sl['tag'] or ('', 'cyan')
            r['tag'].config(text=tg[0], fg={'cyan': CYAN, 'red': RED, 'green': GREEN}.get(tg[1], DIM))
            r['stat'].config(text=sl['stat'])
            r['mk'].config(fg=CYAN if sl['cur'] else GREEN)
            r['c'].config(highlightbackground=CYAN if sl['cur'] else CARD)
            for t, fn in (('삭제', lambda i=i: confirm_delete(i)), ('다시 등록', lambda i=i: start_reg(i)),
                          ('지금 이걸로', lambda i=i: api('use', i))):
                _small_btn(r['bx'], t, fn).pack(side='right', padx=(4, 0))
        w_log.config(text='\n'.join('%s   %s' % (a, clean(b)) for a, b in d['log'][:6]) or '아직 없음')
        q = st['reg_win']
        if q is not None:
            if d['reg'] is None and time.time() - q.t0 > 0.6:
                try:
                    q.destroy()
                except tk.TclError:
                    pass
                st['reg_win'] = None
            else:
                try:
                    q.lab.config(text='기다리는 중... %d초' % max(0, 45 - int(time.time() - q.t0)))
                except tk.TclError:
                    pass
        w.after(500, refresh)
    refresh()
    w.update_idletasks()
    try:
        w.geometry('+%d+%d' % (_root.winfo_rootx() + 30, max(0, _root.winfo_rooty() - 10)))
    except Exception:
        pass
    return w


# ── v3.3 쉬는 시간 설정 창 ───────────────────────────
_rest_win = [None]


def rest_dialog(snap, api):
    if _rest_win[0] is not None:
        try:
            _rest_win[0].lift()
            return _rest_win[0]
        except tk.TclError:
            _rest_win[0] = None
    d = snap()
    cfg = dict(d['cfg'])
    w = tk.Toplevel(_root)
    _rest_win[0] = w
    w.title('쉬는 시간 설정')
    w.configure(bg=BG)
    w.transient(_root)
    w.resizable(False, False)
    hd = tk.Frame(w, bg=BG, padx=14, pady=10)
    hd.pack(fill='x')
    _lbl(hd, '◐ 쉬는 시간 설정', 12, FG, True, bg=BG).pack(side='left')
    v_on = tk.BooleanVar(value=bool(cfg.get('enabled')))
    sw = tk.Label(hd, text='', font=(FONT, 9, 'bold'), padx=10, pady=3, cursor='hand2')
    sw.pack(side='right')

    def paint():
        on = v_on.get()
        sw.config(text='● 켜짐' if on else '○ 꺼짐', bg='#1f3a2c' if on else CARD2, fg=GREEN if on else DIM)
    sw.bind('<Button-1>', lambda e: (v_on.set(not v_on.get()), paint()))
    paint()
    ent = {}

    def row(parent, parts, var=None):
        f = tk.Frame(parent, bg=CARD)
        f.pack(fill='x', pady=2)
        if var is not None:
            tk.Checkbutton(f, variable=var, bg=CARD, activebackground=CARD, selectcolor=CARD2, fg=FG, bd=0,
                           highlightthickness=0).pack(side='left')
        for t in parts:
            if t.startswith('['):
                k = t[1:-1]
                e = tk.Entry(f, font=(FONT, 10, 'bold'), width=4, bg=CARD2, fg=YEL, justify='center', relief='flat',
                             insertbackground=FG)
                e.insert(0, str(cfg.get(k, '')))
                e.pack(side='left', padx=3)
                ent[k] = e
            else:
                _lbl(f, t, 9).pack(side='left')
    c = tk.Frame(w, bg=CARD, padx=12, pady=9)
    c.pack(fill='x', padx=12, pady=(0, 7))
    _lbl(c, '자동으로 쉬는 시간', 10, FG, True).pack(anchor='w', pady=(0, 4))
    v_auto = tk.BooleanVar(value=bool(cfg.get('auto')))
    row(c, ['승률이 낮은 시간대는 자동으로 쉬기'], v_auto)
    row(c, ['   최근', '[days]', '일 기록에서, 평균보다', '[gap]', '%p 이상 낮고'])
    row(c, ['   그 시간대 기록이', '[min_games]', '판 이상일 때 (적으면 운일 수 있어서)'])
    # v3.5 쉬는 방식
    v_mode = tk.StringVar(value=cfg.get('mode') or 'all')
    mf = tk.Frame(c, bg=CARD)
    mf.pack(fill='x', pady=(6, 0))
    _lbl(mf, '쉬는 방식', 9, FG, True).pack(anchor='w')
    for val, txt in (('all', '조건 맞는 시간대 모두 쉬기  (덜 짐 · 쉬는 시간 김)'),
                     ('rotate', '하루 한 칸만, 돌아가며 쉬기  (판수·FC 많음 · 어제 쉰 칸은 오늘 다시 돌려 봄)')):
        tk.Radiobutton(mf, text=txt, variable=v_mode, value=val, font=(FONT, 9), bg=CARD, fg=FG, activebackground=CARD,
                       activeforeground=FG, selectcolor=CARD2, bd=0, highlightthickness=0, anchor='w').pack(fill='x')
    w_now = _lbl(c, '', 8, ORANGE, anchor='w', justify='left')
    w_now.pack(fill='x', pady=(4, 0))
    _lbl(c, '   단위 2시간 · 기준 9%p · 60판은 실제 기록 946판으로 비교해 가장 효율적이었던 값', 8, DIM, anchor='w').pack(fill='x')
    c2 = tk.Frame(w, bg=CARD, padx=12, pady=9)
    c2.pack(fill='x', padx=12, pady=(0, 7))
    _lbl(c2, '쉬는 동안', 10, FG, True).pack(anchor='w', pady=(0, 4))
    _lbl(c2, '· 진행 중인 판은 끝까지 → 로비에서 대기 → 끝나면 자동으로 다시 시작\n'
             '· 연속 진행 중이면 연속 진행이 끝난 뒤 쉼 · 기록·알림·텔레그램은 그대로', 9, justify='left').pack(anchor='w')
    v_noti = tk.BooleanVar(value=bool(cfg.get('notify')))
    row(c2, ['쉬는 시간 시작·끝 알림 (휴대폰)'], v_noti)
    v_pre = tk.BooleanVar(value=bool(cfg.get('pre_on')))
    row(c2, ['다시 시작', '[pre_min]', '분 전 알림'], v_pre)
    c3 = tk.Frame(w, bg=CARD, padx=12, pady=9)
    c3.pack(fill='x', padx=12, pady=(0, 7))
    _lbl(c3, '"지금 계속" = 이번 쉬는 시간만 건너뛰기', 10, FG, True).pack(anchor='w', pady=(0, 3))
    _lbl(c3, '· 매크로 창 주황 띠 [지금 계속] / 텔레그램 [▶ 쉬지 말고 계속] · 다음 쉬는 시간부터는 다시 쉼\n'
             '· 시간대 칸을 누르면  보통 → ✖ 쉼 → − 계속(자동 제외) → 보통', 9, justify='left').pack(anchor='w')
    ft = tk.Frame(w, bg=BG, pady=8)
    ft.pack(fill='x')
    w_err = _lbl(ft, '', 9, RED, bg=BG)
    w_err.pack(side='left', padx=14)

    def save():
        new = {'enabled': bool(v_on.get()), 'auto': bool(v_auto.get()), 'notify': bool(v_noti.get()), 'pre_on': bool(v_pre.get()),
               'mode': v_mode.get()}
        lim = {'days': (3, 365, '기간'), 'gap': (1, 50, '기준 %p'), 'min_games': (5, 2000, '최소 판수'), 'pre_min': (1, 60, '알림 분')}
        for k, (lo, hi, nm) in lim.items():
            try:
                v = int(ent[k].get().strip())
            except ValueError:
                w_err.config(text='%s: 숫자로' % nm, fg=RED)
                return
            if not lo <= v <= hi:
                w_err.config(text='%s: %d ~ %d' % (nm, lo, hi), fg=RED)
                return
            new[k] = v
        api('settings', new)
        w_err.config(text='저장했어요', fg=GREEN)

    def close():
        _rest_win[0] = None
        w.destroy()
    _small_btn(ft, '닫기', close).pack(side='right', padx=(0, 12), ipadx=12, ipady=3)
    _small_btn(ft, '저장', save, '#1f3a2c', GREEN).pack(side='right', padx=(0, 6), ipadx=12, ipady=3)
    w.protocol('WM_DELETE_WINDOW', close)

    def refresh():
        if _rest_win[0] is not w:
            return
        try:
            dd = snap()
            autos = [x['label'] + '~%02d시' % ((int(x['label']) + 2) % 24) for x in dd['cells'] if x['kind'].endswith('auto')]
            few = [x['label'] + '시' for x in dd['cells'] if x['n'] < int(dd['cfg']['min_games']) and x['n'] > 0]
            hours = lambda xs: ', '.join('%s~%02d시' % (x, (int(x) + 2) % 24) for x in xs) or '없음'
            if dd['cfg'].get('mode') == 'rotate':
                head = '   → 오늘 쉬는 칸: %s · 조건 맞는 칸: %s' % (', '.join(autos) or '없음', hours(dd.get('bad', [])))
            else:
                head = '   → 지금 기준으로 자동: %s' % (', '.join(autos) or '없음')
            w_now.config(text=head + (('\n   (기록이 아직 적어 판단 안 함: %s)' % ', '.join(few)) if few else ''))
        except Exception:
            pass
        w.after(2000, refresh)
    refresh()
    try:
        w.geometry('+%d+%d' % (_root.winfo_rootx() + 30, max(0, _root.winfo_rooty() + 40)))
    except Exception:
        pass
    return w
