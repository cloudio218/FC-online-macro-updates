# -*- coding: utf-8 -*-
"""v3.10 FC온라인 공지사항 알림: 새 글 + 이미 올린 글의 제목 변경

https://fconline.nexon.com/news/notice/list (로그인 없이 보이는 서버 HTML, 2026-11-26 구조 확인)
  - 목록: <div class="tr ..."><a href="/news/notice/view?n4ArticleSN=6387"><span class="td sort">점검</span>
          <span class="td subject">제목 <span class='ico ico_new'>새 글</span></span>
  - 위쪽 '중요' 고정글: <a href="/news/notice/view?n4articlesn=5307"> ... <span class="tit">제목</span> ... <i class="i1">공지</i>
글 번호(n4ArticleSN)는 그대로이고 제목만 바뀌는 경우가 많음 (예: '(완료, 10번 추가) 11/26(목) 정기점검', '11/24(화) -> 11/26(목) 현재 발생 중인 오류 안내')
-> 번호마다 제목을 기억해 두고 새 번호 = 새 글, 같은 번호 다른 제목 = 제목 변경
"""
import difflib
import html
import json
import os
import re
import threading
import time
import urllib.request

LIST_URL = 'https://fconline.nexon.com/news/notice/list'
VIEW_URL = 'https://fconline.nexon.com/news/notice/view?n4ArticleSN=%s'
EVERY = 60                      # 1분마다 (사용자 요청)
BACKOFF = (120, 300, 900)       # 실패하면 2분 -> 5분 -> 15분 (넥슨 쪽 부담·차단 방지)
KEEP = 600                      # 기억해 둘 글 수
BATCH = 3                       # 한 번에 이보다 많으면 한 메시지로 묶음
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) '
      'Chrome/130.0.0.0 Safari/537.36')
ICON = {'점검': '🔧', '업데이트': '🆕', '이벤트': '🎁', 'GM소식': '💬'}

_ROW = re.compile(r'<a\s+href="[^"]*?n4ArticleSN=(\d+)"[^>]*>\s*<span class="td sort">(.*?)</span>\s*'
                  r'<span class="td subject">(.*?)</span>\s*<span class="td date">', re.S | re.I)
_PIN = re.compile(r'<a\s+href="[^"]*?n4articlesn=(\d+)"[^>]*>.*?<span class="tit">(.*?)</span>.*?'
                  r'<i class="i1">(.*?)</i>', re.S)
_TAG = re.compile(r'<[^>]+>')


def _clean(s):
    s = re.sub(r"<span class=['\"]ico[^'\"]*['\"]>.*?</span>", '', s, flags=re.S)   # '새 글' 표시 등
    s = html.unescape(_TAG.sub('', s))
    return re.sub(r'\s+', ' ', s).strip()


def parse(text):
    """목록 HTML -> [{'id': 6387, 'cat': '점검', 'title': '...', 'pin': bool}] (번호 중복 없음, 화면 순서)"""
    out, seen = [], set()
    for m in _ROW.finditer(text):
        i = int(m.group(1))
        if i in seen:
            continue
        seen.add(i)
        out.append({'id': i, 'cat': _clean(m.group(2)), 'title': _clean(m.group(3)), 'pin': False})
    for m in _PIN.finditer(text):
        i = int(m.group(1))
        if i in seen:
            continue
        seen.add(i)
        out.append({'id': i, 'cat': _clean(m.group(3)), 'title': _clean(m.group(2)), 'pin': True})
    return out


def diff_text(old, new):
    """바뀐 부분 한 줄: '+ (완료, 10번 추가)' / '11/24(화) → 11/26(목)'"""
    a, b = re.findall(r'\S+', old), re.findall(r'\S+', new)
    parts = []
    for op, i1, i2, j1, j2 in difflib.SequenceMatcher(None, a, b, autojunk=False).get_opcodes():
        if op == 'replace':
            parts.append('%s → %s' % (' '.join(a[i1:i2]), ' '.join(b[j1:j2])))
        elif op == 'insert':
            parts.append('+ ' + ' '.join(b[j1:j2]))
        elif op == 'delete':
            parts.append('- ' + ' '.join(a[i1:i2]))
    return ' · '.join(parts)[:200]


def fetch(timeout=15):
    req = urllib.request.Request(LIST_URL, headers={'User-Agent': UA, 'Accept': 'text/html,application/xhtml+xml',
                                                    'Accept-Language': 'ko-KR,ko;q=0.9', 'Cache-Control': 'no-cache'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        return r.read().decode('utf-8', 'replace')


class Watcher:
    """state: {'seen': {id: [제목, 구분, 처음 본 시각]}, 'init': 처음 한 번 기억만 했나}"""

    def __init__(self, folder, fetch_fn=None):
        self.path = os.path.join(folder, 'notice.json')
        self.fetch_fn = fetch_fn or fetch
        self.s = {'seen': {}, 'init': False, 'on': True}
        try:
            with open(self.path, encoding='utf-8') as fp:
                self.s.update(json.load(fp))
        except (OSError, ValueError):
            pass
        self.fail = 0
        self.last_ok = 0.0
        self.last_err = ''
        self.lock = threading.Lock()

    def save(self):
        try:
            tmp = self.path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as fp:
                json.dump(self.s, fp, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def wait_sec(self):
        return EVERY if not self.fail else BACKOFF[min(self.fail, len(BACKOFF)) - 1]

    def check(self, text=None):
        """한 번 확인 -> 새 일들 [('new', 글) / ('title', 글, 예전 제목)], 실패면 None"""
        with self.lock:
            try:
                items = parse(text if text is not None else self.fetch_fn())
                if len(items) < 5:
                    raise ValueError('공지 목록을 못 읽음 (%d개) - 페이지 구조가 바뀌었을 수 있음' % len(items))
            except Exception as e:                                # noqa: BLE001
                self.fail += 1
                self.last_err = str(e)[:200]
                return None
            self.fail, self.last_ok, self.last_err = 0, time.time(), ''
            seen = self.s['seen']
            ev = []
            for it in items:
                k = str(it['id'])
                old = seen.get(k)
                if old is None:
                    if self.s['init']:
                        ev.append(('new', it))
                    seen[k] = [it['title'], it['cat'], int(time.time())]
                elif old[0] != it['title']:
                    ev.append(('title', it, old[0]))
                    old[0], old[1] = it['title'], it['cat']
            first = not self.s['init']
            self.s['init'] = True
            if len(seen) > KEEP:
                for k in sorted(seen, key=int)[:len(seen) - KEEP]:
                    seen.pop(k, None)
            if ev or first:
                self.save()
            ev.sort(key=lambda e: e[1]['id'])                     # 오래된 글부터
            return ev

    def toggle(self, on=None):
        self.s['on'] = (not self.s.get('on', True)) if on is None else bool(on)
        self.save()
        return self.s['on']

    def recent(self, n=5):
        seen = self.s['seen']
        ks = sorted(seen, key=int, reverse=True)[:n]
        return [(int(k), seen[k][1], seen[k][0]) for k in ks]


def icon(cat):
    return ICON.get(cat, '📢')


def messages(ev, offline=False):
    """새 일들 -> 보낼 메시지 [(제목, 줄들, 글 주소 / None)]  (많으면 한 메시지로 묶음)"""
    if not ev:
        return []
    if offline or len(ev) > BATCH:
        head = ('🔄 매크로 꺼져 있는 동안 공지 %d개' if offline else '📢 공지 %d개가 한꺼번에 올라왔어요') % len(ev)
        lines = []
        for e in ev:
            it = e[1]
            mark = '✏️' if e[0] == 'title' else icon(it['cat'])
            lines.append('%s %s' % (mark, it['title']))
        return [(head, lines, LIST_URL)]
    out = []
    for e in ev:
        it = e[1]
        if e[0] == 'new':
            t = ('🔧 새 점검 공지' if it['cat'] == '점검' else '%s 새 공지 · %s' % (icon(it['cat']), it['cat'] or '공지'))
            out.append((t, [it['title']], VIEW_URL % it['id']))
        else:
            d = diff_text(e[2], it['title'])
            out.append(('✏️ 공지 제목이 바뀌었어요 · %s' % (it['cat'] or '공지'),
                        ['전: ' + e[2], '후: ' + it['title']] + (['', '바뀐 부분: ' + d] if d else []),
                        VIEW_URL % it['id']))
    return out
