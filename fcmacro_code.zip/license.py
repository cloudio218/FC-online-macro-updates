# -*- coding: utf-8 -*-
"""v3.13 등록제: 제작자가 승인한 PC에서만 시작·친구 랭킹 사용

- PC 번호(mid): Windows 고유 번호(MachineGuid)를 한 번 더 섞은 값. 원래 번호는 밖으로 안 나감
- PC 열쇠(key): 처음 켤 때 이 PC에서 만든 무작위 값 (기록 폴더 license.json). 서버에는 섞은 값만 저장
- 승인 기록: 승인되면 license.json 에 'PC 번호 + 열쇠'로 만든 확인값을 남김
    -> 서버가 잠깐 응답이 없어도 승인된 PC는 그대로 켜짐 (폴더째 다른 PC로 복사하면 PC 번호가 달라서 무효)
    -> 서버가 '승인 안 됨(거절·차단·기록 없음)'이라고 분명히 답할 때만 지움 (지금 켜진 건 그대로, 다음에 켤 때부터 막힘)
- 처음 켜는 PC: 서버 확인이 될 때까지 잠김 (인터넷이 안 되면 못 씀 - 사용자 결정)
- 제작자 PC: 자기 텔레그램 봇 토큰으로 서명해서 '제작자'임을 증명 (토큰은 밖으로 안 나감, 코드에 비밀값 없음)
"""
import hashlib
import hmac
import json
import os
import socket
import threading
import time
import urllib.request

UA = 'FCMacroFriends/1.0'
SALT = 'fc-ddalkkak|'
WAIT_POLL = 10           # 승인 기다리는 동안 몇 초마다 확인
RETRY = 30               # 서버 연결이 안 될 때 다시 시도


def machine_guid():
    """Windows 고유 번호 (윈도우를 새로 깔면 바뀜). 시험용 FCMACRO_TEST_MID"""
    if os.environ.get('FCMACRO_TEST_MID'):
        return os.environ['FCMACRO_TEST_MID']
    try:
        import winreg
        k = winreg.OpenKey(winreg.HKEY_LOCAL_MACHINE, r'SOFTWARE\Microsoft\Cryptography', 0,
                           winreg.KEY_READ | getattr(winreg, 'KEY_WOW64_64KEY', 0))
        v, _ = winreg.QueryValueEx(k, 'MachineGuid')
        winreg.CloseKey(k)
        if v:
            return str(v)
    except Exception:                                   # noqa: BLE001
        pass
    try:
        with open('/etc/machine-id', encoding='ascii') as f:
            return f.read().strip()
    except OSError:
        return 'node-%x' % __import__('uuid').getnode()


def pc_name():
    return (os.environ.get('COMPUTERNAME') or socket.gethostname() or 'PC')[:20]


class License:
    """state: checking(확인 중) / ok / wait(승인 기다림) / none(이름 적고 요청 필요) / no(거절) / block(차단) / error(서버 연결 안 됨)"""

    def __init__(self, data_dir, url, ver, log=None, fid_fn=None, admin_fn=None, on_change=None):
        self.path = os.path.join(data_dir, 'license.json')
        self.url = (url or '').strip()
        self.ver = ver
        self.log = log or (lambda m: None)
        self.fid_fn = fid_fn or (lambda: '')
        self.admin_fn = admin_fn or (lambda: None)     # -> (봇 토큰, 대화 번호) / None
        self.on_change = on_change or (lambda st: None)
        self.mid = hashlib.sha256((SALT + machine_guid()).encode('utf-8')).hexdigest()[:32]
        self.s = {}
        try:
            with open(self.path, encoding='utf-8') as fp:
                self.s = json.load(fp)
        except (OSError, ValueError):
            pass
        if len(str(self.s.get('key', ''))) < 32:
            self.s = {'key': os.urandom(16).hex()}
            self._save()
        self.admin = False
        self.name = self.s.get('name', '')
        self.err = ''
        self.last_check = 0.0
        self.lock = threading.Lock()
        self._t = None
        self._stop = threading.Event()
        self.state = 'ok' if self.local_ok() else 'checking'
        self.started_ok = self.state == 'ok'          # 이번에 켜진 동안 승인된 적 있나 (있으면 켜진 동안은 안 막음)

    # ── 이 PC 기록 ─────────────────────────────
    def _save(self):
        try:
            tmp = self.path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as fp:
                json.dump(self.s, fp, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def _sig(self):
        return hashlib.sha256(('%s|%s|approved' % (self.s['key'], self.mid)).encode('utf-8')).hexdigest()

    def local_ok(self):
        return hmac.compare_digest(str(self.s.get('ok', '')), self._sig())

    @property
    def ok(self):
        return self.state == 'ok'

    def auth(self):
        """친구 랭킹 서버에 붙일 것 (승인 전이면 None)"""
        return {'mid': self.mid, 'key': self.s['key']} if self.state == 'ok' else None

    def short_id(self):
        return '%s…%s' % (self.mid[:4], self.mid[-2:])

    # ── 서버 ──────────────────────────────────
    def _post(self, d, timeout=20):
        data = json.dumps(d, ensure_ascii=False).encode('utf-8')
        req = urllib.request.Request(self.url, data=data, method='POST',
                                     headers={'Content-Type': 'text/plain; charset=utf-8', 'User-Agent': UA})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return json.loads(r.read().decode('utf-8', 'replace'))

    def _sign(self, msg, d):
        a = self.admin_fn()
        if not a or not a[0]:
            return d
        ts = int(time.time() * 1000)
        d.update(ts=ts, sig=hmac.new(a[0].strip().encode('utf-8'), ('%s|%d' % (msg, ts)).encode('utf-8'),
                                     hashlib.sha256).hexdigest())
        if a[1]:
            d['chat'] = str(a[1])
        return d

    def check(self, name=None):
        """서버에 확인 (name 이 있으면 등록 요청까지) -> 새 state"""
        if not self.url:
            self._set('error', '서버 주소 없음')
            return self.state
        d = {'op': 'reg', 'mid': self.mid, 'key': self.s['key'], 'fid': self.fid_fn() or '', 'pc': pc_name(), 'ver': self.ver}
        if name:
            d['name'] = name.strip()[:16]
        self._sign('hello|' + self.mid, d)
        try:
            res = self._post(d)
        except Exception as e:                                         # noqa: BLE001
            self.last_check = time.time()
            if self.state == 'ok':                                     # 승인된 PC: 서버가 잠깐 안 돼도 그대로
                self.err = '서버 응답 없음 (승인 기록으로 계속): %s' % ('%s' % e)[:60]
                return self.state
            self._set('error', '서버에 연결하지 못했어요 (%s)' % ('%s' % e)[:60])
            return self.state
        self.last_check = time.time()
        if not res.get('ok'):
            if self.state == 'ok':
                return self.state
            self._set('error', {'busy': '요청이 너무 많아요. 잠시 뒤 다시 시도해 주세요'}.get(res.get('err'), '서버 오류: %s' % res.get('err')))
            return self.state
        self.admin = bool(res.get('admin'))
        st = res.get('st') if res.get('st') in ('ok', 'wait', 'none', 'no', 'block') else 'error'
        if res.get('name'):
            self.name = self.s['name'] = res['name']
        if st == 'ok':
            if not self.local_ok():
                self.s['ok'] = self._sig()
                self.s['at'] = int(time.time())
                self._save()
            self.started_ok = True                     # 이번에 켜진 동안은 계속 사용 (차단은 다음에 켤 때부터)
            self._set('ok')
        else:
            if self.local_ok():                                       # 서버가 분명히 '아님' -> 다음에 켤 때부터 막힘
                self.s.pop('ok', None)
                self._save()
                self.log('등록: 서버가 이 PC를 %s 상태로 알려 줌 - 다음에 켤 때부터 막힘' % st)
            if self.started_ok:
                self.err = '서버에서 %s 상태 (지금은 계속, 다음에 켤 때부터 막힘)' % {'wait': '대기', 'none': '기록 없음',
                                                                          'no': '거절', 'block': '차단'}.get(st, st)
                return self.state
            self._set(st)
        return self.state

    def _set(self, st, err=''):
        self.err = err
        if st != self.state:
            self.state = st
            self.log('등록 상태: %s%s' % (st, (' - ' + err) if err else ''))
            try:
                self.on_change(st)
            except Exception:                                          # noqa: BLE001
                pass

    def request(self, name):
        """[등록 요청] 버튼"""
        name = (name or '').strip()[:16]
        if not name:
            return self.state
        self.s['req_name'] = name
        self.s['req_at'] = int(time.time())
        self._save()
        return self.check(name)

    # ── 켜질 때 ───────────────────────────────
    def start(self):
        """따로 스레드: 승인된 PC는 한 번 확인(차단 여부, 제작자 여부)만, 아니면 승인될 때까지 확인"""
        if self._t is None:
            self._t = threading.Thread(target=self._run, name='license', daemon=True)
            self._t.start()

    def _run(self):
        if self.state == 'ok':
            self.check()
            return
        # 처음: 기존 사용자면 이름 없이도 자동 승인. 요청을 보냈던 PC면 같은 이름으로 다시 (서버가 기록을 지운 경우)
        self.check(None)
        while not self._stop.is_set() and self.state != 'ok':
            if self.state in ('none', 'no', 'block'):
                self._stop.wait(WAIT_POLL)          # 버튼을 기다림 (거절·차단도 시트에서 풀릴 수 있어 계속 확인)
                if self.state in ('no', 'block', 'wait'):
                    self.check()
                continue
            self._stop.wait(WAIT_POLL if self.state == 'wait' else RETRY)
            if not self._stop.is_set():
                self.check()

    def stop(self):
        self._stop.set()

    # ── 제작자 명령 ───────────────────────────
    def adm(self, act, rid=''):
        """승인/거절/차단/목록 -> 서버 응답 dict"""
        d = self._sign('%s|%s' % (act, rid), {'op': 'adm', 'act': act, 'rid': rid})
        if 'sig' not in d:
            return {'ok': False, 'err': 'no token'}
        try:
            return self._post(d)
        except Exception as e:                                         # noqa: BLE001
            return {'ok': False, 'err': '서버 연결 실패: %s' % ('%s' % e)[:60]}
