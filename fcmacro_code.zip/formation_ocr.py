# -*- coding: utf-8 -*-
"""
경기 전 라인업 화면의 '포메이션' 글자(예: 4-2-2-2) 읽기

원리
  1) 오른쪽 아래 '포메이션' 라벨(images/formation_label.png)을 찾아 기준점으로 삼음
  2) 라벨 바로 아래 흰 글씨를 글자 덩어리로 나눔 (높은 덩어리 = 숫자, 납작한 덩어리 = '-')
  3) 숫자는 견본(images/formation_digits/N.png + 기록 폴더 formation_digits/N.png)과 비교
  4) 검산: 숫자들의 합이 10(필드 플레이어 수)이고 3~5줄이어야 인정 -> 잘못 읽은 포메이션은 기록하지 않음
  5) 견본이 없는 숫자 자동 학습: 모르는 글자가 모두 같은 모양이고 합 10을 맞추는 숫자가 하나뿐이면
     그 숫자로 보고 기록 폴더 formation_digits 에 견본으로 저장 (예: 4-3-3 -> 3 학습, 4-1-4-1 -> 1 학습)
  6) 그래도 못 읽으면 글자 부분을 formation_samples 폴더에 저장 (보내 주면 견본 추가)

'상대 기록' 패널(images/opp_record.png)이 왼쪽에 있으면 상대 팀 화면, 없으면 내 팀 화면으로 봄.
"""
import os
import time

import cv2
import numpy as np

import paths

TEXT_TH = 150            # 이 밝기 초과 = 흰 글씨
DIGIT_H = (9, 18)        # 숫자로 인정할 높이(px) 범위 (1280x720 기준 약 13px)
DASH_MAX_H = 4           # 이 높이 이하이고 가로가 더 길면 '-'
MIN_SIM = 0.85           # 견본과의 최소 유사도 (같은 숫자 0.93~1.0, 2와 4는 0.65)
SAME_SHAPE = 0.90        # 모르는 글자끼리 같은 모양으로 볼 유사도
WIDTH_TOL = 3            # 견본과 글자 가로폭 차이 허용(px) ('1'처럼 좁은 글자를 다른 숫자로 오인하지 않게)
LEARN_DIR = 'formation_digits'       # 기록 폴더 안 (자동 학습 견본)
SAMPLE_DIR = 'formation_samples'     # 기록 폴더 안 (못 읽은 글자)
SAMPLE_MAX = 60

# '포메이션' 라벨(왼쪽 위) 기준 글씨 영역: 글씨는 라벨 오른쪽 끝에 맞춰 오른쪽 정렬
AREA_DX0, AREA_DX1 = -40, 10         # 라벨.left + DX0 ~ 라벨.right + DX1 (왼쪽 '강화 팀컬러' 글씨는 빼고)
GAP_MAX = 7                          # 글자 사이 간격이 이보다 크면 다른 글씨 (오른쪽 끝 덩어리만 사용)
AREA_DY0, AREA_DY1 = 4, 34           # 라벨.bottom + DY0 ~ 라벨.bottom + DY1

_tpl = None


def _files(d):
    try:
        return [os.path.join(d, f) for f in sorted(os.listdir(d)) if f.lower().endswith('.png')]
    except OSError:
        return []


def load_templates(reload=False):
    """{숫자: [(정규화 배열, 가로폭, 파일)]} - 내장 견본 + 기록 폴더의 학습 견본. 파일 이름 '3.png', '3_2.png' 모두 가능"""
    global _tpl
    if _tpl is not None and not reload:
        return _tpl
    t = {}
    dirs = [paths.resource(os.path.join('images', 'formation_digits')), LEARN_DIR]
    for d in dirs:
        for p in _files(d):
            name = os.path.basename(p)
            if not name[0].isdigit():
                continue
            img = paths.imread(p)
            if img is None:
                continue
            g = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY) if img.ndim == 3 else img
            g = _tight(g)
            t.setdefault(int(name[0]), []).append((g, g.shape[1], p))
    _tpl = t
    return t


def _tight(g):
    ys, xs = np.nonzero(g > TEXT_TH)
    if len(xs) == 0:
        return g
    return g[ys.min():ys.max() + 1, xs.min():xs.max() + 1]


def area_of(label_box):
    """'포메이션' 라벨 위치(화면 좌표 Box) -> 글씨 영역 (x, y, w, h)"""
    x0 = int(label_box.left) + AREA_DX0
    x1 = int(label_box.left + label_box.width) + AREA_DX1
    y0 = int(label_box.top + label_box.height) + AREA_DY0
    y1 = int(label_box.top + label_box.height) + AREA_DY1
    return (x0, y0, x1 - x0, y1 - y0)


def glyphs(gray):
    """글씨 영역(gray) -> [('d', 잘라낸 gray, x) / ('-', None, x)] 왼쪽부터. 숫자 줄(가장 많은 높이)만"""
    b = (gray > TEXT_TH).astype(np.uint8)
    n, lab, stats, _c = cv2.connectedComponentsWithStats(b, connectivity=8)
    comps = []
    for i in range(1, n):
        x, y, w, h, area = stats[i]
        if area < 3:
            continue
        comps.append((x, y, w, h))
    digs = [c for c in comps if DIGIT_H[0] <= c[3] <= DIGIT_H[1]]
    if not digs:
        return []
    top = int(np.median([c[1] for c in digs]))
    bot = int(np.median([c[1] + c[3] for c in digs]))
    out = []
    for (x, y, w, h) in comps:
        if DIGIT_H[0] <= h <= DIGIT_H[1] and abs(y - top) <= 3:
            out.append(('d', gray[y:y + h, x:x + w], x))
        elif h <= DASH_MAX_H and w >= h and top < y < bot:
            out.append(('-', None, x))
    out.sort(key=lambda t: t[2])
    # 오른쪽 끝(포메이션 글씨)에서 왼쪽으로 붙어 있는 글자만
    keep = []
    for k, g, x in reversed(out):
        w = g.shape[1] if g is not None else 0
        if keep and keep[-1][2] - (x + max(w, 3)) > GAP_MAX:
            break
        keep.append((k, g, x))
    return list(reversed(keep))


def match(g, t):
    """글자 g 와 견본 t (둘 다 원래 크기 gray) 유사도: 1px 정도 어긋남·가로폭 차이를 허용하도록 g 주변을 넓혀 위치를 찾음"""
    if abs(g.shape[0] - t.shape[0]) > 3 or abs(g.shape[1] - t.shape[1]) > WIDTH_TOL:
        return -1.0
    pad = 3
    bg = int(np.percentile(g, 10))
    big = cv2.copyMakeBorder(g, pad, pad, pad, pad, cv2.BORDER_CONSTANT, value=bg)
    if big.shape[0] < t.shape[0] or big.shape[1] < t.shape[1]:
        return -1.0
    r = cv2.matchTemplate(big.astype(np.float32), t.astype(np.float32), cv2.TM_CCOEFF_NORMED)
    return float(r.max())


def _classify(g, tpl):
    """-> (숫자 또는 None, 유사도)"""
    best, bv = None, -1.0
    for d, lst in tpl.items():
        for t, _w, _p in lst:
            v = max(match(g, t), match(t, g))
            if v > bv:
                best, bv = d, v
    return (best, bv) if bv >= MIN_SIM else (None, bv)


def valid(groups):
    return 3 <= len(groups) <= 5 and all(0 <= v <= 6 for v in groups) and sum(groups) == 10


def read(gray, learn=True):
    """
    글씨 영역(gray) -> {'text': '4-2-2-2' 또는 None, 'why': 설명, 'learned': [(숫자, 파일)]}
    """
    gl = glyphs(gray)
    if not gl:
        return {'text': None, 'why': '글씨 없음', 'learned': []}
    # 모양 검사: 숫자-(대시-숫자)* 형태
    kinds = [k for k, _g, _x in gl]
    if kinds[0] != 'd' or kinds[-1] != 'd' or any(kinds[i] == kinds[i + 1] for i in range(len(kinds) - 1)):
        return {'text': None, 'why': '글자 배열이 포메이션 모양이 아님 (%s)' % ''.join('#' if k == 'd' else '-' for k in kinds),
                'learned': []}
    digs = [g for k, g, _x in gl if k == 'd']
    tpl = load_templates()
    vals = [_classify(g, tpl) for g in digs]
    unknown = [i for i, (d, _s) in enumerate(vals) if d is None]
    learned = []
    if unknown:
        known_sum = sum(d for d, _s in vals if d is not None)
        n_unk = len(unknown)
        rest = 10 - known_sum
        same = all(max(match(digs[unknown[0]], digs[j]), match(digs[j], digs[unknown[0]])) >= SAME_SHAPE for j in unknown[1:])
        n_groups = len(digs)
        if not (learn and same and rest >= 0 and rest % n_unk == 0 and 3 <= n_groups <= 5):
            return {'text': None, 'why': '모르는 숫자 %d개 (견본 없음)' % n_unk, 'learned': [], 'glyphs': digs, 'vals': vals}
        v = rest // n_unk
        if v in tpl or not (0 <= v <= 6):
            # 이미 견본이 있는 숫자인데 안 맞음 -> 학습하지 않음 (잘못 배울 위험)
            return {'text': None, 'why': '숫자 모양이 견본과 다름 (추정 %d)' % v, 'learned': [], 'glyphs': digs, 'vals': vals}
        p = save_learned(v, digs[unknown[0]])
        if p:
            learned.append((v, p))
            load_templates(reload=True)
        for i in unknown:
            vals[i] = (v, 0.0)
    groups = [d for d, _s in vals]
    if not valid(groups):
        return {'text': None, 'why': '검산 실패 (%s, 합 %d)' % ('-'.join(map(str, groups)), sum(groups)),
                'learned': learned, 'glyphs': digs, 'vals': vals}
    return {'text': '-'.join(map(str, groups)), 'why': 'ok', 'learned': learned}


def save_learned(v, g):
    try:
        os.makedirs(LEARN_DIR, exist_ok=True)
        p = os.path.join(LEARN_DIR, '%d.png' % v)
        k = 2
        while os.path.exists(p):
            p = os.path.join(LEARN_DIR, '%d_%d.png' % (v, k))
            k += 1
        paths.imwrite(p, g)
        return p
    except Exception:
        return None


def save_sample(gray, tag=''):
    """못 읽은 글씨 영역 저장 (확대본 같이) -> 파일 경로 또는 None"""
    try:
        os.makedirs(SAMPLE_DIR, exist_ok=True)
        if len(os.listdir(SAMPLE_DIR)) >= SAMPLE_MAX * 2:
            return None
        stamp = time.strftime('%Y%m%d_%H%M%S')
        p = os.path.join(SAMPLE_DIR, '%s%s.png' % (stamp, ('_' + tag) if tag else ''))
        paths.imwrite(p, gray)
        big = cv2.resize(gray, None, fx=6, fy=6, interpolation=cv2.INTER_NEAREST)
        paths.imwrite(p[:-4] + '_x6.png', big)
        return p
    except Exception:
        return None
