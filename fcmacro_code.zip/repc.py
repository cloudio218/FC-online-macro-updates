# -*- coding: utf-8 -*-
"""v4.2 리피시(Re:PC)까지 종료

원격 모드로 돌리다 멈출 때(돌릴 시간 · 종료 시각 · 막판종료 · 텔레그램 [리피시까지 종료]):
  1) 매크로 창 내림 (항상 위 매크로 창이 리피시 아이콘·버튼을 가리지 않게)
  2) 원격 화면 속 게임 창 X  -> 게임 창이 사라졌는지 확인 (확인 창 없음 - 사용자 확인)
  3) 리피시 떠 있는 아이콘 클릭 -> 메뉴의 빨간 [종료]  (확인 창 없음 - 사용자 확인)
  4) 내 PC의 'Re:PC' 첫 화면 오른쪽 위 [로그아웃 및 사용종료]
단계마다 다음 화면이 실제로 떴는지 보고 넘어감 (각 3번까지), 못 하면 거기서 멈추고 알림.
화면·클릭·창 찾기는 io 로 받음 (시험에서 가짜로 바꿀 수 있게)
"""
import re
import time

import cv2
import numpy as np

STEPS = ['이번 판 끝 · 로비', '매크로 창 내림', '게임 창 닫기', '리피시 [종료]', '로그아웃 및 사용종료']
ICON_CONF = 0.72          # 반투명 아이콘이라 뒤 화면에 따라 점수가 조금 떨어짐
END_CONF = 0.80
LOGOUT_CONF = 0.80
GX_CONF = 0.80
ICON_CLICK = (21, 22)     # repc_icon.png 왼쪽 위 기준 아이콘 가운데
TRIES = 3


def is_launcher_title(t):
    return (t or '').strip().lower().startswith('re:pc')


def minutes_left(title):
    """'Re:PC - 아이디 남은시간:1053분(사용중-11분)' -> 1053 / None"""
    m = re.search(r'남은\s*시간\s*:?\s*(\d+)\s*분', title or '')
    return int(m.group(1)) if m else None


def _match(gray, tpl, area=None):
    """(점수, (x, y) 화면 좌표) - area=(x0, y0, x1, y1)"""
    x0 = y0 = 0
    g = gray
    if area is not None:
        H, W = gray.shape[:2]
        x0, y0 = max(0, int(area[0])), max(0, int(area[1]))
        x1, y1 = min(W, int(area[2])), min(H, int(area[3]))
        g = gray[y0:y1, x0:x1]
    if g.shape[0] < tpl.shape[0] or g.shape[1] < tpl.shape[1]:
        return 0.0, None
    r = cv2.matchTemplate(g, tpl, cv2.TM_CCOEFF_NORMED)
    _mn, mx, _l, loc = cv2.minMaxLoc(r)
    if not np.isfinite(mx) or mx > 1.01:
        return 0.0, None
    return float(mx), (loc[0] + x0, loc[1] + y0)


def _reddish(rgb, x, y, w, h):
    """메뉴의 [종료]는 빨간 글씨 - 다른 곳의 '종료' 글자와 구분"""
    box = rgb[y:y + h, x:x + w].astype(int)
    if box.size == 0:
        return False
    red = (box[:, :, 0] > 170) & (box[:, :, 1] < 150) & (box[:, :, 2] < 170)
    return int(red.sum()) >= 15


class Shutdown:
    """io: grab() -> RGB np.array 화면 전체 / click(x, y) / sleep(s) / log(msg) / remote_region() -> (x,y,w,h)|None
           windows() -> [(hwnd, title, (l, t, r, b))] / activate(hwnd) / hide_macro() / wait_idle() / progress(i, text)
           tpl(name) -> gray np.array / icon_pos (기억한 아이콘 자리, 없으면 None)"""

    def __init__(self, io):
        self.io = io
        self.step = 0
        self.icon_pos = getattr(io, 'icon_pos', None)

    def _p(self, i, text=''):
        self.step = i
        try:
            self.io.progress(i, text or STEPS[i])
        except Exception:
            pass

    def _click(self, x, y):
        self.io.wait_idle()
        self.io.click(int(x), int(y))

    def _gray(self):
        rgb = self.io.grab()
        return rgb, cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)

    def run(self):
        """-> (성공?, 단계 번호, 설명)"""
        io = self.io
        self._p(1)
        try:
            io.hide_macro()
        except Exception:
            pass
        io.sleep(0.8)
        # 3) 게임 창 닫기
        self._p(2)
        ok, why = self.close_game()
        if not ok:
            return False, 2, why
        # 4) 리피시 [종료]
        self._p(3)
        ok, why = self.end_session()
        if not ok:
            return False, 3, why
        # 5) 로그아웃 및 사용종료
        self._p(4)
        ok, why = self.logout()
        if not ok:
            return False, 4, why
        return True, 5, why

    # ── 게임 창 ──
    def game_gone(self, sec=8):
        """원격 화면에서 게임 창 제목줄이 두 번 연속 안 보이면 닫힌 것"""
        miss = 0
        end = time.time() + sec
        while True:
            miss = miss + 1 if self.io.remote_region() is None else 0
            if miss >= 2:
                return True
            if time.time() >= end:
                return False
            self.io.sleep(1.0)

    def close_game(self):
        io = self.io
        for n in range(TRIES):
            reg = io.remote_region()
            if reg is None:
                if self.game_gone(3):
                    io.log('리피시 종료: 게임 창이 이미 없음')
                    return True, '게임 창 이미 없음'
                continue
            x, y, w, h = reg
            _rgb, g = self._gray()
            sc, loc = _match(g, io.tpl('repc_gx.png'), (x + w - 90, y - 4, x + w + 6, y + 30))
            if loc is not None and sc >= GX_CONF:
                cx, cy = loc[0] + 10, loc[1] + 8
            else:
                cx, cy = x + w - 26, y + 12                      # 1280x720 창 제목줄 X 자리
            io.log('리피시 종료: 게임 창 X 클릭 (%d, %d) · X 유사도 %.2f · %d번째' % (cx, cy, sc, n + 1))
            self._click(cx, cy)
            if self.game_gone(10):
                io.log('리피시 종료: 게임 창 닫힘')
                return True, '게임 창 닫힘'
        return False, '게임 창 X를 %d번 눌렀는데 안 닫힘' % TRIES

    # ── 리피시 메뉴 [종료] ──
    def find_icon(self, g):
        sc, loc = _match(g, self.io.tpl('repc_icon.png'))
        if loc is not None and sc >= ICON_CONF:
            self.icon_pos = loc
            try:
                self.io.save_icon(loc)
            except Exception:
                pass
            return sc, loc
        return sc, None

    def launcher(self):
        for hwnd, title, rect in self.io.windows():
            if is_launcher_title(title):
                return hwnd, title, rect
        return None

    def session_over(self, sec=12):
        """[종료] 뒤: 리피시 아이콘이 사라지고 Re:PC 첫 화면 창이 보이면"""
        end = time.time() + sec
        while True:
            _rgb, g = self._gray()
            sc, _loc = _match(g, self.io.tpl('repc_icon.png'))
            if sc < ICON_CONF and self.launcher() is not None:
                return True
            if time.time() >= end:
                return False
            self.io.sleep(1.0)

    def end_session(self):
        io = self.io
        for n in range(TRIES):
            rgb, g = self._gray()
            sc, loc = self.find_icon(g)
            if loc is None and self.icon_pos is not None:
                loc = self.icon_pos
                io.log('리피시 종료: 아이콘을 못 찾아(%.2f) 기억한 자리 %s 사용' % (sc, loc))
            if loc is None:
                if self.launcher() is not None and n > 0:
                    return True, '이미 리피시 첫 화면'
                io.log('리피시 종료: 리피시 아이콘을 못 찾음 (유사도 %.2f)' % sc)
                io.sleep(1.5)
                continue
            self._click(loc[0] + ICON_CLICK[0], loc[1] + ICON_CLICK[1])
            io.sleep(0.9)
            rgb, g = self._gray()
            area = (loc[0] - 30, loc[1] + 25, loc[0] + 320, loc[1] + 760)
            sc2, eloc = _match(g, io.tpl('repc_end.png'), area)
            t = io.tpl('repc_end.png')
            if eloc is None or sc2 < END_CONF or not _reddish(rgb, eloc[0], eloc[1], t.shape[1], t.shape[0]):
                io.log('리피시 종료: 메뉴의 [종료]를 못 찾음 (유사도 %.2f) - %d번째' % (sc2, n + 1))
                io.sleep(0.8)
                continue
            io.log('리피시 종료: 메뉴 [종료] 클릭 %s (유사도 %.2f)' % (eloc, sc2))
            self._click(eloc[0] + t.shape[1] // 2, eloc[1] + t.shape[0] // 2)
            if self.session_over():
                return True, '리피시 원격 종료됨'
        return False, '리피시 메뉴의 [종료]를 못 눌렀어요'

    # ── 로그아웃 및 사용종료 ──
    def logout(self):
        io = self.io
        for n in range(TRIES):
            lw = self.launcher()
            if lw is None:
                if n > 0:
                    return True, '리피시 창 닫힘'
                return False, "'Re:PC' 첫 화면 창을 못 찾음"
            hwnd, title, (l, t, r, b) = lw
            try:
                io.activate(hwnd)
            except Exception:
                pass
            io.sleep(0.8)
            lw = self.launcher() or lw
            hwnd, title, (l, t, r, b) = lw
            _rgb, g = self._gray()
            tp = io.tpl('repc_logout.png')
            sc, loc = _match(g, tp, (r - 420, t, r, t + 140))
            if loc is not None and sc >= LOGOUT_CONF:
                cx, cy = loc[0] + tp.shape[1] // 2, loc[1] + tp.shape[0] // 2
            else:
                cx, cy = r - 143, t + 51                              # 사용자 화면 (1920 폭) 기준 자리
            io.log('리피시 종료: [로그아웃 및 사용종료] 클릭 (%d, %d) · 유사도 %.2f · %d번째' % (cx, cy, sc, n + 1))
            self._click(cx, cy)
            end = time.time() + 12
            while time.time() < end:
                io.sleep(1.0)
                cur = self.launcher()
                if cur is None:
                    return True, '로그아웃 및 사용종료 완료'
                if '사용중' not in cur[1] and cur[1] != title:
                    return True, '로그아웃 완료 (창: %s)' % re.sub(r'\s.*', '', cur[1])
        return False, '[로그아웃 및 사용종료]를 눌렀는데 리피시 창이 그대로예요 (확인 창이 떴을 수 있어요)'
