# -*- coding: utf-8 -*-
"""v4.0 이적시장 갱신꾼 - 화면 없는 부분 (갱신 매크로 v3.6.1 App 에서 옮김)

- 설정(cfg)이 기준: 화면(transfer_ui)은 cfg 를 고치고 save() 만 부름
- 엔진(transfer_core.Worker)의 큐 메시지를 poll() 이 받아 상태·기록·결과로 정리 -> 화면이 그려 감
- 텔레그램: 갱신싸움꾼 봇 따로 (감독모드 봇과 섞이지 않음)
- 위치 지정은 게임 화면 위에 띄우는 오버레이(pick_on_screen)를 그대로 씀 (root = 매크로 창)
"""
import collections
import datetime
import json
import os
import queue
import re
import shutil
import threading
import time
import traceback

import transfer_core as T

STATE_TEXT = {
    'idle': ('정지', 'dim'), 'armed': ('예약 대기', 'yel'), 'ready': ('준비 중', 'yel'), 'wait': ('대기 중', 'yel'),
    'limit': ('거래 제한 · 경기 대기', 'org'), 'fight': ('갱신싸움 중', 'green'), 'success': ('갱신 성공!', 'cyan'),
    'error': ('멈춤', 'red'),
}
PSTATE_KIND = {'idle': 'off', 'armed': 'res', 'run': 'run', 'limit': 'org', 'success': 'ok', 'timeout': 'off',
               'error': 'red'}


class TransferCtl:
    def __init__(self, base_dir, images_dir=None, version='4.0', log=None):
        T.configure(base_dir)
        T.VERSION = version
        if images_dir:
            p = os.path.join(images_dir, 'tr_home_market.png')
            if os.path.exists(p):
                T.EXTRA_TEMPLATES['home_market'] = p
        self.base = base_dir
        self.ext_log = log or (lambda m: None)
        self.cfg = T.load_cfg()
        self.q = queue.Queue()
        self.worker = None
        self.mode = None
        self.tgbot = None
        self.tg_finding = False
        self._tg_t = 0.0
        self._day = '%s' % datetime.date.today()
        self.state, self.sub = 'idle', ''
        self.logs = collections.deque(maxlen=300)
        self.pst = {}                       # 프리셋 번호 -> (상태, 글자)
        self.preview = None                 # (제목, PIL 그림)
        self.prices = {}                    # 프리셋 번호 -> {'mine', 'target', 'label', 't'}
        self.had_success = False
        self.alerts = collections.deque()   # 화면이 메시지 창으로 보여 줄 것 (제목, 글)
        self.results = collections.deque()  # 갱신 직후 결과 (제목, BGR 배열, 저장 경로)
        self.res_info = ''
        self.hints = {}
        self.tg_label = ('', 'dim')
        self.time_label = ('', 'dim')
        self.rev = 0                        # 바뀔 때마다 +1 (화면이 다시 그릴지 판단)
        self.hist_rev = 0
        self.on_hotkey = None

    # ── 기본 ──
    def save(self):
        T.save_cfg(self.cfg)
        self.rev += 1

    def reload(self):
        if self.worker is None:
            self.cfg = T.load_cfg()
            self.rev += 1

    def log(self, m, kind='info'):
        now = datetime.datetime.now()
        try:
            os.makedirs(T.LOG_DIR, exist_ok=True)
            with open(os.path.join(T.LOG_DIR, '%s.txt' % now.strftime('%Y%m%d')), 'a', encoding='utf-8') as f:
                f.write('[%s] [%s] %s\n' % (now.strftime('%H:%M:%S'), kind, m))
        except Exception:
            pass
        self.logs.append((now.strftime('%H:%M:%S'), str(m), kind))
        self.rev += 1

    def running(self):
        return self.worker is not None

    def name(self, i):
        return self.cfg['presets'][i]['name'] or '프리셋 %d' % (i + 1)

    def enabled(self):
        return [i for i, p in enumerate(self.cfg['presets']) if p['enabled']]

    def ready(self, i):
        return T.preset_ready(self.cfg['presets'][i], i)

    def now(self):
        return time.time() + float(self.cfg.get('clock_offset', 0) or 0)

    # ── 검사 · 시작 · 정지 ──
    def validate(self, mode, idx):
        c = self.cfg
        c['sensitivity'] = max(1, int(c.get('sensitivity', 12)))
        if not (0 <= c['start_sec'] <= 59 and 0 <= c['end_sec'] <= 59) or c['start_sec'] == c['end_sec']:
            raise ValueError('매 분 구간은 0~59초 사이, 시작과 끝을 다르게 넣어 주세요')
        if c['duration_min'] <= 0:
            raise ValueError('갱신싸움 시간은 1분 이상으로 넣어 주세요')
        idxs = [idx] if idx is not None else self.enabled()
        if not idxs:
            raise ValueError("프리셋에서 '사용'을 켠 선수가 없어요")
        miss = []
        if 'dialog' not in c['rects'] or not os.path.exists(T.tmpl_path('dialog')):
            miss.append('위치 지정 › 구매 창 표시')
        if 'panel_lobby' not in c['rects'] or not os.path.exists(T.tmpl_path('header_lobby')):
            miss.append('위치 지정 › ① 창 범위 (이적시장이 열려 있는지 판단할 때 필요)')
        if c['screen_mode'] == 'manager' and not T.manager_ready(c):
            miss.append("위치 지정 › ②③ 감독모드 (화면 모드가 '감독모드만'이라서)")
        if mode != 'test' and c['confirm'] != 'enter' and 'buy_btn' not in c['points']:
            miss.append('위치 지정 › 구매 버튼 (확정 방식이 클릭이라서)')
        for i in idxs:
            p = c['presets'][i]
            if not (0 <= int(p['minute']) <= 59):
                miss.append('%d번 %s: 분은 0~59' % (i + 1, p['name']))
            if 'reg_btn' not in p['points']:
                miss.append('%d번 %s: 재등록 위치' % (i + 1, p['name']))
            if 'row_check' not in p['rects'] or not os.path.exists(T.tmpl_path('row_check_%d' % i)):
                miss.append('%d번 %s: 선수이름' % (i + 1, p['name']))
            if p['target'] not in c['rects']:
                miss.append('위치 지정 › %s 숫자' % T.TARGET[p['target']])
            if p.get('side') == 'sell' and ('dialog_sell' not in c['rects'] or not os.path.exists(T.tmpl_path('dialog_sell'))):
                miss.append("위치 지정 › 판매 창 표시 (%d번 %s이(가) '판매'라서)" % (i + 1, p['name']))
        if miss:
            raise ValueError('먼저 확인해 주세요:\n· ' + '\n· '.join(dict.fromkeys(miss)))
        T.save_cfg(c)

    def start(self, mode='schedule', idx=None, remote=False):
        """-> None(시작함) / 못 한 이유"""
        if self.worker:
            return '이미 진행 중이에요'
        try:
            self.validate(mode, idx)
        except ValueError as e:
            return str(e)
        self.had_success = False
        self.pst = {}
        self.worker = T.Worker(json.loads(json.dumps(self.cfg)), self.q, mode=mode, only=idx)
        self.mode = mode
        self.worker.start()
        label = {'schedule': '예약 시작', 'now': '%s번 지금 시작' % ((idx or 0) + 1),
                 'test': '%s번 테스트' % ((idx or 0) + 1)}[mode]
        self.log(label + (' (텔레그램)' if remote else ''))
        self.ext_log('갱신꾼: ' + label)
        if mode == 'test' and not self.cfg.get('tested'):
            self.cfg['tested'] = True            # v4.1 사용법 6단계 ✓
            self.save()
        return None

    def stop(self):
        if self.worker:
            self.worker.stop()
            return True
        return False

    def control(self, cmd):
        if self.worker is not None:
            self.worker.ctl.put(cmd)

    # ── 큐 처리 (화면 스레드에서 자주) ──
    def poll(self):
        changed = False
        try:
            while True:
                m = self.q.get_nowait()
                changed = True
                self._msg(m)
        except queue.Empty:
            pass
        if time.time() - self._tg_t > 2:
            self._tg_t = time.time()
            self.tg_ensure()
            today = '%s' % datetime.date.today()
            if today != self._day:
                yday, self._day = self._day, today
                if self.cfg.get('tg_daily', True):
                    self.tg_reply(T.day_summary(T.hist_load(), yday))
        if changed:
            self.rev += 1
        return changed

    def _msg(self, m):
        t = m[0]
        if t == 'log':
            self.log(m[1], m[2])
            mm = re.search(r'내 (?:구매|판매) 등록가 (\S+) .{1,3} 지금 (상한가|하한가) (\S+)', m[1])
            if mm:
                self.prices['last'] = {'mine': mm.group(1), 'label': mm.group(2), 'target': mm.group(3), 't': time.time()}
        elif t == 'status':
            self.state, self.sub = m[1], m[2]
        elif t == 'preset':
            self.pst[m[1]] = (m[2], m[3])
        elif t == 'preview':
            try:
                self.preview = (m[1], T.compose(*m[2]))
            except Exception:
                pass
        elif t == 'result':
            self.results.append((m[1], m[2], m[3]))
            self.res_info = '예상 순번 확인 중…  (호가 목록에서 내 가격 줄의 구매 수량)'
        elif t == 'result_info':
            self.res_info = m[1]
        elif t == 'tgchat':
            self.cfg['tg_chat'] = str(m[1])
            self.save()
            self.log('텔레그램 채팅 ID 찾음: %s (%s) — 저장했어요' % (m[1], m[2]), 'ok')
            self.tg_label = ('채팅 ID 찾음: %s (%s) · 저장됨 → [테스트]로 확인하세요' % (m[1], m[2]), 'green')
            self.tg_reply('✅ 연결됐어요! 아래 메뉴 버튼으로 상태 확인·가격 확인·선수 켜고 끄기를 할 수 있어요.', markup=T.TG_KB)
            self.alerts.append(('텔레그램 연결', '채팅 ID를 찾았어요: %s (%s)\n텔레그램에 연결 완료 메시지가 왔는지 확인해 보세요.' % (m[1], m[2])))
        elif t == 'tg_update':
            try:
                self.tg_handle(m[1])
            except Exception:
                self.log('텔레그램 메뉴 처리 오류:\n' + traceback.format_exc(), 'error')
        elif t == 'hist_changed':
            self.hist_rev += 1
        elif t == 'tglbl':
            self.tg_label = (m[1], {'#16a34a': 'green', '#dc2626': 'red', '#c2410c': 'org', '#1d6fe0': 'cyan'}.get(m[2], 'dim'))
        elif t == 'tgalert':
            self.alerts.append(('텔레그램', m[1]))
        elif t == 'clock':
            self.apply_clock(m[1], m[2], m[3])
        elif t == 'tr_hint':
            self.hints[m[1]] = m[2]
        elif t == 'success':
            self.had_success = True
            self.log(m[1], 'ok')
            threading.Thread(target=T._beep_success, daemon=True).start()
        elif t == 'beep_error':
            threading.Thread(target=T._beep_error, daemon=True).start()
        elif t == 'alert':
            self.state, self.sub = 'error', m[1]
            threading.Thread(target=T._beep_error, daemon=True).start()
            self.alerts.append(('갱신꾼', m[1]))
        elif t == 'done':
            self.worker = None
            mode, self.mode = self.mode, None
            res = m[1]
            if len(m) > 2 and m[2] == 'peek':
                return
            if self.state != 'error':
                parts = []
                if res['success']:
                    parts.append('성공: ' + ', '.join(res['success']))
                if res['timeout']:
                    parts.append('시간 종료: ' + ', '.join(res['timeout']))
                if res['error']:
                    parts.append('오류: ' + ', '.join(res['error']))
                self.state = 'success' if self.had_success else 'idle'
                self.sub = ' · '.join(parts) or 'Ctrl+F9 예약 시작'
            self.ext_log('갱신꾼 끝 (%s): %s' % (mode, self.sub))

    # ── 기록 ──
    def today_counts(self):
        h = T.hist_load()
        day = '%s' % datetime.date.today()
        es = [e for e in h if e.get('day') == day and e.get('kind') in T.HIST_KIND]
        return [(k, sum(e['kind'] == k for e in es)) for k in T.HIST_KIND if any(e['kind'] == k for e in es)]

    def preset_stat(self, i):
        succ, tot, seen = T.preset_stats(T.hist_load(), self.name(i))
        sm = T.seen_summary(seen)
        return succ, tot, (sm.split(' (')[0] if sm else '')

    def history(self, n=300):
        return list(reversed([x for x in T.hist_load() if x.get('kind') in T.HIST_KIND][-n:]))

    def next_info(self):
        """[(시작 시각(서버), 번호)] 켜진 선수 다음 갱신 시각 순"""
        now = self.now()
        out = []
        for i, p in enumerate(self.cfg['presets']):
            if p['enabled']:
                out.append((T.next_start(now, p['parity'], int(p['minute'])), i))
        return sorted(out)

    def session_of(self, i):
        w = self.worker
        if w is None:
            return None
        return w.sessions.get(i)

    # ── 프리셋 ──
    def copy_preset(self, i):
        ps = self.cfg['presets']
        j = next((k for k, p in enumerate(ps) if k != i and not p['enabled'] and not T.preset_ready(p, k)
                  and not p['points'] and p['name'] in ('프리셋 %d' % (k + 1), '')), None)
        if j is None:
            return None, "비어 있는 프리셋이 없어요.\n안 쓰는 프리셋의 이름을 '프리셋 N'으로 되돌리면 그 칸에 복사돼요."
        src, dst = ps[i], ps[j]
        for k in ('side', 'parity', 'minute', 'priority', 'target', 'star'):
            dst[k] = src.get(k, dst.get(k))
        dst['name'] = (src['name'] + ' 복사')[:20]
        dst['enabled'] = False
        self.save()
        self.log('%d번 설정을 %d번에 복사했어요 — 선수 이름을 바꾸고 재등록·선수이름·등록가 위치를 지정하세요' % (i + 1, j + 1), 'ok')
        return j, '%d번 칸에 복사했어요.\n선수 이름을 바꾸고, 거래목록에서 그 선수의\n재등록 · 선수이름 · 등록가 위치를 새로 지정해 주세요.' % (j + 1)

    def marks(self):
        """위치 지정 상태 {키: 'ok'/'auto'/'none'/'need'} + 프리셋별 {번호: {키: bool}}"""
        c = self.cfg
        out = {}
        for key, kind, *_ in T.SHARED_ITEMS:
            done = key in (c['points'] if kind == 'point' else c['rects'])
            if key in ('dialog', 'dialog_sell') and done and not os.path.exists(T.tmpl_path(key)):
                done = False
            if key in ('sell_upper', 'sell_lower') and not done:
                out[key] = 'auto' if (key[5:] in c['rects'] and 'dialog_sell' in c['rects']) else 'none'
                continue
            out[key] = 'ok' if done else 'none'
        out['panel_lobby'] = 'ok' if ('panel_lobby' in c['rects'] and os.path.exists(T.tmpl_path('header_lobby'))) else 'need'
        out['panel_manager'] = 'ok' if ('panel_manager' in c['rects'] and os.path.exists(T.tmpl_path('header_manager'))) else 'none'
        out['dialog_manager'] = 'ok' if os.path.exists(T.tmpl_path('dialog_manager')) else 'none'
        pre = {}
        for i, p in enumerate(c['presets']):
            d = {}
            for key, kind, short, _ in T.PRESET_ITEMS:
                done = key in (p['points'] if kind == 'point' else p['rects'])
                if key == 'row_check' and done and not os.path.exists(T.tmpl_path('row_check_%d' % i)):
                    done = False
                d[key] = done
            pre[i] = d
        return out, pre

    def scale_text(self):
        c = self.cfg
        sc = T.layout_scale(c)
        if 'panel_lobby' in c['rects'] and T.same_size(c):
            return '위치 자동 맞춤 켜짐 · 감독모드도 크기가 같으면 ②③ 필요 없어요', 'green'
        if T.manager_ready(c):
            return '보정 완료 · 감독모드 배율 %.2f×%.2f' % (sc[0], sc[1]), 'green'
        if sc:
            return '배율 %.2f×%.2f · 감독모드 구매 창 캡처만 남았어요' % (sc[0], sc[1]), 'org'
        return '① 창 범위를 먼저 지정해 주세요 (시작·테스트에 필요)', 'red'

    # ── 위치 지정 (게임 화면 위 오버레이) ──
    def _game(self):
        hwnd = T.find_game(self.cfg['window_title'])
        if not hwnd:
            raise ValueError('게임 창(FC ONLINE)을 찾을 수 없어요.\n게임을 창 모드로 켜고 다시 해 주세요.')
        return hwnd

    def _offset(self):
        hwnd = T.find_game(self.cfg['window_title'])
        if not hwnd or 'panel_lobby' not in self.cfg['rects']:
            return None
        ox, oy = T.client_origin(hwnd)
        w, h = T.client_size(hwnd)
        with T.mss.mss() as sct:
            client = T.to_arr(sct.grab({'left': ox, 'top': oy, 'width': w, 'height': h}))
        f = T.find_header(client, self.cfg, 'lobby')
        if not f or f[2] < 0.8:
            return None
        return f[0], f[1]

    def pick(self, root, key, idx):
        """-> 안내 글 (실패면 ValueError)"""
        if self.worker:
            raise ValueError('진행 중에는 위치를 지정할 수 없어요 (정지 후 다시)')
        off = (self._offset() or (0, 0)) if idx is not None else (0, 0)
        items = T.PRESET_ITEMS if idx is not None else T.SHARED_ITEMS
        kind, name, guide = next((k2, n, g) for k, k2, n, g in items if k == key)
        hwnd = self._game()
        ox, oy = T.client_origin(hwnd)
        if idx is not None:
            guide = '[%s] %s' % (self.name(idx), guide)
        res = T.pick_on_screen(root, kind, guide)
        if res is None:
            return None
        val, img, (ml, mt) = res
        target = self.cfg['presets'][idx] if idx is not None else self.cfg
        if kind == 'point':
            target['points'][key] = [val[0] - ox - off[0], val[1] - oy - off[1]]
        else:
            x, y, w, h = val
            target['rects'][key] = [x - ox - off[0], y - oy - off[1], w, h]
            tkey = 'row_check_%d' % idx if key == 'row_check' else (key if key in ('dialog', 'dialog_sell') else None)
            if tkey:
                os.makedirs(T.DATA_DIR, exist_ok=True)
                img.crop((x - ml, y - mt, x - ml + w, y - mt + h)).save(T.tmpl_path(tkey))
        self.save()
        where = '%d번 ' % (idx + 1) if idx is not None else ''
        shift = ' (지금 화면 위치 %+d, %+dpx 보정해서 저장)' % off if off != (0, 0) else ''
        msg = "%s'%s' 지정 완료%s" % (where, name, shift)
        self.log(msg)
        return msg

    def pick_panel(self, root, which):
        if self.worker:
            raise ValueError('진행 중에는 위치를 지정할 수 없어요 (정지 후 다시)')
        hwnd = self._game()
        ox, oy = T.client_origin(hwnd)
        guide = ("[%s] 이적시장 창 전체를 테두리에 딱 맞게 드래그하세요 (위 보라색 제목줄 ~ 아래 '모두 받기' 줄까지)"
                 % T.LAYOUT_NAMES[which])
        res = T.pick_on_screen(root, 'rect', guide)
        if res is None:
            return None
        (x, y, w, h), img, (ml, mt) = res
        if w < 200 or h < 150:
            raise ValueError('범위가 너무 작아요. 이적시장 창 전체를 드래그해 주세요.')
        panel = [x - ox, y - oy, w, h]
        self.cfg['rects']['panel_%s' % which] = panel
        hx, hy, hw, hh = T.header_rect(panel)
        os.makedirs(T.DATA_DIR, exist_ok=True)
        img.crop((ox + hx - ml, oy + hy - mt, ox + hx - ml + hw, oy + hy - mt + hh)).save(T.tmpl_path('header_%s' % which))
        if os.path.exists(T.tmpl_path('dialog_manager')):
            os.remove(T.tmpl_path('dialog_manager'))
            self.log("창 범위가 바뀌어서 '감독모드 구매 창'을 다시 캡처해야 해요", 'warn')
        self.save()
        msg = '%s 이적시장 창 범위 지정 완료 (%d×%d)' % (T.LAYOUT_NAMES[which], w, h)
        self.log(msg)
        return msg

    def capture_dialog_manager(self, root):
        if self.worker:
            raise ValueError('진행 중에는 할 수 없어요 (정지 후 다시)')
        c = self.cfg
        if T.layout_scale(c) is None:
            raise ValueError('먼저 로비/감독모드 창 범위를 둘 다 지정해 주세요.')
        if 'dialog' not in c['rects']:
            raise ValueError("먼저 '구매 창 표시'를 로비에서 지정해 주세요.")
        hwnd = self._game()
        ox, oy = T.client_origin(hwnd)
        root.withdraw()
        root.update()
        time.sleep(0.35)
        try:
            with T.mss.mss() as sct:
                mon = sct.monitors[0]
                shot = sct.grab(mon)
        finally:
            root.deiconify()
        img = T.Image.frombytes('RGB', shot.size, shot.bgra, 'raw', 'BGRX')
        ml, mt = mon['left'], mon['top']

        def crop(rect):
            x, y, w, h = rect
            cc = img.crop((ox + x - ml, oy + y - mt, ox + x - ml + w, oy + y - mt + h))
            return T.np.array(cc)[:, :, ::-1].astype(T.np.int16)
        d = crop(T.map_rect(c, c['rects']['dialog']))
        if not T.has_content(d):
            raise ValueError("'구매' 글자가 안 보여요. 감독모드에서 구매 창을 띄운 뒤 다시 눌러 주세요.")
        os.makedirs(T.DATA_DIR, exist_ok=True)
        T.Image.fromarray(T.np.clip(d, 0, 255).astype(T.np.uint8)[:, :, ::-1]).save(T.tmpl_path('dialog_manager'))
        shown = [d] + [crop(T.map_rect(c, c['rects'][k])) for k in ('upper', 'lower') if k in c['rects']]
        self.preview = ('감독모드 변환 확인 · 구매 글자 / 상한가 / 하한가 — 잘려 있으면 창 범위를 다시 지정', T.compose(*shown))
        self.rev += 1
        self.log('감독모드 구매 창 캡처 완료 — 캡처 확인 칸에서 숫자가 제대로 보이는지 확인하세요', 'ok')
        return '감독모드 구매 창 캡처 완료'

    # ── 설정 가져오기 (예전 갱신 매크로 폴더) ──
    def import_settings(self, src):
        if self.worker:
            raise ValueError('진행 중에는 가져올 수 없어요 (정지 후 다시)')
        cands = [src, os.path.join(src, 'data'), os.path.join(src, 'dist', 'data')]
        found = next((d for d in cands if os.path.exists(os.path.join(d, 'settings.json'))), None)
        if not found:
            raise ValueError("그 폴더에서 settings.json 을 못 찾았어요.\n예전 갱신 매크로(TransferMacro.exe)가 있는 폴더를 골라 주세요.")
        if os.path.abspath(found) == os.path.abspath(T.DATA_DIR):
            raise ValueError('지금 쓰고 있는 설정 폴더예요.')
        os.makedirs(T.DATA_DIR, exist_ok=True)
        n = 0
        for f in os.listdir(found):
            fp = os.path.join(found, f)
            if os.path.isfile(fp):
                shutil.copy2(fp, os.path.join(T.DATA_DIR, f))
                n += 1
        self.cfg = T.load_cfg()
        self.rev += 1
        self.hist_rev += 1
        np_ = sum(1 for p in self.cfg['presets'] if T.preset_ready(p, self.cfg['presets'].index(p)))
        msg = '예전 갱신 매크로 설정 %d개 파일을 가져왔어요 (위치 지정이 끝난 선수 %d명)' % (n, np_)
        self.log(msg, 'ok')
        return msg

    # ── 시계 ──
    def apply_clock(self, off, err, host):
        self.cfg['clock_offset'] = round(off, 3)
        self.save()
        how = '느려요' if off > 0 else '빨라요'
        msg = '%s 기준 PC 시계가 %.2f초 %s → 시계 보정 %+.2f초 (오차 ±%.2f초 · %s)' % (
            host, abs(off), how, off, err, datetime.datetime.now().strftime('%H:%M:%S'))
        self.time_label = (msg, 'green')
        self.log(msg, 'ok')

    def sync_now(self):
        host = (self.cfg.get('time_host') or 'fcalrimi.com').strip()
        self.time_label = ('%s 시간 재는 중…' % host, 'dim')

        def job():
            try:
                off, err = T.measure_server_offset(host)
                self.q.put(('clock', off, err, host))
            except Exception as e:
                self.q.put(('log', '%s 시간 맞추기 실패: %s' % (host, e), 'error'))
                self.q.put(('tglbl', '', '#777'))
        threading.Thread(target=job, daemon=True).start()

    # ── 텔레그램 (갱신싸움꾼 봇) ──
    def tg_ok(self):
        tok = T.tg_clean_token(self.cfg.get('tg_token', ''))
        return bool(re.fullmatch(r'\d{5,}:[\w-]{20,}', tok or ''))

    def tg_status(self, text, color='#777'):
        self.q.put(('tglbl', text, color))

    def tg_find(self):
        tok = T.tg_clean_token(self.cfg.get('tg_token', ''))
        self.cfg['tg_token'] = tok
        if not re.fullmatch(r'\d{5,}:[\w-]{20,}', tok):
            raise ValueError("텔레그램 봇 토큰 형식이 아니에요.\nBotFather 가 준 '숫자:영문' 형태 전체를 붙여넣어 주세요.")
        self.save()
        self.tg_label = ('토큰 확인 중…', 'dim')

        def job():
            try:
                me = T._tg_call(tok, 'getMe', {})
            except Exception as e:
                self.tg_status('토큰이 틀렸어요: %s' % e, '#dc2626')
                return
            bot = '@' + (me or {}).get('username', '?')
            if self.tgbot is not None and self.tgbot.is_alive() and self.tgbot.token == tok:
                self.tg_finding = True
                self.tg_status('봇 %s 확인됨 · 텔레그램에서 %s 에게 아무 메시지(예: 안녕)를 보내면 바로 연결돼요' % (bot, bot), '#1d6fe0')
                return
            self.tg_status('봇 %s 확인됨 · 텔레그램에서 %s 에게 아무 메시지를 보내세요… (20초 기다림)' % (bot, bot), '#1d6fe0')
            try:
                r = T.telegram_find_chat(tok) or T.telegram_find_chat(tok, wait=20)
            except Exception as e:
                self.tg_status('채팅 ID 찾기 실패: %s' % e, '#dc2626')
                return
            if r:
                try:
                    T.telegram_send(tok, r[0], '✅ %s 연결 완료!\n이제 갱신에 성공하면 결과 사진과 예상 순번이 여기로 와요.' % T.APP_NAME)
                except Exception:
                    pass
                self.q.put(('tgchat', r[0], r[1]))
            else:
                self.tg_status('20초 동안 메시지가 안 왔어요 — %s 에게 메시지를 보낸 뒤 다시 눌러 주세요' % bot, '#c2410c')
        threading.Thread(target=job, daemon=True).start()

    def tg_test(self):
        tok, chat = T.tg_clean_token(self.cfg.get('tg_token', '')), str(self.cfg.get('tg_chat', '')).strip()
        if not tok or not chat:
            raise ValueError('토큰과 채팅 ID를 넣어 주세요. 채팅 ID는 [채팅 ID 찾기]로 자동으로 채울 수 있어요.')
        self.tg_label = ('테스트 전송 중…', 'dim')

        def job():
            try:
                T.telegram_send(tok, chat, '🔔 %s v%s 연결 테스트 (%s)' % (T.APP_NAME, T.VERSION, datetime.datetime.now().strftime('%H:%M:%S')))
                self.tg_status('테스트 전송 성공 — 텔레그램을 확인하세요', '#16a34a')
            except Exception as e:
                self.tg_status('테스트 전송 실패: %s' % e, '#dc2626')
        threading.Thread(target=job, daemon=True).start()

    def tg_ensure(self):
        tok = T.tg_clean_token(self.cfg.get('tg_token', ''))
        want = bool(tok) and bool(self.cfg.get('tg_menu', True)) and re.fullmatch(r'\d{5,}:[\w-]{20,}', tok) is not None
        if self.tgbot is not None and (not want or self.tgbot.token != tok or not self.tgbot.is_alive()):
            self.tgbot.stop()
            self.tgbot = None
        if want and self.tgbot is None:
            self.tgbot = T.TgBot(tok, self.q)
            self.tgbot.start()

    def tg_reply(self, text, photos=(), markup=None, edit=None):
        tok, chat = T.tg_clean_token(self.cfg.get('tg_token', '')), str(self.cfg.get('tg_chat', '')).strip()
        if not tok or not chat:
            return

        def job():
            try:
                if edit:
                    T._tg_call(tok, 'editMessageText', {'chat_id': chat, 'message_id': edit, 'text': text,
                                                        'reply_markup': markup or {'inline_keyboard': []}})
                elif photos:
                    T.telegram_send(tok, chat, text, photos)
                else:
                    f = {'chat_id': chat, 'text': text}
                    if markup:
                        f['reply_markup'] = markup
                    T._tg_call(tok, 'sendMessage', f)
            except Exception as e:
                if 'not modified' not in str(e):
                    self.q.put(('log', '텔레그램 답장 실패: %s' % e, 'warn'))
        threading.Thread(target=job, daemon=True).start()

    def tg_handle(self, u):
        cur = str(self.cfg.get('tg_chat', '')).strip()
        cq = u.get('callback_query')
        if cq:
            msg = cq.get('message') or {}
            chat = (msg.get('chat') or {}).get('id')
            if not cur or str(chat) != cur:
                return
            tok = T.tg_clean_token(self.cfg.get('tg_token', ''))
            threading.Thread(target=lambda: T._tg_call(tok, 'answerCallbackQuery', {'callback_query_id': cq['id']}),
                             daemon=True).start()
            self.tg_callback(cq.get('data', ''), msg.get('message_id'))
            return
        m = u.get('message') or {}
        ch = m.get('chat') or {}
        chat = ch.get('id')
        if chat is None:
            return
        if not cur or self.tg_finding:
            self.tg_finding = False
            name = ch.get('title') or ' '.join(x for x in (ch.get('first_name'), ch.get('last_name')) if x) \
                or ch.get('username') or ''
            self.q.put(('tgchat', chat, name))
            return
        if str(chat) != cur:
            return
        self.tg_command((m.get('text') or '').strip())

    def tg_players(self):
        h = T.hist_load()
        lines, rows, row = ['👥 선수 관리 — 버튼으로 켜기/끄기 (✅ 켜짐 · ⬜ 꺼짐)'], [], []
        for i, p in enumerate(self.cfg['presets']):
            ready = T.preset_ready(p, i)
            if not ready and not p['enabled']:
                continue
            succ, tot, seen = T.preset_stats(h, p['name'])
            info = ['%s %s' % (T.SIDE[p.get('side', 'buy')], T.TARGET[p['target']]),
                    '%s %02d분' % (T.PARITY[p['parity']], int(p['minute'])), '우선 %d' % T.prio(p)]
            if p.get('star'):
                info.append('⭐ 로비')
            if tot:
                info.append('성공 %d/%d' % (succ, tot))
            sm = T.seen_summary(seen)
            lines.append('%d. %s %s · ' % (i + 1, '✅' if p['enabled'] else '⬜', p['name']) + ' · '.join(info)
                         + ('\n    실제 갱신: %s' % sm if sm else '') + ('' if ready else '\n    ⚠️ 위치 지정 필요'))
            row.append({'text': '%s %d %s' % ('✅' if p['enabled'] else '⬜', i + 1, p['name'][:10]), 'callback_data': 'tog:%d' % i})
            if len(row) == 2:
                rows.append(row)
                row = []
        if row:
            rows.append(row)
        if len(lines) == 1:
            lines.append('위치 지정까지 끝난 선수가 없어요 — PC의 갱신꾼 프리셋에서 지정해 주세요')
        if self.worker is None:
            lines.append('\n(지금은 예약이 꺼져 있어요 — 바꾼 내용은 [▶ 예약 시작] 때 반영돼요)')
        return '\n'.join(lines), {'inline_keyboard': rows}

    def tg_status_text(self):
        now = self.now()
        st = STATE_TEXT.get(self.state, (self.state, ''))[0]
        lines = ['📊 상태 (%s)' % datetime.datetime.now().strftime('%H:%M:%S'), '· %s' % st + (' — %s' % self.sub if self.sub else '')]
        lines.append('· 예약: ' + {'schedule': '켜짐', 'now': '지금 진행 중', 'test': '테스트 중', 'peek': '가격 확인 중'}.get(self.mode, '꺼짐'))
        nxt = []
        for i, p in enumerate(self.cfg['presets']):
            if p['enabled'] and T.preset_ready(p, i):
                nxt.append((T.next_start(now, p['parity'], int(p['minute'])), p['name'], T.prio(p), p.get('star')))
        for ts, nm, pr, star in sorted(nxt)[:4]:
            lines.append('· 다음: %s %s (우선 %d%s)' % (T.hhmm(ts), nm, pr, ' · ⭐ 로비' if star else ''))
        tc = self.today_counts()
        if tc:
            lines.append('· 오늘: ' + ' · '.join('%s %d' % (T.HIST_KIND[k], n) for k, n in tc))
        return '\n'.join(lines)

    def tg_command(self, text):
        k = text.lower()
        if '상태' in k:
            self.tg_reply(self.tg_status_text(), markup=T.TG_KB)
        elif '가격' in k:
            rows = [[{'text': '%d. %s · %s %s' % (i + 1, p['name'], T.SIDE[p.get('side', 'buy')], T.TARGET[p['target']]),
                      'callback_data': 'peek:%d' % i}]
                    for i, p in enumerate(self.cfg['presets']) if T.preset_ready(p, i)]
            if not rows:
                self.tg_reply('위치 지정까지 끝난 선수가 없어요', markup=T.TG_KB)
            else:
                self.tg_reply('💰 어느 선수 창을 열어 볼까요? (Enter는 절대 안 눌러요)', markup={'inline_keyboard': rows})
        elif '선수' in k:
            txt, kb = self.tg_players()
            self.tg_reply(txt, markup=kb)
        elif '결과' in k:
            h = [e for e in T.hist_load() if e.get('kind') in T.HIST_KIND][-8:]
            if not h:
                self.tg_reply('아직 기록이 없어요', markup=T.TG_KB)
                return
            lines, rows = ['🏆 최근 결과 (사진은 버튼)'], []
            for e in reversed(h):
                ex = [x for x in (e.get('queue'), e.get('note') if e['kind'] != 'success' else None) if x]
                lines.append('· %s %s %s %s' % (e.get('day', '')[5:], e.get('hm', '')[:5], e.get('name'), T.HIST_KIND[e['kind']])
                             + (' — %s' % ' · '.join(ex) if ex else ''))
                if e.get('img') and os.path.exists(e['img']):
                    rows.append([{'text': '📷 %s %s %s' % (e.get('hm', '')[:5], e.get('name'), T.HIST_KIND[e['kind']]),
                                  'callback_data': 'img:%s' % e['id']}])
            self.tg_reply('\n'.join(lines), markup={'inline_keyboard': rows[:8]} if rows else T.TG_KB)
        elif '화면' in k:
            self.tg_screen()
        elif '요약' in k:
            self.tg_reply(T.day_summary(T.hist_load(), '%s' % datetime.date.today()), markup=T.TG_KB)
        elif '시작' in k and '/start' not in k:
            err = self.start('schedule', remote=True)
            if err:
                self.tg_reply('시작 못 했어요: %s' % err, markup=T.TG_KB)
            else:
                self.tg_reply('▶ 예약을 시작했어요: ' + ', '.join(self.name(i) for i in self.enabled()), markup=T.TG_KB)
        elif '정지' in k:
            if self.stop():
                self.tg_reply('■ 정지했어요', markup=T.TG_KB)
            else:
                self.tg_reply('진행 중인 게 없어요', markup=T.TG_KB)
        else:
            self.tg_reply('🤖 %s v%s\n아래 메뉴 버튼을 눌러 주세요.' % (T.APP_NAME, T.VERSION), markup=T.TG_KB)

    def tg_callback(self, data, msg_id):
        kind, _, arg = data.partition(':')
        if kind == 'peek':
            i = int(arg)
            p = self.cfg['presets'][i]
            mode = self.mode
            if mode in ('test', 'peek'):
                self.tg_reply('지금은 ' + ('테스트' if mode == 'test' else '다른 가격 확인') + ' 중이에요 — 끝난 뒤 다시 눌러 주세요')
            elif mode:
                self.control(('peek', i))
                self.tg_reply('💰 %s 확인할게요 — 갱신싸움 중이면 이번 20초가 끝난 뒤 바로 보내요' % p['name'])
            else:
                if 'dialog' not in self.cfg['rects'] or 'panel_lobby' not in self.cfg['rects']:
                    self.tg_reply("PC에서 '구매 창 표시'와 '① 창 범위' 위치 지정을 먼저 해 주세요")
                    return
                self.worker = T.Worker(json.loads(json.dumps(self.cfg)), self.q, mode='peek', only=i)
                self.mode = 'peek'
                self.worker.start()
                self.tg_reply('💰 %s 창을 열어서 확인 중이에요…' % p['name'])
        elif kind == 'tog':
            i = int(arg)
            p = self.cfg['presets'][i]
            on = not p['enabled']
            if on and not T.preset_ready(p, i):
                self.tg_reply('%s: 위치 지정(재등록·선수이름)이 안 돼 있어서 켤 수 없어요' % p['name'])
                return
            p['enabled'] = on
            self.save()
            self.log('[%s] 텔레그램에서 %s' % (p['name'], '켬' if on else '끔'), 'ok')
            if self.worker is not None and self.mode == 'schedule':
                self.control(('enable', i, on, {k: p[k] for k in ('name', 'parity', 'minute', 'target', 'side', 'priority')}))
            txt, kb = self.tg_players()
            self.tg_reply(txt, markup=kb, edit=msg_id)
        elif kind == 'img':
            e = next((x for x in T.hist_load() if x.get('id') == arg), None)
            if e and e.get('img') and os.path.exists(e['img']):
                ex = [x for x in (e.get('queue'), e.get('seen_full'), e.get('note')) if x]
                self.tg_reply('%s %s %s %s' % (e.get('day'), e.get('hm'), e.get('name'), T.HIST_KIND.get(e['kind'], ''))
                              + ('\n' + '\n'.join(ex) if ex else ''), photos=[e['img']])
            else:
                self.tg_reply('그 사진 파일이 없어요 (지워졌을 수 있어요)')

    def tg_screen(self):
        title = self.cfg.get('window_title', 'FC ONLINE')

        def job():
            try:
                hwnd = T.find_game(title)
                if not hwnd:
                    self.tg_reply('게임 창을 못 찾았어요 (게임이 꺼져 있거나 최소화돼 있어요)', markup=T.TG_KB)
                    return
                ox, oy = T.client_origin(hwnd)
                w, h = T.client_size(hwnd)
                with T.mss.mss() as sct:
                    shot = sct.grab({'left': ox, 'top': oy, 'width': w, 'height': h})
                os.makedirs(T.CAP_DIR, exist_ok=True)
                path = os.path.join(T.CAP_DIR, '지금화면_%s.png' % datetime.datetime.now().strftime('%Y%m%d_%H%M%S'))
                T.Image.frombytes('RGB', shot.size, shot.bgra, 'raw', 'BGRX').save(path)
                self.tg_reply('📸 지금 게임 화면 (%s)' % datetime.datetime.now().strftime('%H:%M:%S'), photos=[path])
            except Exception as e:
                self.tg_reply('화면 캡처 실패: %s' % e, markup=T.TG_KB)
        threading.Thread(target=job, daemon=True).start()

    # ── 감독모드와 같이 쓰기 ──
    def star_due(self, avg_game_sec, now_local=None):
        """⭐ 선수 갱신이 다음 경기와 겹치나 -> (번호, 시작(PC 시각), 끝(PC 시각)) / None.
        예약 진행 중일 때만. 다음 경기를 하면 시작 전에 못 끝날 것 같으면(평균 경기 시간 + 여유) 로비에서 기다림"""
        w = self.worker
        if w is None or self.mode != 'schedule':
            return None
        now_l = now_local if now_local is not None else time.time()
        off = float(self.cfg.get('clock_offset', 0) or 0)
        now_s = now_l + off
        dur = float(self.cfg['duration_min']) * 60
        prep = float(self.cfg['prep_sec'])
        margin = float(self.cfg.get('star_margin_sec', 60))
        best = None
        for i in sorted(getattr(w, 'pending', set())):
            p = self.cfg['presets'][i]
            if not p.get('star'):
                continue
            ss = w.sessions.get(i)
            if ss is not None:
                st, en = ss['start'], ss['end']
            else:
                win = T.session_window(now_s, p['parity'], int(p['minute']), dur, prep)
                st = win[0] if win else T.next_start(now_s, p['parity'], int(p['minute']))
                en = st + dur
            if st - prep - now_s <= avg_game_sec + margin and en > now_s:
                if best is None or st < best[1]:
                    best = (i, st - off, en - off)
        return best
