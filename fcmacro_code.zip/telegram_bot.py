# -*- coding: utf-8 -*-
"""
텔레그램 알림 + 원격 명령 (추가 설치 없음: 파이썬 기본 urllib)
 - 설정: 봇 토큰 하나 (텔레그램 @BotFather 에서 /newbot 으로 만들기)
 - 내 텔레그램에서 봇에게 /start 를 보내면 그 대화가 '주인'으로 등록 -> 알림은 그 대화로만, 명령도 주인만
 - 명령 메뉴: 채팅창 왼쪽 아래 [메뉴] 버튼(setMyCommands) + 자판 자리에 뜨는 버튼(ReplyKeyboard)
 - 몇 초마다가 아니라 '롱 폴링'(새 메시지가 올 때까지 최대 25초 대기)이라 반응이 빠르고 요청 수가 적음
"""
import html
import json
import os
import re
import threading
import time
import urllib.error
import urllib.parse
import urllib.request
import uuid

API = os.environ.get('FCMACRO_TELEGRAM_API', 'https://api.telegram.org')   # 테스트 때만 바꿈
POLL_TIMEOUT = 25
KIND_ICON = {'done': '✅', 'stop': '⛔', 'warn': '⚠️', 'info': 'ℹ️'}

# (영문 명령, 설명, 매크로 쪽 명령 이름, 인자)  - 텔레그램 메뉴 명령은 영문 소문자만 가능
COMMANDS = [
    ('status', '지금 상황 + 게임 화면', '상태', ''),
    ('chart', '최근 기록 그래프', '차트', ''),
    ('today', '오늘 결산 (지금까지)', '결산', ''),
    ('yesterday', '어제 결산', '결산', '어제'),
    ('formation', '포메이션별 승률', '포메이션', ''),
    ('settings', '설정 보기 · 바꾸기 (/settings 도움)', '설정', ''),
    ('pause', '일시정지 (F10)', '정지', ''),
    ('resume', '다시 진행 (F10)', '재개', ''),
    ('stop', '자동진행 종료 (F12)', '종료', ''),
    ('help', '명령 목록', '도움', ''),
]
EN2KO = {c[0]: (c[2], c[3]) for c in COMMANDS}
KEYBOARD = [['📋 상태', '📈 차트', '📅 오늘 결산'],
            ['⚔ 포메이션', '⚙ 설정', '❓ 도움'],
            ['❚❚ 일시정지', '▶ 재개', '⏹ 종료']]
# 한글로 쳐도 됨 (버튼 글자 포함)
KO_ALIAS = {'상태': '상태', '차트': '차트', '오늘결산': '결산', '결산': '결산', '오늘': '결산', '포메이션': '포메이션',
            '설정': '설정', '도움': '도움', '도움말': '도움', '명령': '도움', '일시정지': '정지', '정지': '정지',
            '재개': '재개', '종료': '종료', '어제': '결산'}
# 디스코드용 안내 문구를 텔레그램 명령으로 바꿔 보여줌
TEXT_MAP = [('!설정 도움', '/settings 도움'), ('!설정', '/settings'), ('!상태', '/status'), ('!차트', '/chart'),
            ('!결산 어제', '/yesterday'), ('!결산', '/today'), ('!정지', '/pause'), ('!재개', '/resume'),
            ('!종료', '/stop'), ('!포메이션', '/formation'), ('!도움', '/help'), ('!등록', '/start')]


def _esc(t):
    return html.escape(t, quote=False)


def is_token(t):
    return bool(re.fullmatch(r'\d{5,}:[\w-]{20,}', (t or '').strip()))


def tg_text(s):
    for a, b in TEXT_MAP:
        s = s.replace(a, b)
    return s


def format_message(title, lines, kind='info'):
    """제목 + 줄 목록 -> 텔레그램 HTML. 디스코드식 ``` 묶음은 <pre> 로"""
    out, block, in_pre = [], [], False
    for ln in lines:
        ln = tg_text(str(ln))
        if ln.strip() == '```':
            if in_pre:
                out.append('<pre>' + _esc('\n'.join(block)) + '</pre>')
                block = []
            in_pre = not in_pre
            continue
        if in_pre:
            block.append(ln)
        else:
            out.append(_esc(ln))
    if block:
        out.append('<pre>' + _esc('\n'.join(block)) + '</pre>')
    head = '<b>%s</b>' % _esc(tg_text(title))
    if kind in ('stop', 'warn') and not re.match(r'^\W', title or ''):
        head = KIND_ICON[kind] + ' ' + head
    body = '\n'.join(out).strip()
    return head + ('\n' + body if body else '')


def _cut(text, limit):
    """HTML이 깨지지 않게 자르기 (태그 없는 끝부분에서)"""
    if len(text) <= limit:
        return text
    plain = re.sub(r'<[^>]+>', '', text)
    return _esc(html.unescape(plain)[:limit - 20]) + '\n…'


class Bot:
    def __init__(self, token, chat_id, handlers, on_owner=None, log=None):
        """
        handlers: {'상태': fn(args) -> dict(title, lines, kind, image_fn, image_name)}  (디스코드 봇과 같은 함수)
        on_owner(chat_id, name): /start 로 주인이 정해졌을 때 (설정 저장용)
        """
        self.token = (token or '').strip()
        self.chat_id = str(chat_id) if chat_id else None
        self.handlers = handlers
        self.on_owner = on_owner
        self.log = log
        self.offset = None
        self.username = None
        self.status = '연결 준비 중'
        self.ok = None
        self.last_send = ''
        self._stop = threading.Event()
        self._thread = None
        self._started_at = time.time()

    # ── HTTP ─────────────────────────────────────
    def _call(self, method, params=None, files=None, timeout=20):
        url = '%s/bot%s/%s' % (API, self.token, method)
        params = params or {}
        if files:
            boundary = 'fcmacro' + uuid.uuid4().hex
            parts = []
            for k, v in params.items():
                parts += [('--%s\r\nContent-Disposition: form-data; name="%s"\r\n\r\n' % (boundary, k)).encode('utf-8'),
                          (v if isinstance(v, str) else json.dumps(v)).encode('utf-8'), b'\r\n']
            for k, (name, data, ctype) in files.items():
                parts += [('--%s\r\nContent-Disposition: form-data; name="%s"; filename="%s"\r\nContent-Type: %s\r\n\r\n'
                           % (boundary, k, name, ctype)).encode('utf-8'), data, b'\r\n']
            parts.append(('--%s--\r\n' % boundary).encode('utf-8'))
            data, ctype = b''.join(parts), 'multipart/form-data; boundary=' + boundary
        else:
            data, ctype = json.dumps(params).encode('utf-8'), 'application/json'
        for _ in range(3):
            req = urllib.request.Request(url, data=data, method='POST', headers={'Content-Type': ctype})
            try:
                with urllib.request.urlopen(req, timeout=timeout) as r:
                    res = json.loads(r.read().decode('utf-8'))
            except urllib.error.HTTPError as e:
                try:
                    res = json.loads(e.read().decode('utf-8'))
                except Exception:
                    raise RuntimeError('HTTP %s' % e.code)
            if res.get('ok'):
                return res.get('result')
            code = res.get('error_code')
            if code == 429:                                   # 너무 자주 보냄 -> 잠깐 쉬고 다시
                wait = (res.get('parameters') or {}).get('retry_after', 3)
                time.sleep(min(float(wait), 30))
                continue
            raise TgError(code, res.get('description', ''))
        raise RuntimeError('텔레그램 요청 반복 제한')

    # ── 보내기 ────────────────────────────────────
    def send(self, title, lines=(), kind='info', image=None, image_name='image.png', chat_id=None, keyboard=False,
             reply_to=None):
        """바로 전송 -> (성공 여부, 메시지). 주인이 없으면 실패"""
        cid = chat_id or self.chat_id
        if not cid:
            return False, '텔레그램 주인 미등록 (봇에게 /start 를 보내 주세요)'
        text = format_message(title, lines, kind)
        extra = {}
        if keyboard:
            extra['reply_markup'] = menu_keyboard()
        if reply_to:
            extra['reply_parameters'] = {'message_id': reply_to, 'allow_sending_without_reply': True}
        try:
            if image:
                ctype = 'image/jpeg' if image_name.lower().endswith(('.jpg', '.jpeg')) else 'image/png'
                if len(text) <= 1024:
                    p = dict(chat_id=str(cid), caption=text, parse_mode='HTML', **extra)
                    self._call('sendPhoto', p, files={'photo': (image_name, image, ctype)}, timeout=60)
                else:                                          # 글이 길면 글 먼저, 사진은 제목만 달아서
                    self._call('sendMessage', dict(chat_id=str(cid), text=_cut(text, 4000), parse_mode='HTML', **extra))
                    self._call('sendPhoto', {'chat_id': str(cid), 'caption': _cut('<b>%s</b>' % _esc(tg_text(title)), 1000),
                                             'parse_mode': 'HTML'}, files={'photo': (image_name, image, ctype)}, timeout=60)
            else:
                self._call('sendMessage', dict(chat_id=str(cid), text=_cut(text, 4000), parse_mode='HTML', **extra))
            self.last_send = '전송 성공 ' + time.strftime('%H:%M')
            return True, '전송 성공'
        except TgError as e:
            self.last_send = '전송 실패 %s - %s' % (time.strftime('%H:%M'), e)
            return False, '전송 실패: %s' % e
        except Exception as e:
            self.last_send = '전송 실패 %s - %s' % (time.strftime('%H:%M'), e)
            return False, '전송 실패: %s' % e

    def send_async(self, title, lines=(), kind='info', image_fn=None, image_name='image.png', on_done=None):
        if not self.chat_id:
            return

        def run():
            image = None
            if image_fn is not None:
                try:
                    image = image_fn()
                except Exception:
                    image = None
            res = self.send(title, lines, kind, image, image_name)
            if on_done is not None:
                try:
                    on_done(*res)
                except Exception:
                    pass
        threading.Thread(target=run, daemon=True).start()

    # ── 실행 ─────────────────────────────────────
    def start(self):
        if not self.token:
            self.status, self.ok = '꺼짐 (봇 토큰 없음)', None
            return False
        self._started_at = time.time()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return True

    def stop(self):
        self._stop.set()

    def _log(self, msg):
        if self.log:
            try:
                self.log(msg)
            except Exception:
                pass

    def _set(self, status, ok):
        if status != self.status:
            self._log('텔레그램 봇: ' + status)
        self.status, self.ok = status, ok

    def _connected_text(self):
        who = '@' + self.username if self.username else '봇'
        if self.chat_id:
            return '연결됨 (%s) · 알림·명령 사용 중' % who
        return "연결됨 (%s) · 텔레그램에서 이 봇에게 /start 를 보내면 등록됩니다" % who

    def _run(self):
        backoff = 3
        ready = False
        while not self._stop.is_set():
            try:
                if not ready:
                    me = self._call('getMe')
                    self.username = me.get('username')
                    try:
                        self._call('deleteWebhook', {'drop_pending_updates': False})
                        self._call('setMyCommands', {'commands': [{'command': c, 'description': d} for c, d, _k, _a in COMMANDS]})
                        self._call('setChatMenuButton', {'menu_button': {'type': 'commands'}})
                    except Exception as e:
                        self._log('텔레그램 메뉴 등록 실패: %s' % e)
                    ready = True
                    self._set(self._connected_text(), True)
                params = {'timeout': POLL_TIMEOUT, 'allowed_updates': ['message', 'callback_query']}
                if self.offset is not None:
                    params['offset'] = self.offset
                ups = self._call('getUpdates', params, timeout=POLL_TIMEOUT + 15) or []
                for u in ups:
                    if self._stop.is_set():
                        return                                # 설정을 바꿔서 새 연결로 넘어감 (명령은 새 연결이 처리)
                    self.offset = u['update_id'] + 1
                    try:
                        self._update(u)
                    except Exception as e:
                        self._log('텔레그램 처리 오류: %s' % e)
                if self.ok is not True:
                    self._set(self._connected_text(), True)
                backoff = 3
                continue
            except TgError as e:
                hint = {401: '봇 토큰이 틀림', 404: '봇 토큰이 틀림',
                        409: '같은 봇을 다른 곳(다른 PC의 매크로 등)에서 쓰는 중 - 봇은 PC마다 따로 만들어 주세요'}.get(e.code, '')
                if e.code == 409 and time.time() - self._started_at < POLL_TIMEOUT + 20:
                    self._set('연결 중 (이전 연결이 끝나길 기다리는 중)', None)   # 설정을 바꿔 다시 연결한 직후
                    self._stop.wait(3)
                    continue
                self._set('오류 %s %s' % (e.code, hint or e.desc), False)
                backoff = min(backoff * 2, 120) if e.code not in (401, 404) else 300
            except Exception as e:
                self._set('연결 안 됨 (%s) - 다시 시도 중' % e, False)
                backoff = min(backoff * 2, 120)
            self._stop.wait(backoff)

    def _update(self, u):
        if 'callback_query' in u:
            q = u['callback_query']
            cid = str(((q.get('message') or {}).get('chat') or {}).get('id', ''))
            try:
                self._call('answerCallbackQuery', {'callback_query_id': q['id']})
            except Exception:
                pass
            if cid != self.chat_id:
                return
            if q.get('data') == 'stop_ok':
                self._run_cmd('종료', '', cid, None)
            elif q.get('data') == 'stop_no':
                self.send('취소했습니다', ['자동진행은 그대로 계속됩니다.'], 'info')
            return
        m = u.get('message') or {}
        text = (m.get('text') or '').strip()
        chat = m.get('chat') or {}
        cid = str(chat.get('id', ''))
        if not text or not cid:
            return
        name = chat.get('first_name') or chat.get('username') or chat.get('title') or '?'
        old = m.get('date', 0) < self._started_at - 10           # 매크로 켜기 전에 보낸 메시지
        cmd, args = parse_command(text, self.username)
        if cmd == 'start':
            self._register(cid, name, m.get('message_id'))
            return
        if old:
            return                                                # 예전 명령은 실행하지 않음 (예: 어제 보낸 /stop)
        if cmd is None:
            if cid == self.chat_id:
                self.send('모르는 명령입니다', ['아래 버튼이나 /help 로 명령을 볼 수 있어요.'], 'info', keyboard=True,
                          reply_to=m.get('message_id'))
            return
        if not self.chat_id:
            self.send('먼저 /start 를 눌러 주세요', ['처음 /start 를 보낸 대화만 알림·명령을 받습니다.'], 'warn', chat_id=cid)
            return
        if cid != self.chat_id:
            return                                                # 다른 사람 명령은 무시
        if cmd == '도움':
            self.send('명령 목록', help_lines(), 'info', keyboard=True, reply_to=m.get('message_id'))
            return
        if cmd == '종료' and args != '확인':
            self._call('sendMessage', {'chat_id': cid, 'text': '자동진행을 종료할까요?\n(다시 시작은 PC에서 F9)',
                                       'reply_markup': {'inline_keyboard': [[{'text': '⏹ 종료', 'callback_data': 'stop_ok'},
                                                                             {'text': '취소', 'callback_data': 'stop_no'}]]}})
            return
        self._run_cmd(cmd, args, cid, m.get('message_id'))

    def _register(self, cid, name, mid):
        if self.chat_id and self.chat_id != cid:
            self.send('이미 다른 사람이 등록되어 있습니다', ['이 매크로는 주인만 쓸 수 있어요.'], 'warn', chat_id=cid)
            return
        first = self.chat_id is None
        self.chat_id = cid
        if first and self.on_owner:
            self.on_owner(cid, name)
        if first:
            self._log('텔레그램 봇: 주인 등록 - %s (%s)' % (name, cid))
        self._set(self._connected_text(), True)
        self.send('✅ %s 님, FC 매크로 텔레그램 연결 완료' % name,
                  ['이제 이 대화로 알림이 오고, 아래 버튼이나 [메뉴]로 명령할 수 있어요.', ''] + help_lines(),
                  'done', keyboard=True, reply_to=mid)

    def _run_cmd(self, cmd, args, cid, mid):
        fn = self.handlers.get(cmd)
        if fn is None:
            self.send('모르는 명령입니다', ['/help 로 명령 목록을 볼 수 있어요.'], 'info', reply_to=mid)
            return
        try:
            r = fn(args) or {}
            image = None
            if r.get('image_fn'):
                try:
                    image = r['image_fn']()
                except Exception:
                    image = None
            self.send(r.get('title', '완료'), r.get('lines', ()), r.get('kind', 'info'), image,
                      r.get('image_name', 'image.png'), reply_to=mid)
            self._log('텔레그램 명령 %s 처리' % cmd)
        except Exception as e:
            self._log('텔레그램 명령 %s 오류: %s' % (cmd, e))
            self.send('명령 처리 중 오류', [str(e)], 'stop', reply_to=mid)


class TgError(Exception):
    def __init__(self, code, desc):
        super().__init__('%s %s' % (code, desc))
        self.code, self.desc = code, desc


def menu_keyboard():
    return {'keyboard': [[{'text': t} for t in row] for row in KEYBOARD], 'resize_keyboard': True, 'is_persistent': True}


def help_lines():
    return ['/%s - %s' % (c, d) for c, d, _k, _a in COMMANDS] + ['', '한글로 쳐도 됩니다: 상태, 차트, 결산, 설정 점수 4500 …']


def parse_command(text, username=None):
    """'/status', '/status@봇이름', '/settings 점수 4500', '📋 상태', '!상태', '설정 점수 4500' -> (매크로 명령, 인자) / (None, '')"""
    t = text.strip()
    if t.startswith('/'):
        head, _, args = t[1:].partition(' ')
        head = head.split('@')[0].lower()
        if head == 'start':
            return 'start', ''
        if head in EN2KO:
            k, a = EN2KO[head]
            return k, (a or args.strip())
        head_ko = head
    else:
        t = re.sub(r'^[^\w가-힣]+', '', t.lstrip('!'))      # 버튼 앞 그림 문자, '!' 제거
        head_ko, _, args = t.partition(' ')
    key = head_ko.replace(' ', '')
    if key == '오늘' and args.strip() == '결산':
        return '결산', ''
    if key in KO_ALIAS:
        a = args.strip()
        if key == '어제':
            a = '어제'
        return KO_ALIAS[key], a
    return None, ''


def test_connection(token, chat_id=None):
    """설정창 '테스트' 버튼: 토큰 확인 -> (주인이 없으면 최근 /start 보낸 대화 찾기) -> 테스트 메시지
    반환 (성공 여부, 메시지, 찾은 chat_id 또는 None, 이름)"""
    if not is_token(token):
        return False, '봇 토큰 형식이 아닙니다 (예: 123456789:AA...)', None, None
    b = Bot(token, chat_id, {})
    try:
        me = b._call('getMe', timeout=10)
    except TgError as e:
        return False, '봇 토큰이 틀립니다 (%s)' % e, None, None
    except Exception as e:
        return False, '텔레그램 연결 실패: %s' % e, None, None
    name = None
    if not b.chat_id:
        try:
            ups = b._call('getUpdates', {'timeout': 0, 'allowed_updates': ['message']}, timeout=10) or []
        except TgError as e:
            if e.code == 409:
                return False, '이 봇을 매크로가 이미 쓰는 중 - 텔레그램에서 /start 를 보내면 바로 등록됩니다', None, None
            return False, '확인 실패: %s' % e, None, None
        for u in reversed(ups):
            m = u.get('message') or {}
            if (m.get('text') or '').startswith('/start'):
                b.chat_id = str(m['chat']['id'])
                name = m['chat'].get('first_name') or m['chat'].get('username') or '?'
                break
        if not b.chat_id:
            return False, '텔레그램에서 @%s 에게 /start 를 보낸 뒤 다시 [테스트] 해 주세요' % me.get('username'), None, None
    ok, msg = b.send('✅ FC 매크로 텔레그램 알림 테스트',
                     ['이 메시지가 보이면 텔레그램 알림이 정상입니다.',
                      '주차 완료 / 종료 시각 / 승급·강등 / 연패 / 오류 정지 / 멈춤 감지 때 알림이 옵니다.'], 'info', keyboard=True)
    return ok, ('@%s 로 %s' % (me.get('username'), msg)), b.chat_id, name
