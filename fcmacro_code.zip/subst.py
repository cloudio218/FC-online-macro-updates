# -*- coding: utf-8 -*-
"""v3.6 경기 중 선수 자동 교체 (사용자 요청 2026-11-22)

게임 흐름 (사용자 확인):
  경기 중 ESC -> 포메이션 창 (목록은 항상 맨 위 ST부터, 창이 떠 있어도 경기는 흘러감)
  나갈 선수 줄 클릭 -> 들어갈 선수 줄에 마우스를 올리면 그 줄 오른쪽에 ⇄ 버튼 -> 클릭 = 두 선수 자리 바뀜
  여러 쌍 반복 후 [확인]. 다음 경기는 다시 선발 명단으로 시작
매크로:
  - 경기 화면 위 시계(19:55)를 읽어 '정한 분이 지났으면' 교체 (리플레이로 시계가 건너뛰어도 됨, 경기마다 한 번)
  - 조건: 항상 / 지고 있을 때 / 비기거나 질 때 (점수는 경기 화면 점수 칸, 내 편은 포메이션 창 ▼ HOME/AWAY 표시)
  - 등록: 포메이션 창을 연 채로 나갈 줄 -> 들어갈 줄에 마우스를 잠깐 올려 둠 (줄 이름 모양 저장)
  - 교체할 때 이름 모양으로 줄을 찾음 (안 보이면 목록을 내려 가며), 다르면 그 쌍은 건너뜀
기준 좌표: 1280x720 게임 창 캡처(제목줄 포함) 기준, 화면에서 찾은 기준 그림(sub_tab / sub_ok)에서의 거리
"""
import os
import json
import time
import base64
import numpy as np
import cv2

SLOTS = 5
DEFAULTS = {'enabled': False, 'minute': 60, 'cond': 'always', 'notify': True}
CONDS = {'always': '항상', 'losing': '지고 있을 때', 'not_win': '비기거나 질 때'}

# 경기 화면 기준 = sub_tab.png(아래 '팀 전술 · 개인 전술 · 경기 분석' 줄) 왼쪽 위
CLOCK_DX, CLOCK_DY = 270, -493               # 시계 칸 왼쪽 위 (67 x 25)
CLOCK_CELLS = (13, 22, 35, 43)                # 숫자 4칸 (분 2 + 초 2) 시계 칸 안 x
SCORE_BOX = ((68, -493), (95, -493))          # 홈 / 원정 점수 칸 왼쪽 위 (25 x 25)
# 포메이션 창 기준 = sub_ok.png([확인] 버튼 글자) 왼쪽 위
LIST_Y0, LIST_Y1 = -472, -18                  # 선수 목록 세로 범위
NAME_X0, NAME_X1 = -190, -43                  # 이름 칸 (등급 그림 + 이름)
CLICK_DX = -128                               # 줄을 누를 x
SWAP_X0, SWAP_X1 = 12, 66                     # ⇄ 버튼이 생기는 x 범위
NAME_H = 18                                   # 이름 그림 높이 (줄 가운데 ±9)
OK_W, OK_H = 52, 20


def cfg_of(raw):
    c = dict(DEFAULTS)
    if isinstance(raw, dict):
        c.update(raw)
    try:
        c['minute'] = max(1, min(120, int(c.get('minute') or 60)))
    except (TypeError, ValueError):
        c['minute'] = 60
    if c.get('cond') not in CONDS:
        c['cond'] = 'always'
    return c


def _norm(a):
    a = a.astype(np.float32)
    return (a - a.mean()) / (a.std() + 1e-6)


def png_b64(arr_rgb):
    ok, buf = cv2.imencode('.png', cv2.cvtColor(arr_rgb, cv2.COLOR_RGB2BGR))
    return base64.b64encode(buf.tobytes()).decode('ascii') if ok else ''


def b64_gray(s):
    try:
        a = cv2.imdecode(np.frombuffer(base64.b64decode(s), np.uint8), cv2.IMREAD_GRAYSCALE)
        return a
    except Exception:
        return None


class Digits:
    """시계·점수 숫자 읽기. 견본(images/sub_digits.npz) + 경기 중 배운 것(기록 폴더)"""

    def __init__(self, base_path, learn_path):
        self.learn_path = learn_path
        self.t = {}
        for p in (base_path, learn_path):
            try:
                z = np.load(p)
                for k in z.files:
                    self.t.setdefault(k[1:], []).extend(list(z[k]))
            except Exception:
                pass
        self.learned = 0

    def read_cell(self, g, x, y):
        """g 회색 화면, (x, y) = 15x9 숫자 칸 왼쪽 위 -> (숫자, 점수, 2등과 차이)"""
        best = {}
        for dy in (-1, 0, 1):
            for dx in (-1, 0, 1):
                c = g[y + dy:y + dy + 15, x + dx:x + dx + 9]
                if c.shape != (15, 9):
                    continue
                cn = _norm(c)
                for ch, ts in self.t.items():
                    for tp in ts:
                        s = float((cn * _norm(tp[1:16, 1:10])).mean())
                        if s > best.get(ch, -9):
                            best[ch] = s
        if not best:
            return None, 0.0, 0.0
        r = sorted(best.items(), key=lambda kv: -kv[1])
        return r[0][0], r[0][1], r[0][1] - (r[1][1] if len(r) > 1 else 0)

    def learn(self, ch, sample):
        """확실히 읽힌 숫자 모양을 견본에 더함 (숫자마다 최대 8개, 기록 폴더에 저장)"""
        ts = self.t.setdefault(ch, [])
        if len(ts) >= 8 or sample.shape != (17, 11):
            return
        ts.append(sample.astype(np.uint8))
        self.learned += 1
        try:
            os.makedirs(os.path.dirname(self.learn_path), exist_ok=True)
            np.savez_compressed(self.learn_path, **{'d' + k: np.stack(v) for k, v in self.t.items()})
        except Exception:
            pass


def read_clock(dig, g, ax, ay):
    """경기 시계 -> (분, 초, 근거) / 못 읽으면 (None, None, 이유). ax, ay = sub_tab 위치(frame 안 좌표)"""
    x0, y0 = ax + CLOCK_DX, ay + CLOCK_DY
    box = g[y0:y0 + 25, x0:x0 + 67]
    if box.shape != (25, 67) or float(box.mean()) < 170:          # 시계 칸이 안 보임 (흰 칸이 아님)
        return None, None, '시계 안 보임'
    out = ''
    low = []
    learn = []
    for cx in CLOCK_CELLS:
        ch, s, m = dig.read_cell(g, x0 + cx, y0 + 4)
        if ch is None or s < 0.80 or m < 0.04:
            return None, None, '숫자 불확실 (%.2f/%.2f)' % (s, m)
        out += ch
        low.append(s)
        learn.append((ch, s, m, g[y0 + 2:y0 + 19, x0 + cx - 1:x0 + cx + 10]))
    mm, ss = int(out[:2]), int(out[2:])
    if ss > 59:
        return None, None, '초가 60 이상 (%s)' % out
    return mm, ss, {'text': '%s:%s' % (out[:2], out[2:]), 'min_score': min(low), 'learn': learn}


def read_score(dig, g, ax, ay):
    """경기 화면 점수 칸 -> (홈, 원정) / 못 읽으면 None"""
    res = []
    for dx, dy in SCORE_BOX:
        bx, by = ax + dx, ay + dy
        box = g[by + 3:by + 19, bx + 2:bx + 23]
        if box.shape != (16, 21) or float(g[by:by + 25, bx:bx + 25].mean()) < 150:
            return None
        ink = (box < 110).any(0)
        xs = np.where(ink)[0]
        if len(xs) == 0 or xs.max() - xs.min() > 10:              # 비었거나 두 자리(10골+) -> 모름
            return None
        cx = bx + 2 + (int(xs.min()) + int(xs.max())) // 2
        ch, s, m = dig.read_cell(g, cx - 4, by + 3)
        if ch is None or s < 0.75 or m < 0.08:
            return None
        res.append(int(ch))
    return tuple(res)


def cond_ok(cond, mine, theirs):
    if cond == 'always':
        return True
    if mine is None or theirs is None:
        return None
    if cond == 'losing':
        return mine < theirs
    return mine <= theirs


def my_side(g, okx, oky):
    """포메이션 창 위 ▼ 표시(내 편 HOME/AWAY 위) -> 'home' / 'away' / None
    ▼ 가 있는 줄(확인 버튼 기준 위로 약 650px)에서 흰 점들의 가로 위치가 화면 가운데보다 왼쪽이면 HOME"""
    y0, y1 = oky - 652, oky - 636
    x0, x1 = okx - 600, okx - 180
    band = g[max(0, y0):y1, max(0, x0):x1]
    if band.size == 0:
        return None
    cols = np.where((band > 200).sum(0) >= 2)[0]
    if len(cols) < 3 or cols.max() - cols.min() > 20:            # ▼ 하나만 (폭 10px 안팎)
        return None
    cx = max(0, x0) + (int(cols.min()) + int(cols.max())) // 2
    return 'home' if cx < okx - 388 else 'away'


def row_center(g, okx, oky, my):
    """마우스 y 근처 줄의 가운데 y (이름 글자 세로 범위로). 목록 밖이면 None"""
    y0, y1 = oky + LIST_Y0, oky + LIST_Y1
    if not y0 + 6 <= my <= y1 - 6:
        return None
    x0, x1 = okx + NAME_X0 + 24, okx + NAME_X1
    band = g[my - 14:my + 15, x0:x1].astype(np.int16)
    if band.shape[0] < 29:
        return None
    med = np.median(band, axis=1, keepdims=True)
    rows = (np.abs(band - med) > 60).sum(1) > 2
    ys = np.where(rows)[0]
    if len(ys) == 0:
        return None
    # 마우스와 가장 가까운 글자 덩어리
    runs, s = [], ys[0]
    for a, b in zip(ys, ys[1:]):
        if b - a > 2:
            runs.append((s, a))
            s = b
    runs.append((s, ys[-1]))
    s, e = min(runs, key=lambda r: abs((r[0] + r[1]) / 2 - 14))
    return my - 14 + (s + e) // 2


def name_img(g, okx, oky, cy):
    y = cy - NAME_H // 2
    a = g[y:y + NAME_H, okx + NAME_X0:okx + NAME_X1]
    return a if a.shape == (NAME_H, NAME_X1 - NAME_X0) else None


def find_row(g, okx, oky, tpl, thr=0.78):
    """목록에서 이름 그림 찾기 -> (가운데 y, 점수) / (None, 최고 점수). 선택된 줄(흰 바탕)은 뒤집은 그림으로"""
    y0, y1 = oky + LIST_Y0, oky + LIST_Y1
    reg = g[y0:y1, okx + NAME_X0 - 4:okx + NAME_X1 + 4]
    if reg.shape[0] < tpl.shape[0] or reg.shape[1] < tpl.shape[1]:
        return None, 0.0
    best, by = -1.0, None
    for t in (tpl, 255 - tpl):
        r = cv2.matchTemplate(reg, t, cv2.TM_CCOEFF_NORMED)
        _mn, mx, _l, loc = cv2.minMaxLoc(r)
        if mx > best:
            best, by = mx, loc[1]
    if best < thr:
        return None, best
    return y0 + by + NAME_H // 2, best


class Store:
    """설정·교체 쌍·기록 (기록 폴더\\subst\\state.json)"""

    def __init__(self, folder):
        self.folder = folder
        self.path = os.path.join(folder, 'state.json')
        self.s = {'settings': dict(DEFAULTS), 'pairs': [], 'log': [], 'games': {}}
        try:
            with open(self.path, encoding='utf-8') as f:
                d = json.load(f)
            if isinstance(d, dict):
                self.s.update(d)
        except (OSError, ValueError):
            pass
        self.s['settings'] = cfg_of(self.s.get('settings'))
        self.s['pairs'] = [p for p in self.s.get('pairs') or [] if isinstance(p, dict)][:SLOTS]

    @property
    def settings(self):
        return self.s['settings']

    def save(self):
        try:
            os.makedirs(self.folder, exist_ok=True)
            tmp = self.path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(self.s, f, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def active(self):
        return [(i, p) for i, p in enumerate(self.s['pairs']) if p.get('on', True)]

    def add_pair(self, out, inn):
        if len(self.s['pairs']) >= SLOTS:
            return False
        self.s['pairs'].append({'on': True, 'out': out, 'in': inn, 'id': '%x' % int(time.time() * 1000)})
        self.save()
        return True

    def add_log(self, text):
        self.s['log'].insert(0, [time.strftime('%m/%d %H:%M'), text])
        del self.s['log'][30:]
        self.save()

    def mark_game(self, key, minute):
        self.s['games'][key] = minute
        if len(self.s['games']) > 600:
            for k in list(self.s['games'])[:100]:
                self.s['games'].pop(k, None)
        self.save()
