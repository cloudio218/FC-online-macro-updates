# -*- coding: utf-8 -*-
"""
랭킹점수 기록(ranking_log.csv) + 추이 그래프(ranking_chart.html) 생성
 - CSV: 날짜시간, 게임번호, 랭킹점수, 순위, 결과, 비고   (엑셀에서 바로 열리도록 UTF-8 BOM)
   · 랭킹점수/순위는 '그 판 시작 직전' 값 (챔스 홈 화면 또는 VS 화면). 못 읽으면 빈칸
   · 비고: 승급 / 강등 / 티어 변경 / 배치 / 연속 진행 (게임 줄), 주차 / 종료 (게임번호 '-' 줄 = 정지 시점)
 - 그래프: 외부 라이브러리/인터넷 없이 SVG로 그려 브라우저에서 열림
"""
import csv
import json
import os
import html
from datetime import datetime

LOG_FILE = 'ranking_log.csv'
CHART_FILE = 'ranking_chart.html'
HEADER = ['날짜시간', '게임번호', '랭킹점수', '순위', '결과', '비고']


def _load_rows():
    """CSV 전체를 dict 리스트로 읽음 (예전 4칸 형식도 읽힘)"""
    if not os.path.exists(LOG_FILE):
        return None, []
    for enc in ('utf-8-sig', 'cp949'):       # 엑셀에서 다른 형식으로 저장한 경우(cp949)도 읽음
        try:
            with open(LOG_FILE, newline='', encoding=enc) as f:
                rd = csv.DictReader(f)
                rows = [dict(r) for r in rd]
                return rd.fieldnames, rows
        except UnicodeDecodeError:
            continue
    return None, []


def _save_rows(rows):
    tmp = LOG_FILE + '.tmp'
    with open(tmp, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(HEADER)
        for r in rows:
            w.writerow([r.get(h, '') or '' for h in HEADER])
    os.replace(tmp, LOG_FILE)


def _ensure_header():
    """예전 형식(순위 칸 없음) 파일이면 순위 칸을 추가해 다시 저장"""
    fields, rows = _load_rows()
    if fields is not None and fields != HEADER:
        _save_rows(rows)


def append_record(game_no, score, note='', rank=''):
    """score/rank 가 None 이면 빈칸"""
    score = '' if score is None else score
    rank = '' if rank is None else rank
    """기록 한 줄 추가. 이 기록의 날짜시간 문자열을 반환 (나중에 순위 채울 때 사용)"""
    _ensure_header()
    ts = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
    if os.path.exists(LOG_FILE):
        try:
            with open(LOG_FILE, encoding='utf-8-sig') as f:
                f.read()
        except UnicodeDecodeError:            # 엑셀이 cp949로 저장했으면 UTF-8로 다시 저장 후 이어 쓰기
            _, rows = _load_rows()
            _save_rows(rows)
    new = not os.path.exists(LOG_FILE)
    with open(LOG_FILE, 'a', newline='', encoding='utf-8-sig' if new else 'utf-8') as f:
        w = csv.writer(f)
        if new:
            w.writerow(HEADER)
        w.writerow([ts, game_no, score, rank, '', note])
    return ts


def update_fields(ts, game_no, **fields):
    """append_record로 쓴 줄(날짜시간+게임번호 일치)의 칸을 채움. 예: update_fields(ts, 3, 랭킹점수=2166, 순위=12)
    비고는 기존 내용 뒤에 덧붙임"""
    _ensure_header()
    _, rows = _load_rows()
    for r in reversed(rows):
        if r.get('날짜시간') == ts and str(r.get('게임번호')) == str(game_no):
            for k, v in fields.items():
                if k == '비고':
                    old = r.get('비고') or ''
                    r['비고'] = (old + ', ' + v) if old and v not in old.split(', ') else (old or v)
                else:
                    r[k] = '' if v is None else str(v)
            _save_rows(rows)
            return True
    return False


def update_rank(ts, game_no, rank):
    """append_record로 쓴 기록(날짜시간+게임번호 일치)에 순위를 채움"""
    _ensure_header()
    _, rows = _load_rows()
    for r in reversed(rows):
        if r.get('날짜시간') == ts and str(r.get('게임번호')) == str(game_no):
            r['순위'] = str(rank)
            _save_rows(rows)
            return True
    return False


def _int(v):
    try:
        return int(str(v).replace(',', '').strip())
    except (ValueError, TypeError, AttributeError):
        return None


def read_records():
    """[(날짜시간, 게임번호, 랭킹점수|None, 순위|None, 비고, 결과('승'/'무'/'패'|''))]
    점수가 빈칸인 판(하위 티어에서 못 읽은 판 등)도 포함. 정지 줄은 점수가 있을 때만"""
    _, rows = _load_rows()
    out = []
    for r in rows:
        score = _int(r.get('랭킹점수'))
        no = str(r.get('게임번호', '') or '')
        if not r.get('날짜시간') or (score is None and no in ('-', '')):
            continue
        out.append((r.get('날짜시간', ''), no, score, _int(r.get('순위')), r.get('비고') or '', r.get('결과') or ''))
    return out


def is_stop_row(rec):
    return str(rec[1]) == '-'


def build_chart(target=None):
    """그래프 HTML을 만들고 경로 반환 (기록이 없으면 None).
    모든 기록을 페이지에 담고, 페이지 안에서 '최근 N판'을 골라 다시 그림."""
    rows = read_records()
    if not rows:
        return None
    data = [{'t': r[0], 'n': str(r[1]), 's': r[2], 'r': r[3], 'note': r[4], 'res': r[5], 'stop': is_stop_row(r)} for r in rows]
    page = CHART_TEMPLATE.replace('__DATA__', json.dumps(data, ensure_ascii=False)) \
                         .replace('__TARGET__', json.dumps(target)) \
                         .replace('__LOGFILE__', html.escape(os.path.abspath(LOG_FILE)))
    with open(CHART_FILE, 'w', encoding='utf-8') as f:
        f.write(page)
    return os.path.abspath(CHART_FILE)


CHART_TEMPLATE = r"""<!doctype html><html lang="ko"><head><meta charset="utf-8"><title>감독모드 기록</title>
<style>
.ev{font-size:13px;font-weight:bold;text-anchor:middle} .ev.up{fill:#3ddc84} .ev.dn{fill:#ff5d7a} .ev.tc{fill:#ffc94a}
.evline{stroke-width:1;stroke-dasharray:2 3;opacity:.55} .evline.up{stroke:#3ddc84} .evline.dn{stroke:#ff5d7a} .evline.tc{stroke:#ffc94a}
.lg.e{background:none;width:auto;height:auto;margin:0 2px 0 16px;font-weight:bold}
body{font-family:"Malgun Gothic",sans-serif;background:#16141f;color:#e8e6f0;margin:24px}
h1{font-size:20px;margin:0 0 10px}
.ctl{display:flex;flex-wrap:wrap;gap:8px;align-items:center;margin-bottom:10px;font-size:14px}
.ctl input{width:80px;padding:5px 8px;font-size:14px;background:#26233a;color:#fff;border:1px solid #4a4566;border-radius:6px}
.ctl button{padding:5px 12px;font-size:13px;background:#2f2b47;color:#e8e6f0;border:1px solid #4a4566;border-radius:6px;cursor:pointer}
.ctl button:hover{background:#3d3860} .ctl button.on{background:#3ddc84;color:#111;border-color:#3ddc84}
.sum{color:#aaa6bd;font-size:13px;margin-bottom:12px;line-height:1.6}
.wrap{display:flex;background:#1f1c2c;border-radius:10px;overflow:hidden}
#yaxis,#raxis{flex:0 0 70px;display:block} #scroller{flex:1;overflow-x:auto;overflow-y:hidden}
#chart{cursor:crosshair} .guide{stroke:#cfcbe0;stroke-width:1;stroke-dasharray:3 3;opacity:.7}
.hs{fill:#3ddc84;stroke:#fff;stroke-width:2} .hr{fill:#4aa8ff;stroke:#fff;stroke-width:2}
#tip{position:fixed;pointer-events:none;display:none;z-index:10;background:#0f0d18;border:1px solid #4a4566;border-radius:8px;
 padding:8px 12px;font-size:13px;line-height:1.7;box-shadow:0 6px 20px rgba(0,0,0,.45);white-space:nowrap}
#tip .t{color:#aaa6bd;font-size:12px} #tip .k{display:inline-block;width:56px;color:#aaa6bd}
#tip .sv{color:#3ddc84;font-weight:bold} #tip .rv{color:#4aa8ff;font-weight:bold}
#chart{display:block} #scroller::-webkit-scrollbar{height:12px} #scroller::-webkit-scrollbar-thumb{background:#4a4566;border-radius:6px}
#scroller::-webkit-scrollbar-track{background:#26233a} .hint{color:#8f8aa8;font-size:12px;margin:6px 0 0 70px;min-height:16px}
.legend{font-size:13px;color:#cfcbe0;margin-bottom:10px} .lg{display:inline-block;width:18px;height:3px;vertical-align:middle;margin:0 6px 0 4px;border-radius:2px} .lg.s{background:#3ddc84} .lg.r{background:#4aa8ff;margin-left:16px}
.rlab{fill:#6fb6ff;font-size:12px;text-anchor:start} .rline{fill:none;stroke:#4aa8ff;stroke-width:2;opacity:.9} .rpt{fill:#4aa8ff}
.rup{color:#4aa8ff} .rdown{color:#ff9f43}
.grid{stroke:#34304a;stroke-width:1} .day{stroke:#2a2740;stroke-dasharray:3 4}
.ylab{fill:#8f8aa8;font-size:12px;text-anchor:end} .xlab{fill:#8f8aa8;font-size:12px;text-anchor:middle}
.target{stroke:#ff5d7a;stroke-width:1.5;stroke-dasharray:6 4} .tlab{fill:#ff5d7a;font-size:12px}
.line{fill:none;stroke:#3ddc84;stroke-width:2} .pt{fill:#3ddc84} .pt.park{fill:#ff5d7a}
table{border-collapse:collapse;margin-top:18px;font-size:13px}
h2{font-size:16px;margin:28px 0 0} .note{color:#8f8aa8;font-size:12px;margin-top:4px}
#daily td:first-child,#daily th:first-child{text-align:left}
td,th{padding:4px 14px;border-bottom:1px solid #2c2940;text-align:right} th{color:#aaa6bd;font-weight:normal;position:sticky;top:0;background:#16141f}
.up{color:#3ddc84} .down{color:#ff5d7a} .draw{color:#ffc94a}
.pat{display:flex;flex-wrap:wrap;gap:10px 34px} .pat h3{font-size:14px;margin:16px 0 0;color:#cfcbe0;font-weight:normal}
.pat table{margin-top:6px} .pat td:first-child{text-align:left;color:#cfcbe0} .pat tr.few td{opacity:.45}
.bar{display:inline-block;height:10px;border-radius:3px;background:#3ddc84;vertical-align:middle;margin-right:6px}
.bar.lo{background:#ff5d7a} .wr{min-width:150px;text-align:left!important}
</style></head><body>
<h1>감독모드 랭킹점수 · 순위 · 승급/강등</h1>
<div class="legend"><span class="lg s"></span>랭킹점수 (왼쪽 눈금) <span class="lg r"></span>순위 (오른쪽 눈금 · 위로 갈수록 높은 순위)
 <span class="lg e up" style="color:#3ddc84">▲</span>승급 <span class="lg e" style="color:#ff5d7a">▼</span>강등 <span class="lg e" style="color:#ffc94a">◆</span>티어 변경</div>
<div class="ctl">최근 <input id="cnt" type="number" min="1" step="1"> 판
 <button id="go">보기</button>
 <button data-n="50">50판</button><button data-n="100">100판</button><button data-n="200">200판</button><button data-n="500">500판</button>
 <button data-n="0">전체</button></div>
<div class="sum" id="sum"></div>
<div class="wrap"><svg id="yaxis" width="70" height="460"></svg><div id="scroller"><svg id="chart" height="460"></svg></div><svg id="raxis" width="70" height="460"></svg></div>
<div class="hint" id="hint"></div>
<div id="tip"></div>
<h2>날짜별 요약</h2>
<div class="note">전체 기록 기준 · 승/무/패는 기록된 결과(챔스 아래 티어는 화면의 결과 칸, 챔스는 점수 변화), 없으면 다음 판 점수와 비교</div>
<table id="daily"><thead><tr><th>날짜</th><th>판수</th><th>승 / 무 / 패</th><th>승률</th><th>랭킹점수 (시작 → 끝)</th><th>점수 변화</th><th>순위 (시작 → 끝)</th><th>최고 순위</th><th>승급 / 강등</th></tr></thead><tbody id="db"></tbody></table>
<h2>패턴 분석</h2>
<div class="note">전체 기록 기준 · 10판 미만인 칸은 흐리게 (참고만) · 세션 = 앞 판과 40분 넘게 떨어지면 새 세션으로 봄</div>
<div class="pat">
<div><h3>세션 안에서 몇 판째인지</h3><table id="p_sess"></table></div>
<div><h3>연패·연승 직후 다음 판</h3><table id="p_after"></table></div>
<div><h3>시간대</h3><table id="p_hour"></table></div>
<div><h3>요일</h3><table id="p_wday"></table></div>
<div><h3>연승 · 연패 기록</h3><table id="p_streak"></table></div>
</div>
<h2>판별 기록</h2>
<table><thead><tr><th>회차</th><th>결과</th><th>랭킹점수</th><th>변화</th><th>순위</th><th>순위 변화</th><th>날짜시간</th><th>비고</th></tr></thead><tbody id="tb"></tbody></table>
<div class="sum">전체 기록 파일: __LOGFILE__</div>
<script>
const DATA=__DATA__, TARGET=__TARGET__;
const NS='http://www.w3.org/2000/svg', H=460,T=30,B=60,PH=H-T-B, PAD=20, PX=14; // PX = 한 판당 가로 간격(px)
let curN=100;
const fmt=v=>v==null?'-':v.toLocaleString('ko-KR');
const totalGames=DATA.filter(d=>!d.stop).length;
const EVS=[['승급','▲','up'],['강등','▼','dn'],['티어 변경','◆','tc']];
function evOf(r){ if(!r.note) return null; const p=r.note.split(', '); for(const e of EVS) if(p.includes(e[0])) return e; return null }
function prevKnown(rows,i){ for(let j=i-1;j>=0;j--) if(rows[j].s!=null) return rows[j]; return null }
function el(tag,attrs,text){const e=document.createElementNS(NS,tag);for(const k in attrs)e.setAttribute(k,attrs[k]);if(text!=null)e.textContent=text;return e}
function lastN(n){ // 최근 n판 (주차 기록은 판수에 안 셈)
  if(!n||n<=0) return DATA.slice();
  let c=0,i=DATA.length-1;
  for(;i>=0;i--){ if(!DATA[i].stop){c++; if(c===n) break;} }
  return DATA.slice(Math.max(0,i));
}
function draw(n){
  curN=n;
  const rows=lastN(n), svg=document.getElementById('chart'), ax=document.getElementById('yaxis'), sc_=document.getElementById('scroller');
  svg.innerHTML=''; ax.innerHTML=''; const rax=document.getElementById('raxis'); rax.innerHTML='';
  document.querySelectorAll('.ctl button[data-n]').forEach(b=>b.classList.toggle('on',+b.dataset.n===(n||0)));
  if(!rows.length) return;
  const sc=rows.map(r=>r.s).filter(v=>v!=null); let lo=sc.length?Math.min(...sc):0,hi=sc.length?Math.max(...sc):100;
  if(TARGET!==null&&sc.length){lo=Math.min(lo,TARGET);hi=Math.max(hi,TARGET)}
  const pad=Math.max(20,(hi-lo)*0.1); lo=Math.floor((lo-pad)/50)*50; hi=Math.ceil((hi+pad)/50)*50;
  const N=rows.length, avail=sc_.clientWidth, W=Math.max(avail,(N-1)*PX+PAD*2), PW=W-PAD*2;
  svg.setAttribute('width',W);
  const X=i=>PAD+(N>1?PW*i/(N-1):PW/2), Y=v=>T+PH-(v-lo)/(hi-lo)*PH;
  let step=50; while((hi-lo)/step>10) step*=2;
  for(let v=lo;v<=hi;v+=step){svg.append(el('line',{x1:0,y1:Y(v),x2:W,y2:Y(v),class:'grid'}));ax.append(el('text',{x:62,y:Y(v)+4,class:'ylab'},fmt(v)))}
  if(TARGET!==null){svg.append(el('line',{x1:0,y1:Y(TARGET),x2:W,y2:Y(TARGET),class:'target'}));
    for(let x=6;x<W;x+=Math.max(avail,600)) svg.append(el('text',{x:x,y:Y(TARGET)-6,class:'tlab'},'목표 '+fmt(TARGET)))}
  let prevDay=null;
  rows.forEach((r,i)=>{const d=r.t.slice(0,10); if(d!==prevDay){svg.append(el('line',{x1:X(i),y1:T,x2:X(i),y2:T+PH,class:'day'}));svg.append(el('text',{x:X(i),y:T+PH+18,class:'xlab'},d.slice(5)));prevDay=d}});
  { let seg=[]; const flush=()=>{ if(seg.length>1) svg.append(el('polyline',{points:seg.join(' '),class:'line'})); seg=[] };
    rows.forEach((r,i)=>{ if(r.s==null) return; seg.push(X(i).toFixed(1)+','+Y(r.s).toFixed(1)) }); flush(); } // 점수 빈칸은 건너뛰고 이음
  const rad=N>300?1.5:(N>120?2.2:3);
  // 승급/강등 표시: 그 판 위치에 세로 점선 + 기호
  rows.forEach((r,i)=>{ const e=evOf(r); if(!e) return; const y=r.s!=null?Y(r.s)-12:T+12;
    svg.append(el('line',{x1:X(i),y1:T,x2:X(i),y2:T+PH,class:'evline '+e[2]}));
    const t=el('text',{x:X(i),y:y,class:'ev '+e[2]},e[1]); t.append(el('title',{},r.t+' | '+r.n+'번째 게임 후 '+e[0])); svg.append(t) });
  // ── 순위 (오른쪽 눈금, 숫자가 작을수록 위) ──
  const rk=rows.filter(r=>r.r!=null).map(r=>r.r);
  let RY=null;
  if(rk.length){
    let rlo=Math.min(...rk), rhi=Math.max(...rk);
    let rstep=1; const cand=[1,2,5]; let m=1; while(true){let ok=false; for(const c of cand){rstep=c*m; if((rhi-rlo)/rstep<=8){ok=true;break}} if(ok)break; m*=10}
    rlo=Math.max(0,Math.floor(rlo/rstep)*rstep-rstep); rhi=Math.ceil(rhi/rstep)*rstep+rstep;
    RY=v=>T+(v-rlo)/(rhi-rlo)*PH;
    for(let v=rlo;v<=rhi;v+=rstep) rax.append(el('text',{x:8,y:RY(v)+4,class:'rlab'},fmt(Math.max(v,1))+'위'));
    let seg=[];
    const flush=()=>{ if(seg.length>1) svg.append(el('polyline',{points:seg.join(' '),class:'rline'})); seg=[] };
    rows.forEach((r,i)=>{ if(r.r==null){flush();return} seg.push(X(i).toFixed(1)+','+RY(r.r).toFixed(1)) }); flush();
    rows.forEach((r,i)=>{ if(r.r==null) return; const c=el('circle',{cx:X(i),cy:RY(r.r),r:rad,class:'rpt'});
      c.append(el('title',{},r.t+' | '+r.n+'번째 게임 | 순위 '+fmt(r.r)+'위 | '+fmt(r.s)+'점')); svg.append(c) });
  }
  rows.forEach((r,i)=>{ if(r.s==null) return; const c=el('circle',{cx:X(i),cy:Y(r.s),r:r.stop?5:rad,class:'pt'+(r.stop?' park':'')});
    c.append(el('title',{},r.t+' | '+(r.stop?r.note:r.n+'번째 게임')+' | '+fmt(r.s)+'점'+(r.r!=null?' | 순위 '+fmt(r.r)+'위':'')));svg.append(c)});
  const games=rows.filter(r=>!r.stop).length, kn=rows.filter(r=>r.s!=null), first=kn.length?kn[0]:rows[0], last=kn.length?kn[kn.length-1]:rows[rows.length-1];
  const nUp=rows.filter(r=>{const e=evOf(r);return e&&e[0]==='승급'}).length, nDn=rows.filter(r=>{const e=evOf(r);return e&&e[0]==='강등'}).length;
  document.getElementById('sum').innerHTML=
    '표시 중: <b>'+games+'판</b> (전체 '+totalGames+'판) · '+(kn.length?fmt(first.s)+'점 → '+fmt(last.s)+'점 (<span class="'+(last.s>=first.s?'up':'down')+'">'+(last.s-first.s>=0?'+':'')+(last.s-first.s)+'</span>) · 최고 '+fmt(Math.max(...sc))+' · 최저 '+fmt(Math.min(...sc)):'점수 기록 없음')+
    ' · 승급 '+nUp+'번 / 강등 '+nDn+'번'+
    (rk.length?' · 순위 최고 '+fmt(Math.min(...rk))+'위 / 최저 '+fmt(Math.max(...rk))+'위':'')+
    '<br>'+first.t+' ~ '+last.t+' · 그래프 위에 마우스를 올리면 그 판의 점수·순위가 바로 보입니다. 빨간 점 = 주차(정지)';
  const tb=document.getElementById('tb'); tb.innerHTML='';
  for(let i=rows.length-1;i>=0;i--){const r=rows[i], p=i>0?rows[i-1]:null, df=(p&&p.s!=null&&r.s!=null)?r.s-p.s:null;
    const rd=(p&&p.r!=null&&r.r!=null)?r.r-p.r:null;
    const tr=document.createElement('tr'); const e=evOf(r);
    [r.stop?'-':r.n+'번째', r.res||'', r.s!=null?fmt(r.s):'', df===null?'':(df>=0?'+':'')+df, r.r!=null?fmt(r.r)+'위':'', rd===null?'':(rd>0?'▼'+fmt(rd):(rd<0?'▲'+fmt(-rd):'-')),
     r.t, (e?e[1]+' ':'')+r.note].forEach((v,k)=>{const td=document.createElement('td');td.textContent=v;
      if(k===1&&r.res)td.className=r.res==='승'?'up':(r.res==='패'?'down':'draw'); if(k===3&&df!==null)td.className=df>=0?'up':'down'; if(k===5&&rd)td.className=rd<0?'rup':'rdown'; if(k===7&&e)td.className=e[2]==='dn'?'down':'up'; tr.append(td)});
    tb.append(tr)}
  HV={rows,X,Y,RY,N,PW};
  hvGuide=el('line',{x1:0,y1:T,x2:0,y2:T+PH,class:'guide',visibility:'hidden'}); svg.append(hvGuide);
  hvS=el('circle',{r:6,class:'hs',visibility:'hidden'}); svg.append(hvS);
  hvR=el('circle',{r:6,class:'hr',visibility:'hidden'}); svg.append(hvR);
  sc_.scrollLeft=sc_.scrollWidth; // 최신 기록(오른쪽 끝)부터 보이게
  document.getElementById('hint').textContent=W>avail+1?'← 그래프가 길어서 가로 스크롤됩니다 (스크롤바를 끌거나, 그래프 위에서 마우스 휠)':'';
  try{localStorage.setItem('rk_n',String(n||0))}catch(e){}
}
const scroller=document.getElementById('scroller');
scroller.addEventListener('wheel',e=>{ if(scroller.scrollWidth>scroller.clientWidth && Math.abs(e.deltaY)>Math.abs(e.deltaX)){ scroller.scrollLeft+=e.deltaY; e.preventDefault(); } },{passive:false});
let rt; window.addEventListener('resize',()=>{clearTimeout(rt);rt=setTimeout(()=>draw(curN),150)});
// ── 마우스 올리면 가장 가까운 판의 점수·순위 표시 ──
let HV=null, hvGuide=null, hvS=null, hvR=null;
const tip=document.getElementById('tip'), chartEl=document.getElementById('chart');
function sgn(v){return v>0?'+'+fmt(v):(v<0?'-'+fmt(-v):'±0')}
function hideTip(){tip.style.display='none'; [hvGuide,hvS,hvR].forEach(e=>e&&e.setAttribute('visibility','hidden'))}
chartEl.addEventListener('mousemove',e=>{
  if(!HV||!HV.N) return;
  const pt=chartEl.getBoundingClientRect(), x=e.clientX-pt.left;
  let i=HV.N>1?Math.round((x-PAD)/HV.PW*(HV.N-1)):0; i=Math.max(0,Math.min(HV.N-1,i));
  const r=HV.rows[i], p=i>0?HV.rows[i-1]:null, gx=HV.X(i);
  hvGuide.setAttribute('x1',gx); hvGuide.setAttribute('x2',gx); hvGuide.setAttribute('visibility','visible');
  if(r.s!=null){hvS.setAttribute('cx',gx); hvS.setAttribute('cy',HV.Y(r.s)); hvS.setAttribute('visibility','visible')} else hvS.setAttribute('visibility','hidden');
  if(HV.RY&&r.r!=null){hvR.setAttribute('cx',gx); hvR.setAttribute('cy',HV.RY(r.r)); hvR.setAttribute('visibility','visible')} else hvR.setAttribute('visibility','hidden');
  let h='<div class="t">'+(r.stop?r.note+' 시점':r.n+'번째 게임')+' · '+r.t+'</div>';
  const pk=prevKnown(HV.rows,i);
  if(r.res) h+='<div><span class="k">결과</span><b class="'+(r.res==='승'?'up':(r.res==='패'?'down':'draw'))+'">'+r.res+'</b></div>';
  h+='<div><span class="k">랭킹점수</span>'+(r.s!=null?'<span class="sv">'+fmt(r.s)+'점</span>'+(pk?' <span class="t">('+sgn(r.s-pk.s)+')</span>':''):'<span class="t">기록 없음</span>')+'</div>';
  if(r.r!=null){ const rd=(p&&p.r!=null)?r.r-p.r:null;
    h+='<div><span class="k">순위</span><span class="rv">'+fmt(r.r)+'위</span>'+(rd===null?'':' <span class="t">('+(rd<0?'▲'+fmt(-rd):(rd>0?'▼'+fmt(rd):'변동 없음'))+')</span>')+'</div>'; }
  else h+='<div><span class="k">순위</span><span class="t">기록 없음</span></div>';
  const ev=evOf(r); if(ev) h+='<div><span class="k">티어</span><b style="color:'+(ev[2]==='dn'?'#ff5d7a':(ev[2]==='up'?'#3ddc84':'#ffc94a'))+'">'+ev[1]+' '+ev[0]+'</b></div>';
  else if(r.note&&!r.stop) h+='<div><span class="k">비고</span>'+r.note+'</div>';
  tip.innerHTML=h; tip.style.display='block';
  const tw=tip.offsetWidth, th=tip.offsetHeight;
  let lx=e.clientX+16, ly=e.clientY-th-12;
  if(lx+tw>window.innerWidth-8) lx=e.clientX-tw-16;
  if(ly<8) ly=e.clientY+16;
  tip.style.left=lx+'px'; tip.style.top=ly+'px';
});
chartEl.addEventListener('mouseleave',hideTip);
scroller.addEventListener('scroll',hideTip);
const inp=document.getElementById('cnt');
function go(){const v=parseInt(inp.value,10); draw(isNaN(v)||v<=0?0:v)}
document.getElementById('go').onclick=go;
inp.addEventListener('keydown',e=>{if(e.key==='Enter')go()});
document.querySelectorAll('.ctl button[data-n]').forEach(b=>b.onclick=()=>{const n=+b.dataset.n; inp.value=n||''; draw(n)});
// ── 날짜별 요약 (전체 기록) ──
function drawDaily(){
  const tms=DATA.map(r=>new Date(r.t.replace(' ','T')).getTime());
  const res=DATA.map((r,i)=>{ if(r.stop||r.s==null||i+1>=DATA.length||DATA[i+1].s==null) return null;
    const gap=(tms[i+1]-tms[i])/60000; return (gap>=0&&gap<=40)?DATA[i+1].s-r.s:null });
  const days={}, order=[];
  DATA.forEach((r,i)=>{const d=r.t.slice(0,10); if(!days[d]){days[d]=[];order.push(d)} days[d].push(i)});
  const tb=document.getElementById('db'); tb.innerHTML='';
  order.slice().reverse().forEach(d=>{
    const idx=days[d], games=idx.filter(i=>!DATA[i].stop), ks=idx.filter(i=>DATA[i].s!=null);
    // 승/무/패: 기록된 결과(결과 칸·점수 변화) 우선, 없으면 다음 판 점수와 비교
    const rs=games.map(i=>DATA[i].res||(res[i]===null?null:(res[i]>0?'승':(res[i]<0?'패':'무')))).filter(v=>v);
    const w=rs.filter(v=>v==='승').length, dr=rs.filter(v=>v==='무').length, l=rs.filter(v=>v==='패').length;
    const s0=ks.length?DATA[ks[0]].s:null;
    const lastI=ks.length?ks[ks.length-1]:null, sEnd=lastI==null?null:(DATA[lastI].stop?DATA[lastI].s:(res[lastI]!==null?DATA[lastI].s+res[lastI]:DATA[lastI].s));
    const rk=idx.map(i=>DATA[i].r).filter(v=>v!=null);
    const ups=idx.filter(i=>{const e=evOf(DATA[i]);return e&&e[0]==='승급'}).length, dns=idx.filter(i=>{const e=evOf(DATA[i]);return e&&e[0]==='강등'}).length;
    const cells=[d, games.length+'판', rs.length?(w+' / '+dr+' / '+l):'-', rs.length?Math.round(w/rs.length*100)+'%':'-',
      s0==null?'-':fmt(s0)+' → '+fmt(sEnd), s0==null?'-':(sEnd-s0>=0?'+':'')+fmt(sEnd-s0),
      rk.length?(fmt(rk[0])+'위 → '+fmt(rk[rk.length-1])+'위'):'-', rk.length?fmt(Math.min(...rk))+'위':'-', (ups||dns)?('▲'+ups+' / ▼'+dns):'-'];
    const tr=document.createElement('tr');
    cells.forEach((v,k)=>{const td=document.createElement('td'); td.textContent=v; if(k===5&&s0!=null) td.className=sEnd>=s0?'up':'down'; tr.append(td)});
    tb.append(tr)});
}
drawDaily();
// ── 패턴 분석 ──
function drawPatterns(){
  const tms=DATA.map(r=>new Date(r.t.replace(' ','T')).getTime());
  const G=[]; DATA.forEach((r,i)=>{ if(!r.stop) G.push(i) });
  // 결과: 기록된 결과 우선, 없으면 다음 판 점수와 비교 (40분 이내)
  const RES={};
  G.forEach((i,k)=>{ const r=DATA[i]; if(r.res){RES[i]=r.res;return}
    const j=G[k+1]; if(j==null||r.s==null||DATA[j].s==null) return; if((tms[j]-tms[i])/60000>40) return;
    const d=DATA[j].s-r.s; RES[i]=d>0?'승':(d<0?'패':'무') });
  const total=Object.keys(RES).length; const avg=total?Object.values(RES).filter(v=>v==='승').length/total:0;
  function rows(id, groups){
    const t=document.getElementById(id); t.innerHTML='<tr><th>구분</th><th>판수</th><th>승/무/패</th><th>승률</th></tr>';
    groups.forEach(([label,list])=>{ const n=list.length, w=list.filter(v=>v==='승').length, d=list.filter(v=>v==='무').length, l=n-w-d;
      const tr=document.createElement('tr'); if(n<10) tr.className='few';
      const wr=n?w/n:0, bar=n?'<span class="bar'+(wr<avg-0.05?' lo':'')+'" style="width:'+Math.round(wr*100)+'px"></span>'+Math.round(wr*100)+'%':'-';
      tr.innerHTML='<td>'+label+'</td><td>'+n+'</td><td>'+(n?w+' / '+d+' / '+l:'-')+'</td><td class="wr">'+bar+'</td>'; t.append(tr) });
  }
  // 1) 세션 안 몇 판째
  const sessIdx={}; let idx=0;
  G.forEach((i,k)=>{ if(k===0||(tms[i]-tms[G[k-1]])/60000>40) idx=0; idx++; sessIdx[i]=idx });
  const SB=[[1,5],[6,10],[11,20],[21,30],[31,50],[51,1e9]];
  rows('p_sess', SB.map(([a,b])=>[(b>1e8?a+'판째 이후':a+'~'+b+'판째'), G.filter(i=>RES[i]&&sessIdx[i]>=a&&sessIdx[i]<=b).map(i=>RES[i])]));
  // 2) 직전 연패/연승 뒤
  const after={'첫 판(직전 기록 없음)':[], '1승 뒤':[], '2연승 이상 뒤':[], '무승부 뒤':[], '1패 뒤':[], '2연패 뒤':[], '3연패 뒤':[], '4연패 이상 뒤':[]};
  G.forEach((i,k)=>{ if(!RES[i]) return; let n=0, last=null;
    for(let m=k-1;m>=0;m--){ const v=RES[G[m]]; if(!v) break; if(last===null) last=v; if(v!==last) break; n++; }
    const key= last===null?'첫 판(직전 기록 없음)': last==='무'?'무승부 뒤': last==='승'?(n>=2?'2연승 이상 뒤':'1승 뒤'): (n>=4?'4연패 이상 뒤':n+(n===1?'패 뒤':'연패 뒤'));
    after[key].push(RES[i]) });
  rows('p_after', Object.entries(after));
  // 3) 시간대 (3시간 단위)
  rows('p_hour', [0,3,6,9,12,15,18,21].map(h=>[String(h).padStart(2,'0')+'~'+String(h+3).padStart(2,'0')+'시',
    G.filter(i=>RES[i]&&(new Date(tms[i]).getHours()>=h)&&(new Date(tms[i]).getHours()<h+3)).map(i=>RES[i])]));
  // 4) 요일
  rows('p_wday', ['일','월','화','수','목','금','토'].map((d,w)=>[d+'요일', G.filter(i=>RES[i]&&new Date(tms[i]).getDay()===w).map(i=>RES[i])]));
  // 5) 연승/연패 길이
  const runs={'승':[],'패':[]}; let cur=null, n=0;
  G.forEach(i=>{ const v=RES[i]; if(!v){ if(cur&&runs[cur]) runs[cur].push(n); cur=null; n=0; return }
    if(v===cur) n++; else { if(cur&&runs[cur]) runs[cur].push(n); cur=v; n=1 } });
  if(cur&&runs[cur]) runs[cur].push(n);
  const t=document.getElementById('p_streak'); t.innerHTML='<tr><th>구분</th><th>최장</th><th>3번 이상 연속</th><th>5번 이상 연속</th></tr>';
  [['연승','승'],['연패','패']].forEach(([lab,k])=>{ const a=runs[k]; const tr=document.createElement('tr');
    tr.innerHTML='<td>'+lab+'</td><td>'+(a.length?Math.max(...a):0)+'</td><td>'+a.filter(x=>x>=3).length+'번</td><td>'+a.filter(x=>x>=5).length+'번</td>'; t.append(tr) });
  const tr=document.createElement('tr'); tr.innerHTML='<td>전체 승률</td><td colspan="3" style="text-align:left">'+total+'판 · '+Math.round(avg*100)+'% (이보다 5%p 넘게 낮은 칸은 빨간 막대)</td>'; t.append(tr);
}
drawPatterns();
let init=100; try{const s=localStorage.getItem('rk_n'); if(s!==null) init=+s}catch(e){}
inp.value=init||''; draw(init);
</script></body></html>"""
