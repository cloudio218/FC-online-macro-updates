# -*- coding: utf-8 -*-
"""
FC 딸깍이 Pro v4.0 - 이적시장 갱신꾼 엔진 (갱신 매크로 v3.6.1 빠른 버전에서 옮김, tools/build_transfer_core.py 로 만듦)
바뀐 점: 화면(App)은 transfer_app/transfer_ui 로 새로 · 데이터는 기록 폴더\갱신꾼 · 감독모드와 화면 나눠 쓰기(Arbiter)
  - 감독모드 경기 중이면 매 분 갱신 구간(0~20초)이 끝나면 이적시장을 닫고, 다음 분 0초 N초 전(기본 3초)에 다시 엶
  - 감독모드가 교체 등으로 화면이 필요하면(예약·사용 중) 그 분은 쉼 (필요할 때만 비켜 주기)
  - ⭐ 최우선 선수: 감독모드가 로비에서 기다리는 동안 로비 이적시장으로 갱신 (lobby_ok)

이적시장 갱신 매크로 v1.1
FC ONLINE 거래목록 '재등록' 갱신싸움 자동화 — 선수 프리셋 10개 + 시간 예약

프리셋마다 "홀수시/짝수시/매시 + 시작 분"을 정해두면
  그 시각(미리 준비 몇 초 전)에 기준가를 저장하고
  시작 분부터 N분(기본 20분) 동안, 매 분 설정 구간(기본 0~18초)에만
    재등록 → 구매 창 → 상한가/하한가 무조건 클릭 → 같으면 ESC / 다르면 확정
  성공하거나 N분이 지나면 그 프리셋은 끝. 모든 프리셋이 끝나면 매크로 종료.
"""
import ctypes
import ctypes.wintypes as wt
import datetime
import json
import os
import base64
import io
import queue
import re
import shutil
import subprocess
import sys
import urllib.request
import urllib.error
import http.client
import email.utils
import ssl
import statistics
import uuid
import threading
import time
import traceback
import tkinter as tk

try:
    import mss
except ImportError:                     # 실행기(exe)에 mss 가 없음 -> 같은 모양의 GDI 캡처
    import mss_shim as mss
import numpy as np
from PIL import Image, ImageTk, ImageOps

APP_NAME = "FC 딸깍이 Pro · 이적시장 갱신꾼"
VERSION = "4.0"
N_PRESETS = 10

# ───────────────────────── DPI (좌표·캡처를 실제 픽셀로 통일) ─────────────────────────
# v4.0: 감독모드 매크로와 같은 프로그램이라 DPI 설정은 건드리지 않음 (Windows 배율 100% 기준)
user32 = ctypes.windll.user32 if hasattr(ctypes, "windll") else None


BASE = DATA_DIR = CAP_DIR = LOG_DIR = CFG_PATH = HIST_PATH = ""


def configure(base):
    """v4.0: 데이터 위치 (감독모드 기록 폴더\\갱신꾼). 다른 함수보다 먼저 한 번"""
    global BASE, DATA_DIR, CAP_DIR, LOG_DIR, CFG_PATH, HIST_PATH
    BASE = base
    DATA_DIR = os.path.join(base, "data")
    CAP_DIR = os.path.join(base, "captures")
    LOG_DIR = os.path.join(base, "logs")
    CFG_PATH = os.path.join(DATA_DIR, "settings.json")
    HIST_PATH = os.path.join(DATA_DIR, "history.json")

# ───────────────────────── 입력 (SendInput, 스캔코드) ─────────────────────────
ULONG_PTR = ctypes.c_size_t


class MOUSEINPUT(ctypes.Structure):
    _fields_ = [("dx", wt.LONG), ("dy", wt.LONG), ("mouseData", wt.DWORD),
                ("dwFlags", wt.DWORD), ("time", wt.DWORD), ("dwExtraInfo", ULONG_PTR)]


class KEYBDINPUT(ctypes.Structure):
    _fields_ = [("wVk", wt.WORD), ("wScan", wt.WORD), ("dwFlags", wt.DWORD),
                ("time", wt.DWORD), ("dwExtraInfo", ULONG_PTR)]


class HARDWAREINPUT(ctypes.Structure):
    _fields_ = [("uMsg", wt.DWORD), ("wParamL", wt.WORD), ("wParamH", wt.WORD)]


class _INPUTUNION(ctypes.Union):
    _fields_ = [("mi", MOUSEINPUT), ("ki", KEYBDINPUT), ("hi", HARDWAREINPUT)]


class INPUT(ctypes.Structure):
    _anonymous_ = ("u",)
    _fields_ = [("type", wt.DWORD), ("u", _INPUTUNION)]


INPUT_MOUSE, INPUT_KEYBOARD = 0, 1
MOUSEEVENTF_LEFTDOWN, MOUSEEVENTF_LEFTUP = 0x0002, 0x0004
KEYEVENTF_KEYUP, KEYEVENTF_SCANCODE = 0x0002, 0x0008
SC_ESC, SC_ENTER = 0x01, 0x1C
VK_F9, VK_F10, VK_MENU = 0x78, 0x79, 0x12


def _send(inp):
    user32.SendInput(1, ctypes.byref(inp), ctypes.sizeof(INPUT))


def mouse_move(x, y):
    user32.SetCursorPos(int(x), int(y))


def mouse_click():
    d = INPUT(type=INPUT_MOUSE)
    d.mi = MOUSEINPUT(0, 0, 0, MOUSEEVENTF_LEFTDOWN, 0, 0)
    u = INPUT(type=INPUT_MOUSE)
    u.mi = MOUSEINPUT(0, 0, 0, MOUSEEVENTF_LEFTUP, 0, 0)
    _send(d)
    time.sleep(0.012)
    _send(u)


class Clicker:
    """구매/판매 창이 떠 있는 동안 지금 마우스 자리(상한가/하한가)를 연타.
    매 클릭 전에 창이 아직 떠 있는지 직접 확인 → 창이 사라지면 즉시 멈춤 (거래목록 버튼 오클릭 방지)"""

    def __init__(self):
        self.ev = threading.Event()
        self.lock = threading.Lock()
        self.t = None
        self.n = 0

    def start(self, interval, checks):
        """checks = [(절대좌표 rect, 템플릿), ...] 중 하나라도 맞으면 창이 떠 있는 것"""
        self.stop()
        self.ev.clear()
        self.n = 0
        self.t = threading.Thread(target=self._run, args=(interval, checks), daemon=True)
        self.t.start()

    def _run(self, interval, checks):
        with mss.mss() as sct:
            while not self.ev.is_set():
                ok = False
                for (x, y, w, h), t in checks:
                    a = to_arr(sct.grab({"left": x, "top": y, "width": w, "height": h}))
                    if similar(a, t):
                        ok = True
                        break
                if not ok:
                    return                       # 창이 닫힘 → 더 누르지 않음
                with self.lock:
                    if self.ev.is_set():
                        return
                    mouse_click()
                    self.n += 1
                self.ev.wait(interval)

    def stop(self):
        """멈추고, 누르던 클릭이 끝날 때까지 기다림 (이후엔 절대 클릭 안 함)"""
        self.ev.set()
        with self.lock:
            pass
        if self.t is not None:
            self.t.join(0.3)
            self.t = None

    @property
    def running(self):
        return self.t is not None and self.t.is_alive()


def key_press(sc):
    d = INPUT(type=INPUT_KEYBOARD)
    d.ki = KEYBDINPUT(0, sc, KEYEVENTF_SCANCODE, 0, 0)
    u = INPUT(type=INPUT_KEYBOARD)
    u.ki = KEYBDINPUT(0, sc, KEYEVENTF_SCANCODE | KEYEVENTF_KEYUP, 0, 0)
    _send(d)
    time.sleep(0.015)
    _send(u)


# ───────────────────────── 게임 창 ─────────────────────────
def find_game(title):
    return user32.FindWindowW(None, title) or None


def client_origin(hwnd):
    p = wt.POINT(0, 0)
    user32.ClientToScreen(hwnd, ctypes.byref(p))
    return p.x, p.y


def client_size(hwnd):
    r = wt.RECT()
    user32.GetClientRect(hwnd, ctypes.byref(r))
    return r.right, r.bottom


def bring_to_front(hwnd):
    """예약 시각에 게임 창을 맨 앞으로 (Alt 한 번 눌러 포커스 잠금을 풀고 전환)"""
    if user32.IsIconic(hwnd):
        user32.ShowWindow(hwnd, 9)  # SW_RESTORE
    d = INPUT(type=INPUT_KEYBOARD)
    d.ki = KEYBDINPUT(VK_MENU, 0, 0, 0, 0)
    u = INPUT(type=INPUT_KEYBOARD)
    u.ki = KEYBDINPUT(VK_MENU, 0, KEYEVENTF_KEYUP, 0, 0)
    _send(d)
    _send(u)
    user32.SetForegroundWindow(hwnd)


# ───────────────────────── 이미지 비교 ─────────────────────────
def to_arr(shot):
    """mss 캡처 → H×W×3 (BGR) int16"""
    return np.asarray(shot, dtype=np.uint8)[:, :, :3].astype(np.int16)


def similar(a, t, tol=12.0, raw_tol=50.0):
    """템플릿과 같은 화면인지. 마우스 호버로 배경색이 살짝 바뀌는 건 무시."""
    if a is None or t is None or a.shape != t.shape:
        return False
    if float(np.abs(a - t).mean()) > raw_tol:
        return False
    an = a - np.median(a, axis=(0, 1))
    tn = t - np.median(t, axis=(0, 1))
    return float(np.abs(an - tn).mean()) <= tol


def sim_score(a, t, raw_tol=60.0):
    """작을수록 비슷함 (모양이 다르거나 밝기가 크게 다르면 아주 큰 값)"""
    if a is None or t is None or a.shape != t.shape:
        return 1e9
    if float(np.abs(a - t).mean()) > raw_tol:
        return 1e9
    an = a - np.median(a, axis=(0, 1))
    tn = t - np.median(t, axis=(0, 1))
    return float(np.abs(an - tn).mean())


def diff_pixels(a, b):
    """두 캡처 사이에 확실히 달라진 픽셀 수"""
    if a is None or b is None or a.shape != b.shape:
        return 10 ** 9
    return int(np.count_nonzero(np.abs(a - b).max(axis=2) > 40))


def ink_map(a, both=False):
    """밝은 배경 위 어두운 글자의 진하기 (0~1). 글자가 없거나 너무 흐리면 None
    both=True: 배경과 다른 정도를 밝기 방향 상관없이 (금액 칸처럼 파란 바탕에 흰 글씨가 섞인 곳)"""
    g = np.asarray(a, np.float64)[:, :, :3].mean(axis=2)
    ink = np.abs(np.median(g) - g) if both else np.clip(np.median(g) - g, 0, None)
    top = float(np.percentile(ink, 99.5))
    if top < 40:
        return None
    return np.clip(ink / top, 0, 1)


def ink_top(a):
    g = np.asarray(a, np.float64)[:, :, :3].mean(axis=2)
    return float(np.percentile(np.clip(np.median(g) - g, 0, None), 99.5))


def text_mismatch(cur, base, win=14, step=7, sx=2, sy=1, thr=0.55, both=False):
    """글자 모양 비교: 14px 구간마다 ±2px 맞춰본 뒤 가장 안 맞는 구간의 '확실히 다른 픽셀 수'.
    애니메이션 중 반 픽셀 밀림·살짝 작아짐·흐림은 무시됨 (같은 숫자 0~6 · 한 자리 다른 숫자 12 이상)"""
    A, B = ink_map(base, both), ink_map(cur, both)
    if A is None or B is None or A.shape != B.shape:
        return 999
    H, W = A.shape
    xs = np.where((A > 0.5).any(axis=0) | (B > 0.5).any(axis=0))[0]
    if len(xs) == 0:
        return 999
    lo, hi = int(xs[0]), int(xs[-1]) + 1
    P = np.pad(B, ((sy, sy), (sx, sx)))
    worst = 0
    x0 = lo
    while True:
        x0 = min(x0, max(lo, hi - win))
        x1 = min(W, x0 + win)
        a = A[:, x0:x1]
        best = 10 ** 9
        for dy in range(-sy, sy + 1):
            for dx in range(-sx, sx + 1):
                b = P[sy + dy:sy + dy + H, sx + dx + x0:sx + dx + x1]
                best = min(best, int((np.abs(a - b) > thr).sum()))
                if best == 0:
                    break
            if best == 0:
                break
        worst = max(worst, best)
        if x1 >= hi:
            break
        x0 += step
    return worst


AMOUNT_DY = {"buy": 73, "sell": 98}   # 상한가 → 금액 칸 (구매 창 73px · 판매 창 98px 아래, 실측)
SELL_SHIFT = 29        # 판매 창은 구매 창보다 하한가·상한가가 29px 아래 (1280×720 기준 실측)
def field_change(cur, ref, win=16, step=8, sx=2, sy=1, thr=1.2):
    """금액 칸이 바뀌었는지: 밝기·대비를 맞추고 16px 구간마다 ±2px 맞춰 비교.
    숫자 바뀜 58~121 · 같은 숫자(창 뜨는 중 흐림·작아짐) 0~9 → 25 이상이면 바뀜"""
    def z(a):
        g = np.asarray(a, np.float64)[:, :, :3].mean(axis=2)
        return (g - np.median(g)) / max(8.0, float(g.std()))
    A, B = z(ref), z(cur)
    if A.shape != B.shape:
        return 999
    H, W = A.shape
    P = np.pad(B, ((sy, sy), (sx, sx)), mode="edge")
    worst, x0 = 0, 0
    while True:
        x0 = max(0, min(x0, W - win))
        a = A[:, x0:x0 + win]
        best = 10 ** 9
        for dy in range(-sy, sy + 1):
            for dx in range(-sx, sx + 1):
                b = P[sy + dy:sy + dy + H, sx + dx + x0:sx + dx + x0 + win]
                best = min(best, int((np.abs(a - b) > thr)[1:-1].sum()))
        worst = max(worst, best)
        if x0 + win >= W:
            break
        x0 += step
    return worst


FIELD_CHANGED = 25


def blue_px(a):
    """금액 칸의 파란 선택 표시 픽셀 수 (BGR). 창이 막 열리면 파랑(약 1000) → 가격을 클릭하면 회색(0)"""
    b, r = a[..., 0].astype(int), a[..., 2].astype(int)
    return int(((b - r > 60) & (b > 150)).sum())


BLUE_FRESH = 100       # 이 이상이면 아직 클릭 안 먹힘 (파랑)
BLUE_DONE = 20         # 이 미만이면 클릭 먹힘 (회색)
FAST_SAME = 6          # 글자 모양 차이가 이 이하면 '같은 가격'으로 바로 판단
FAST_DIFF = 12         # 이 이상이 두 장 연속 + 반대쪽 가격도 바뀌었으면 '확실히 바뀜' → 기다리지 않고 바로 확정
BG_TOL = 6             # 가격 칸 바탕 밝기가 기준과 이만큼 이상 다르면 '창이 아직 다 안 밝아짐(뜨는 중)' → 비교 안 함
SHIFT_X, SHIFT_Y = 4, 2  # '바뀜' 판정 때는 위치 밀림을 ±4px까지 봐줌 (창 뜨는 중 3px 밀린 같은 숫자를 바뀜으로 오판한 사례)


def bg_level(a):
    """캡처 바탕 밝기 (중앙값). 구매 창이 다 뜨면 약 248~250, 뜨는 중(반투명)이면 230대"""
    return float(np.median(np.asarray(a, np.float64)[:, :, :3].mean(axis=2)))


def bg_ok(cur, base_bg):
    return base_bg is None or abs(bg_level(cur) - base_bg) <= BG_TOL


def really_diff(cur, base):
    """'바뀜'을 확정할 때 쓰는 엄격한 비교: 위치 밀림을 넉넉히 봐줘도 여전히 다른 숫자인지"""
    return text_mismatch(cur, base, sx=SHIFT_X, sy=SHIFT_Y)


def has_content(a):
    """빈 칸이 아니라 숫자가 그려져 있는지"""
    return float(a.mean(axis=2).std()) > 6


def compose(*imgs, gap=10):
    """BGR int16 캡처 여러 장 → 가로로 이어 붙인 RGB PIL 이미지"""
    arrs = [np.clip(a, 0, 255).astype(np.uint8)[:, :, ::-1] for a in imgs]
    h = max(a.shape[0] for a in arrs)
    canvas = np.full((h, sum(a.shape[1] for a in arrs) + gap * (len(arrs) - 1), 3), 255, np.uint8)
    x = 0
    for a in arrs:
        canvas[:a.shape[0], x:x + a.shape[1]] = a
        x += a.shape[1] + gap
    return Image.fromarray(canvas)


# ───────────────────────── 로비 ↔ 감독모드 좌표 변환 ─────────────────────────
LAYOUT_NAMES = {"lobby": "로비", "manager": "감독모드", "moved": "위치 자동 맞춤"}
SCREEN_MODES = {"auto": "자동 감지", "lobby": "로비만", "manager": "감독모드만"}


def to_gray(a):
    return np.asarray(a, dtype=np.float64)[:, :, :3].mean(axis=2)


def ncc_map(img, tmpl):
    """정규화 상관(NCC) 지도 — 각 위치의 일치도 (1.0이 완전 일치). 계산 불가면 None"""
    img = np.asarray(img, np.float64)
    t = np.asarray(tmpl, np.float64)
    H, W = img.shape
    h, w = t.shape
    if h > H or w > W:
        return None
    t = t - t.mean()
    tn = float(np.sqrt((t * t).sum()))
    if tn < 1e-6:
        return None
    fh, fw = H + h - 1, W + w - 1
    corr = np.fft.irfft2(np.fft.rfft2(img, (fh, fw)) * np.fft.rfft2(t[::-1, ::-1], (fh, fw)),
                         (fh, fw))[h - 1:H, w - 1:W]
    ii = np.pad(img, ((1, 0), (1, 0))).cumsum(0).cumsum(1)
    ii2 = np.pad(img * img, ((1, 0), (1, 0))).cumsum(0).cumsum(1)

    def win(a):
        return a[h:, w:] - a[:-h, w:] - a[h:, :-w] + a[:-h, :-w]
    s1, s2 = win(ii), win(ii2)
    var = s2 - s1 * s1 / (h * w)
    ncc = corr / (np.sqrt(np.maximum(var, 1e-6)) * tn)
    ncc[var < 1e-2 * h * w] = -1
    return ncc


def match_template(img, tmpl):
    """가장 잘 맞는 위치 (x, y, 점수)"""
    ncc = ncc_map(img, tmpl)
    if ncc is None:
        return 0, 0, -1.0
    y, x = np.unravel_index(int(np.argmax(ncc)), ncc.shape)
    return int(x), int(y), float(ncc[y, x])


def match_peaks(img, tmpl, thr, max_n=6):
    """기준 이상으로 맞는 위치들 [(x, y, 점수), ...] — 같은 이름이 여러 줄일 때"""
    ncc = ncc_map(img, tmpl)
    if ncc is None:
        return []
    ncc = ncc.copy()
    h, w = np.asarray(tmpl).shape
    out = []
    for _ in range(max_n):
        y, x = np.unravel_index(int(np.argmax(ncc)), ncc.shape)
        sc = float(ncc[y, x])
        if sc < thr:
            break
        out.append((int(x), int(y), sc))
        ncc[max(0, y - h // 2):y + h // 2 + 1, max(0, x - w // 2):x + w // 2 + 1] = -1
    return out


def match_fast(img, tmpl):
    """큰 화면용: 1/2 크기로 대략 찾고 → 원래 크기로 주변만 정밀 검색"""
    img = np.asarray(img, np.float64)
    t = np.asarray(tmpl, np.float64)
    if img.shape[0] * img.shape[1] < 200_000 or min(t.shape) < 12:
        return match_template(img, t)
    def half(a):
        a = a[:a.shape[0] // 2 * 2, :a.shape[1] // 2 * 2]
        return (a[0::2, 0::2] + a[1::2, 0::2] + a[0::2, 1::2] + a[1::2, 1::2]) / 4
    cx, cy, _ = match_template(half(img), half(t))
    m = 4
    x0, y0 = max(0, cx * 2 - m), max(0, cy * 2 - m)
    x1 = min(img.shape[1], cx * 2 + t.shape[1] + m)
    y1 = min(img.shape[0], cy * 2 + t.shape[0] + m)
    x, y, sc = match_template(img[y0:y1, x0:x1], t)
    return x + x0, y + y0, sc


def find_header(client_bgr, cfg, which="lobby"):
    """게임 화면에서 이적시장 제목줄을 찾아, 지정할 때 위치와의 차이 (dx, dy, 점수)"""
    t = load_template(f"header_{which}")
    panel = cfg["rects"].get(f"panel_{which}")
    if t is None or not panel:
        return None
    hx, hy = header_rect(panel)[:2]
    x, y, sc = match_fast(to_gray(client_bgr), to_gray(t))
    return x - hx, y - hy, sc


def same_size(cfg):
    """감독모드 창이 로비와 크기가 사실상 같으면(드래그 오차 3% 이내) True"""
    sc = layout_scale(cfg)
    return sc is None or (abs(sc[0] - 1) < 0.03 and abs(sc[1] - 1) < 0.03)


def layout_scale(cfg):
    L, M = cfg["rects"].get("panel_lobby"), cfg["rects"].get("panel_manager")
    if not (L and M):
        return None
    return M[2] / L[2], M[3] / L[3]


def map_pt(cfg, pt):
    """로비 기준 좌표 → 감독모드 좌표"""
    L, M = cfg["rects"]["panel_lobby"], cfg["rects"]["panel_manager"]
    sx, sy = layout_scale(cfg)
    return [round(M[0] + (pt[0] - L[0]) * sx), round(M[1] + (pt[1] - L[1]) * sy)]


def map_rect(cfg, r):
    sx, sy = layout_scale(cfg)
    x, y = map_pt(cfg, r[:2])
    return [x, y, max(2, round(r[2] * sx)), max(2, round(r[3] * sy))]


def header_rect(panel):
    """이적시장 창 맨 위 제목줄 가운데 ('이적시장' 글자) — 로비/감독모드 구분용"""
    x, y, w, h = panel
    hh = max(12, min(40, int(h * 0.05)))
    return [x + int(w * 0.35), y + 3, max(20, int(w * 0.30)), hh]


def manager_ready(cfg):
    return (layout_scale(cfg) is not None
            and os.path.exists(tmpl_path("dialog_manager"))
            and os.path.exists(tmpl_path("header_lobby"))
            and os.path.exists(tmpl_path("header_manager")))


def tmpl_path(key):
    return os.path.join(DATA_DIR, f"tmpl_{key}.png")


# 감독모드 이적시장 다시 열기용 버튼 이미지 (1280×720 게임 화면 기준, data/tmpl_<이름>.png 를 넣으면 그걸 우선 사용)
EXTRA_TEMPLATES = {}                # v4.0: {이름: png 경로} - 예) home_market = 감독모드 홈 아래 줄 [이적시장]
BUILTIN_TEMPLATES = {
    "menu": (
        "iVBORw0KGgoAAAANSUhEUgAAABsAAAAbCAIAAAACtmMCAAAAuElEQVR42u2TQQ6CQAxFXwd3hpWRk0DieXDvPfAOnIjZyIqJ"
        "G6+gE6OSMOPOFQkTxUQDXbb5L21/K5vdquUGgAgoFQlKJPIeARyozokTADwIeK8AHB6cd6+KEgQl6yRh1FCMHTPxV4mL3mxd"
        "H0LEeb7VWn+9x2leeL8zZVkOKj1tsS+O5hREzLJ0kOi4x/Ey1JksHSZ2tMaYq338odfv7xFoGmOtDZr6ky/s77GqdADQXex5"
        "/sIpE58BDT5iOiaXoAAAAABJRU5ErkJggg=="
    ),
    "menu_market": (
        "iVBORw0KGgoAAAANSUhEUgAAAJIAAAAhCAIAAAC9R2UCAAAGVUlEQVR42u1ab2iTSRr/zUyaNDa1f2gSaHqJpxaholXS26qo"
        "VE68rHcL2nLQLyIIVhChgmVPC1Vpy3rigXqCoCfWP7kPEbUia0X8gxjzwVvbJet/uvlwtpa2qKlo06bJzHMfXg3ZbNxtFjl4"
        "5f19mneemXlnnh/PM88zM+yr/QuhAAAEggIjQAKQpBQkwLliQgiAK1IEYpKBAQBxglIK4AATQgguwCSIAJBSiqCBMw4OAEwB"
        "UARI4hAmE4MAOJcykZRJmZhK0IRSkwStI+PEFRQATpygCCBIMM6YNi5jHIwJE8/njClIggRJqaSSUvsrAxMQEgQoAArgCgx5"
        "4IxAgFRKAQQOzhgDiKAUgRQYAK71gPah8hhMxJNMKLxfDxjyoJikJEEqpYjASJuWAggAEwwEKA4FbS2a6jg4g4kYZxAAA4go"
        "oWRSUkJJKClJKcY5GBiE4ByAVIpIkgLjgjGYaEr9+O8ksoDj/fQAvOfyQzm9zc8bZCCrKKNGAFbACgPTA2eCG1rQH23ElKEF"
        "/dFmMucZWtAfbZDS0IL+aJMwnKQurc1Qgh5Dkp8E9AZ0kwAwQws6dJIGDNoM6Iy2RdUL2lpbPlc1zZw502w2f0xqs9kKCgo+"
        "Ji0oKCgsLMwqYoyVlpZaLJZc52PKtUPb7rZfiErbdrdd+fbbvr7v9U6Sw+FIJBIjIyOTk5MA2tvbL168GAwGvV6v3W5PtXz5"
        "8mU4HG5qaorH40ePHiUiABaLpbi4eHR0VPvctGmTy+XauXOny+Vyu92pvlLKSCTS1dV1+PDhmzdv5kabjMtPmDRwyK/+8uWf"
        "fX/s+OYfOuWspKRk7969+fn5Npvt3r17J06ciMViKanD4XC73TU1NaWlpdeuXeOcc57psebNm7d169bt27drlKdQXl6+ZMkS"
        "h8NRW1t748aNaDQ6NDT02yZp+uTLPnnq7MDzAf2a2oYNG/Lz81tbW4UQR44cCYVCvb29moiIenp6TCaT3W63Wq3Hjh3zer1N"
        "TU01NTWhUCg1ghDCas1ym3H//v3e3t76+vqqqiq/3z84OKi5x8bGxrKyskuXLsXj8enSlpRJQEx/VR3tHVnrF1QvWPvl2v1/"
        "36/3bWz16tWBQODVq1cA+vv73W53ijYNbrd7/vz5TqfT5/O9fv06kUgopTKsatasWUJkapWISkpKGhsbzWbzihUrzp8/r3nR"
        "Fy9eDA0NZQzyK7R9qqOtB+EHD8IPPoPoY8aMGW/fvtXK4+Pj6ZGIxWKpq6vbuHHjrVu3Hj9+vGPHjp6entOnT2fY1tKlSwsL"
        "C71e7507d9LrFy5cuHnz5oGBAb/fv2XLltmzZ/v9fgDBYDAYDOa2T4nc022353dtuz/boHFgYMDj8aR2smg0mh741dbWnjt3"
        "7tSpU6FQqLm5eXBwMMNKFi1atHjx4u7u7j179qQHkIyx6urqSCTS2tra19fX0tLy8OHD8fHx37i3CSGQy/lW2+4WwApMfChk"
        "YOLIP/81NvZGv7T5/f5t27aFw2GbzVZeXt7f358STU5Otre3u91un8+XqlyzZs3IyMjTp0+FEFVVVR0dHVevXu3q6nK5XJ2d"
        "nfv27Ut5yLNnzwoh5s6dW11dXVZWRkQrV648cOBAhhOeXkjCOKZ3nPyHL7w+39oPkaQ529sCKFg1f61f3L592263r1u3DsCh"
        "Q4eeP3+e0SAvLy8jD1u1alVxcfGjR4+WL19+5cqVM2fOxGKxXbt2NTQ0pGcLAJYtW9bc3Hz58uVnz54B8Hg869ev7+zsfPLk"
        "SW60UXK6CcB3/+n9Ifzw6799DUBBAOD0s75sQu+0SSkDgcCFCxeIKJnM8somEolEIpH0GqfTCSAejx8/flwppbnNaDR68uRJ"
        "Iqqrq0vPDcxmcyAQ0ILGoqKi+vr6OXPm5EybVHL6kWQ8Hu9o72j4a0NV5e/1m5n9KogokUik17x7925qaupj7WOxmCbNoFnj"
        "b2JiIpX5dXd3ezyegwcPDg8Pc86dTufdu3evX7+e6wzZn76p/O8ZAQO/iMrKytHR0Tdvsu/ZFRUVSqmP5c4VFRUWiyVloEII"
        "l8tVVFRERGNjY8PDw1lt2qDtMwRPPRc1oCfapuJThhb0R9vk1BtDCzq8b+PGWxLjdtvA/4c2JQ1r0+ODO2XQpkPa8slmaEF3"
        "+B9AFbgabn7WzAAAAABJRU5ErkJggg=="
    ),
    "tab_trades": (
        "iVBORw0KGgoAAAANSUhEUgAAAGoAAAAfCAIAAACArM+yAAAEOUlEQVR42u2ZzU8bRxTA3355zRrbENubGCUUY5skUJOKAEFQ"
        "g6kaSiSktFETNemph/w9rdQcKvXAoZekbaJUQVVa1FRQPtsQIBTzFUdpi8HfNrbX613vRw+bbowdiFQpVVfad5r35s3szm/e"
        "zLzZRRw0Dbr8W0F1BDo+HZ+OT8eni45Px6fj0/G9BsEwjCBwBEEOckAQBMdxFNXGvOL/8fNOnWxpbDwxPTOXzWYrqt5oPGE0"
        "GlPp9Jl2359/bW9ubqlVza6m6q6YQiEajSnEOzreqnZgC+zWk1CpVNIePoLA/f4+VRUEYWNjKxqNnTzV0tfbs/L7qizLA/0v"
        "HCYmpzs7z9K0Y3pmNhDwz8zMl+O7eu2KKIglQXgeoQAEQYRCT7/+5o6C71x3574QRlG7zZZnmO0vRzWJD0WxM+0+pUyZKNJg"
        "SKUySrAoYjAQLlcTAJjN5iNH6h8uLB7Sm8Nun5//7cHPE4pqNpsvDA9ZrRZFlWV5NxKt2CJMFIWh6MGbxP8bH8dxn352QykP"
        "v3e+v7+vWGTLHZLJ1Oc3vgCAnp7u9y+OIK8aqNForLNalXJtbS1B4MUiqPgCA36O41KpdHmTaCwmiqK29z4MwzweN8fxsiQ3"
        "u5rUkCFJ0uNuBoCGBieGYWqcNjidGFb5VuHwjt1uu3TpIk07eJ5PJJIAkEimyn3S6czM7Fy5RZZkUdA4Pq/Xffx4QzC47vO1"
        "eb2euro6xW61Wq5f/2Rvby+dzoTDOzxfAgDaYae6zpKkQW1uMlEWi2V8/AEA1NaaRkYuJJMpReV4zuk8lkgkSiVh4dEiAHjc"
        "bre7GcOxYHANACRRWlpeATVKNYePph2DgQGe5+//MC5J8qPF5XcGB3y+NnXRraysTkxOAUAmkwGA3d3I0tLjoaF31R5aW08P"
        "BvqVPAbDMJIkHQ778PB5pVaSpLGx+07n0UKBBQACxyVJRCVEUUGW/W/3zs3/WrGotYHPZrNd/vADl6tpdPSrWCyuGLO53L7k"
        "gykkEsmampr6+joA4Dg+lU5L0osVFwo9ze1vUiEURXV2dZgoqvyUb/9nhgBgNbimPXwtLd6Pr10RBOHmzW/X1jeqHWRZ5nne"
        "7+/z+3slWd4J70Sj8Wo3ZeRXP7pckVtjGBbe3rl95y4ArAXXu891VbctsuzS8grHcdpbvNlsNhhcf7iw+OzZH5IkVTvk88y9"
        "e9+LkiSKIssW9zKZrq7OAw5xfmsrVG4hjaTvzTan89jzHNNAeD3NFXkfTTtQBN3YfKJJfJFI9O53Y4e8OsuyU9Oz5ZaD8DEM"
        "8+P4T+UWi8VylKaNRqM6E7du3d6XtBuIQKC/rfW0hi9tL2WXy+VjsfhLbwKTv0wZDAYEQeKJJMMwh/QsS1I+n+d5Xj1Acvn8"
        "vlHheDyeiEQirzvvQ/Q/bfoHKx2fjk/Hp4uOT8en49Px6fIq+Rtri86MN7AwqQAAAABJRU5ErkJggg=="
    ),
    "close_x": (
        "iVBORw0KGgoAAAANSUhEUgAAACIAAAAhCAIAAAAzse47AAAC2klEQVR42mNUUVFhoD1gYqALGLVm1BqsogICApGR4czMzMQb"
        "pKGhrqOjjUuWWUhICFM0ISEuLy/79evXt27d+v//P34LGBkZVVRU5syZoaamumnTFhKsuXLlKjs7e0ZG6o8fP69cuYrfJk1N"
        "jQkTet68eVtT0/Dx40cSrPnz58+ZM+fk5eViY6Pv3r1/7959XHZISkrMnz/n9+/fCQkpr169Ii3QGBgY/v37d/ToMUFBwfT0"
        "lLdv396+fRvTT0pKipMnT/j27Vt+ftGLFy/x+BinNQwMDH/+/D158rSmpkZcXPSVK9cePXqMlkwWL17AyckZG5v47Nlz/PGH"
        "zxoGBoa/f/8ePHhYVlY6JSX50aPHDx8+gPhJVlZmypQJjIyMubkFT548IZgOCVgDiaeTJ0/p6elERoZfvHj56dNnfHy8M2dO"
        "ExUVTUvLxBNtpFnDwMDw69evAwcO6erqxMfHvXz5srKyTEhIKDe34PbtO0TmKqKsYWBg+P379/HjJ4yNDWNjozk5OXNzC65d"
        "u06TwoaRkZGBgRGS3JiYmGhSpnFzczc3N6irq1ZUVN2//6C3t0tbW4vK1vDy8vT0dBgaGhQUlOzYsSs7O+/z589Tp05SVFRg"
        "ZGSkjjWcnJy1tdX6+vq1tQ1nz55jYGD49OlzXl7hixcvJk+eoKamSlSA429ycHCwd3W1W1tb5eUVHT16DFmKn59/9eplrKxs"
        "YWFRr1+/Jt83HBzspaXFZmamzc1tJ06cQJP9+PFjRkbOhw8fZs2apqioQKZvWFlZm5vr3d3dysoq9+zZh6uQFhcXW7ly2c+f"
        "P8LConEVzzh9w87OnpeX4+jo0Ns7Yd++A3gqgpcvX6WnZ/39+2/WrGmysjKkWZOQEBcdHdHe3r18+Yq/f//iD5Bbt27n5hZI"
        "Sko0NNSSVgo8ePDw1atX69Zt+Pv3HzEJ6f3798eOnTh37gKu6oBxtHE7ag1dAAA8njKiBh/wLwAAAABJRU5ErkJggg=="
    ),
}


# 프로그램 창 아이콘 (64px PNG) — exe 아이콘은 빌드할 때 icon.ico
APP_ICON_PNG = (
    "iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAASBUlEQVR4XtVbCXSc1XX+3vuXWTQzGo1WL3jBILMb4wABu8ih"
    "ocBJmrJUcELShBDa1FAg22mbcqhx24BpmxOazSxuUkhIipWkpTmcAGGxICyOWGzHsUHIxraEZe3S7PMv7/Xc98+MRvtYso35"
    "dAYZz/z/vHvfvd/97n2/GY4Q6yE5mrZyYC26k2+wI7z8mGBeaJUEtgKta8UGMAmAXkcTkq1vekE/mnc8lqC1SsiyNmfGDzU3"
    "S62lhbmFBd+6ZncjBDsbrlws4EaOpSHlgQMcSQ3aAVewXZu2Ld9TuG782ifDNA6QbD3ANoCJdWt2VmnCvFFIcQMgVxg8YDCm"
    "5e83ow+PAySkFLDdlMvAfy8ZHhewfvjAq+f2rsd6vgF3S3ipMQFTrJ7Cx7tg3YU7v8C5sUHngZNcacFxs5AQLuTkN/zAwCRj"
    "YJrO/dC4D7ZI90jh/tOmbWf/gNbkOWKDGL++SRzgGd98xi6zOoyHTb3ic7abhissBwBnjNE1J8K2TwZJsUA7pHFDN7UQLDf5"
    "i/54340tuz+WnMwJ44hNsubmFt7wVrueC2ef8OmVl6etAQcMnIGpz0p5tAn2qKKwOdwRlnTFkOM3qq6tComGW5p2XYHWljRK"
    "opvAS7++uRm8peU6N1MV3+zXI5en7H4LTDmJk1s/TD8UpRLSSNkDtk8Pr7bS1mOUAmRjqc3FUC4w5s0XtH3Or8ceydjDNmMw"
    "jur+fECQEnbAqDKy9sDtm9vO/25pdcg7wKuZn1+xtdIwIm9zbtQS4Y2PkA8xBGc6pBBJm9nLH2m7oIcSmYFJFQ7rm7ZqFDFc"
    "D33BNML1tpsVEvJDF/bTpCh3XEuYRjiiga8jW+9WNhfZ3KtpN61qe1PXAitcNyMkQ6HQf/CgbZq7wBU69zFHZPcZUjv9oTdW"
    "OWQ+V9oeTN688s1lAM5yRJpJFRmFb/xgf9PWsDQDHKiYnMO6uC0yYExf5jBxlir1zVs436oaG8Dm9rm6FtClkK6UklG5OxFe"
    "cCWGr++DE7XBEgxCE7Nfl4CrMz9cKc4jm8/orWV8bSHApbuEMY787U+Mkkc7nmVIXhrHoQf2wTolAz6keU6Y5Q8Yg2RiKZnd"
    "nQwzTv+h/xES4RNhxyesARJ8RIO1JIdDP9iPxJVD4IOaZz5V+iOOVAHpijDZPC+UkEUlyEjk5b16YkFCahI8rUEaEr3//D6s"
    "U7OIbqoF0bT0SaDYq04Pj0GUki3KWR14Q10lCsF/IkldteI88WlkKANPcgzf1A9rWQ7V/9IAbUCHCLuAU0Z7Ij0pXyrmx8jC"
    "I84rUgpaXjHQn4/JS4y2XmQjtf+DOtJrkjj80EFkz06DUUrQOiglyvihzS6gmAJCePTnJUIZYABP5KtlGc6fFahAp6gEUoNa"
    "cgddgsc1OPNs9H6/C9Fv1SL080rIsFBFvcS+schHQOn747vB8sZptB5i50+OIHtJSoXmMXOCC9jLcur7xnyHJr2/04DBu3pg"
    "n5pD5f01YCLPC1Psopfio2+WOEBA5Bl1WpBoTnCkrkhg8J7DgH2stj8PirTMJFFAyO82H+FI3DAEe4mF6L210Hp1KM4Y74R8"
    "BJRORUZTIN/rS/X29EYxVyJ7cVoZr/VrGB9HRxtSp4nWFHelv9cArU9H5tIkRMRFzZfme5VhwjUeQ5TmwJgIKKsMkhe5hPm6"
    "H+lr4xAxdyZ/zRksx5UUntQJeXvcWhe+V4OIfrMG0ianTJYDnoVCTkqCnmEzlkEXcCtcBJ6sgAzUIHdJegpvHwXQDroMTqMF"
    "USkmOoHs4ICoEgj+bwiR+6rBMhwyQMZM8v3jUnwrxgTvqLycERQFpkTwZ2EEHg8duwigKpBmGHygB+6aLBjxTSGsXUD6vdSI"
    "/GsMFY9GIIMSIkg7NFUWq/3Pp7kH3ZNBXlYUZGW5cEOTSDBaEy2cgWbHc3OO6lOJBcetiDrDiADv1RG5OwbfSwG4UfIIRUz+"
    "s9NEgChhwSPngFJMGDIDnDM4loCdE/BXaChJt9mh9DvyBsqYgPE7PyL/GIPWqcOtyu/6jJhIgqO+9UJg1i+KHk0DUgkbwbCO"
    "5nUnq2iVYvb3HLOefL7LqID/pyFUrqsBO8zhRkgGH+F3lKCkDHq5UaYOnABNZxgezGFJYxh3bloFn4+j5cG98Pm5J+fngny+"
    "k/AJbYjC/3gIMiSgRrb5yC8P+SowuRA6cg4gMO6x0lBfDms/NR+333sOwpUG3tkxDFZsV8tb3gTkQ15USmiHNYS/HIP+hglB"
    "IU8RUWYXWEShCpSQwLgIKORIedA0BstyVb7f+LfL8ZnbG9WFFPYUEaONySxB1cwvYfzWhPl0BNp7hqc7SBPMCoUIGMUoCZar"
    "A/LQdY5k3Ea4ysA3vnMeLrqsAYJmyRLKMcXW0zusmj044N9codQeqTyQyJktijpgMiFUpg6g8sY1hqGBLE4/rwp/f/8qLDw5"
    "BNclEmTKCV5uAHSArA6R5+IAurbCuwE1Oh5tF27I1Hrou8vDdBFQBgdQiaMdHerP4crrl+D2b66AP6AVjS+FcAUSwxYMc+4k"
    "6LXqXmRpGlcbQOtwbQHHkQhVGvm1zeCGmTjAGxhNfhfOGLJZUiASt244B39+8ynq22jHVcjn4R0eAwuWhHDPoxephc02Ashw"
    "Itlw2IRuaEgmHAwP5ZBJOyoFiWz3/WEETzy6F7bl5tc+XSM30b4xHCBoCjtZwjLAdgSq63z4yr0r8ZGmeghXqsUpA0uQtx8V"
    "EQMXXzavvMicAdtf78ZzT+5GV8deOJleMJlRKl5oVahfcjKMsMBIl0QkbMK2yRFTCNDCAHWqecCU3WC+j75r04U4bUUVrJwL"
    "0zf9wRH50bFLxlllQAknktIM0A2OV1sP4uH7fg0z+zKaPrIfl1+awLx6BwGfhOMw9A9x7NkbhFx6El7sa0R3/ymorYqpiKOO"
    "j02IhgIHTEqCU+sAWhBdet9X2/C1jatw1vnVKu9p9ws7Ph7095T/s8V373kRr/7PY7j18zuwek0S8HEg672kK2H6GBbFGBad"
    "mcbln9yNmw7uw8M/bcSvnl+Fmsql4Jxk+Lh0LnLA6KrK6gUUAekMBzvi+PpnWnHbhpX4xKeXekpVeKlQQGEH0ykH7TuHVGNU"
    "LgcQn+g6Q8tjbUjs/iH+6zvtMMOAO6hjeDCN+HAKuZxdTD/D0FARDqCqOoSGegd3/d12nN04iI0P/RGqQqd5ThiT0l43OPlQ"
    "tEiBk5MgeZ2aG8r9jV/9HTp2D+Fv1q9UjimUwEIlISLs3BvHbdc8D9NXXhWghRq6ht7BXly2uhXf/rd3AEtDotNCd+cAbMtB"
    "KOJHdW0IpqnBcQSyGRsjgwkM9sVRN68S1XWVuOragzD0F7HhewZqo6eOI/VpSZAmqtMPRMhQCu1IlYEtD72DfW8P487/+Cjq"
    "5gfhOp76K4DSI1ChlVkGKZ04UukszjxjD+69821l/HBPBp3v9aGyKogljbUwfTqgc8icC2aSMpIQjsBAbwLdXUOwcw7qZQyf"
    "+FQn2ve34We/iqIuVgfHzY+T8ilQOhEqJmlpBEw3W6fBqeMKRGt8ePOVHqz7s2fx5m97lPEUHYWIUzJeiLJfFP7pXBe+/Bc7"
    "oYdcJAdtdO7vQ928CBaR8SYdhwG5pIWf/PgdvNc+BOj0iINE7cIoTm6sw0BfAv09I5AZE1/6dAfmN7QjnbVURJbaVIoSliKx"
    "Uf7JK5UbqsND/Rl87bNb0bL5HSVQOB0VKHIYJdWZzu9IY8STWZx7+l6cv2oAIq7hcNcAwpEA6k+qgrSFchBxzbPPHERvbw7P"
    "P9eFxEAWzOQQWQehWBALFsfQ2z2CzLCDYJ2Fqz/+LuKpIY/ES2wrJaVxNF2YmZf327YFDB+HYTJ86x/acM9XXkMu6yqPU46W"
    "d5bvlcqslcDHLuwCghLx4azK73kLo95BjZTgAQOvvfQ+2tsTiEQYUkkHTz25X6Ueo8bLchGrC8HvNzDQFwcsHWsv6EFFoA9O"
    "USp7dpWy3GgK5E+GZtqt0vfpZiR56ZbRahNP/ORd3HL1b3C4K4VotQ8uvVfG6S1xi2mO4Jzlw4DDER9OI1Bhwhc0VI7zoIG9"
    "u/qxbVsfAgFyroTPz9D1fgatz3YqPlBRxxmi1UGkElmQVjppfgYLGgaQzXntY2EtZGuRq0rzoZxztUk/Q7zgCFTV+LBnez9u"
    "vfYZPPvEfpjUJ1CHOM0PgXYoFEyhriarzhpyWRvBClPpOW5q6OtM4KmnDqqJUyF8KSX8fuDNt4bw1qvd4H5dPUxB15HjKRJ5"
    "UKChJgHLcbzZxHTnAkfjdLjAC/09aTy4cTsCQZIZM7TDNDwVAqZhw28Kj9mFUE0PxaeVdfDKy4cQCBrQaeSW8vph2nC/X0NF"
    "SMOOHQNYsDCMuoWhojRXHSIHAn67eO5ZjICSXS8RQqNnq3MB7SbJWMP0DCsLjMGydeQsjhAjIuVqFwkaGK64cikMv6YId8vj"
    "7YpjcjmJi1fX4ezz6+GmbE/2uuQ8L8M11YQxZHOG4pixVWD0UXo9FGr0rpAySapuxoORMnAk91AExxmS6SD6Bn2oXmDB5zeQ"
    "SdsqGqi8agZXJY9UYilUe6wzcEMrdqGZtKWix+fXINJAT38Iuqap2q8iwBvSJuk+yWQ742il8xE6gNEOCLgQ9IzY7NlgVldy"
    "LpHJhvGHd6OALhCuDCCdysHK2orYiGi9sjrW+4WD3uJ5hpRKMgdDPrAgcKjbj87DMZimN6jx6pKAy9gBuhNtPj0kpWJNc90d"
    "tpt2mYSi1HLY++h8xksVXQ/i+W0LgSwpzYBSfYe7RpQDVMNVGDTRQ/HFl+cQ1X8YHMP9KRUB1bURwHDw4ut1GEnGoPHCeaDQ"
    "HJGlL3yLrqtr7ZP5Z+glu2R/x7tSunsYMyhY8odr5emB8ur91PcixVgR1NH2+8XYsb0aWtjFvAXVGB5Ko69rBIzYj84AhUQ2"
    "K5HLCvXb0xqAZmjIxLPo3D+I2voIglEDuUEDv/zNKQj4Q+r+5GfODLjSOhDUBnfSdS24Tqgy2IStmvrHBFI+xpjBhBTHMQIK"
    "vEPpU4dvP3Im3DRDqNqHhYur0f3+MLr29cPJuaiM+nHNtUtx1TVLcd31S3FqYwywBQZ64uh4uwfRWBA1DVVgFTn8qGUZOg4u"
    "hd+nQQiXOEAwZjIp5H8/1XFHrgnrVYlSDmjFWnWKxy1rs+0mBznTqS2aoYLPLt+nusoVLiqCJra/vRz/vulMMJ+FWH0Ii5fV"
    "IRnPon3nIXR3DiJWZaC+zoeGehPpRBrtOw6hu2sYdQ1RzF9UAz2WwwtPL8R//mIlIuEIHFeNyiTVFttNpZktv0+2tuZTf/Rx"
    "eWzRWnCde/HizX9tapWbbDdBteX4Pi6fH3wOj/Tjs3/6Or5+yy4wncMeoSl0Ss0DrJzj9QVqaqQhFPHmAcGoDvgtPPv0Qtx1"
    "/0Xg2qKSeYC0DS1i2G78Gy8f+OLGgq20+WPqStEJizb/0tAjV9tO3AZjx9cJqoYDI/ERrF65B3d8cReWnz7iHTnnOCTlvppG"
    "ARpNnOiIXHMx3OPDj7acgsf+bwVMX/2o8VLauhY2HJF87pUDB/+kGWcyyv0CrY4boZJAuJtdVr8skPI7T+s8uNp2kzYg9WKh"
    "PU4gIZNM5VDh68GlF+3Dx9d04YxlcVRX2mAGURrVcR373g/ipbYG/HrryTh4eAEi4ZAKeKkKPnN0rcJw3Mx2Kdw/fq3r5iGy"
    "DyX/eGqSGfJ6Th9oqv1eKBcI/NjgwascmSYicRg9TDzxtP6YgZxAEiCVzkFjSdRUjaA2lkIwYMG2NQwMB9E7EEEmF0Eg4Idp"
    "koJUDC4447rOK+CIzDOOk7qh7dBtA8jbVrrgKYbonhPogxedtPkOMH4X575qIS3QC5LN+nTuyOA9AULSmP5oO1CdIA1lFAdo"
    "njpUb3uUrXFmMM58ECI3IqV732udf7nRC/dRm8pwgJIXKh3IER9duGmBZMZfAbiOMZxGXzC3Rz+OFNLbKRJAJczlKUHvFECN"
    "O6VFvzsY8HPJ7Ae3HVi337NDXTTpsHPGh/xKGbMJL+i5Re+dI4Q4F0wsAROROT8BMkeopBQ8yTgOcKFv7/MndnZ03JGj25au"
    "fY6QLC8cPhTw1kohPzNmjIBxYM3YwntRy9A0882PK1qBOvTJ0hJXDv4fBEllRBe+gssAAAAASUVORK5CYII="
)


def load_builtin(key):
    """data/tmpl_<key>.png 가 있으면 그것, 없으면 내장 이미지"""
    t = load_template(key)
    if t is not None:
        return t
    raw = base64.b64decode("".join(BUILTIN_TEMPLATES[key]))
    return np.array(Image.open(io.BytesIO(raw)).convert("RGB"))[:, :, ::-1].astype(np.int16)


def load_template(key):
    p = tmpl_path(key)
    if not os.path.exists(p):
        return None
    return np.array(Image.open(p).convert("RGB"))[:, :, ::-1].astype(np.int16)


# ───────────────────────── 시간 계산 ─────────────────────────
def in_sec_window(t, s, e):
    """매 분 s초 ~ e초 구간 안인지 (58~18처럼 분을 넘겨도 됨)"""
    sec = t % 60
    if s <= e:
        return s <= sec < e
    return sec >= s or sec < e


def until_sec(t, s):
    return (s - (t % 60)) % 60


def _hour_ok(hour, parity):
    if parity == "odd":
        return hour % 2 == 1
    if parity == "even":
        return hour % 2 == 0
    return True


def _candidate_starts(t, parity, minute):
    base = datetime.datetime.fromtimestamp(t).replace(minute=0, second=0, microsecond=0)
    for dh in range(-3, 4):
        h = base + datetime.timedelta(hours=dh)
        if _hour_ok(h.hour, parity):
            yield (h + datetime.timedelta(minutes=minute)).timestamp()


def session_window(t, parity, minute, dur, prep):
    """지금이 (시작-준비 ~ 시작+지속) 안이면 (시작, 끝) 타임스탬프"""
    for s in _candidate_starts(t, parity, minute):
        if s - prep <= t < s + dur:
            return s, s + dur
    return None


def next_start(t, parity, minute):
    return min(s for s in _candidate_starts(t, parity, minute) if s > t)


def hhmm(ts):
    return datetime.datetime.fromtimestamp(ts).strftime("%H:%M")


def human(sec):
    sec = int(max(0, sec))
    h, r = divmod(sec, 3600)
    m, s = divmod(r, 60)
    if h:
        return f"{h}시간 {m}분"
    if m:
        return f"{m}분 {s}초"
    return f"{s}초"


# ───────────────────────── 설정 ─────────────────────────
PARITY = {"odd": "홀수시", "even": "짝수시", "every": "매시"}
TARGET = {"upper": "상한가", "lower": "하한가"}
SIDE = {"buy": "구매", "sell": "판매"}          # v3.6: 거래목록에서 이 선수가 '구매 중'인지 '판매 중'인지
HIST_KIND = {"success": "✅ 성공", "nochange": "➖ 안 바뀜", "missed": "⚠️ 놓침", "limited": "⛔ 제한",
             "error": "❌ 오류"}
CONFIRM_LABELS = {
    "enter": "Enter 누르기",
    "click": "구매 버튼 클릭",
    "click_enter": "구매 버튼 클릭 → Enter",
}


def default_preset(i):
    return {"enabled": False, "name": f"프리셋 {i + 1}", "parity": "odd", "minute": 0,
            "target": "upper", "side": "buy", "priority": 5, "points": {}, "rects": {},
            "star": False}                  # v4.0 ⭐ 최우선: 감독모드가 로비에서 기다리고 로비 이적시장으로


def preset_ready(p, i):
    """위치 지정이 끝나 실제로 돌릴 수 있는 프리셋인지"""
    return "reg_btn" in p.get("points", {}) and "row_check" in p.get("rects", {}) \
        and os.path.exists(tmpl_path(f"row_check_{i}"))


def prio(p):
    try:
        return max(1, min(10, int(p.get("priority", 5))))
    except (TypeError, ValueError):
        return 5


DEFAULT_CFG = {
    "window_title": "FC ONLINE",
    "points": {},            # 공통: buy_btn
    "rects": {},             # 공통: dialog, upper, lower
    "presets": [],
    "duration_min": 20,
    "prep_sec": 30,
    "start_sec": 0,
    "end_sec": 20,
    "clock_offset": 0.0,
    "confirm": "enter",
    "hover_ms": 40,
    "dialog_timeout_ms": 2000,
    "sensitivity": 12,
    "topmost": False,
    "discord_webhook": "",
    "tg_token": "",            # 텔레그램 봇 토큰 (BotFather 가 준 값)
    "tg_chat": "",             # 텔레그램 채팅 ID
    "auto_market": True,
    "fast_compare": True,
    "time_host": "fcalrimi.com",   # 이 사이트 시간에 맞춤
    "auto_time_sync": True,         # 시작할 때마다 자동으로 맞추기
    "test_sec": 20,                 # 테스트 시간 (0 = 한 번만)
    "spam_click": True,             # 구매 창이 떠 있는 동안 상한가/하한가 광클
    "spam_ms": 30,                  # 광클 간격 (ms)
    "screen_mode": "auto",   # auto / lobby / manager
    "tg_menu": True,                # v3.6: 텔레그램 메뉴로 원격 조작 (가격 확인·선수 관리·상태 등)
    "tg_daily": True,               # v3.6: 매일 밤 12시 하루 요약
    "end_report": True,             # v3.6: 20분 끝났는데 갱신 못 했으면 구매 창 캡처해서 알림
    "tg_ready": True,               # v3.6.1: 갱신싸움 준비(기준가 저장)가 끝나면 텔레그램으로 미리 알림
    "close_each_min": True,         # v4.0: 감독모드 경기 중이면 매 분 갱신 구간이 끝나면 이적시장 닫기
    "reopen_sec": 3,                # v4.0: 다음 분 0초 몇 초 전에 다시 열지
    "share_screen": True,           # v4.0: 감독모드가 교체 등으로 화면이 필요하면 그 분은 쉼 (B)
    "star_margin_sec": 60,          # v4.0: ⭐ 로비 대기 판단 여유 (경기 평균 시간 + 이만큼)
}

# 프리셋별 위치 (거래목록 화면)
PRESET_ITEMS = [
    ("reg_btn", "point", "재등록",
     "이 선수 줄에 마우스를 올렸을 때 '재등록' 버튼이 뜨는 자리를 클릭하세요 — 줄이 바뀌면 Y축이 따라갑니다"),
    ("row_check", "rect", "선수이름",
     "이 선수의 시즌 아이콘+이름을 드래그하세요 — 줄이 바뀌어도 이 이름을 찾아갑니다 (필수)"),
    ("my_price", "rect", "등록가",
     "이 선수 줄의 '금액' 숫자를 드래그하세요 — 갱신 성공 확인에 씁니다 (선택)"),
]
# 공통 위치 (구매 창)
SHARED_ITEMS = [
    ("dialog", "rect", "구매 창 표시",
     "구매 창 왼쪽 위의 '구매' 글자를 드래그하세요 — 창이 떴는지 판단합니다"),
    ("dialog_sell", "rect", "판매 창 표시",
     "판매 중인 선수의 재등록 창에서 왼쪽 위 '판매' 글자를 드래그하세요 — 판매 중 선수를 갱신할 때 필요"),
    ("sell_upper", "rect", "판매 상한가",
     "판매 창의 상한가 숫자를 드래그하세요 (선택 — 안 하면 구매 창 상한가에서 29px 아래로 자동)"),
    ("sell_lower", "rect", "판매 하한가",
     "판매 창의 하한가 숫자를 드래그하세요 (선택 — 안 하면 구매 창 하한가에서 29px 아래로 자동)"),
    ("upper", "rect", "상한가 숫자",
     "상한가 숫자를 드래그하세요 — 비교에 쓰고, 이 영역 가운데를 클릭합니다"),
    ("lower", "rect", "하한가 숫자",
     "하한가 숫자를 드래그하세요 — 비교에 쓰고, 이 영역 가운데를 클릭합니다"),
    ("buy_btn", "point", "구매 버튼",
     "빨간 '구매' 버튼을 클릭하세요 — 확정 방식이 '클릭'일 때만 필요"),
    ("book", "rect", "호가 목록",
     "구매 창 가운데 '금액 · 구매 수량' 표를 통째로 드래그하세요 — 성공 후 예상 순번 확인용 (선택)"),
]


# ───────────────────────── 디스코드 알림 · 글자 인식 ─────────────────────────
def discord_send(url, content, files=()):
    """디스코드 웹훅으로 메시지 + 이미지 전송. files = [경로, ...]"""
    boundary = uuid.uuid4().hex
    parts = []

    def add(header, data):
        parts.append(f"--{boundary}\r\n{header}\r\n\r\n".encode("utf-8") + data + b"\r\n")

    add('Content-Disposition: form-data; name="payload_json"\r\nContent-Type: application/json',
        json.dumps({"content": content}, ensure_ascii=False).encode("utf-8"))
    for n, path in enumerate(f for f in files if f and os.path.exists(f)):
        with open(path, "rb") as fh:
            add(f'Content-Disposition: form-data; name="files[{n}]"; filename="{os.path.basename(path)}"\r\n'
                f'Content-Type: image/png', fh.read())
    body = b"".join(parts) + f"--{boundary}--\r\n".encode("utf-8")
    req = urllib.request.Request(url, data=body, method="POST", headers={
        "Content-Type": f"multipart/form-data; boundary={boundary}",
        "User-Agent": "TransferMacro (personal, 1.0)"})
    with urllib.request.urlopen(req, timeout=20) as r:
        return r.status


def tg_clean_token(t):
    t = (t or "").strip().replace(" ", "")
    if t.lower().startswith("bot") and ":" in t:
        t = t[3:]
    return t


def _tg_call(token, method, fields=None, photo=None, timeout=20):
    """텔레그램 Bot API 호출. photo = 이미지 경로 (있으면 multipart)"""
    url = f"https://api.telegram.org/bot{tg_clean_token(token)}/{method}"
    if photo:
        boundary = uuid.uuid4().hex
        parts = []
        for k, v in (fields or {}).items():
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="{k}"\r\n\r\n'.encode("utf-8")
                         + str(v).encode("utf-8") + b"\r\n")
        with open(photo, "rb") as fh:
            parts.append(f'--{boundary}\r\nContent-Disposition: form-data; name="photo"; '
                         f'filename="{os.path.basename(photo)}"\r\nContent-Type: image/png\r\n\r\n'.encode("utf-8")
                         + fh.read() + b"\r\n")
        body = b"".join(parts) + f"--{boundary}--\r\n".encode("utf-8")
        headers = {"Content-Type": f"multipart/form-data; boundary={boundary}"}
    else:
        body = json.dumps(fields or {}, ensure_ascii=False).encode("utf-8")
        headers = {"Content-Type": "application/json"}
    req = urllib.request.Request(url, data=body, method="POST", headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            res = json.loads(r.read().decode("utf-8"))
    except urllib.error.HTTPError as e:
        try:
            res = json.loads(e.read().decode("utf-8"))
        except Exception:
            raise RuntimeError(f"HTTP {e.code}")
    if not res.get("ok"):
        raise RuntimeError(res.get("description", "알 수 없는 오류"))
    return res.get("result")


def telegram_send(token, chat_id, text, photos=()):
    """텔레그램으로 메시지 + 사진. 사진이 있으면 첫 사진에 글을 붙이고, 나머지는 사진만"""
    photos = [p for p in photos if p and os.path.exists(p)]
    if not photos:
        _tg_call(token, "sendMessage", {"chat_id": chat_id, "text": text})
        return
    for n, ph in enumerate(photos):
        f = {"chat_id": chat_id}
        if n == 0:
            f["caption"] = text[:1000]
        _tg_call(token, "sendPhoto", f, photo=ph)


def telegram_find_chat(token, wait=0):
    """봇에게 최근에 말을 건 채팅 → (채팅 ID, 이름). 없으면 None. wait 초 동안 새 메시지를 기다림"""
    try:
        ups = _tg_call(token, "getUpdates", {"timeout": wait}, timeout=wait + 10) or []
    except RuntimeError as e:
        if "webhook" in str(e).lower():                 # 웹훅이 걸려 있으면 풀고 다시
            _tg_call(token, "deleteWebhook", {})
            ups = _tg_call(token, "getUpdates", {"timeout": wait}, timeout=wait + 10) or []
        else:
            raise
    for u in reversed(ups):
        m = u.get("message") or u.get("channel_post") or u.get("my_chat_member") or {}
        ch = m.get("chat")
        if ch:
            name = ch.get("title") or " ".join(x for x in (ch.get("first_name"), ch.get("last_name")) if x) \
                or ch.get("username") or ""
            return ch["id"], name
    return None


def measure_server_offset(host, need=3, limit=6.0):
    """웹 서버 응답의 시각(Date, 초 단위)이 바뀌는 순간을 여러 번 잡아서 '서버 시각 − PC 시각'을 0.0x초 단위로 추정.
    서버시간 확인 사이트들과 같은 원리. 반환 (차이 초, 오차 초) / 실패 시 예외"""
    host = host.replace("https://", "").replace("http://", "").strip().strip("/").split("/")[0]
    ctx = ssl.create_default_context()
    proxy = os.environ.get("HTTPS_PROXY") or os.environ.get("https_proxy")
    if proxy:
        from urllib.parse import urlparse
        pu = urlparse(proxy)
        conn = http.client.HTTPSConnection(pu.hostname, pu.port, timeout=5, context=ctx)
        conn.set_tunnel(host, 443)
    else:
        conn = http.client.HTTPSConnection(host, timeout=5, context=ctx)
    prev, bounds = None, []
    end = time.time() + limit
    try:
        while time.time() < end and len(bounds) < need:
            t0 = time.time()
            conn.request("HEAD", "/", headers={"User-Agent": "Mozilla/5.0", "Cache-Control": "no-cache"})
            r = conn.getresponse()
            r.read()
            t1 = time.time()
            d = r.getheader("Date")
            if not d:
                raise RuntimeError("서버가 시각(Date)을 보내지 않아요")
            sec = email.utils.parsedate_to_datetime(d).timestamp()
            mid = (t0 + t1) / 2
            if prev and sec > prev[1]:
                bounds.append((prev[0], mid, sec))
            prev = (mid, sec)
            time.sleep(0.01)
    finally:
        conn.close()
    if not bounds:
        raise RuntimeError("시각이 바뀌는 순간을 못 잡았어요 (응답이 너무 느림)")
    offs = [S - (m0 + m1) / 2 for m0, m1, S in bounds]
    err = max((m1 - m0) / 2 for m0, m1, S in bounds)
    return statistics.median(offs), err


_OCR_PS = r"""
[Console]::OutputEncoding = [Text.Encoding]::UTF8
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics, ContentType = WindowsRuntime]
$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() | Where-Object {
  $_.Name -eq 'AsTask' -and $_.GetParameters().Count -eq 1 -and
  $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1' })[0]
Function Await($t, $type) { $a = $asTaskGeneric.MakeGenericMethod($type); $n = $a.Invoke($null, @($t)); $n.Wait(-1) | Out-Null; $n.Result }
$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
foreach ($path in @(__PATHS__)) {
  $f = Await ([Windows.Storage.StorageFile]::GetFileFromPathAsync($path)) ([Windows.Storage.StorageFile])
  $st = Await ($f.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
  $dec = Await ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($st)) ([Windows.Graphics.Imaging.BitmapDecoder])
  $bmp = Await ($dec.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
  $res = Await ($engine.RecognizeAsync($bmp)) ([Windows.Media.Ocr.OcrResult])
  Write-Output "===FILE==="
  foreach ($l in $res.Lines) { Write-Output $l.Text }
  $st.Dispose()
}
"""


def ocr_images(paths):
    """Windows 내장 글자 인식(OCR). 이미지마다 인식된 줄 목록을 돌려줌 (실패하면 None)"""
    try:
        quoted = ",".join("'" + os.path.abspath(pth).replace("'", "''") + "'" for pth in paths)
        script = _OCR_PS.replace("__PATHS__", quoted)
        enc = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
        out = subprocess.run(["powershell", "-NoProfile", "-ExecutionPolicy", "Bypass", "-EncodedCommand", enc],
                             capture_output=True, timeout=40, creationflags=0x08000000)
        text = out.stdout.decode("utf-8", errors="ignore")
        blocks = text.split("===FILE===")[1:]
        if len(blocks) != len(paths):
            return None
        return [[ln.strip() for ln in b.splitlines() if ln.strip()] for b in blocks]
    except Exception:
        return None


def parse_queue(lines):
    """호가 목록 OCR 결과에서 가장 높은 가격 줄(맨 아래)의 구매 수량 → (가격 글자, 수량)"""
    best = None
    for ln in lines or []:
        t = ln.replace(" ", "").replace(".", ",")
        m = re.search(r"(\d+억[\d,]*만?)(\d{1,4})$", t)
        if m and "억" in m.group(1):
            price = m.group(1)
            if not price.endswith("만"):           # '만'을 못 읽은 경우: 수량과 붙어버림 → 마지막 숫자 묶음만 수량으로
                mm = re.search(r"(\d+억[\d,]*?,\d{3})(\d{1,4})$", t)
                if not mm:
                    continue
                price, cnt = mm.group(1) + "만", mm.group(2)
            else:
                cnt = m.group(2)
            best = (price, int(cnt))
    return best


def parse_won(text):
    """'117만' · '1,060만' · '6억 8,800만' · '6억' · '760,000' → 원 단위 숫자. 못 읽으면 None"""
    if not text:
        return None
    t = re.sub(r"\s", "", text).replace(".", ",")
    for a, b in (("O", "0"), ("o", "0"), ("I", "1"), ("l", "1"), ("|", "1"), ("!", "1"), ("S", "5"), ("B", "8")):
        t = t.replace(a, b)
    m = re.search(r"(\d+)억(?:([\d,]+)만?)?", t)
    if m:
        eok = int(m.group(1))
        man = int(m.group(2).replace(",", "")) if m.group(2) and m.group(2).replace(",", "") else 0
        return eok * 100_000_000 + man * 10_000
    m = re.search(r"([\d,]+)만", t)
    if m and m.group(1).replace(",", ""):
        return int(m.group(1).replace(",", "")) * 10_000
    m = re.search(r"\d[\d,]*", t)
    if m:
        return int(m.group(0).replace(",", ""))
    return None


def fmt_won(v):
    if v is None:
        return "?"
    if v < 10_000 or v % 10_000:
        return f"{v:,}"
    eok, rest = divmod(v, 100_000_000)
    man = rest // 10_000
    if eok and man:
        return f"{eok}억 {man:,}만"
    if eok:
        return f"{eok}억"
    if man:
        return f"{man:,}만"
    return f"{v:,}"


def _upscale_save(arr, path, k=3):
    """BGR 캡처를 흑백·확대해서 저장 (OCR 정확도↑). 어두운 바탕에 흰 글씨면 뒤집어서 저장"""
    img = Image.fromarray(np.clip(arr, 0, 255).astype(np.uint8)[:, :, ::-1]).convert("L")
    if float(np.asarray(img).mean()) < 110:
        img = ImageOps.invert(img)
    img = img.resize((img.width * k, img.height * k), Image.LANCZOS)
    img.save(path)
    return path


def load_cfg():
    cfg = json.loads(json.dumps(DEFAULT_CFG))
    try:
        with open(CFG_PATH, encoding="utf-8") as f:
            cfg.update(json.load(f))
    except Exception:
        pass
    if cfg.get("cfg_rev", 0) < 2:
        if cfg.get("end_sec") == 18:
            cfg["end_sec"] = 20                 # 매 분 0~20초 갱신싸움
        cfg["auto_market"] = True               # 이적시장이 안 보이면 자동으로 열기 (기본)
        cfg["cfg_rev"] = 2
    presets = cfg.get("presets") or []
    while len(presets) < N_PRESETS:
        presets.append(default_preset(len(presets)))
    cfg["presets"] = presets[:N_PRESETS]
    for i, p in enumerate(cfg["presets"]):
        if "side" not in p:                      # v3.6 이전 설정: 하한가면 보통 판매 중 선수
            p["side"] = "sell" if p.get("target") == "lower" else "buy"
        for k, v in default_preset(i).items():
            p.setdefault(k, v)

    # v1.0 설정 이어받기 → 프리셋 1
    old_pts, old_rects = cfg["points"], cfg["rects"]
    p0 = cfg["presets"][0]
    if "reg_btn" in old_pts and "reg_btn" not in p0["points"]:
        p0["points"]["reg_btn"] = old_pts.pop("reg_btn")
        for k in ("row_check", "my_price"):
            if k in old_rects:
                p0["rects"][k] = old_rects.pop(k)
        if os.path.exists(tmpl_path("row_check")):
            shutil.move(tmpl_path("row_check"), tmpl_path("row_check_0"))
        if cfg.get("target") in TARGET:
            p0["target"] = cfg["target"]
    for k in ("target", "max_minutes", "after_success"):
        cfg.pop(k, None)
    return cfg


def save_cfg(cfg):
    os.makedirs(DATA_DIR, exist_ok=True)
    with open(CFG_PATH, "w", encoding="utf-8") as f:
        json.dump(cfg, f, ensure_ascii=False, indent=2)


# ───────────────────────── 갱신 기록 (v3.6) ─────────────────────────
_HIST_LOCK = threading.Lock()


def hist_load():
    with _HIST_LOCK:
        try:
            with open(HIST_PATH, encoding="utf-8") as f:
                h = json.load(f)
            return h if isinstance(h, list) else []
        except Exception:
            return []


def _hist_save(h):
    os.makedirs(DATA_DIR, exist_ok=True)
    tmp = HIST_PATH + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(h[-800:], f, ensure_ascii=False, indent=1)
    os.replace(tmp, HIST_PATH)


def hist_add(entry):
    """기록 한 줄 추가 → id 반환. entry: idx, name, side, target, kind(success/nochange/missed/limited/error), ..."""
    entry = dict(entry)
    entry.setdefault("id", uuid.uuid4().hex[:10])
    now = datetime.datetime.now()
    entry.setdefault("t", time.time())
    entry.setdefault("day", f"{now:%Y-%m-%d}")
    entry.setdefault("hm", f"{now:%H:%M:%S}")
    with _HIST_LOCK:
        try:
            with open(HIST_PATH, encoding="utf-8") as f:
                h = json.load(f)
            if not isinstance(h, list):
                h = []
        except Exception:
            h = []
        h.append(entry)
        try:
            _hist_save(h)
        except Exception:
            pass
    return entry["id"]


def hist_update(hid, **kw):
    if not hid:
        return
    with _HIST_LOCK:
        try:
            with open(HIST_PATH, encoding="utf-8") as f:
                h = json.load(f)
        except Exception:
            return
        for e in reversed(h):
            if e.get("id") == hid:
                e.update(kw)
                break
        try:
            _hist_save(h)
        except Exception:
            pass


def preset_stats(h, name):
    """선수 이름 기준: (성공 수, 끝난 판 수, 실제 갱신 시각 목록 'mm:ss')"""
    es = [e for e in h if e.get("name") == name and e.get("kind") in HIST_KIND]
    succ = sum(e["kind"] == "success" for e in es)
    seen = [e["seen"] for e in es if e.get("seen")]
    return succ, len(es), seen


def seen_summary(seen):
    """실제 가격대가 바뀐 걸 본 시각들 → '06:03 근처 (2~5초 · 4번)' 같은 요약"""
    if not seen:
        return ""
    secs = []
    for s in seen:
        try:
            m, x = s.split(":")
            secs.append(int(m) * 60 + float(x))
        except (ValueError, AttributeError):
            pass
    if not secs:
        return ""
    med = statistics.median(secs)
    lo, hi = min(x % 60 for x in secs), max(x % 60 for x in secs)
    rng = f"{lo:.0f}초" if round(lo) == round(hi) else f"{lo:.0f}~{hi:.0f}초"
    return f"{int(med // 60):02d}:{int(med % 60):02d} 근처 (매분 {rng} · {len(secs)}번)"


def day_summary(h, day):
    es = [e for e in h if e.get("day") == day and e.get("kind") in HIST_KIND]
    if not es:
        return f"📅 {day} 요약\n· 기록 없음"
    cnt = {k: sum(e["kind"] == k for e in es) for k in HIST_KIND}
    head = " · ".join(f"{HIST_KIND[k]} {v}" for k, v in cnt.items() if v)
    lines = [f"📅 {day} 요약", head]
    for e in es[-15:]:
        extra = []
        if e.get("queue"):
            extra.append(e["queue"])
        if e.get("enter_ms") is not None:
            extra.append(f"감지→Enter {e['enter_ms'] / 1000:.2f}초")
        lines.append(f"· {e.get('hm', '')[:5]} {e.get('name')} {HIST_KIND[e['kind']]}"
                     + (f" ({' · '.join(extra)})" if extra else ""))
    return "\n".join(lines)


def _notify_job(url, info, crop_png, shot, price_png, book_png, q, tg=None):
    price_txt, queue_txt = None, "확인 못 함 (사진 참고)"
    paths = [pth for pth in (price_png, book_png) if pth]
    res = ocr_images(paths) if paths else None
    if res:
        if price_png:
            joined = " ".join(res[0]).replace(" ", "")
            m = re.search(r"\d+억[\d,]*만", joined)
            price_txt = m.group(0) if m else None
        if book_png:
            pq = parse_queue(res[-1])
            if pq:
                queue_txt = f"{pq[1]}번째 ({pq[0]} 줄 구매 수량 기준)"
    q.put(("log", f"[{info['name']}] 예상 순번: {queue_txt}" + (f" · 등록가 {price_txt}" if price_txt else ""), "ok"))
    q.put(("result_info", f"예상 순번: {queue_txt}" + (f"   ·   등록가 {price_txt}" if price_txt else "")))
    if info.get("hid"):
        hist_update(info["hid"], queue=queue_txt.split(" (")[0], price=price_txt)
        q.put(("hist_changed",))
    text = (f"✅ {info['name']} 갱신 성공 ({info['time']})\n"
            f"· {info['label']}" + (f" {price_txt}" if price_txt else "") + "\n"
            f"· 예상 순번: {queue_txt}")
    if info.get("extra"):
        text += "\n" + info["extra"]
    if url:
        try:
            discord_send(url, text.replace(f"{info['name']} 갱신 성공", f"**{info['name']} 갱신 성공**", 1),
                         [crop_png, shot])
            q.put(("log", "디스코드로 성공 알림을 보냈어요", "ok"))
        except Exception as e:
            q.put(("log", f"디스코드 전송 실패: {e}", "error"))
    if tg and tg[0] and tg[1]:
        try:
            telegram_send(tg[0], tg[1], text, [crop_png, shot])
            q.put(("log", "텔레그램으로 성공 알림을 보냈어요", "ok"))
        except Exception as e:
            q.put(("log", f"텔레그램 전송 실패: {e}", "error"))


# ───────────────────────── 매크로 본체 ─────────────────────────
class Arbiter:
    """v4.0 감독모드 매크로와 갱신꾼이 게임 화면을 나눠 쓰기
    - gm_running: 감독모드 자동진행 중 (감독모드가 매 판 알려 줌)
    - lock: 갱신꾼이 이적시장을 열어 쓰는 동안 잡음 -> 감독모드는 그동안 아무것도 누르지 않음
    - want: 곧 열 거라 감독모드는 새 동작을 시작하지 말라는 표시
    - reserve: 감독모드가 곧 화면이 필요함(교체 등) -> 그 시간에 걸치는 분은 갱신꾼이 쉼
    - lobby_ok: 감독모드가 ⭐ 선수 때문에 로비에서 기다리는 중 -> 로비 이적시장을 열어도 됨
    - star_done: 로비에서 끝낸 ⭐ 선수 번호 (감독모드가 보고 다시 시작)"""

    def __init__(self):
        self.lock = threading.Lock()
        self.gm_running = False
        self.want = False
        self.owner = None
        self.lobby_ok = False
        self.lobby_idx = None
        self.star_done = set()
        self._res = {}
        self._rlock = threading.Lock()

    def take(self, timeout):
        """갱신꾼: 화면 잡기 (감독모드가 하던 동작이 끝날 때까지 최대 timeout초) -> True/False"""
        if self.owner == threading.get_ident():
            return True
        self.want = True
        ok = self.lock.acquire(timeout=max(0.0, timeout))
        if ok:
            self.owner = threading.get_ident()
        else:
            self.want = False
        return ok

    def give(self):
        self.want = False
        if self.owner == threading.get_ident():
            self.owner = None
            try:
                self.lock.release()
            except RuntimeError:
                pass

    @property
    def tr_busy(self):
        return self.owner is not None or self.want

    def gm_try(self):
        """감독모드: 이번 차례에 화면을 써도 되나 (잡았으면 끝나고 gm_done)"""
        if self.want or self.owner is not None:
            return False
        return self.lock.acquire(blocking=False)

    def gm_done(self):
        try:
            self.lock.release()
        except RuntimeError:
            pass

    def reserve(self, key, t0, t1, why):
        """감독모드: [t0, t1] (time.time 기준) 동안 화면 필요"""
        with self._rlock:
            self._res[key] = (t0, t1, why)

    def unreserve(self, key):
        with self._rlock:
            self._res.pop(key, None)

    def reserved(self, t0, t1):
        """[t0, t1] 에 걸치는 감독모드 예약 이유 / None"""
        now = time.time()
        with self._rlock:
            for k, (a, b, why) in list(self._res.items()):
                if b < now - 5:
                    self._res.pop(k, None)
                elif a <= t1 and b >= t0:
                    return why
        return None


ARB = Arbiter()


class StopMacro(Exception):
    """전체를 멈춰야 하는 상황"""


class PresetError(Exception):
    """이 선수만 멈추고 나머지는 계속"""


class Blocked(Exception):
    """거래 제한·이적시장이 안 보임 → 이 선수는 1분 뒤 다시 시도"""


class Restricted(Blocked):
    """감독모드 경기 막바지: 상단에 초록 안내 띠 → 사라질 때까지 대기 (클릭 안 함)"""


class UserStop(Exception):
    pass


class Worker(threading.Thread):
    """
    mode = "schedule" : 사용 체크된 프리셋들을 예약 시각에 진행
    mode = "now"      : only 프리셋을 지금부터 N분 진행
    mode = "test"     : only 프리셋으로 재등록 → 가격 클릭 → ESC 1회 (확정 안 함)
    """

    def __init__(self, cfg, q, mode="schedule", only=None):
        super().__init__(daemon=True)
        self.cfg = cfg
        self.q = q
        self.mode = mode
        self.only = only
        self.stop_evt = threading.Event()
        self.tmpl_dialog_lobby = load_template("dialog")
        self.tmpl_dialog_mgr = load_template("dialog_manager")
        self.tmpl_sell = load_template("dialog_sell")      # 판매 중 선수의 재등록 창 ('판매' 글자)
        self.dlg_kind = "buy"
        self.tmpl_header = {k: load_template(f"header_{k}") for k in ("lobby", "manager")}
        self.tmpl_dialog = self.tmpl_dialog_lobby
        self._row_cache = {}
        self.layout = None
        self.hdr_live = None             # 진행 중인 화면에서 찍어둔 이적시장 제목줄 (같은 모드끼리 비교)
        self.hdr_pos = None
        self.hdr_p99 = None
        self.T = (1.0, 1.0, 0, 0)        # 거래목록(이적시장 창) 좌표 변환: x*sx+tx, y*sy+ty
        self.Td = (1.0, 1.0, 0, 0)       # 구매 창 좌표 변환 — 구매 창은 게임 화면 가운데라 보통 그대로
        self._warned_no_header = False
        self.row_dy = {}                 # 선수 줄이 처음 지정한 위치에서 위아래로 옮겨진 정도 (로비 기준 px)
        self.btn = {k: load_builtin(k) for k in BUILTIN_TEMPLATES}
        for k, pth in EXTRA_TEMPLATES.items():          # v4.0
            try:
                self.btn[k] = np.array(Image.open(pth).convert("RGB"))[:, :, ::-1].astype(np.int16)
            except Exception:
                pass
        # 감독모드 거래 제한 → 이적시장 닫기 → 다음 경기에서 다시 열기
        self.mk = {"phase": None, "after_t": 0.0, "saw_no_menu": False, "menu_seen": False, "fails": 0}
        self.sens = cfg["sensitivity"]
        self.tmpl_row = {i: load_template(f"row_check_{i}") for i in range(N_PRESETS)}
        self.attempts = 0
        self._last_status = None
        self.sessions = {}
        self.pending = set()
        self.results = {"success": [], "timeout": [], "error": []}
        self.hwnd = None
        self.ox = self.oy = 0
        self.fail_reason, self.fail_imgs = "", ()
        self.clicker = Clicker()
        self._gate_t = 0.0
        self.ctl = queue.Queue()         # v3.6: 텔레그램 등에서 온 요청 (가격 확인 / 켜기·끄기)
        self.ctl_wait = []               # 갱신싸움 중이라 미뤄 둔 가격 확인
        self.want_kind = "buy"
        self.tm_reset()
        # v4.0 감독모드와 같이 쓰기
        self.arb = ARB
        self._mm_closed = False          # 이번 분 갱신이 끝나 우리가 일부러 닫아 둠 (keep_market 이 다시 열지 않게)
        self._skip_until = 0.0           # 감독모드 때문에 쉬는 분 (now() 기준 끝)
        self._skip_noted = None
        self._open_secs = []             # 다시 여는 데 걸린 시간
        self._open_warned = False
        self._quiet = False
        self._in_match_t = (0.0, False)

    # ── 단계별 시간 ──
    TM_KEYS = ("확인", "이름 찾기", "클릭", "창 열림", "가격 읽기", "가격 클릭", "창 닫힘")

    def tm_reset(self):
        self.tm = {k: 0.0 for k in self.TM_KEYS}
        self.tm_n = 0
        self.n_fast = 0
        self.n_clicks = 0
        self.n_reg = 0

    def note_click_reg(self):
        """닫기 직전 금액 칸이 회색이면 '클릭 반영됨'으로 셈 (매 분 기록에 표시)"""
        ar = self.amount_rect()
        if ar is not None and getattr(self, "amt0", None) is not None and blue_px(self.amt0) >= BLUE_FRESH:
            if blue_px(self.d_grab(ar)) < BLUE_DONE:
                self.n_reg += 1
        self.tm_t0 = time.perf_counter()

    def mark(self, key):
        now = time.perf_counter()
        if key in self.tm and getattr(self, "_tmark", None) is not None:
            self.tm[key] += now - self._tmark
        self._tmark = now

    def tm_summary(self):
        if not self.tm_n:
            return ""
        n = self.tm_n
        per = sum(self.tm.values()) / n
        parts = " · ".join(f"{k} {self.tm[k] / n:.2f}" for k in self.TM_KEYS)
        fast = f" · 빠른 판정 {self.n_fast}/{n}회" if self.cfg.get("fast_compare", True) else ""
        if self.cfg.get("spam_click", True):
            fast += f" · 광클 평균 {self.n_clicks / n:.1f}번/회 · 클릭 반영(파랑→회색) {self.n_reg}/{n}회"
        return f"평균 {per:.2f}초/회 ({parts}){fast}"

    # ── 통신 ──
    def stop(self):
        self.stop_evt.set()

    def log(self, m, kind="info"):
        self.q.put(("log", m, kind))

    def status(self, s, sub=""):
        if (s, sub) != self._last_status:
            self._last_status = (s, sub)
            self.q.put(("status", s, sub))

    def pstate(self, i, state, text=""):
        self.q.put(("preset", i, state, text))

    def preview(self, title, *imgs):
        """프로그램 화면의 '캡처 확인' 칸에 띄움"""
        self.q.put(("preview", title, [a.copy() for a in imgs]))

    def check_stop(self):
        if self.stop_evt.is_set():
            raise UserStop()

    def sleep(self, sec):
        end = time.perf_counter() + sec
        while True:
            self.check_stop()
            r = end - time.perf_counter()
            if r <= 0:
                return
            time.sleep(min(r, 0.02))

    def now(self):
        return time.time() + self.cfg["clock_offset"]

    def P(self, i):
        return self.cfg["presets"][i]

    def name(self, i):
        return self.P(i)["name"] or f"프리셋 {i + 1}"

    # ── v4.0 감독모드와 같이 쓰기 ──
    def shared(self):
        """감독모드 경기 중에 매 분 닫고 여는 방식인지 (감독모드가 돌고 있고 ≡ 메뉴가 보이는 경기 화면)"""
        if not (self.arb.gm_running and self.cfg.get("close_each_min", True)) or self.arb.lobby_ok or not self.hwnd:
            return False
        t, v = self._in_match_t
        if time.time() - t < 2.0:
            return v
        try:
            v = self.find_btn("menu", self.menu_region()) is not None
        except Exception:
            v = False
        self._in_match_t = (time.time(), v)
        return v

    def _take(self, timeout):
        """감독모드가 돌고 있으면 화면 잡기 (로비 ⭐ 대기 중이거나 감독모드가 안 돌면 그냥 True)"""
        if not self.arb.gm_running or self.arb.lobby_ok:
            return True
        return self.arb.take(timeout)

    def mm_close(self):
        """이번 분 갱신이 끝남 -> 구매 창·이적시장 닫기 (감독모드가 나머지 시간 동안 빠르게 돌게)"""
        if self._mm_closed:
            return True
        try:
            self.refresh_window()
            try:
                if self.dialog_open():
                    self.close_dialog()
            except (Blocked, PresetError):
                pass
            if self.market_visible(confirm=False):
                cw, ch = client_size(self.hwnd)
                pos = self.find_btn("close_x", [cw // 2, 0, cw - cw // 2, ch // 3])
                if pos:
                    mouse_move(*pos)
                    time.sleep(0.03)
                    mouse_click()
                end = time.perf_counter() + 1.5
                while time.perf_counter() < end:
                    self.sleep(0.1)
                    if not self.market_visible(confirm=False):
                        break
            self._mm_closed = not self.market_visible(confirm=False)
            if not self._mm_closed:
                self.log("이번 분 갱신 뒤 이적시장을 닫지 못했어요 — 다음 분에 다시 시도", "warn")
            return self._mm_closed
        finally:
            if self._mm_closed:
                self.park_mouse()
                self.arb.give()

    def mm_reopen(self, i, rs):
        """다음 분 0초 rs초 전: 화면을 잡고 ≡ 메뉴로 이적시장 다시 열기 -> True(열림)/False(이번 분 쉼)"""
        s = self.sessions.get(i)
        if s is None:
            return False
        t0 = time.perf_counter()
        if not self.arb.take(max(0.3, rs - 1.0)):
            self._skip_minute("감독모드가 화면을 쓰는 중")
            return False
        try:
            self._quiet = True
            self.refresh_window()
            self.gate(i, s)
        except Blocked as e:
            self._quiet = False
            self.arb.give()
            self.block(i, s, e)
            return False
        except PresetError as e:
            self._quiet = False
            self.arb.give()
            self.finish(i, "error", str(e))
            return False
        self._quiet = False
        self._mm_closed = False
        dt = time.perf_counter() - t0
        self._open_secs = (self._open_secs + [dt])[-30:]
        if dt > rs - 0.5 and not self._open_warned:
            self._open_warned = True
            self.log(f"이적시장을 다시 여는 데 {dt:.1f}초 걸렸어요 — 갱신 설정에서 '다시 열기'를 {int(dt + 1.5)}초 전으로 늘리는 걸 추천해요", "warn")
            self.q.put(("tr_hint", "reopen", round(dt, 1)))
        return True

    def _skip_minute(self, why):
        """이번 분은 갱신꾼이 쉼 (감독모드 교체 등). 다음 분 시작 전까지"""
        t = self.now()
        nxt = t + until_sec(t, self.cfg["start_sec"])
        self._skip_until = nxt + (self.cfg["end_sec"] - self.cfg["start_sec"]) % 60 + 1
        key = int(nxt // 60)
        if self._skip_noted != key:
            self._skip_noted = key
            self.log(f"[감독모드] {why} → {datetime.datetime.fromtimestamp(nxt - self.cfg['clock_offset']):%H:%M} 분은 이적시장을 열지 않고 쉬어요")

    def open_market_lobby(self):
        """⭐ 로비 대기: 감독모드 홈 아래 줄의 [이적시장] → 거래 목록"""
        cw, ch = client_size(self.hwnd)
        pos = self.find_btn("home_market", [0, ch * 4 // 5, cw, ch - ch * 4 // 5], thr=0.8)
        if not pos:
            raise Restricted("로비 아래 줄의 [이적시장] 버튼을 못 찾았어요")
        self.log("⭐ 로비에서 이적시장을 열어요")
        mouse_move(*pos)
        time.sleep(0.03)
        mouse_click()
        end = time.perf_counter() + 6.0
        while not self.market_visible(confirm=False):
            if time.perf_counter() > end:
                shot = self.err_capture("로비_이적시장안열림")
                raise Restricted("로비에서 이적시장 창이 안 열렸어요" + (f" · {shot}" if shot else ""))
            self.sleep(0.2)
        self.sleep(0.5)
        if not self.ensure_trades_tab():
            raise Restricted("'거래 목록' 탭으로 못 넘어갔어요")
        self.park_mouse()
        self.detect_layout()

    # ── 게임 창 ──
    def focus_game(self):
        hwnd = find_game(self.cfg["window_title"])
        if not hwnd:
            raise StopMacro("게임 창(FC ONLINE)을 찾을 수 없어요")
        if user32.GetForegroundWindow() != hwnd:
            bring_to_front(hwnd)
            end = time.perf_counter() + 1.5
            while user32.GetForegroundWindow() != hwnd and time.perf_counter() < end:
                self.sleep(0.05)
            self.sleep(0.3)
        self.refresh_window()

    def set_layout(self, lay, T=(1.0, 1.0, 0, 0)):
        changed = (lay, T) != (self.layout, self.T)
        self.layout, self.T = lay, T
        self._row_cache = {}
        sx, sy, tx, ty = T
        if lay == "manager":
            self.Td = T                  # 크기 자체가 다른 감독모드는 보정값 그대로
            self.tmpl_dialog = self.tmpl_dialog_mgr
            self.sens = max(3, round(self.cfg["sensitivity"] * sx * sy))
            info = f" (배율 {sx:.2f}×{sy:.2f}, 감도 {self.sens}px)"
        else:
            self.tmpl_dialog = self.tmpl_dialog_lobby
            self.sens = self.cfg["sensitivity"]
            info = f" (로비 기준에서 {tx:+d}, {ty:+d}px 이동)" if lay == "moved" else ""
        if changed:
            self.log(f"{LAYOUT_NAMES[lay]} 이적시장 화면으로 진행{info}", "ok")

    def grab_client(self):
        w, h = client_size(self.hwnd)
        return to_arr(self.sct.grab({"left": self.ox, "top": self.oy, "width": w, "height": h}))

    def detect_layout(self):
        """이적시장 '제목줄'을 화면에서 찾아 좌표를 자동으로 맞춤"""
        c = self.cfg
        mode = c.get("screen_mode", "auto")
        if mode == "lobby":
            return self.set_layout("lobby")
        client = self.grab_client()
        found = find_header(client, c, "lobby")
        if found is None:
            if not self._warned_no_header:
                self._warned_no_header = True
                self.log("위치 지정 탭에서 '창 범위 · 로비'를 지정하면 이적시장 위치를 자동으로 맞춰요", "warn")
            return self.set_layout("lobby")
        dx, dy, sc = found
        if sc >= 0.75:
            hx, hy, hw, hh = header_rect(c["rects"]["panel_lobby"])
            self.remember_header(client, hx + dx, hy + dy, hw, min(14, hh))
        if sc >= 0.75 and (mode == "auto" or same_size(c)):
            if abs(dx) <= 1 and abs(dy) <= 1:
                return self.set_layout("lobby")
            return self.set_layout("moved", (1.0, 1.0, dx, dy))
        # 크기가 정말 다른 감독모드 (보정값 사용)
        if not same_size(c) and manager_ready(c):
            fm = find_header(client, c, "manager")
            if fm and fm[2] >= 0.8:
                L, M = c["rects"]["panel_lobby"], c["rects"]["panel_manager"]
                sx, sy = M[2] / L[2], M[3] / L[3]
                tx = round(M[0] - L[0] * sx + fm[0])
                ty = round(M[1] - L[1] * sy + fm[1])
                return self.set_layout("manager", (sx, sy, tx, ty))
        raise Blocked(f"이적시장 화면이 안 보여요 (일치도 {sc:.2f})")

    def refresh_window(self):
        hwnd = find_game(self.cfg["window_title"])
        if not hwnd:
            raise StopMacro("게임 창(FC ONLINE)을 찾을 수 없어요")
        if user32.IsIconic(hwnd):
            raise StopMacro("게임 창이 최소화돼 있어요")
        if user32.GetForegroundWindow() != hwnd:
            # 다른 창을 눌렀어도 멈추지 않고 게임 창을 다시 앞으로 가져옴
            bring_to_front(hwnd)
            end = time.perf_counter() + 1.5
            while user32.GetForegroundWindow() != hwnd and time.perf_counter() < end:
                self.sleep(0.05)
            if user32.GetForegroundWindow() != hwnd:
                raise StopMacro("게임 창을 다시 앞으로 가져오지 못했어요")
            self.log("게임 창이 뒤로 가 있어서 다시 앞으로 가져왔어요", "warn")
            self.sleep(0.3)
        self.hwnd = hwnd
        self.ox, self.oy = client_origin(hwnd)

    # ── 좌표/캡처 (저장된 좌표는 모두 로비 기준 → 감독모드면 자동 변환) ──
    def mp(self, pt):
        sx, sy, tx, ty = self.T
        return [round(pt[0] * sx + tx), round(pt[1] * sy + ty)]

    def mr(self, rect):
        sx, sy, _, _ = self.T
        x, y = self.mp(rect[:2])
        return [x, y, max(2, round(rect[2] * sx)), max(2, round(rect[3] * sy))]

    def to_abs(self, pt):
        x, y = self.mp(pt)
        return self.ox + x, self.oy + y

    def center(self, rect):
        x, y, w, h = self.mr(rect)
        return self.ox + x + w // 2, self.oy + y + h // 2

    def grab_raw(self, rect):
        x, y, w, h = rect
        return to_arr(self.sct.grab({"left": self.ox + x, "top": self.oy + y,
                                     "width": w, "height": h}))

    def grab(self, rect):
        return self.grab_raw(self.mr(rect))

    # 구매 창 쪽 (구매 글자 · 상한가/하한가 · 구매 버튼 · 호가 목록)
    def dr(self, rect):
        sx, sy, tx, ty = self.Td
        return [round(rect[0] * sx + tx), round(rect[1] * sy + ty),
                max(2, round(rect[2] * sx)), max(2, round(rect[3] * sy))]

    def d_center(self, rect):
        x, y, w, h = self.dr(rect)
        return self.ox + x + w // 2, self.oy + y + h // 2

    def d_abs(self, pt):
        sx, sy, tx, ty = self.Td
        return self.ox + round(pt[0] * sx + tx), self.oy + round(pt[1] * sy + ty)

    def d_grab(self, rect):
        return self.grab_raw(self.dr(rect))

    def locate_dialog(self):
        """구매 창이 예상 자리에 없으면 화면 전체에서 '구매' 글자를 찾아 위치를 맞춤"""
        t = self.tmpl_dialog_lobby
        if t is None:
            return False
        x, y, sc = match_fast(to_gray(self.grab_client()), to_gray(t))
        if sc < 0.9:
            return False
        dx0, dy0 = self.cfg["rects"]["dialog"][:2]
        Td = (1.0, 1.0, x - dx0, y - dy0)
        if Td != self.Td:
            self.Td = Td
            self.tmpl_dialog = t
            self.log(f"구매 창 위치를 자동으로 맞췄어요 (지정할 때보다 {Td[2]:+d}, {Td[3]:+d}px)", "ok")
            return True
        return False

    def row_template(self, i):
        """선수 확인 템플릿 — 감독모드면 크기에 맞게 줄여서 사용"""
        t = self.tmpl_row.get(i)
        if t is None or self.T[0] == 1.0 and self.T[1] == 1.0:
            return t
        if i not in self._row_cache:
            w, h = self.mr(self.P(i)["rects"]["row_check"])[2:]
            img = Image.fromarray(np.clip(t, 0, 255).astype(np.uint8)[:, :, ::-1]).resize((w, h), Image.LANCZOS)
            self._row_cache[i] = np.array(img)[:, :, ::-1].astype(np.int16)
        return self._row_cache[i]

    def kind_rect(self, key):
        """구매 창이면 upper/lower, 판매 창이면 판매 위치 (없으면 구매 위치에서 29px 아래)"""
        r = self.cfg["rects"]
        if getattr(self, "dlg_kind", "buy") != "sell":
            return r.get(key)
        if r.get("sell_" + key):
            return r["sell_" + key]
        if r.get(key):
            x, y, w, h = r[key]
            return [x, y + SELL_SHIFT, w, h]
        return None

    def amount_rect(self):
        u = self.kind_rect("upper")
        if not u:
            lo = self.kind_rect("lower")
            if not lo:
                return None
            u = [lo[0], lo[1] + 29, lo[2], lo[3]]
        dy = AMOUNT_DY["sell" if getattr(self, "dlg_kind", "buy") == "sell" else "buy"]
        return [u[0] - 80, u[1] + dy, u[2] + 80, u[3]]

    def other_rect(self, i):
        other = "lower" if self.P(i)["target"] == "upper" else "upper"
        return self.kind_rect(other)

    def price_rect(self, i):
        return self.kind_rect(self.P(i)["target"])

    def dialog_open(self, strict=False):
        """strict=True: 페이드인이 끝나 완전히 뜬 상태만 인정
           strict=False: 반투명이라도 창이 남아 있으면 열린 걸로 봄 (ESC 판단용)"""
        # v3.6: 프리셋에 정한 쪽(구매/판매) 창부터 확인
        order = ("sell", "buy") if self.want_kind == "sell" else ("buy", "sell")
        for kind in order:
            if kind == "buy":
                key, tmpl = "dialog", self.tmpl_dialog
            else:
                key, tmpl = "dialog_sell", self.tmpl_sell
                if tmpl is None or key not in self.cfg["rects"]:
                    continue
            img = self.d_grab(self.cfg["rects"][key])
            if strict:
                # 애니메이션이 완전히 끝나면 지정할 때 찍은 '구매'/'판매' 글자와 거의 똑같아짐
                ok = similar(img, tmpl, tol=3, raw_tol=3)
            else:
                ok = similar(img, tmpl)
            if ok:
                self.dlg_kind = kind
                return True
        return False

    def wait_dialog(self, want_open, timeout):
        end = time.perf_counter() + timeout
        loose_since = None
        while time.perf_counter() < end:
            self.check_stop()
            if want_open:
                # 떠 있는 게 보이면 바로 다음 단계로 — 애니메이션이 끝났는지는
                # read_price 가 '가격 숫자가 완전히 멈춤(3장 연속 동일)'으로 확인함
                if self.dialog_open():
                    return True
            elif not self.dialog_open():
                return True
            time.sleep(0.004)
        return False

    def read_price(self, i, timeout=1.0):
        """가격 숫자가 다 그려지고 3번 연속 똑같을 때의 캡처 (애니메이션 중 캡처 방지)"""
        rect = self.price_rect(i)
        end = time.perf_counter() + timeout
        prev, same, since = None, 0, None
        self._price_frames = []
        while time.perf_counter() < end:
            cur = self.d_grab(rect)
            now = time.perf_counter()
            self._price_frames = (self._price_frames + [cur])[-2:]
            if has_content(cur) and prev is not None and int(np.abs(cur - prev).max()) <= 1:
                same += 1
                if since is None:
                    since = now
                # 게임 화면은 1/60초마다 바뀌므로, 3장 이상 + 40ms 동안 완전히 같아야 '멈춤'으로 인정
                if same >= 2 and now - since >= 0.04:
                    return cur
            else:
                same, since = 0, None
            prev = cur
            time.sleep(0.008)
        return None

    def read_price_early(self, i, s, timeout=0.6):
        """애니메이션이 끝나길 기다리지 않고, 글자가 또렷해지고(기준가의 75% 이상) 두 장 연속 같은 모양이면 바로 반환"""
        rect = self.price_rect(i)
        need = 0.75 * s.get("base_top", 0)
        end = time.perf_counter() + timeout
        prev = None
        while time.perf_counter() < end:
            cur = self.d_grab(rect)
            if need and ink_top(cur) >= need and bg_ok(cur, s.get("base_bg")):
                if prev is not None and text_mismatch(cur, prev) <= 3:
                    return cur
                prev = cur
            else:
                prev = None
            time.sleep(0.006)
        return None

    def save_debug(self, tag, *imgs):
        """가격 변동 판단에 쓴 캡처를 나란히 저장 (오작동 확인용)"""
        try:
            os.makedirs(CAP_DIR, exist_ok=True)
            path = os.path.join(CAP_DIR, f"{tag}_{datetime.datetime.now():%Y%m%d_%H%M%S}.png")
            compose(*imgs).save(path)
            return path
        except Exception:
            return None

    # ── 동작 단위 ──
    def spam_start(self, i):
        """구매 창이 뜨자마자 가격 자리로 마우스를 옮기고 광클 시작"""
        if not self.cfg.get("spam_click", True) or getattr(self, "_no_spam", False):
            return
        mouse_move(*self.d_center(self.price_rect(i)))
        checks = []
        for key, t in (("dialog", self.tmpl_dialog), ("dialog_sell", self.tmpl_sell)):
            if t is not None and key in self.cfg["rects"]:
                x, y, w, h = self.dr(self.cfg["rects"][key])
                checks.append(((self.ox + x, self.oy + y, w, h), t))
        if checks:
            self.clicker.start(max(0.01, self.cfg.get("spam_ms", 30) / 1000), checks)

    def spam_stop(self):
        if self.clicker.t is not None:
            self.clicker.stop()
            self.n_clicks = getattr(self, "n_clicks", 0) + self.clicker.n
            self.clicker.n = 0
        return 0

    def park_mouse(self):
        self.spam_stop()
        """마우스를 '구매' 제목 자리(거래목록 줄과 안 겹침)로 치움. 옮겼으면 True"""
        tgt = self.d_center(self.cfg["rects"]["dialog"])
        p = wt.POINT()
        user32.GetCursorPos(ctypes.byref(p))
        if abs(p.x - tgt[0]) <= 2 and abs(p.y - tgt[1]) <= 2:
            return False
        mouse_move(*tgt)
        return True

    def row_pt(self, i, key):
        x, y = self.P(i)["points"][key]
        return [x, y + self.row_dy.get(i, 0)]

    def row_rect(self, i, key):
        x, y, w, h = self.P(i)["rects"][key]
        return [x, y + self.row_dy.get(i, 0), w, h]

    def locate_row(self, i):
        """거래목록에서 이 선수 이름을 찾아 row_dy 갱신. (찾았는지, 일치도, 검색한 화면)"""
        c = self.cfg
        x, y, w, h = self.mr(self.P(i)["rects"]["row_check"])
        cw, ch = client_size(self.hwnd)
        if "panel_lobby" in c["rects"]:
            px, py, pw, ph = self.mr(c["rects"]["panel_lobby"])
            top, bot = max(0, py), min(ch, py + ph)
        else:
            top, bot = 0, ch
        m = 6
        strip = self.grab_raw([max(0, x - m), top, w + 2 * m, max(h + 2, bot - top)])
        tmpl = to_gray(self.row_template(i))
        peaks = match_peaks(to_gray(strip), tmpl, 0.9)
        if not peaks:
            best = match_template(to_gray(strip), tmpl)[2]
            return False, best, strip
        sy = self.T[1]
        prev = self.row_dy.get(i, 0)
        # 같은 이름이 여러 줄이면 직전 위치에서 가장 가까운 줄
        cands = [((top + py_) - y) / sy for _, py_, _ in peaks]
        dy = round(min(cands, key=lambda d: abs(d - prev)))
        if abs(dy - prev) >= 3:
            step = dy - prev
            self.log(f"[{self.name(i)}] 거래목록 줄이 {'아래' if step > 0 else '위'}로 {abs(step)}px 바뀌어서 따라갔어요")
        self.row_dy[i] = dy
        return True, max(p[2] for p in peaks), strip

    def find_row(self, i):
        """선수 이름 찾기 — 마우스를 치우고, 못 찾으면 잠깐 뒤·위치 다시 맞춘 뒤 재시도"""
        if self.park_mouse():
            self.sleep(0.06)
        ok, sc, strip = self.locate_row(i)
        if ok:
            return
        self.sleep(0.3)
        ok, sc, strip = self.locate_row(i)
        if ok:
            return
        self.detect_layout()                       # 이적시장이 안 보이면 여기서 Blocked
        ok, sc, strip = self.locate_row(i)
        if ok:
            return
        pos = self.find_btn("tab_trades")          # '보유 선수' 등 다른 탭에 있으면 거래 목록으로
        if pos and not self.trades_tab_selected(pos):
            self.log("거래 목록 탭이 아니어서 거래 목록으로 넘어갈게요", "warn")
            if self.ensure_trades_tab():
                self.park_mouse()
                self.sleep(0.1)
                ok, sc, strip = self.locate_row(i)
                if ok:
                    return
        dbg = self.save_debug(f"선수못찾음_{i + 1}_이름vs목록", self.row_template(i), strip)
        raise PresetError(f"거래목록에서 이 선수 이름을 못 찾았어요 (최고 일치도 {sc:.2f}) — "
                          f"체결돼서 목록에서 빠졌거나 이름 지정이 잘못됐을 수 있어요"
                          + (f" · {os.path.basename(dbg)}" if dbg else ""))

    def header_dim(self):
        """제목줄 '흰 글자' 밝기 비율 (1.0 평소 · 0.6 정도면 위에 창이 떠서 어두워짐). 모르면 None
        — 배경이 아니라 글자 밝기라서 로비/감모 상관없이 같은 기준"""
        lh = self.live_header()
        if lh is None or lh[0] < 0.5:
            return None
        return lh[1]

    def handle_popup(self, i):
        self.spam_stop()
        """구매 창이 아닌 안내창(거래 제한 등)이 떠 있으면 닫고 Blocked"""
        if self.dialog_open() or (self.tmpl_dialog_lobby is not None and
                                  match_fast(to_gray(self.grab_client()),
                                             to_gray(self.tmpl_dialog_lobby))[2] >= 0.8) or \
                (self.tmpl_sell is not None and
                 match_fast(to_gray(self.grab_client()), to_gray(self.tmpl_sell))[2] >= 0.8):
            return                                 # 구매/판매 창이 떠 있음 — 감지만 늦었던 것
        if not self.market_visible():
            # 이적시장 자체가 닫혀 있음 → 키를 누르면 경기 화면에서 채팅·메뉴가 열리므로 누르지 않음
            raise Restricted("이적시장이 닫혀 있어요 — 메뉴에서 다시 열게요")
        dim = self.header_dim()
        if dim is None or dim >= 0.75:
            return                                 # 어두워지지 않았거나 판단 불가 → 키 안 누름
        shot = self.err_capture(f"안내창_{i + 1}")
        if self.tmpl_sell is None:
            self.log("판매 중인 선수라면 위치 지정 탭에서 '판매 창 표시'('판매' 글자)를 지정해야 판매 창을 알아봐요", "warn")
        key_press(SC_ESC)                          # ESC 한 번만 (Enter 는 경기 화면 채팅창을 열 수 있어 안 누름)
        end = time.perf_counter() + 1.2
        while time.perf_counter() < end:
            self.sleep(0.05)
            d = self.header_dim()
            if d is not None and d >= 0.75:
                raise Blocked("구매 창 대신 안내창이 떴어요 (거래 제한 추정)" + (f" · {shot}" if shot else ""))
        raise Restricted("안내창이 안 닫혀요 — 잠시 뒤 다시 확인" + (f" · {shot}" if shot else ""))

    def open_dialog(self, i, s=None):
        p = self.P(i)
        self.want_kind = p.get("side", "buy")
        if p["rects"].get("row_check") and self.tmpl_row.get(i) is not None:
            last = getattr(self, "_row_t", {}).get(i, 0)
            if s is None or time.time() - last >= 3 or getattr(self, "_row_force", False):
                self.find_row(i)
                self._row_t = getattr(self, "_row_t", {})
                self._row_t[i] = time.time()
                self._row_force = False
            else:
                self.park_mouse()
        self.mark("이름 찾기")
        mouse_move(*self.to_abs(self.row_pt(i, "reg_btn")))
        self.sleep(self.cfg["hover_ms"] / 1000)
        mouse_click()
        # 재등록 자리가 구매 창의 가격 숫자와 겹칠 수 있어서, 클릭 직후 마우스를
        # 움직이지 않는 '구매' 제목 글자 위로 옮김 → 숫자에 마우스 효과가 안 찍힘
        time.sleep(0.015)
        mouse_move(*self.d_center(self.cfg["rects"]["dialog"]))
        self.mark("클릭")
        self.fail_reason, self.fail_imgs = "", ()
        if not self.wait_dialog(True, self.cfg["dialog_timeout_ms"] / 1000):
            # 구매 창이 다른 자리에 떠 있을 수 있음 → 화면에서 찾아서 맞춘 뒤 다시 확인
            if not (self.locate_dialog() and self.wait_dialog(True, 0.6)):
                self.handle_popup(i)               # 안내창이면 닫고 1분 대기로
                self._row_force = True             # 줄이 바뀌었을 수 있으니 다음엔 이름부터 다시 찾기
                self.fail_reason = "구매 창이 시간 안에 안 떴어요 (왼쪽 기대한 '구매' 글자 / 오른쪽 실제 화면)"
                self.fail_imgs = (self.tmpl_dialog, self.d_grab(self.cfg["rects"]["dialog"]))
                return None
        self.mark("창 열림")
        ar = self.amount_rect()
        self.amt0 = self.d_grab(ar) if ar else None    # 클릭 전 금액 칸 (클릭이 먹혔는지 비교용)
        if not getattr(self, "_no_spam", False):
            mouse_move(*self.d_center(self.price_rect(i)))
            mouse_click()                      # 창이 뜨자마자 무조건 1번
            self.n_clicks = getattr(self, "n_clicks", 0) + 1
        self.spam_start(i)                     # 그 뒤 창이 떠 있는 동안 계속 연타 (비교는 그대로 진행)
        self.early_same = False
        self.early_diff = False
        if s is not None and s.get("base") is not None and self.cfg.get("fast_compare", True):
            early = self.read_price_early(i, s)
            if early is not None:
                mm = text_mismatch(early, s["base"])
                s["last_mm"] = mm
                if mm <= FAST_SAME:            # 확실히 같은 가격 → 멈출 때까지 안 기다림
                    self.early_same = True
                    self.mark("가격 읽기")
                    return early
                if mm >= FAST_DIFF:            # 확실히 다른 것 같음 → 한 장 더 + 반대쪽 가격까지 확인 (약 0.01초)
                    again = self.d_grab(self.price_rect(i))
                    mm2 = really_diff(again, s["base"])
                    other_ok, mo = True, None
                    if s.get("base_other") is not None:
                        oth = self.d_grab(self.other_rect(i))
                        mo = really_diff(oth, s["base_other"])
                        other_ok = mo >= FAST_DIFF and bg_ok(oth, s.get("base_other_bg"))
                    s["fast_check"] = (mm, mm2, mo)
                    # 창이 완전히 밝아진 상태(바탕 밝기 = 기준)에서만 빠른 확정 — 뜨는 중이면 아래 정밀 비교로
                    if mm2 >= FAST_DIFF and other_ok and bg_ok(again, s.get("base_bg")):
                        self.early_diff = True
                        self.mark("가격 읽기")
                        return again
        price = self.read_price(i)              # 애매하거나 바뀐 것 같음 → 완전히 멈춘 화면으로 정밀 비교
        self.mark("가격 읽기")
        if price is None:
            fr = getattr(self, "_price_frames", [])
            if fr and not has_content(fr[-1]):
                self.fail_reason = "가격 칸이 비어 있어요 — 상한가/하한가 숫자 영역을 다시 지정해보세요"
            else:
                self.fail_reason = "가격 숫자가 계속 움직여서 캡처 못 했어요 (연속 두 장)"
            self.fail_imgs = tuple(fr)
        return price

    def click_price(self, i, park=True):
        self.spam_stop()
        mouse_move(*self.d_center(self.price_rect(i)))
        time.sleep(0.008)
        mouse_click()
        time.sleep(0.008)
        if park:
            self.park_mouse()

    def close_dialog(self):
        self.spam_stop()                       # ESC 전에 광클 멈춤 (닫힌 뒤 거래목록 오클릭 방지)
        """구매 창이 열려 있을 때만 ESC (안 열렸는데 누르면 이적시장이 닫힐 수 있음)"""
        if not self.dialog_open():
            return True
        key_press(SC_ESC)
        if self.wait_dialog(False, 0.35):
            time.sleep(0.01)
            return True
        if self.dialog_open():                 # 0.35초 동안 그대로 떠 있음 = ESC 가 안 먹힘 → 한 번 더
            key_press(SC_ESC)
            if self.wait_dialog(False, 1.0):
                time.sleep(0.01)
                return True
        # 닫히는 중(반투명)일 때 또 누르면 이적시장까지 닫힘 → 완전히 떠 있을 때만 한 번 더
        if self.dialog_open(strict=True):
            key_press(SC_ESC)
            if self.wait_dialog(False, 1.5):
                time.sleep(0.015)
                return True
            return False
        return self.wait_dialog(False, 1.0)

    def commit(self, i):
        """가격이 바뀜 → 확정.
        · 구매 창 + 상한가: 금액 칸에 처음부터 상한가가 들어 있음 → 클릭 기다리지 않고 즉시 Enter
        · 그 외(하한가·판매): 금액 칸이 파랑→회색(클릭 먹힘)될 때까지 연타(최대 0.6초) → Enter.
          끝내 확인 안 되면 Enter 안 누름 (엉뚱한 금액으로 등록 방지)
        반환: (추가 클릭 수, 상태 문구, Enter 눌렀는지)"""
        self.spam_stop()
        if getattr(self, "dlg_kind", "buy") == "buy" and self.P(i)["target"] == "upper":
            self.confirm()                     # Enter 딱 한 번 (금액 칸 = 상한가)
            return 0, "구매 상한가라 즉시 Enter", True
        ar = self.amount_rect()
        mouse_move(*self.d_center(self.price_rect(i)))
        fresh_blue = ar is not None and self.amt0 is not None and blue_px(self.amt0) >= BLUE_FRESH

        def clicked():
            cur = self.d_grab(ar)
            if fresh_blue:
                return blue_px(cur) < BLUE_DONE            # 파랑 → 회색 = 클릭 먹힘
            return field_change(cur, self.amt0) >= FIELD_CHANGED

        if ar is None or self.amt0 is None:
            for _ in range(3):
                mouse_click()
                time.sleep(0.02)
            self.confirm()
            return 3, "금액 칸 확인 불가 — 3번 클릭 후 Enter", True
        if clicked():
            self.confirm()                     # 이미 광클로 먹힌 상태
            return 0, "클릭 반영 확인(파랑→회색)", True
        n = 0
        end = time.perf_counter() + 0.6
        while time.perf_counter() < end:
            mouse_click()
            n += 1
            t2 = time.perf_counter() + 0.025
            while time.perf_counter() < t2:
                if clicked():
                    self.confirm()             # Enter 딱 한 번
                    return n, "클릭 반영 확인(파랑→회색)", True
                time.sleep(0.004)
        return n, "0.6초 동안 클릭이 안 먹혀서 Enter 안 누름", False

    def confirm(self):
        self.spam_stop()
        m = self.cfg["confirm"]
        if m == "enter":
            key_press(SC_ENTER)
            return
        mouse_move(*self.d_abs(self.cfg["points"]["buy_btn"]))
        time.sleep(0.01)
        mouse_click()
        if m == "click_enter":
            self.sleep(0.15)
            key_press(SC_ENTER)

    def verify(self, i, s):
        if not self.wait_dialog(False, 3.0):
            return False, "확정 후에도 구매 창이 안 닫혔어요 (확정 방식 설정을 확인하세요)"
        mp = self.row_rect(i, "my_price") if self.P(i)["rects"].get("my_price") else None
        if mp and s["base_my"] is not None:
            end = time.perf_counter() + 3.0
            while time.perf_counter() < end:
                if diff_pixels(self.grab(mp), s["base_my"]) >= self.sens:
                    return True, "거래목록 금액이 바뀐 것까지 확인했어요"
                time.sleep(0.05)
            return False, "구매 창은 닫혔는데 거래목록 금액이 안 바뀌었어요"
        return True, "구매 창이 닫혔어요"

    def save_capture(self, tag):
        os.makedirs(CAP_DIR, exist_ok=True)
        w, h = client_size(self.hwnd)
        shot = self.sct.grab({"left": self.ox, "top": self.oy, "width": w, "height": h})
        img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
        path = os.path.join(CAP_DIR, f"{tag}_{datetime.datetime.now():%Y%m%d_%H%M%S}.png")
        img.save(path)
        return path

    # ── 세션 ──
    def start_session(self, i, start, end):
        self.sessions[i] = {"start": start, "end": end, "base": None, "base_my": None,
                            "fails": 0, "focused": False, "last_diff": 0,
                            "blocked_until": 0}
        self.log(f"[{self.name(i)}] 준비 · {hhmm(start)}~{hhmm(end)} 갱신싸움", "ok")
        self.pstate(i, "run", "준비")

    def err_capture(self, tag):
        """멈춘 순간의 게임 화면을 저장 (원인 확인용)"""
        try:
            hwnd = find_game(self.cfg["window_title"])
            if not hwnd:
                return None
            ox, oy = client_origin(hwnd)
            w, h = client_size(hwnd)
            with mss.mss() as sct:
                shot = sct.grab({"left": ox, "top": oy, "width": w, "height": h})
            os.makedirs(CAP_DIR, exist_ok=True)
            path = os.path.join(CAP_DIR, f"{tag}_{datetime.datetime.now():%Y%m%d_%H%M%S}.png")
            Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX").save(path)
            return os.path.basename(path)
        except Exception:
            return None

    def finish(self, i, kind, msg=""):
        s = self.sessions.get(i)
        if kind == "timeout" and s is not None and not s.get("ending"):
            s["ending"] = True
            try:
                self.report_end(i, s)
            except (UserStop, StopMacro):
                raise
            except Exception:
                self.log(f"[{self.name(i)}] 끝 알림 중 문제: {traceback.format_exc(limit=1)}", "warn")
        if kind == "error":
            hist_add({"idx": i, "name": self.name(i), "side": self.P(i).get("side", "buy"),
                      "target": self.P(i)["target"], "kind": "error", "note": str(msg)[:200],
                      "start": hhmm(s["start"]) if s and s.get("start") else ""})
            self.q.put(("hist_changed",))
        self.sessions.pop(i, None)
        self.pending.discard(i)
        self._close_after = True
        if self.arb.lobby_ok and self.arb.lobby_idx == i:
            self.arb.star_done.add(i)                    # v4.0: 감독모드가 보고 다시 시작 (이적시장은 end_close 가 닫음)
        self.results[kind].append(self.name(i))
        if kind == "success":
            self.pstate(i, "success", "성공 ✔")
            self.q.put(("success", f"{self.name(i)} 갱신 성공 · {msg}"))
        elif kind == "timeout":
            self.pstate(i, "timeout", "시간 종료")
            self.log(f"[{self.name(i)}] {self.cfg['duration_min']}분이 지나서 종료", "warn")
        else:
            self.pstate(i, "error", "오류")
            shot = self.err_capture(f"오류_{i + 1}")
            self.log(f"[{self.name(i)}] 멈춤: {msg}" + (f" · 그 순간 화면: {shot}" if shot else ""), "error")
            self.q.put(("beep_error",))
            try:
                if self.dialog_open():
                    self.close_dialog()
            except UserStop:
                raise
            except Exception:
                pass

    def capture_dialog(self, i, tag):
        """v3.6: 그 선수 구매/판매 창을 열어서 캡처만 하고 ESC로 닫음 (Enter·가격 클릭 안 함)
        반환 (경로, BGR 캡처, [상한가·하한가 OCR용 경로], 창 종류) / 못 열면 None"""
        self._no_spam = True
        try:
            price = None
            for _ in range(2):
                price = self.open_dialog(i)
                if price is not None:
                    break
                if self.dialog_open():
                    self.close_dialog()
                self.sleep(0.3)
            if price is None:
                return None
            stamp = f"{datetime.datetime.now():%Y%m%d_%H%M%S}"
            os.makedirs(CAP_DIR, exist_ok=True)
            crop = self.grab_raw(self.dialog_crop_rect())
            path = os.path.join(CAP_DIR, f"{tag}_{SIDE[self.dlg_kind]}창_{i + 1}_{stamp}.png")
            Image.fromarray(np.clip(crop, 0, 255).astype(np.uint8)[:, :, ::-1]).save(path)
            ocr = []
            for key in ("upper", "lower"):
                r = self.kind_rect(key)
                if r:
                    ocr.append(_upscale_save(self.d_grab(r), os.path.join(CAP_DIR, f"ocr_{key}_{i + 1}_{stamp}.png")))
            kind = self.dlg_kind
            self.close_dialog()
            return path, crop, ocr, kind
        finally:
            self._no_spam = False

    def tg(self):
        c = self.cfg
        tok, chat = c.get("tg_token", "").strip(), str(c.get("tg_chat", "")).strip()
        return (tok, chat) if tok and chat else None

    def tg_text(self, text, photos=()):
        """텔레그램으로 짧은 알림 (뒤에서 보냄)"""
        tg = self.tg()
        if not tg:
            return

        def job():
            try:
                telegram_send(tg[0], tg[1], text, photos)
            except Exception as e:
                self.q.put(("log", f"텔레그램 전송 실패: {e}", "error"))
        threading.Thread(target=job, daemon=True).start()

    def notify_ready(self, i, s):
        """v3.6.1: 기준가 저장까지 끝나 갱신싸움 준비 완료 → 텔레그램으로 미리 알림 (기준가 사진 + 글자)"""
        c = self.cfg
        tg = self.tg()
        if not c.get("tg_ready", True) or not tg:
            return
        p = self.P(i)
        nm = self.name(i)
        kind = SIDE[getattr(self, "dlg_kind", p.get("side", "buy"))]
        label = TARGET[p["target"]]
        lines = [f"🔔 {nm} 갱신싸움 준비 완료",
                 f"· {kind} {label} · {hhmm(s['start'])}~{hhmm(s['end'])} (매분 {c['start_sec']}~{c['end_sec']}초)"]
        others = [k for k in self.sessions if k != i]
        if others:
            mine = prio(p)
            top = min(prio(self.P(k)) for k in list(self.sessions))
            olist = ", ".join(f"{self.name(k)}(우선 {prio(self.P(k))})" for k in others)
            lines.append(f"· 우선 {mine} — 시간 겹침: {olist} → "
                         + ("이 선수 먼저 진행" if mine == top and all(prio(self.P(k)) > mine for k in others)
                            else "같은 우선끼리 번갈아" if mine == top else "앞 선수가 끝나면 진행"))
        _succ, _tot, seen = preset_stats(hist_load(), nm)
        sm = seen_summary(seen)
        if sm:
            lines.append(f"· 지난 기록상 실제 갱신: {sm}")
        png = None
        try:
            os.makedirs(CAP_DIR, exist_ok=True)
            png = _upscale_save(s["base"], os.path.join(
                CAP_DIR, f"준비_기준{label}_{i + 1}_{datetime.datetime.now():%Y%m%d_%H%M%S}.png"))
        except Exception:
            png = None

        def job():
            text = "\n".join(lines)
            if png:
                res = ocr_images([png])
                v = parse_won(" ".join(res[0])) if res else None
                if v:
                    lines.insert(2, f"· 기준 {label}: {fmt_won(v)}")
                    text = "\n".join(lines)
            try:
                telegram_send(tg[0], tg[1], text, [png] if png else [])
            except Exception as e:
                self.q.put(("log", f"텔레그램 준비 알림 실패: {e}", "error"))
        threading.Thread(target=job, daemon=True).start()

    def report_end(self, i, s):
        """v3.6: 20분이 끝났는데 갱신 못 함 → 그 선수 창을 열어 캡처해서 '이번엔 갱신되지 않았어요' 알림"""
        c = self.cfg
        dur = c["duration_min"] * 60
        nm = self.name(i)
        if s.get("missed"):
            kind, text = "missed", f"가격대는 바뀌었는데 등록(Enter)을 못 했어요 ({s['missed']}번)"
        elif s.get("base") is None or s.get("blocked_s", 0) >= dur * 0.5:
            kind, text = "limited", "거래 제한·경기 대기로 거의 진행하지 못했어요"
        else:
            kind, text = "nochange", "이번엔 가격이 갱신되지 않았어요"
        r = None
        if c.get("end_report", True) and not s.get("restricted") and s.get("base") is not None:
            try:
                self.refresh_window()
                self.gate(i, s)
                r = self.capture_dialog(i, "끝_갱신안됨" if kind == "nochange" else f"끝_{kind}")
            except (Blocked, PresetError, StopMacro) as e:
                text += f" · 창을 못 열어 캡처 없음 ({e})"
        period = f"{hhmm(s['start'])}~{hhmm(s['end'])}" if s.get("start") else ""
        hid = hist_add({"idx": i, "name": nm, "side": r[3] if r else self.P(i).get("side", "buy"),
                        "target": self.P(i)["target"], "kind": kind, "img": r[0] if r else None,
                        "start": hhmm(s["start"]) if s.get("start") else "", "attempts": s.get("n", 0),
                        "note": text})
        self.q.put(("hist_changed",))
        self.log(f"[{nm}] {period} 끝 · {text} · 시도 {s.get('n', 0)}회"
                 + (f" · 캡처: {os.path.basename(r[0])}" if r else ""), "warn" if kind != "nochange" else "info")
        if not c.get("end_report", True):
            return
        icon = {"nochange": "⏹", "missed": "⚠️", "limited": "⛔"}[kind]
        msg = f"{icon} {nm} · {period}\n{text}\n· 시도 {s.get('n', 0)}회"
        url, tg = c.get("discord_webhook", "").strip(), self.tg()
        photos = [r[0]] if r else []

        def job():
            if url:
                try:
                    discord_send(url, msg, photos)
                except Exception as e:
                    self.q.put(("log", f"디스코드 전송 실패: {e}", "error"))
            if tg:
                try:
                    telegram_send(tg[0], tg[1], msg, photos)
                except Exception as e:
                    self.q.put(("log", f"텔레그램 전송 실패: {e}", "error"))
        threading.Thread(target=job, daemon=True).start()

    def peek(self, i, who="텔레그램"):
        """v3.6 가격 확인: 그 선수 창을 열어 캡처 → 텔레그램으로 (Enter 절대 안 누름)"""
        nm = self.name(i)
        r, why = None, ""
        tmp = {"restricted": False}
        try:
            if not self.sessions:
                self.focus_game()
            self.refresh_window()
            self.gate(i, tmp)
            self.detect_layout()
            r = self.capture_dialog(i, "가격확인")
            if r is None:
                why = f"창이 안 열렸어요 — {self.fail_reason or '이유 모름'}"
        except Restricted as e:
            why = f"지금은 이적시장을 열 수 없어요 ({e})"
        except (Blocked, PresetError) as e:
            why = f"확인 못 했어요 ({e})"
        self.log(f"[{nm}] 가격 확인({who}) " + (f"→ {os.path.basename(r[0])}" if r else f"실패: {why}"),
                 "ok" if r else "warn")
        if not self.sessions:
            self.end_close()
        tg = self.tg()
        if not tg:
            return
        when = f"{datetime.datetime.now():%H:%M:%S}"

        def job():
            try:
                if not r:
                    telegram_send(tg[0], tg[1], f"💰 {nm} 가격 확인 실패 ({when})\n{why}")
                    return
                cap = f"💰 {nm} · {SIDE[r[3]]} 창 ({when})"
                res = ocr_images(r[2]) if r[2] else None
                if res and len(res) == 2:
                    up, lo = parse_won(" ".join(res[0])), parse_won(" ".join(res[1]))
                    cap += f"\n상한가 {fmt_won(up)} · 하한가 {fmt_won(lo)}"
                telegram_send(tg[0], tg[1], cap, [r[0]])
            except Exception as e:
                self.q.put(("log", f"텔레그램 전송 실패: {e}", "error"))
        threading.Thread(target=job, daemon=True).start()

    def handle_ctl(self, room):
        """v3.6: 밖에서 온 요청 처리. room = 갱신싸움 전까지 남은 여유(초) — 가격 확인은 6초 이상일 때만"""
        while True:
            try:
                self.ctl_wait.append(self.ctl.get_nowait())
            except queue.Empty:
                break
        keep = []
        for cmd in self.ctl_wait:
            if cmd[0] == "enable":
                _, i, on, pdata = cmd
                self.cfg["presets"][i].update(pdata)
                nm = self.name(i)
                if on:
                    if self.mode == "schedule" and i not in self.pending:
                        self.pending.add(i)
                        p = self.P(i)
                        self.pstate(i, "armed", "예약")
                        self.log(f"[{nm}] 텔레그램에서 켬 → 예약 · {PARITY[p['parity']]} {p['minute']}분 → "
                                 f"{hhmm(next_start(self.now(), p['parity'], p['minute']))} 시작", "ok")
                else:
                    if i in self.sessions:
                        try:
                            if self.dialog_open():
                                self.close_dialog()
                        except (Blocked, PresetError):
                            pass
                        self.sessions.pop(i, None)
                        self._close_after = True
                    if i in self.pending:
                        self.pending.discard(i)
                        self.pstate(i, "idle", "꺼짐")
                        self.log(f"[{nm}] 텔레그램에서 끔 → 이번 예약에서 뺐어요", "warn")
            elif cmd[0] == "peek":
                if room >= 6:
                    self.peek(cmd[1])
                    room = 0                       # 한 번에 하나씩
                else:
                    keep.append(cmd)
        self.ctl_wait = keep

    def keep_market(self):
        """갱신싸움 사이 대기 중에도 3초마다 이적시장 확인 → 안 보이면 바로 다시 열기"""
        if self._mm_closed:
            return
        if time.time() - getattr(self, "_mk_check", 0) < 3:
            return
        self._mk_check = time.time()
        for i, s in list(self.sessions.items()):
            if s["base"] is None or s.get("restricted"):
                continue
            if not self._take(1.0):
                return
            try:
                self.refresh_window()
                self.gate(i, s)
            except Blocked as e:
                self.block(i, s, e)
            except PresetError as e:
                self.finish(i, "error", str(e))
            return

    def end_close(self):
        """진행 중인 선수가 없으면, 감독모드 경기 중(≡ 메뉴 보임)일 때 이적시장을 닫아 감모가 계속 돌게 함"""
        if self.sessions or not self.cfg.get("auto_market", True) or not self.hwnd:
            if not self.sessions:
                self.arb.give()
            return
        try:
            self.refresh_window()
            lobby = self.arb.lobby_ok and self.arb.lobby_idx is not None
            if not self.market_visible() or (not lobby and not self.find_btn("menu", self.menu_region())):
                self.arb.give()
                return
            if self.dialog_open():
                self.close_dialog()
            cw, ch = client_size(self.hwnd)
            pos = self.find_btn("close_x", [cw // 2, 0, cw - cw // 2, ch // 3])
            if pos:
                mouse_move(*pos)
                time.sleep(0.03)
                mouse_click()
                self.sleep(0.8)
                if not self.market_visible():
                    self.log("갱신싸움이 끝나서 이적시장을 닫았어요 — 감독모드는 그대로 진행돼요", "ok")
                    self.arb.give()
                    return
            self.log("끝난 뒤 이적시장을 닫지 못했어요", "warn")
        except (UserStop, StopMacro):
            raise
        except Exception:
            pass

    def dialog_crop_rect(self):
        """구매 창 전체가 들어가는 영역 (지정해둔 구매 글자 · 가격 · 호가 목록 · 구매 버튼 기준)"""
        c = self.cfg
        rs = [self.dr(c["rects"][k]) for k in ("dialog", "upper", "lower", "book") if k in c["rects"]]
        if "buy_btn" in c["points"]:
            bx, by = self.d_abs(c["points"]["buy_btn"])
            rs.append([bx - self.ox, by - self.oy, 1, 1])
        x0 = min(r[0] for r in rs) - 70
        y0 = min(r[1] for r in rs) - 35
        x1 = max(r[0] + r[2] for r in rs) + 70
        y1 = max(r[1] + r[3] for r in rs) + (35 if "buy_btn" in c["points"] else 140)
        if getattr(self, "dlg_kind", "buy") == "sell":
            y1 += 30
        cw, ch = client_size(self.hwnd)
        x0, y0, x1, y1 = max(0, x0), max(0, y0), min(cw, x1), min(ch, y1)
        return [x0, y0, x1 - x0, y1 - y0]

    def report_success(self, i, hid=None, extra=""):
        """확정 직후 곧바로 재등록 → 구매 창 캡처 → 프로그램에 띄우고 (백그라운드) 순번 인식 · 디스코드 전송"""
        c = self.cfg
        shot = crop_png = book_png = price_png = None
        self._no_spam = True                         # 결과 캡처 때는 광클 안 함 (깨끗하게)
        try:
            price = None
            for wait in (0.1, 0.35, 0.6):            # 거래목록이 새 가격으로 바뀔 짧은 시간만
                self.sleep(wait)
                price = self.open_dialog(i)
                if price is not None:
                    break
                if self.dialog_open():
                    self.close_dialog()
            if price is not None:
                stamp = f"{datetime.datetime.now():%Y%m%d_%H%M%S}"
                os.makedirs(CAP_DIR, exist_ok=True)
                crop = self.grab_raw(self.dialog_crop_rect())
                crop_png = os.path.join(CAP_DIR, f"갱신결과_구매창_{i + 1}_{stamp}.png")
                Image.fromarray(np.clip(crop, 0, 255).astype(np.uint8)[:, :, ::-1]).save(crop_png)
                shot = self.save_capture(f"갱신결과_전체_{i + 1}")
                price_png = _upscale_save(price, os.path.join(CAP_DIR, f"ocr_가격_{i + 1}_{stamp}.png"))
                if "book" in c["rects"]:
                    book_png = _upscale_save(self.d_grab(c["rects"]["book"]),
                                             os.path.join(CAP_DIR, f"ocr_호가_{i + 1}_{stamp}.png"))
                self.q.put(("result", f"{self.name(i)} · 갱신 직후 {SIDE[self.dlg_kind]} 창 "
                                      f"({datetime.datetime.now():%H:%M:%S})", crop.copy(), crop_png))
                self.log(f"[{self.name(i)}] 갱신 직후 구매 창 캡처: {os.path.basename(crop_png)}", "ok")
            else:
                shot = self.save_capture(f"갱신결과_전체_{i + 1}")
                full = self.grab_client()
                self.q.put(("result", f"{self.name(i)} · 구매 창을 다시 못 열어서 전체 화면 "
                                      f"({datetime.datetime.now():%H:%M:%S})", full.copy(), shot))
                self.log(f"[{self.name(i)}] 갱신 뒤 구매 창을 3번 다 못 열었어요 — 전체 화면을 결과 창에 띄웠어요", "warn")
            self.close_dialog()
        except (PresetError, Blocked, StopMacro) as e:
            self.log(f"[{self.name(i)}] 갱신 뒤 확인 중 문제: {e}", "warn")
            try:
                shot = self.save_capture(f"갱신결과_전체_{i + 1}")
                self.q.put(("result", f"{self.name(i)} · 확인 중 문제 — 전체 화면 "
                                      f"({datetime.datetime.now():%H:%M:%S})", self.grab_client().copy(), shot))
            except Exception:
                pass
        finally:
            self._no_spam = False
        hist_update(hid, img=crop_png or shot)
        info = {"name": self.name(i), "label": f"{SIDE[self.dlg_kind]} {TARGET[self.P(i)['target']]}",
                "time": f"{datetime.datetime.now():%H:%M:%S}", "hid": hid, "extra": extra}
        threading.Thread(target=_notify_job, daemon=True,
                         args=(c.get("discord_webhook", "").strip(), info, crop_png, shot,
                               price_png, book_png, self.q,
                               (c.get("tg_token", "").strip(), str(c.get("tg_chat", "")).strip()))).start()

    # ── 감독모드: 거래 제한이면 이적시장 닫고, 다음 경기에서 다시 열기 ──
    def find_btn(self, key, region=None, thr=0.85):
        """버튼 이미지를 화면(또는 region=[x,y,w,h] 안)에서 찾음 → 화면 좌표 가운데 (x, y) 또는 None"""
        cw, ch = client_size(self.hwnd)
        x0, y0, w, h = region or [0, 0, cw, ch]
        x0, y0 = max(0, x0), max(0, y0)
        w, h = min(w, cw - x0), min(h, ch - y0)
        t = self.btn[key]
        if w < t.shape[1] or h < t.shape[0]:
            return None
        x, y, sc = match_fast(to_gray(self.grab_raw([x0, y0, w, h])), to_gray(t))
        if sc < thr:
            return None
        return self.ox + x0 + x + t.shape[1] // 2, self.oy + y0 + y + t.shape[0] // 2

    def wait_btn(self, key, timeout, region=None):
        end = time.perf_counter() + timeout
        while time.perf_counter() < end:
            pos = self.find_btn(key, region)
            if pos:
                return pos
            self.sleep(0.15)
        return None

    def remember_header(self, client, x, y, w, h):
        """이적시장 제목줄 윗부분을 지금 화면 그대로 기억 (어두워지지 않은 상태일 때만)
        — 감모에서는 구매 창이 제목줄 아래쪽을 가려서 윗부분 14줄만 씀"""
        reg = client[max(0, y):y + h, max(0, x):x + w]
        if reg.shape[:2] != (h, w):
            return
        p = float(np.percentile(to_gray(reg), 99))
        if p >= 200:                       # 흰 글자가 또렷 = 위에 아무 창도 없음
            self.hdr_live, self.hdr_pos, self.hdr_p99 = reg.copy(), (x, y, w, h), p

    def live_header(self):
        """기억해둔 제목줄 자리의 (일치도, 글자 밝기 비율). 기억 없으면 None"""
        if self.hdr_live is None:
            return None
        reg = self.grab_raw(list(self.hdr_pos))
        sc = match_template(to_gray(reg), to_gray(self.hdr_live))[2]
        return sc, float(np.percentile(to_gray(reg), 99)) / max(1.0, self.hdr_p99)

    def _market_once(self):
        lh = self.live_header()
        if lh and lh[0] >= 0.85:                       # 1) 기억해둔 제목줄 그대로 (어두워져도 OK)
            return True
        client = self.grab_client()
        f = find_header(client, self.cfg, "lobby")      # 2) 로비 제목줄 이미지로 화면 전체 검색
        if f and f[2] >= 0.75:
            hx, hy, hw, hh = header_rect(self.cfg["rects"]["panel_lobby"])
            self.remember_header(client, hx + f[0], hy + f[1], hw, min(14, hh))
            return True
        cw, ch = client_size(self.hwnd)                 # 3) '거래 목록' 탭이나 X 버튼
        if self.find_btn("tab_trades", [0, 0, cw, ch // 2]) or \
                self.find_btn("close_x", [cw // 2, 0, cw - cw // 2, ch // 3]):
            return True
        return False

    def market_visible(self, confirm=True):
        """이적시장이 떠 있는지. 안 보이면 0.3초 뒤 한 번 더 확인 (잘못 판단해서 메뉴를 누르지 않게)"""
        if self._market_once():
            return True
        if not confirm:
            return False
        self.sleep(0.3)
        return self._market_once()

    def menu_region(self):
        cw, ch = client_size(self.hwnd)
        return [cw // 2, ch * 3 // 5, cw - cw // 2, ch - ch * 3 // 5]     # 오른쪽 아래

    def close_market(self):
        cw, ch = client_size(self.hwnd)
        pos = self.find_btn("close_x", [cw // 2, 0, cw - cw // 2, ch // 3])
        if pos:
            mouse_move(*pos)
            time.sleep(0.03)
            mouse_click()
        end = time.perf_counter() + 2.0
        while time.perf_counter() < end:
            self.sleep(0.15)
            if not self.market_visible():
                self.log("거래 제한 → 이적시장을 닫았어요 (다음 경기에서 다시 열어요)", "warn")
                return True
        shot = self.err_capture("이적시장닫기실패")
        self.log("이적시장 X 버튼을 못 눌렀어요" + (f" · {shot}" if shot else ""), "error")
        return False

    def trades_tab_selected(self, pos):
        """'거래 목록' 탭 글자가 밝으면(선택됨 250 · 선택 안 됨 154) True"""
        t = self.btn["tab_trades"]
        h, w = t.shape[:2]
        x, y = pos[0] - self.ox - w // 2, pos[1] - self.oy - h // 2
        return float(np.percentile(to_gray(self.grab_raw([x, y, w, h])), 99)) >= 200

    def ensure_trades_tab(self, tries=4):
        """'거래 목록' 탭이 선택될 때까지 눌러서 확인. 이미 선택돼 있으면 안 누름"""
        for k in range(tries):
            pos = self.wait_btn("tab_trades", 3.0 if k == 0 else 1.0)
            if not pos:
                return False
            if self.trades_tab_selected(pos):
                return True
            mouse_move(*pos)
            time.sleep(0.03)
            mouse_click()
            end = time.perf_counter() + 0.8
            while time.perf_counter() < end:
                self.sleep(0.08)
                if self.trades_tab_selected(pos):
                    self.sleep(0.4)                # 거래목록이 다 그려질 시간
                    return True
        return False

    def open_market(self):
        """≡ 메뉴 → 이적시장 → 거래 목록"""
        if self._market_once():                    # 이미 떠 있으면 메뉴를 누르지 않음
            self.detect_layout()
            self.mk.update(phase=None, fails=0, menu_seen=False)
            return
        pos = self.find_btn("menu", self.menu_region())
        if not pos:
            raise Restricted("다음 경기 대기 — 메뉴(≡) 버튼이 안 보여요")
        if not self._quiet:
            self.log("다음 경기 진입 확인 → ≡ 메뉴에서 이적시장을 열어요")
        mouse_move(*pos)
        time.sleep(0.03)
        mouse_click()
        item = self.wait_btn("menu_market", 3.0)
        if not item:
            self.mk["fails"] += 1
            shot = self.err_capture("메뉴_이적시장없음")
            raise Restricted("메뉴에서 '이적시장'을 못 찾았어요" + (f" · {shot}" if shot else ""))
        mouse_move(*item)
        time.sleep(0.03)
        mouse_click()
        end = time.perf_counter() + 6.0
        while not self.market_visible(confirm=False):
            if time.perf_counter() > end:
                self.mk["fails"] += 1
                shot = self.err_capture("이적시장안열림")
                raise Restricted("이적시장 창이 안 열렸어요" + (f" · {shot}" if shot else ""))
            self.sleep(0.2)
        self.sleep(0.5)
        if not self.ensure_trades_tab():
            self.mk["fails"] += 1
            shot = self.err_capture("거래목록탭실패")
            raise Restricted("'거래 목록' 탭으로 못 넘어갔어요" + (f" · {shot}" if shot else ""))
        self.park_mouse()
        self.detect_layout()
        self.mk.update(phase=None, fails=0, menu_seen=False)
        if not self._quiet:
            self.log("이적시장 → 거래 목록까지 다시 들어왔어요", "ok")

    def green_banner(self):
        """게임 화면 맨 위 띠가 초록색이면 True (감독모드 멀티태스킹 제한 안내)"""
        w, _ = client_size(self.hwnd)
        a = self.grab_raw([0, 0, w, 40])
        b, g, r = a[..., 0], a[..., 1], a[..., 2]
        m = (g > 180) & (r < 140) & (g - r > 80) & (g - b > 40)
        self._green_rows = int((m.mean(axis=1) > 0.8).sum())
        return self._green_rows >= 20     # 실제 띠 33줄 · 경기장 초록 전광판 0줄

    def gate(self, i, s, full=True):
        """진행해도 되는지 확인. 거래 제한이면 이적시장을 닫고, 다음 경기에서 다시 열 때까지 Restricted
           full=False: 초록 띠만 빠르게 확인 (이적시장 화면 전체 검사는 3초에 한 번)"""
        mk = self.mk
        if not full and not s.get("restricted"):
            if not self.green_banner():
                return
        self._gate_t = time.time()
        if self.green_banner():
            if mk["phase"] != "banner":                # 처음 감지한 순간만 화면 저장 (오인인지 확인용)
                shot = self.err_capture("초록띠")
                self.log(f"상단 초록 띠 감지 (맨 위 40줄 중 초록 줄 {getattr(self, '_green_rows', '?')}개 · 기준 20개)"
                         + (f" · 화면: {shot}" if shot else ""), "warn")
            if self.market_visible():
                self.close_market()
            mk.update(phase="banner", saw_no_menu=False, menu_seen=False)
            raise Restricted("상단 초록 안내(거래 제한) — 이적시장 닫고 다음 경기 대기")
        if self.market_visible():
            if s.get("restricted"):
                s["restricted"] = False
                s["limit_msg"] = ""
                self.pstate(i, "run", "진행 중")
                self.log(f"[{self.name(i)}] 다시 진행해요", "ok")
            return
        # 이적시장이 닫혀 있음
        if not self.cfg.get("auto_market", True):
            raise Blocked("이적시장이 안 보여요")
        if self.arb.lobby_ok and not self.find_btn("menu", self.menu_region()):     # v4.0 ⭐ 로비 대기 중
            self.open_market_lobby()
            if s.get("restricted"):
                s["restricted"] = False
                s["limit_msg"] = ""
                self.pstate(i, "run", "진행 중")
            return
        if mk["phase"] == "banner":                 # 초록 띠가 막 사라짐 = 지금 경기 끝
            mk.update(phase="after", after_t=time.time())
        menu = self.find_btn("menu", self.menu_region())
        if mk["phase"] == "after":
            if not menu:
                mk["saw_no_menu"] = True
            if not mk["saw_no_menu"] and time.time() - mk["after_t"] < 150:
                raise Restricted("경기 끝나는 중 — 다음 경기 대기")
        if not menu:
            mk["menu_seen"] = False
            raise Restricted("다음 경기 대기 — 메뉴(≡) 버튼이 안 보여요")
        if mk["phase"] == "after" and not mk["menu_seen"]:   # 경기 끝난 뒤엔 3초 뒤 한 번 더 보이면 진입한 걸로
            mk["menu_seen"] = True
            raise Restricted("다음 경기 진입 확인 중")
        if mk["fails"] >= 5:
            mk["fails"] = 0
            raise Restricted("이적시장 열기를 5번 연속 실패 — 잠시 뒤 다시 시도 (captures 확인)")
        if mk["phase"] is None and not self._quiet:
            self.log("이적시장이 안 보여요 → ≡ 메뉴에서 다시 열게요", "warn")
        self.open_market()
        if s.get("restricted"):
            s["restricted"] = False
            s["limit_msg"] = ""
            self.pstate(i, "run", "진행 중")

    def block(self, i, s, why):
        """거래 제한·다음 경기 대기는 3초마다 확인, 그 밖의 문제는 약 1분 뒤 다시 시도"""
        t = self.now()
        if t >= s["end"]:
            self.log(f"[{self.name(i)}] {why} → 남은 시간이 없어 종료", "warn")
            self.finish(i, "timeout")
            return
        if s.get("base") is None and not s.get("ready_fail_sent") and self.now() >= s["start"]:   # 시작 시각까지 준비 못 함
            s["ready_fail_sent"] = True
            self.tg_text(f"⛔ {self.name(i)} 준비 못 함 ({hhmm(s['start'])} 시작 예정)\n· {why}\n"
                         f"· 풀리면 바로 준비해서 다시 알려 드릴게요")
        if isinstance(why, Restricted):
            self.arb.give()                              # v4.0: 경기 끝·다음 경기 대기 -> 감독모드가 화면 씀
            msg = str(why)
            if not s.get("restricted"):
                s["restricted"] = True
                self.pstate(i, "limit", "경기 대기")
            if msg != s.get("limit_msg"):
                s["limit_msg"] = msg
                self.log(f"[{self.name(i)}] {msg}", "warn")
            s["blocked_until"] = t + 3
            s["blocked_s"] = s.get("blocked_s", 0) + 3
            return
        why = str(why)
        nt = t + 55
        nt += until_sec(nt, self.cfg["start_sec"])
        if nt >= s["end"]:
            self.log(f"[{self.name(i)}] {why} → 남은 시간이 없어 종료", "warn")
            self.finish(i, "timeout")
            return
        s["blocked_until"] = nt
        s["blocked_s"] = s.get("blocked_s", 0) + (nt - t)
        s["fails"] = 0
        self.pstate(i, "limit", "제한 대기")
        self.log(f"[{self.name(i)}] {why} → {datetime.datetime.fromtimestamp(nt):%H:%M:%S}에 다시 시도", "warn")
        try:
            if self.dialog_open():
                self.close_dialog()
        except (Blocked, PresetError):
            pass

    def start_gap(self, i, s, dry=False):
        """시작할 때 거래목록의 내 등록가와 구매/판매 창의 목표가(상한가/하한가)를 글자 인식으로 비교.
        이미 갱신이 끝나 내 가격이 목표가와 다르면(구매·상한가: 내 가격이 더 낮음) 바로 갱신.
        반환: True = 갱신해서 이 선수는 끝남"""
        p = self.P(i)
        if not p["rects"].get("my_price"):
            self.log(f"[{self.name(i)}] '등록가' 위치를 지정하면 시작할 때 내 가격과 목표가를 비교해서, "
                     f"이미 갱신돼 있으면 바로 맞춰요", "warn")
            return False
        os.makedirs(CAP_DIR, exist_ok=True)
        stamp = f"{datetime.datetime.now():%Y%m%d_%H%M%S}"
        mine_png = _upscale_save(self.grab(self.row_rect(i, "my_price")),
                                 os.path.join(CAP_DIR, f"ocr_내등록가_{i + 1}_{stamp}.png"))
        tgt_png = _upscale_save(s["base"], os.path.join(CAP_DIR, f"ocr_목표가_{i + 1}_{stamp}.png"))
        paths = [mine_png, tgt_png]
        if s.get("base_amt") is not None:
            paths.append(_upscale_save(s["base_amt"], os.path.join(CAP_DIR, f"ocr_금액칸_{i + 1}_{stamp}.png")))
        res = ocr_images(paths)
        if not res:
            self.log(f"[{self.name(i)}] 글자 인식이 안 돼서 내 가격 비교를 건너뛰어요 (Windows 한국어 OCR 필요)", "warn")
            return False
        mine, tgt = parse_won(" ".join(res[0])), parse_won(" ".join(res[1]))
        label = TARGET[p["target"]]
        if mine is None or tgt is None:
            self.log(f"[{self.name(i)}] 가격 글자를 못 읽었어요 (내 가격 '{' '.join(res[0])}' · "
                     f"{label} '{' '.join(res[1])}') — 비교 건너뜀", "warn")
            return False
        sell = getattr(self, "dlg_kind", "buy") == "sell"
        # 안전장치 1: 금액 칸 숫자(처음부터 구매=상한가, 판매=하한가가 들어 있음)와 목표가가 같아야 믿음
        if len(res) >= 3 and ((not sell and p["target"] == "upper") or (sell and p["target"] == "lower")):
            amt = parse_won(" ".join(res[2]))
            if amt is not None and amt != tgt:
                self.log(f"[{self.name(i)}] 목표가 글자 인식이 확실하지 않아요 ({label} {fmt_won(tgt)} · 금액 칸 {fmt_won(amt)}) "
                         f"— 비교 건너뜀", "warn")
                return False
        # 안전장치 2: 내 가격이 목표가의 70~130% 밖이면 잘못 읽은 것으로 봄
        if not (0.7 * tgt <= mine <= 1.3 * tgt):
            self.log(f"[{self.name(i)}] 내 가격을 잘못 읽은 것 같아요 (내 가격 {fmt_won(mine)} · {label} {fmt_won(tgt)}) "
                     f"— 비교 건너뜀", "warn")
            return False
        # 구매·상한가: 내 가격 < 상한가 / 하한가 목표: 내 가격 > 하한가 → 맞춰야 함
        need = (mine < tgt) if p["target"] == "upper" else (mine > tgt)
        kind = "판매" if sell else "구매"
        if not need:
            self.log(f"[{self.name(i)}] 내 {kind} 등록가 {fmt_won(mine)} = 지금 {label} {fmt_won(tgt)} → 다음 갱신을 기다려요", "ok")
            return False
        if dry:
            self.log(f"[{self.name(i)}] 내 등록가 {fmt_won(mine)} ≠ 지금 {label} {fmt_won(tgt)} — "
                     f"이미 갱신돼 있어요. 실전이면 지금 바로 {label}로 갱신해요 (테스트라 누르지 않음)", "warn")
            return False
        self.log(f"[{self.name(i)}] 내 등록가 {fmt_won(mine)} ≠ 지금 {label} {fmt_won(tgt)} — 이미 갱신돼 있어서 바로 맞출게요", "warn")
        price = self.open_dialog(i)
        if price is None:
            if self.dialog_open():
                self.close_dialog()
            self.log(f"[{self.name(i)}] 바로 갱신하려 했는데 창이 안 열렸어요 — 다음 시도에서 다시", "warn")
            return False
        n, how, entered = self.commit(i)
        self.park_mouse()
        self.log(f"[{self.name(i)}] {label} {fmt_won(tgt)}로 바로 갱신 → "
                 f"{'확정' if entered else '확정 못 함'} ({how})", "ok" if entered else "warn")
        if not entered:
            self.close_dialog()
            return False
        self._after_confirm(i, s, price, 0)
        return True

    def init_base(self, i, s):
        price = None
        for n in range(3):
            if self.dialog_open():
                self.close_dialog()
            price = self.open_dialog(i)
            if price is not None:
                break
            if self.dialog_open():
                self.close_dialog()
            dbg = self.save_debug(f"기준가실패_{i + 1}", *self.fail_imgs) if self.fail_imgs else None
            self.log(f"[{self.name(i)}] 기준가 읽기 실패 ({n + 1}/3): {self.fail_reason}"
                     + (f" · {os.path.basename(dbg)}" if dbg else ""), "warn")
            self.sleep(0.5)
            if n == 1:
                self.detect_layout()
        if price is None:
            raise PresetError(f"기준가를 3번 연속 못 읽었어요: {self.fail_reason}")
        s["base"] = price
        s["base_top"] = ink_top(price)
        orr = self.other_rect(i)
        s["base_other"] = self.d_grab(orr) if orr else None   # 구매 창이 아직 떠 있을 때 같이 찍음
        s["base_bg"] = bg_level(price)
        s["base_other_bg"] = bg_level(s["base_other"]) if s["base_other"] is not None else None
        ar = self.amount_rect()
        s["base_amt"] = self.d_grab(ar) if ar else None        # 금액 칸 (목표가 글자 인식 교차 확인용)
        label = TARGET[self.P(i)["target"]]
        self.preview(f"[{self.name(i)}] 기준 {label} · {datetime.datetime.now():%H:%M:%S} 저장", price)
        self.save_debug(f"기준가_{i + 1}", price)
        if not self.close_dialog():
            raise StopMacro("ESC를 눌러도 구매 창이 안 닫혀요")
        mp = self.row_rect(i, "my_price") if self.P(i)["rects"].get("my_price") else None
        s["base_my"] = self.grab(mp) if mp else None
        self.log(f"[{self.name(i)}] 기준 {TARGET[self.P(i)['target']]} 저장 완료")

    def attempt(self, i, s, dry=False):
        sens = self.sens
        self._tmark = time.perf_counter()
        self.refresh_window()
        self.gate(i, s, full=time.time() - self._gate_t >= 3)
        self.mark("확인")
        mp = self.row_rect(i, "my_price") if self.P(i)["rects"].get("my_price") else None
        s["pre_my"] = self.grab(mp) if mp else None     # 이번 바퀴 직전 거래목록 내 등록가 (Enter 뒤 진짜 바뀌었는지 비교용)
        price = self.open_dialog(i, s)
        t_read = self.now()                              # v3.6: 가격을 읽은 시각 (실제 갱신 시각 기록용)
        self.attempts += 1
        s["n"] = s.get("n", 0) + 1
        if price is None:
            s["fails"] += 1
            dbg = self.save_debug(f"열기실패_{i + 1}", *self.fail_imgs) if self.fail_imgs else None
            self.log(f"[{self.name(i)}] 열기 실패 ({s['fails']}/3): {self.fail_reason}"
                     + (f" · {os.path.basename(dbg)}" if dbg else ""), "warn")
            if self.dialog_open():
                self.close_dialog()
            if s["fails"] == 2:
                self.detect_layout()
            if s["fails"] >= 3:
                s["fails"] = 0
                raise Blocked(f"구매 창이 3번 연속 안 열렸어요 (거래 제한 추정) — 마지막 이유: {self.fail_reason}")
            return
        s["fails"] = 0
        if self.dlg_kind != self.P(i).get("side", "buy") and not s.get("kind_warned"):
            s["kind_warned"] = True
            self.log(f"[{self.name(i)}] 프리셋은 '{SIDE[self.P(i).get('side', 'buy')]}'인데 '{SIDE[self.dlg_kind]}' 창이 떴어요 "
                     f"— 실제 뜬 창 기준으로 진행해요. 프리셋 탭의 구매/판매를 확인해 주세요", "warn")

        if self.early_same:
            s["last_same_t"] = t_read
            s["last_diff"] = 0
            self.n_fast += 1
            if not self.cfg.get("spam_click", True):
                self.click_price(i)      # 같아도 무조건 클릭 (요청대로)
            self.note_click_reg()
            self.mark("가격 클릭")
            if not self.close_dialog():
                raise StopMacro("ESC를 눌러도 구매 창이 안 닫혀요")
            self.mark("창 닫힘")
            self.tm_n += 1
            return

        if self.early_diff:
            d = diff_pixels(price, s["base"])
            s["last_diff"] = d
            s["detect_t"] = t_read
            if dry:
                self.log(f"[{self.name(i)}] 테스트: 가격대가 바뀐 걸 {self.seen_text(s)}에 봤어요")
                self.click_price(i, park=False)
                self.park_mouse()
                self.preview(f"[{self.name(i)}] 테스트 · 빠른 변동 감지 · 왼쪽 기준 / 오른쪽 지금", s["base"], price)
                self.log(f"[{self.name(i)}] 테스트: 빠른 변동 감지 (글자 차이 {s.get('fast_check')}) — "
                         f"실전이면 여기서 바로 Enter 한 번 (테스트라 누르지 않음)", "ok")
                self._rebase(i, s, price)
                self.close_dialog()
                s["changes"] = s.get("changes", 0) + 1
                return
            n, how, entered = self.commit(i)
            s["enter_ms"] = int((self.now() - t_read) * 1000)
            self.park_mouse()
            self.log(f"[{self.name(i)}] {TARGET[self.P(i)['target']]} 변동 → "
                     f"{'바로 확정' if entered else '확정 못 함'} (글자 차이 {s.get('fast_check')} · {how} · 추가 클릭 {n}번"
                     f" · 감지→Enter {s['enter_ms'] / 1000:.2f}초 · 바뀐 걸 본 시각 {self.seen_text(s)})",
                     "ok" if entered else "warn")
            if not entered:
                s["missed"] = s.get("missed", 0) + 1
                self.close_dialog()            # 다음 바퀴에 다시 (기준가는 그대로 → 또 '변동'으로 잡힘)
                return
            return self._after_confirm(i, s, price, d)

        d = diff_pixels(price, s["base"])
        s["last_diff"] = d
        if d < sens:
            s["last_same_t"] = t_read
            if not self.cfg.get("spam_click", True):
                self.click_price(i)      # 같아도 무조건 클릭 (요청대로)
            self.note_click_reg()
            self.mark("가격 클릭")
            if not self.close_dialog():
                raise StopMacro("ESC를 눌러도 구매 창이 안 닫혀요")
            self.mark("창 닫힘")
            self.tm_n += 1
            return

        # 변동 의심 → 한 번 더 찍어서 같은 숫자가 그대로인지 확인 (애니메이션 오감지 방지)
        self.sleep(0.03)
        again = self.read_price(i, timeout=0.5)
        # 광클로 숫자 색이 잠깐 바뀌는 효과에 속지 않게: 클릭하지 않는 반대쪽 가격도 바뀌었는지 같이 확인
        other_same = False
        if s.get("base_other") is not None and self.other_rect(i):
            mo = text_mismatch(self.d_grab(self.other_rect(i)), s["base_other"])
            other_same = mo <= FAST_SAME or really_diff(self.d_grab(self.other_rect(i)), s["base_other"]) < FAST_DIFF
        if again is None or diff_pixels(again, price) >= 3 or diff_pixels(again, s["base"]) < sens \
                or really_diff(again, s["base"]) < FAST_DIFF or other_same \
                or not bg_ok(again, s.get("base_bg")):
            s["last_diff"] = 0 if again is None else diff_pixels(again, s["base"])
            dbg = self.save_debug(f"재확인무시_{i + 1}_기준vs첫캡처vs재확인", s["base"], price,
                                  again if again is not None else price)
            self.log(f"[{self.name(i)}] 변동 의심({d}px)이었지만 재확인에서 같은 가격 → 무시"
                     + (f" · {os.path.basename(dbg)}" if dbg else ""), "warn")
            self.click_price(i)
            if not self.close_dialog():
                raise StopMacro("ESC를 눌러도 구매 창이 안 닫혀요")
            return
        s["detect_t"] = t_read
        if dry:
            self.click_price(i)
            self.preview(f"[{self.name(i)}] 테스트 · 변동 감지 · 왼쪽 기준 / 오른쪽 지금 ({d}px)", s["base"], price)
            self.log(f"[{self.name(i)}] 테스트: {TARGET[self.P(i)['target']]} 변동 감지 ({d}px) — "
                     f"실전이면 여기서 Enter로 확정해요 (테스트라 누르지 않음)", "ok")
            self._rebase(i, s, price)
            self.close_dialog()
            s["changes"] = s.get("changes", 0) + 1
            return
        n, how, entered = self.commit(i)
        s["enter_ms"] = int((self.now() - t_read) * 1000)
        self.park_mouse()
        self.log(f"[{self.name(i)}] {TARGET[self.P(i)['target']]} 변동 감지 ({d}px) → "
                 f"{'확정' if entered else '확정 못 함'} ({how} · 추가 클릭 {n}번 · 감지→Enter {s['enter_ms'] / 1000:.2f}초"
                 f" · 바뀐 걸 본 시각 {self.seen_text(s)})", "ok" if entered else "warn")
        if not entered:
            s["missed"] = s.get("missed", 0) + 1
            self.close_dialog()
            return
        return self._after_confirm(i, s, price, d)

    def seen_text(self, s):
        """가격대가 바뀐 걸 처음 본 시각 (서버 시계 기준) + 바로 전에 '그대로'를 본 시각"""
        dt = s.get("detect_t")
        if not dt:
            return "모름"
        a = datetime.datetime.fromtimestamp(dt)
        txt = f"{a:%H:%M:%S}.{a.microsecond // 100000}"
        ls = s.get("last_same_t")
        if ls and 0 < dt - ls < 120:
            b = datetime.datetime.fromtimestamp(ls)
            txt += f" (직전 그대로 {b:%M:%S}.{b.microsecond // 100000})"
        return txt

    def _rebase(self, i, s, price):
        s["base"] = price
        s["base_top"] = ink_top(price)
        s["base_bg"] = bg_level(price)
        orr = self.other_rect(i)
        if orr and s.get("base_other") is not None:
            s["base_other"] = self.d_grab(orr) if self.dialog_open() else s["base_other"]
            s["base_other_bg"] = bg_level(s["base_other"])

    def _rebase_after_false(self, i, s):
        """오판 뒤: 기준가를 지금 화면으로 다시 찍어서 같은 오판이 반복되지 않게"""
        s.pop("detect_t", None)
        s.pop("enter_ms", None)
        try:
            price = self.open_dialog(i)
            if price is not None:
                self._rebase(i, s, price)
            if self.dialog_open():
                self.close_dialog()
        except (UserStop, StopMacro):
            raise
        except Exception:
            pass
        mp = self.row_rect(i, "my_price") if self.P(i)["rects"].get("my_price") else None
        if mp:
            s["base_my"] = self.grab(mp)

    def _after_confirm(self, i, s, price, d):
        """확정(Enter 한 번) 뒤: 구매 창이 닫히자마자 바로 재등록 → 구매 창 캡처해서 보여주기 → 기록"""
        if not self.wait_dialog(False, 3.0):
            path = self.save_capture(f"갱신확인실패_{i + 1}")
            try:
                crop = self.grab_raw(self.dialog_crop_rect())
                self.q.put(("result", f"{self.name(i)} · Enter 후 창이 안 닫힘 — 이 화면을 확인하세요 "
                                      f"({datetime.datetime.now():%H:%M:%S})", crop.copy(), path))
            except Exception:
                pass
            raise PresetError(f"확정 후에도 구매 창이 안 닫혔어요 · 화면 저장: {os.path.basename(path)}")
        mp = self.row_rect(i, "my_price") if self.P(i)["rects"].get("my_price") else None
        if mp and s.get("pre_my") is not None:
            moved = False
            end = time.perf_counter() + 1.5
            while time.perf_counter() < end:
                if diff_pixels(self.grab(mp), s["pre_my"]) >= self.sens:
                    moved = True
                    break
                time.sleep(0.05)
            if not moved:
                # 내 등록가가 Enter 전과 똑같음 = 가격대가 안 바뀌었는데 바뀐 걸로 잘못 봤음 → 성공 아님, 계속 싸움
                dbg = self.save_debug(f"오판_{i + 1}_기준vs지금", s["base"], price)
                self.log(f"[{self.name(i)}] Enter 뒤에도 거래목록 내 등록가가 그대로예요 → 가격대가 바뀐 게 아니었어요 "
                         f"(오판). 성공으로 치지 않고 계속 진행해요" + (f" · {os.path.basename(dbg)}" if dbg else ""), "warn")
                self._rebase_after_false(i, s)
                return
        p = self.P(i)
        entry = {"idx": i, "name": self.name(i), "side": self.dlg_kind, "target": p["target"], "kind": "success",
                 "start": hhmm(s["start"]) if s.get("start") else ""}
        extra = []
        if s.get("detect_t"):
            dt = datetime.datetime.fromtimestamp(s["detect_t"])
            entry["seen"] = f"{dt:%M}:{dt:%S}.{dt.microsecond // 100000}"
            entry["seen_full"] = self.seen_text(s)
            extra.append(f"· 가격대 바뀐 걸 본 시각: {entry['seen_full']}")
        else:
            extra.append("· 시작할 때 이미 바뀌어 있어서 바로 맞췄어요")
        if s.get("enter_ms") is not None:
            entry["enter_ms"] = s["enter_ms"]
            extra.append(f"· 감지 → Enter: {s['enter_ms'] / 1000:.2f}초")
        entry["attempts"] = s.get("n", 0)
        hid = hist_add(entry)
        self.report_success(i, hid, "\n".join(extra))      # 곧바로 재등록 → 구매 창(호가 목록) 캡처
        self.q.put(("hist_changed",))
        dbg = self.save_debug(f"변동감지_{i + 1}_기준vs지금", s["base"], price)
        self.preview(f"[{self.name(i)}] 변동 감지 · 왼쪽 기준 / 오른쪽 지금 ({d}px)", s["base"], price)
        msg = "구매 창이 닫혔어요"
        mp = self.row_rect(i, "my_price") if self.P(i)["rects"].get("my_price") else None
        if mp and s.get("base_my") is not None:
            if diff_pixels(self.grab(mp), s["base_my"]) >= self.sens:
                msg = "거래목록 금액이 바뀐 것까지 확인했어요"
            else:
                msg = "구매 창은 닫혔는데 거래목록 금액은 그대로예요 — 결과 화면을 확인하세요"
        if dbg:
            self.log(f"[{self.name(i)}] 비교 화면: {os.path.basename(dbg)}")
        self.finish(i, "success", msg)

    # ── 실행 ──
    def sync_time(self):
        c = self.cfg
        if not c.get("auto_time_sync", True):
            return
        host = c.get("time_host") or "fcalrimi.com"
        self.status("ready", f"{host} 시간에 맞추는 중…")
        try:
            off, err = measure_server_offset(host)
        except Exception as e:
            self.log(f"{host} 시간 맞추기 실패 ({e}) — 기존 시계 보정 {c['clock_offset']:+.2f}초 그대로 사용", "warn")
            return
        c["clock_offset"] = round(off, 3)
        self.q.put(("clock", off, err, host))

    def run(self):
        try:
            if self.mode != "peek":
                self.sync_time()
            with mss.mss() as sct:
                self.sct = sct
                if self.mode == "test":
                    self._test()
                elif self.mode == "peek":
                    self.peek(self.only)
                else:
                    self._main()
        except UserStop:
            self.log("정지했어요")
        except Blocked as e:
            self.log(f"테스트 중단: {e}", "warn")
            self.q.put(("alert", f"지금은 진행할 수 없어요: {e}"))
        except StopMacro as e:
            shot = self.err_capture("전체멈춤")
            self.log(f"전체 멈춤: {e}" + (f" · 그 순간 화면: {shot}" if shot else ""), "error")
            self.q.put(("alert", str(e)))
        except Exception:
            shot = self.err_capture("예외")
            self.log("오류:\n" + traceback.format_exc() + (f"그 순간 화면: {shot}" if shot else ""), "error")
            self.q.put(("alert", "예상치 못한 오류로 멈췄어요. 로그를 확인해주세요."))
        finally:
            try:
                self.clicker.stop()
            except Exception:
                pass
            self.arb.give()
            for i in list(self.pending):
                self.pstate(i, "idle", "")
            self.q.put(("done", self.results, self.mode))

    def _test(self):
        """실전과 같은 순서로 20초: 이적시장 열기 → 선수 찾기 → 기준가 → 재등록·가격 클릭·비교·ESC 반복 (확정은 안 함)"""
        i = self.only
        nm = self.name(i)
        s = {"base": None, "fails": 0, "last_diff": 0, "blocked_until": 0, "restricted": False,
             "start": 0, "end": time.time() + 600, "changes": 0}
        self.status("ready", f"[{nm}] 테스트 · 이적시장 확인")
        self.focus_game()
        end = time.time() + 30
        while True:
            try:
                self.refresh_window()
                self.gate(i, s)
                break
            except Restricted as e:
                if self.mk["phase"] == "banner":
                    raise StopMacro("지금은 거래 제한(상단 초록 띠) 중이라 테스트할 수 없어요")
                if time.time() > end:
                    raise StopMacro(f"이적시장을 열지 못했어요: {e}")
                self.log(f"[{nm}] {e}", "warn")
                self.sleep(3)
            except Blocked as e:
                raise StopMacro(f"이적시장이 안 보여요: {e}")
        self.detect_layout()
        self.status("ready", f"[{nm}] 테스트 · 기준가 저장")
        self.init_base(i, s)
        self.log(f"[{nm}] 거래목록 이름 위치: 처음 지정한 곳에서 {self.row_dy.get(i, 0):+d}px", "ok")
        self.start_gap(i, s, dry=True)
        tsec = max(0, int(self.cfg.get("test_sec", 20)))
        t_end = time.time() + tsec
        n0 = self.attempts
        self.tm_reset()
        while time.time() < t_end or self.attempts == n0:      # 0초면 딱 한 번
            if tsec == 0 and self.attempts > n0:
                break
            self.status("fight", f"[{nm}] 테스트 중 · {t_end - time.time():.0f}초 남음 · "
                                 f"시도 {self.attempts - n0}회 · 마지막 차이 {s['last_diff']}px · 글자 {s.get('last_mm', '-')}")
            try:
                self.attempt(i, s, dry=True)
            except Blocked as e:
                self.log(f"[{nm}] 테스트 중 멈춤: {e}", "warn")
                break
            except PresetError as e:
                raise StopMacro(str(e))
        self.log(f"[{nm}] 테스트 {f'{tsec}초' if tsec else '1회'} 완료 · 시도 {self.attempts - n0}회 · 가격 변동 {s['changes']}회 "
                 f"(같은 가격일 때 차이는 0 근처여야 정상: 마지막 {s['last_diff']}px)", "ok")
        if self.tm_n:
            self.log(f"[{nm}] 단계별 시간(초): {self.tm_summary()}", "info")

    def _main(self):
        c = self.cfg
        dur = c["duration_min"] * 60
        prep = c["prep_sec"]
        s_sec, e_sec = c["start_sec"], c["end_sec"]

        if self.mode == "now":
            idxs = [self.only]
        else:
            idxs = [i for i, p in enumerate(c["presets"]) if p["enabled"]]
        self.pending = set(idxs)
        for i in idxs:
            self.pstate(i, "armed", "예약")
        if self.mode == "now":
            t = self.now()
            self.start_session(self.only, t, t + dur)
        else:
            for i in idxs:
                p = self.P(i)
                nxt = session_window(self.now(), p["parity"], p["minute"], dur, prep)
                first = nxt[0] if nxt else next_start(self.now(), p["parity"], p["minute"])
                self.log(f"[{self.name(i)}] 예약 · {PARITY[p['parity']]} {p['minute']}분 → "
                         f"{hhmm(first)} 시작")
        rr = 0

        while True:
            self.check_stop()
            t = self.now()

            # 예약 시각 → 세션 시작
            if self.mode == "schedule":
                for i in sorted(self.pending - set(self.sessions)):
                    p = self.P(i)
                    w = session_window(t, p["parity"], p["minute"], dur, prep)
                    if w:
                        self.start_session(i, *w)

            # 지속 시간 끝 → 종료
            for i in list(self.sessions):
                if t >= self.sessions[i]["end"]:
                    self.finish(i, "timeout")
            if getattr(self, "_close_after", False) and not self.sessions:
                self._close_after = False
                self.end_close()

            if not self.pending:
                break

            # 진행 중인 세션이 없으면 다음 예약까지 대기 (PC는 자유롭게 써도 됨)
            if not self.sessions:
                nxt_t = min(next_start(t, self.P(i)["parity"], self.P(i)["minute"]) for i in self.pending)
                self.handle_ctl(nxt_t - prep - t)
                if not self.pending:
                    break
                nxt_t, nxt_i = min((next_start(t, self.P(i)["parity"], self.P(i)["minute"]), i)
                                   for i in self.pending)
                self.status("armed", f"다음: {self.name(nxt_i)} · {hhmm(nxt_t)} "
                                     f"({human(nxt_t - prep - t)} 후 준비)")
                self.sleep(0.2)
                continue

            # 새 세션: 게임 창을 앞으로 + 기준가 저장
            for i, s in list(self.sessions.items()):
                if s["base"] is None and self.now() >= s["blocked_until"]:
                    if self.arb.gm_running and not self.arb.lobby_ok and not self.arb.take(8.0):
                        self.status("ready", f"{self.name(i)} · 감독모드가 화면을 쓰는 중이라 준비를 잠깐 기다려요")
                        self.sleep(0.5)
                        continue
                    self._mm_closed = False
                    try:
                        if not s["focused"]:
                            self.focus_game()
                            s["focused"] = True
                        self.refresh_window()
                        self.gate(i, s)
                        self.detect_layout()
                        self.init_base(i, s)
                        self.pstate(i, "run", "진행 중")
                        self.start_gap(i, s)
                        if i in self.sessions:
                            self.notify_ready(i, s)
                    except Blocked as e:
                        self.block(i, s, e)
                    except PresetError as e:
                        self.finish(i, "error", str(e))
            if not self.sessions:
                continue

            for i, s in list(self.sessions.items()):
                if s.get("restricted") and s["base"] is not None and self.now() >= s["blocked_until"]:
                    if not self._take(3.0):
                        s["blocked_until"] = self.now() + 2
                        continue
                    try:
                        self.refresh_window()
                        self.gate(i, s)
                    except Blocked as e:
                        self.block(i, s, e)
                    except PresetError as e:
                        self.finish(i, "error", str(e))
            if not self.sessions:
                continue

            t = self.now()
            ready = {i: s for i, s in self.sessions.items() if s["base"] is not None and t >= s["blocked_until"]}
            names = ", ".join(self.name(i) for i in self.sessions)
            if not ready:
                nb = min(s["blocked_until"] for s in self.sessions.values())
                if nb > t:
                    self.handle_ctl(nb - t)
                    msgs = [s.get("limit_msg") for s in self.sessions.values() if s.get("restricted")]
                    if msgs:
                        self.status("limit", f"{names} · {msgs[0]}")
                    else:
                        self.status("limit", f"{names} · 거래 제한/화면 대기 · {human(nb - t)} 뒤 다시 시도")
                    self.sleep(0.2)
                    continue
            fighting = [i for i, s in ready.items() if t >= s["start"]]
            # v3.6 우선순위: 같은 때 싸우는 선수가 여럿이면 숫자가 가장 작은(우선) 선수만. 그 선수가 끝나면 다음 선수
            if len(fighting) > 1:
                top = min(prio(self.P(k)) for k in fighting)
                for k in fighting:
                    held = prio(self.P(k)) != top
                    sk = self.sessions[k]
                    if held and not sk.get("held"):
                        sk["held"] = True
                        self.pstate(k, "armed", "우선순위 대기")
                        self.log(f"[{self.name(k)}] 시간이 겹쳐서 우선순위가 높은 선수가 끝날 때까지 기다려요", "warn")
                    elif not held and sk.get("held"):
                        sk["held"] = False
                        self.pstate(k, "run", "진행 중")
                fighting = [k for k in fighting if prio(self.P(k)) == top]
            for k in fighting:
                sk = self.sessions[k]
                if sk.get("held"):
                    sk["held"] = False
                    self.pstate(k, "run", "진행 중")
                    self.log(f"[{self.name(k)}] 우선 선수가 끝나서 이제 진행해요", "ok")
            if not fighting:
                first = min(s["start"] for s in self.sessions.values())
                self.handle_ctl(first - t)
                self.status("ready", f"{names} · 시작까지 {human(first - t)}")
                rs = float(self.cfg.get("reopen_sec", 3))
                if self.shared() and ready:
                    k = min(ready, key=lambda q: self.sessions[q]["start"])
                    if first - t > rs + 3:
                        self.mm_close()
                    elif self._mm_closed and not self.mm_reopen(k, rs):
                        self.sleep(0.2)
                        continue
                self.keep_market()
                self.sleep(0.1)
                continue

            if t < self._skip_until:                     # v4.0: 감독모드 때문에 이번 분은 쉼
                self.status("wait", f"{names} · 감독모드가 화면을 쓰는 분이라 쉬어요 · {human(self._skip_until - t)}")
                if self._mm_closed is False and self.shared():
                    self.mm_close()
                self.sleep(0.1)
                continue

            if in_sec_window(t, s_sec, e_sec) and self._mm_closed and self.shared():   # 늦게 열림 -> 지금 열기
                if not self.mm_reopen(fighting[0], 0.5):
                    self.sleep(0.1)
                    continue

            if not in_sec_window(t, s_sec, e_sec):
                if self.tm_n:
                    self.log(f"이번 분 {self.tm_n}회 · {self.tm_summary()}")
                    self.tm_reset()
                left = max(s["end"] for s in self.sessions.values()) - t
                wait = until_sec(t, s_sec)
                self.handle_ctl(wait - 1)
                self.status("wait", f"{names} · 다음 {s_sec}초까지 {wait:.0f}초 · "
                                    f"남은 시간 {human(left)}" + (" · 이적시장 닫아 둠" if self._mm_closed else ""))
                if self.shared():                        # v4.0: 매 분 닫고 N초 전에 다시 열기
                    rs = float(self.cfg.get("reopen_sec", 3))
                    if wait > rs + 0.3:
                        self.mm_close()
                    elif self._mm_closed and left > wait:
                        lt = time.time()
                        why = self.arb.reserved(lt, lt + wait + (e_sec - s_sec) % 60 + 2) \
                            if self.cfg.get("share_screen", True) else None
                        if why:
                            self._skip_minute(why)
                        else:
                            self.mm_reopen(fighting[0], rs)
                if wait > 4:
                    self.keep_market()
                self.sleep(min(0.1, max(0.001, wait - 0.003)))
                continue

            i = fighting[rr % len(fighting)]
            rr += 1
            ld = self.sessions[fighting[(rr - 1) % len(fighting)]]["last_diff"] if self.attempts else 0
            self.status("fight", f"{', '.join(self.name(k) for k in fighting)} · 시도 {self.attempts}회 · "
                                 f"마지막 차이 {ld}px (감도 {self.sens}) · {LAYOUT_NAMES.get(self.layout, '')}")
            try:
                self.attempt(i, self.sessions[i])
            except Blocked as e:
                self.block(i, self.sessions[i], e)
            except PresetError as e:
                self.finish(i, "error", str(e))


# ───────────────────────── 화면 지정 오버레이 ─────────────────────────
def pick_on_screen(root, kind, guide):
    root.withdraw()
    root.update()
    time.sleep(0.35)
    with mss.mss() as sct:
        mon = sct.monitors[0]
        shot = sct.grab(mon)
    img = Image.frombytes("RGB", shot.size, shot.bgra, "raw", "BGRX")
    ml, mt, mw, mh = mon["left"], mon["top"], mon["width"], mon["height"]

    top = tk.Toplevel(root)
    top.overrideredirect(True)
    top.attributes("-topmost", True)
    top.geometry(f"{mw}x{mh}{ml:+d}{mt:+d}")
    cv = tk.Canvas(top, width=mw, height=mh, highlightthickness=0, cursor="crosshair")
    cv.pack()
    photo = ImageTk.PhotoImage(img)
    cv.create_image(0, 0, anchor="nw", image=photo)
    cv.photo = photo

    p = wt.POINT()
    user32.GetCursorPos(ctypes.byref(p))
    gx, gy = p.x - ml, max(p.y - mt - 70, 30)
    txt = cv.create_text(gx, gy, text=f"{guide}    (ESC: 취소)", fill="white",
                         font=("맑은 고딕", 13, "bold"))
    bb = cv.bbox(txt)
    box = cv.create_rectangle(bb[0] - 12, bb[1] - 7, bb[2] + 12, bb[3] + 7,
                              fill="#151515", outline="#22c55e", width=2)
    cv.tag_raise(txt)

    st = {"res": None, "start": None, "rect": None}

    def press(ev):
        st["start"] = (ev.x, ev.y)
        cv.itemconfigure(txt, state="hidden")
        cv.itemconfigure(box, state="hidden")

    def drag(ev):
        if kind != "rect" or st["start"] is None:
            return
        x0, y0 = st["start"]
        if st["rect"]:
            cv.coords(st["rect"], x0, y0, ev.x, ev.y)
        else:
            st["rect"] = cv.create_rectangle(x0, y0, ev.x, ev.y, outline="#22c55e", width=2)

    def release(ev):
        if st["start"] is None:
            return
        x0, y0 = st["start"]
        if kind == "point":
            st["res"] = (ev.x + ml, ev.y + mt)
        else:
            w, h = abs(ev.x - x0), abs(ev.y - y0)
            if w < 4 or h < 4:
                if st["rect"]:
                    cv.delete(st["rect"])
                    st["rect"] = None
                st["start"] = None
                cv.itemconfigure(txt, state="normal")
                cv.itemconfigure(box, state="normal")
                return
            st["res"] = (min(x0, ev.x) + ml, min(y0, ev.y) + mt, w, h)
        top.destroy()

    cv.bind("<ButtonPress-1>", press)
    cv.bind("<B1-Motion>", drag)
    cv.bind("<ButtonRelease-1>", release)
    top.bind("<Escape>", lambda ev: top.destroy())
    top.focus_force()
    top.grab_set()
    root.wait_window(top)
    root.deiconify()
    if not st["res"]:
        return None
    return st["res"], img, (ml, mt)


# ───────────────────────── GUI ─────────────────────────
STATES = {
    "idle": ("정지", "#8a8a8a"),
    "armed": ("예약 대기", "#d9a400"),
    "ready": ("준비 중", "#d9a400"),
    "wait": ("대기중", "#e53935"),
    "limit": ("거래 제한 · 경기 대기", "#d97706"),
    "fight": ("갱신싸움중", "#16a34a"),
    "success": ("갱신 성공!", "#1d6fe0"),
    "error": ("멈춤", "#e53935"),
}
PSTATE_COLORS = {"idle": "#999", "armed": "#b38600", "run": "#16a34a", "limit": "#d97706",
                 "success": "#1d6fe0", "timeout": "#777", "error": "#dc2626"}
FONT = "맑은 고딕"


# ───────────────────────── 텔레그램 메뉴 (v3.6) ─────────────────────────
TG_MENU = [["📊 상태", "💰 가격 확인"], ["👥 선수 관리", "🏆 최근 결과"],
           ["📸 지금 화면", "📅 오늘 요약"], ["▶ 예약 시작", "■ 정지"]]
TG_KB = {"keyboard": [[{"text": x} for x in row] for row in TG_MENU], "resize_keyboard": True, "is_persistent": True}


class TgBot(threading.Thread):
    """봇에게 온 메시지·버튼을 받아 프로그램(App)으로 넘김. 답장·조작은 App이 함"""

    def __init__(self, token, q):
        super().__init__(daemon=True)
        self.token = token
        self.q = q
        self.stop_evt = threading.Event()
        self.offset = None
        self.err_noted = False

    def stop(self):
        self.stop_evt.set()

    def run(self):
        try:
            _tg_call(self.token, "deleteWebhook", {}, timeout=15)
        except Exception:
            pass
        try:                    # 켜기 전에 쌓인 옛 메시지는 건너뜀 (예전에 누른 버튼이 한꺼번에 실행되지 않게)
            ups = _tg_call(self.token, "getUpdates", {"timeout": 0, "offset": -1}, timeout=15) or []
            if ups:
                self.offset = ups[-1]["update_id"] + 1
        except Exception:
            pass
        while not self.stop_evt.is_set():
            try:
                f = {"timeout": 25, "allowed_updates": ["message", "callback_query"]}
                if self.offset is not None:
                    f["offset"] = self.offset
                ups = _tg_call(self.token, "getUpdates", f, timeout=40) or []
                self.err_noted = False
            except Exception as e:
                if not self.err_noted and not self.stop_evt.is_set():
                    self.err_noted = True
                    self.q.put(("log", f"텔레그램 메뉴 연결 문제: {e} — 잠시 뒤 다시 시도해요", "warn"))
                self.stop_evt.wait(8)
                continue
            for u in ups:
                self.offset = u["update_id"] + 1
                if not self.stop_evt.is_set():
                    self.q.put(("tg_update", u))


