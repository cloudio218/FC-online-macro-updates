# -*- coding: utf-8 -*-
"""v3.3 쉬는 시간 - 승률이 낮은 시간대에는 판을 시작하지 않고 로비에서 대기했다가 끝나면 자동 재개

단위: 2시간 (00~02, 02~04, …, 22~24시 = 12칸)
  2026-11-16 실제 기록 946판(19일)으로 1·2·3시간 단위를 '하루씩 빼고 검증'한 결과 2시간이 가장 효율적:
   - 1시간: 시간당 30~50판이라 운이 커서 고른 시간이 다른 날엔 효과 없음 (앞·뒤 절반 승률 상관 0.04)
   - 3시간: 몇 시에 끊느냐에 따라 효과가 있다가 없다가 함
   - 2시간: 어디서 끊든 효과, 시간대 승률도 가장 꾸준 (상관 0.27~0.41)
자동 기준: 최근 30일 기록에서 그 시간대 승률이 평균보다 9%p 이상 낮고, 그 시간대 기록이 60판 이상
  (기준값 4~12%p 비교: 7~9%p가 안정 구간, 9%p가 쉬는 시간 대비 효과가 가장 좋음 / 60판이면 운에 따른 흔들림 ±6.4%p)
칸마다 직접 지정: 'rest'(항상 쉼) / 'never'(자동이어도 안 쉼) / 없음(자동에 맡김)
"""
import datetime

BLOCK_H = 2
BLOCKS = 24 // BLOCK_H
DEFAULTS = {'enabled': True, 'auto': True, 'days': 30, 'gap': 9, 'min_games': 60,
            'manual': {}, 'notify': True, 'pre_on': True, 'pre_min': 3}


def cfg_of(raw):
    c = dict(DEFAULTS)
    if isinstance(raw, dict):
        c.update(raw)
    c['manual'] = {str(k): v for k, v in (c.get('manual') or {}).items() if v in ('rest', 'never')}
    return c


def block_of(dt):
    return dt.hour // BLOCK_H


def label(b):
    return '%02d~%02d시' % (b * BLOCK_H, (b + 1) * BLOCK_H)


def stats(games, now, days):
    """games: [(datetime, '승'|'무'|'패'), ...] -> 칸별 {'n','w','d','l','rate'} 목록 + 전체 평균 승률"""
    since = now - datetime.timedelta(days=days)
    out = [{'n': 0, 'w': 0, 'd': 0, 'l': 0, 'rate': None} for _ in range(BLOCKS)]
    tot = w_all = 0
    for dt, r in games:
        if dt is None or r not in ('승', '무', '패') or dt < since or dt > now:
            continue
        s = out[block_of(dt)]
        s['n'] += 1
        s[{'승': 'w', '무': 'd', '패': 'l'}[r]] += 1
        tot += 1
        w_all += r == '승'
    for s in out:
        s['rate'] = s['w'] * 100.0 / s['n'] if s['n'] else None
    return out, (w_all * 100.0 / tot if tot else None), tot


def auto_blocks(st, avg, cfg):
    """자동으로 쉴 칸 (기록 충분 + 평균보다 gap%p 이상 낮음)"""
    if avg is None or not cfg.get('auto'):
        return set()
    return {b for b, s in enumerate(st)
            if s['n'] >= int(cfg['min_games']) and s['rate'] is not None and s['rate'] < avg - float(cfg['gap'])}


def kind(b, cfg, autos):
    """칸 상태: 'rest'(직접 쉼) / 'never'(직접 계속) / 'auto'(자동 쉼) / ''(보통)"""
    m = cfg['manual'].get(str(b))
    if m:
        return m
    return 'auto' if b in autos else ''


def is_rest(b, cfg, autos):
    return bool(cfg.get('enabled')) and kind(b, cfg, autos) in ('rest', 'auto')


def block_start(dt, b=None):
    b = block_of(dt) if b is None else b
    return dt.replace(hour=b * BLOCK_H, minute=0, second=0, microsecond=0)


def window_end(now, cfg, autos):
    """지금 쉬는 시간이면 이어지는 쉬는 칸까지 합쳐 끝나는 시각, 아니면 None (최대 24시간)"""
    if not is_rest(block_of(now), cfg, autos):
        return None
    t = block_start(now)
    for _ in range(BLOCKS):
        t = t + datetime.timedelta(hours=BLOCK_H)
        if not is_rest(block_of(t), cfg, autos):
            return t
    return None                                         # 하루 종일 쉬는 칸 -> 쉬지 않음 (설정 실수 방지)


def next_window(now, cfg, autos):
    """다음 쉬는 시간 (시작, 끝) - 24시간 안에 없으면 None"""
    t = block_start(now)
    for _ in range(BLOCKS):
        t = t + datetime.timedelta(hours=BLOCK_H)
        if is_rest(block_of(t), cfg, autos):
            end = window_end(t, cfg, autos)
            return (t, end) if end else None
    return None


def cycle(cur):
    """칸 누를 때: 보통 -> 쉼 -> 계속 -> 보통"""
    return {'': 'rest', 'auto': 'rest', 'rest': 'never', 'never': ''}.get(cur or '', '')
