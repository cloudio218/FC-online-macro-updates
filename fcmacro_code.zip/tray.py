# -*- coding: utf-8 -*-
"""작업표시줄 트레이 아이콘: 상태 색 점 + 마우스 올리면 현재 상태 + 우클릭 메뉴 (pystray 없으면 조용히 생략)"""
import threading

from PIL import Image, ImageDraw

try:
    import pystray
    AVAILABLE = True
except Exception:
    AVAILABLE = False

DOT = {'run': (61, 220, 132), 'warn': (255, 176, 32), 'stop': (255, 93, 122), 'done': (61, 220, 132),
       'info': (74, 168, 255), 'idle': (130, 130, 140)}

_icon = None
_base = None
_last_kind = None
_lock = threading.Lock()


def _make_image(kind):
    img = _base.copy() if _base is not None else Image.new('RGBA', (64, 64), (40, 30, 80, 255))
    d = ImageDraw.Draw(img)
    s = img.size[0]
    r = int(s * 0.2)
    d.ellipse([s - 2 * r - 1, s - 2 * r - 1, s - 1, s - 1], fill=DOT.get(kind, DOT['idle']) + (255,),
              outline=(20, 20, 24, 255), width=max(1, s // 32))
    return img


def start(icon_path, on_graph, on_stop, on_quit, on_topmost=None, is_topmost=None, on_open_folder=None,
          on_pause=None, is_paused=None):
    """트레이 아이콘 시작. 실패하면 False"""
    global _icon, _base
    if not AVAILABLE:
        return False
    try:
        try:
            _base = Image.open(icon_path).convert('RGBA').resize((64, 64), Image.LANCZOS)
        except Exception:
            _base = None
        menu = pystray.Menu(
            pystray.MenuItem('기록 차트 열기 (F11)', lambda *_: on_graph()),
            pystray.MenuItem('기록 폴더 열기', lambda *_: on_open_folder() if on_open_folder else None),
            pystray.MenuItem('일시정지 (F10)', lambda *_: on_pause() if on_pause else None,
                             checked=lambda item: bool(is_paused and is_paused())),
            pystray.MenuItem('자동진행 종료 (F12)', lambda *_: on_stop()),
            pystray.MenuItem('매크로 창 항상 위 (F6)', lambda *_: on_topmost() if on_topmost else None,
                             checked=lambda item: bool(is_topmost and is_topmost())),
            pystray.Menu.SEPARATOR,
            pystray.MenuItem('매크로 종료', lambda *_: on_quit()),
        )
        _icon = pystray.Icon('fc_macro', _make_image('idle'), 'FC 감독모드 매크로', menu)
        _icon.run_detached()
        return True
    except Exception:
        _icon = None
        return False


def update(kind, tooltip):
    """상태 색/툴팁 갱신 (draw_ui에서 호출)"""
    global _last_kind
    if _icon is None:
        return
    with _lock:
        try:
            if kind != _last_kind:
                _icon.icon = _make_image(kind)
                _last_kind = kind
            _icon.title = tooltip[:120]
        except Exception:
            pass


def stop():
    if _icon is not None:
        try:
            _icon.stop()
        except Exception:
            pass
