# -*- coding: utf-8 -*-
"""디스코드 첨부용 그래프 이미지 (PIL로 그림, 브라우저 불필요). 최근 N개 기록의 랭킹점수·순위."""
import io
import os

from PIL import Image, ImageDraw, ImageFont

W, H = 960, 480
L, R, T, B = 78, 84, 72, 46
BG, PANEL, GRID = (22, 20, 31), (31, 28, 44), (52, 48, 74)
GREEN, BLUE, RED, TXT, SUB = (61, 220, 132), (74, 168, 255), (255, 93, 122), (232, 230, 240), (143, 138, 168)

_FONT_CANDIDATES = [
    r'C:\Windows\Fonts\malgunbd.ttf', r'C:\Windows\Fonts\malgun.ttf',
    '/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc', '/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc',
]


def _font(size):
    for p in _FONT_CANDIDATES:
        if os.path.exists(p):
            try:
                return ImageFont.truetype(p, size)
            except Exception:
                pass
    return ImageFont.load_default()


def _nice_step(span, max_ticks, bases=(1, 2, 5)):
    m = 1
    while True:
        for b in bases:
            if span / (b * m) <= max_ticks:
                return b * m
        m *= 10


def _dashed(d, x0, y, x1, color, dash=10, gap=7, width=2):
    x = x0
    while x < x1:
        d.line([(x, y), (min(x + dash, x1), y)], fill=color, width=width)
        x += dash + gap


def render(records, target=None, title='최근 기록'):
    """records: [(날짜시간, 게임번호, 점수|None, 순위|None, 비고, ...)]  -> PNG 바이트 (기록 없으면 None)"""
    if not records:
        return None
    is_stop = [str(r[1]) == '-' for r in records]
    img = Image.new('RGB', (W, H), BG)
    d = ImageDraw.Draw(img)
    f_title, f_lab, f_big = _font(20), _font(14), _font(18)
    d.rounded_rectangle([10, 10, W - 10, H - 10], 14, fill=PANEL)
    n = len(records)
    scores = [r[2] for r in records]
    known = [v for v in scores if v is not None]
    lo, hi = (min(known), max(known)) if known else (0, 100)
    if target is not None and known:
        lo, hi = min(lo, target), max(hi, target)
    pad = max(20, (hi - lo) * 0.1)
    step = _nice_step((hi - lo) + 2 * pad, 6, (1, 2, 5))
    step = max(step, 10)
    lo = int((lo - pad) // step * step)
    hi = int(-(-(hi + pad) // step) * step)
    pw, ph = W - L - R, H - T - B

    def X(i):
        return L + (pw * i / (n - 1) if n > 1 else pw / 2)

    def Y(v):
        return T + ph - (v - lo) / (hi - lo) * ph

    v = lo
    while v <= hi:
        y = Y(v)
        d.line([(L, y), (W - R, y)], fill=GRID, width=1)
        d.text((L - 8, y), format(v, ','), fill=SUB, font=f_lab, anchor='rm')
        v += step
    if target is not None and known:
        _dashed(d, L, Y(target), W - R, RED)
        d.text((L + 6, Y(target) - 4), '목표 %s' % format(target, ','), fill=RED, font=f_lab, anchor='ld')
    # 순위 (오른쪽 눈금, 위로 갈수록 높은 순위)
    ranks = [r[3] for r in records if r[3] is not None]
    RY = None
    if ranks:
        rlo, rhi = min(ranks), max(ranks)
        rstep = _nice_step(max(rhi - rlo, 1), 6)
        rlo = max(0, (rlo // rstep) * rstep - rstep)
        rhi = (-(-rhi // rstep)) * rstep + rstep

        def RY(v):
            return T + (v - rlo) / (rhi - rlo) * ph
        v = rlo
        while v <= rhi:
            d.text((W - R + 8, RY(v)), '%s위' % format(max(v, 1), ','), fill=BLUE, font=f_lab, anchor='lm')
            v += rstep
        seg = []
        for i, r in enumerate(records):
            if r[3] is None:
                if len(seg) > 1:
                    d.line(seg, fill=BLUE, width=3)
                seg = []
                continue
            seg.append((X(i), RY(r[3])))
        if len(seg) > 1:
            d.line(seg, fill=BLUE, width=3)
        rad = 3 if n <= 60 else 2
        for i, r in enumerate(records):
            if r[3] is not None:
                x, y = X(i), RY(r[3])
                d.ellipse([x - rad, y - rad, x + rad, y + rad], fill=BLUE)
    # 랭킹점수
    pts = [(i, X(i), Y(s)) for i, s in enumerate(scores) if s is not None]
    if len(pts) > 1:
        d.line([(x, y) for _i, x, y in pts], fill=GREEN, width=3, joint='curve')
    rad = 4 if n <= 60 else 2
    for i, x, y in pts:
        c = RED if is_stop[i] else GREEN
        rr = rad + (2 if is_stop[i] else 0)
        d.ellipse([x - rr, y - rr, x + rr, y + rr], fill=c)
    # 승급 ▲ / 강등 ▼
    for i, r in enumerate(records):
        parts = (r[4] or '').split(', ')
        ev = '승급' if '승급' in parts else ('강등' if '강등' in parts else None)
        if not ev:
            continue
        x = X(i)
        y = Y(scores[i]) if scores[i] is not None else T + 10
        c = GREEN if ev == '승급' else RED
        if ev == '승급':
            d.polygon([(x, y - 18), (x - 7, y - 6), (x + 7, y - 6)], fill=c)
        else:
            d.polygon([(x, y - 6), (x - 7, y - 18), (x + 7, y - 18)], fill=c)
    # x 라벨: 날짜가 바뀌는 곳 + 처음/끝
    shown = set()
    for i, r in enumerate(records):
        day = r[0][5:10]
        if i == 0 or day != records[i - 1][0][5:10]:
            d.text((X(i), H - B + 14), day, fill=SUB, font=f_lab, anchor='mm')
            shown.add(i)
    if n - 1 not in shown:
        d.text((X(n - 1), H - B + 14), records[-1][0][11:16], fill=SUB, font=f_lab, anchor='mm')
    # 제목 + 현재값
    d.text((L - 50, 26), title, fill=TXT, font=f_title, anchor='lm')
    last = records[-1]
    cur = ('현재 %s점' % format(known[-1], ',')) if known else '점수 기록 없음'
    if ranks:
        cur += '  ·  %s위' % format(ranks[-1], ',')
    d.text((W - 26, 26), cur, fill=GREEN, font=f_big, anchor='rm')
    d.text((L - 50, 48), '초록 = 랭킹점수(왼쪽)   파랑 = 순위(오른쪽)   빨간 점 = 정지   ▲승급 ▼강등', fill=SUB, font=f_lab, anchor='lm')
    buf = io.BytesIO()
    img.save(buf, 'PNG', optimize=True)
    return buf.getvalue()


# ── v4.3 텔레그램 친구 랭킹 그래프 (하루치) ─────────────────
FR_COLORS = [(245, 185, 66), (61, 220, 132), (199, 125, 255), (255, 127, 110), (94, 224, 208), (255, 209, 102), (160, 160, 255), (255, 154, 213)]
ME_RGB = (74, 168, 255)


def render_friends(series, t0, t1, title='친구 랭킹 · 오늘'):
    """series: [(이름, 나?, 왕관?, [(t초, 점수|None, 결과, 챔스?)])]  t0~t1 시간 범위 -> PNG 바이트 (점이 없으면 None)
    선 = 점수 (챔스 밖·점수 빈 구간은 점선), 점 = 판 (승 꽉 찬 점 · 패 빈 점 · 무 반 점), 오른쪽 끝에 이름·점수"""
    import datetime as _dt
    ser = [(n, me, cr, [p for p in pts if t0 <= p[0] <= t1]) for n, me, cr, pts in series]
    ser = [s for s in ser if any(p[1] is not None for p in s[3])]
    if not ser:
        return None
    WW, HH = 1000, 580
    LL, RR, TT, BB = 70, 170, 66, 64
    img = Image.new('RGB', (WW, HH), BG)
    d = ImageDraw.Draw(img)
    f_title, f_lab, f_name = _font(20), _font(13), _font(15)
    d.rounded_rectangle([10, 10, WW - 10, HH - 10], 14, fill=PANEL)
    d.text((28, 30), title, fill=TXT, font=f_title, anchor='lm')
    d.text((WW - 28, 30), _dt.datetime.fromtimestamp(t1).strftime('%m/%d %H:%M 기준'), fill=SUB, font=f_lab, anchor='rm')
    vals = [p[1] for s in ser for p in s[3] if p[1] is not None]
    lo, hi = min(vals), max(vals)
    pad = max(15, (hi - lo) * 0.08)
    step = max(10, _nice_step((hi - lo) + 2 * pad, 6, (1, 2, 5)))
    lo = int((lo - pad) // step * step)
    hi = int(-(-(hi + pad) // step) * step)
    pw, ph = WW - LL - RR, HH - TT - BB

    def X(t):
        return LL + (t - t0) / max(1.0, (t1 - t0)) * pw

    def Y(v):
        return TT + ph - (v - lo) / max(1, (hi - lo)) * ph
    v = lo
    while v <= hi:
        y = Y(v)
        d.line([(LL, y), (WW - RR, y)], fill=GRID, width=1)
        d.text((LL - 8, y), format(v, ','), fill=SUB, font=f_lab, anchor='rm')
        v += step
    # 시각 눈금: 3시간마다 (짧으면 1시간)
    span_h = (t1 - t0) / 3600.0
    every = 1 if span_h <= 6 else (2 if span_h <= 12 else 3)
    t = _dt.datetime.fromtimestamp(t0).replace(minute=0, second=0, microsecond=0)
    while t.timestamp() <= t1:
        if t.timestamp() >= t0 and t.hour % every == 0:
            x = X(t.timestamp())
            d.line([(x, TT), (x, TT + ph)], fill=(40, 37, 58), width=1)
            d.text((x, HH - BB + 14), '%02d시' % t.hour, fill=SUB, font=f_lab, anchor='mm')
        t += _dt.timedelta(hours=1)
    # 선 (나를 맨 위에 그리게 마지막)
    order = sorted(range(len(ser)), key=lambda i: ser[i][1])
    ci = 0
    colors = {}
    for i in range(len(ser)):
        if ser[i][1]:
            colors[i] = ME_RGB
        else:
            colors[i] = FR_COLORS[ci % len(FR_COLORS)]
            ci += 1
    ends = []
    for i in order:
        name, me, crown, pts = ser[i]
        c = colors[i]
        last = None
        for p in pts:
            if p[1] is None:
                continue
            xy = (X(p[0]), Y(p[1]))
            if last is not None:
                if p[3] and last[1]:
                    d.line([last[0], xy], fill=c, width=4 if me else 3)
                else:
                    x0, y0 = last[0]
                    x1, y1 = xy
                    n = max(2, int(((x1 - x0) ** 2 + (y1 - y0) ** 2) ** 0.5 // 9))
                    for k in range(0, n, 2):
                        a, b = k / n, min(1, (k + 1) / n)
                        d.line([(x0 + (x1 - x0) * a, y0 + (y1 - y0) * a), (x0 + (x1 - x0) * b, y0 + (y1 - y0) * b)], fill=c, width=3)
            last = (xy, p[3])
        for p in pts:
            if p[1] is None:
                continue
            x, y = X(p[0]), Y(p[1])
            r = 4 if me else 3
            if p[2] == '승':
                d.ellipse([x - r, y - r, x + r, y + r], fill=c)
            elif p[2] == '패':
                d.ellipse([x - r, y - r, x + r, y + r], fill=PANEL, outline=c, width=2)
            elif p[2] == '무':
                d.ellipse([x - r, y - r, x + r, y + r], fill=PANEL, outline=c, width=2)
                d.pieslice([x - r, y - r, x + r, y + r], 90, 270, fill=c)
        lastv = [p for p in pts if p[1] is not None][-1]
        ends.append([Y(lastv[1]), name, me, crown, lastv[1], c, X(lastv[0])])
    # 오른쪽 끝 이름 (겹치면 위아래로 벌림)
    ends.sort(key=lambda e: e[0])
    for k in range(1, len(ends)):
        if ends[k][0] - ends[k - 1][0] < 20:
            ends[k][0] = ends[k - 1][0] + 20
    for y, name, me, crown, sc, c, x in ends:
        d.line([(x, y), (WW - RR + 8, y)], fill=c, width=1)
        label = '%s %s' % (name + (' (나)' if me else ''), format(sc, ','))
        d.text((WW - RR + 12, y), label, fill=c, font=f_name, anchor='lm')
    d.text((LL, HH - 22), '선 = 랭킹점수 · ● 승  ○ 패  ◐ 무 · 점선 = 챔스 밖/점수 없음', fill=SUB, font=f_lab, anchor='lm')
    buf = io.BytesIO()
    img.save(buf, 'PNG')
    return buf.getvalue()
