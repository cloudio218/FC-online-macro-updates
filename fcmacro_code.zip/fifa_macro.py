# -*- coding: utf-8 -*-
# FC온라인 감독모드 매크로 v2.0
#  - v0.2(2024-05-31) 원본의 버튼 순서를 그대로 유지한 자동 진행
#  - v1.5: F9 하나로 자동진행(모든 티어·배치 경기) + 매판 기록 + 정지 조건(목표 점수 / 목표 순위 / 종료 시각)
#          F8 설정 변경, F10 일시정지, F11 기록 차트, 화면 1장으로 모든 버튼 인식(빠른 반응)
#  - 기록: 챔스 홈 화면 랭킹점수 + VS 화면 점수·순위, 승급/강등, 연속 진행
#  - v1.6: 디스코드 봇 원격 조작 (!상태 !차트 !정지 !재개 !종료)
#  - v1.7: 연패 경고/자동 일시정지, 하루 결산(자정), !설정 명령, F11 패턴 분석, 이적시장 자동 닫기
#  - v2.0: 실행기(exe) + 코드 패키지 분리 -> GitHub에서 자동 업데이트 (launcher.py)
#  - 단일 exe, 게임 창 영역만 인식, macro.log, 디스코드 알림, 멈춤 감지, 점검(F7), 트레이 아이콘
import keyboard
import threading
import pyautogui
import time
import pydirectinput
import os
import sys
import datetime

import numpy as np
import logging
import logging.handlers
import io
import traceback
import collections

import cv2

import paths
DATA_DIR = paths.data_dir()                 # 문서\FC매크로_기록 (exe 폴더와 분리)
_MIGRATE_MSGS = paths.migrate_old_files(DATA_DIR)
os.chdir(DATA_DIR)                          # 기록/설정/로그는 모두 기록 폴더에 저장
_BACKUP = paths.backup_log(DATA_DIR)

import score_ocr
import score_log
import target_dialog
import notify
import session_stats
import chart_png
import tray
import discord_bot

VERSION = 'v2.0 (2026-11-01)'

# ── 설정 ─────────────────────────────────────────────
SETTINGS = target_dialog.load_settings(4500)   # macro_settings.json (목표 점수·순위, 디스코드 웹훅)
TARGET_SCORE = SETTINGS['target']            # 랭킹점수가 이 점수 '이상'이면 정지 (None = 조건 없음)
TARGET_RANK = SETTINGS['rank']               # 순위가 이 순위 '이내'면 정지 (None = 조건 없음)
LOSE_STREAK = SETTINGS.get('lose_streak')     # N연패면 디스코드 알림 (None = 끔)
LOSE_PAUSE = SETTINGS.get('lose_pause', False)  # 연패 경고 때 일시정지도
DAILY_REPORT = SETTINGS.get('daily_report', False)   # 매일 자정 하루 결산 리포트
MARKET_IDLE_SEC = 60                           # 이적시장 창이 열려 있고 사람 입력이 이 시간(초) 없으면 X로 닫음
PROMO_WAIT = SETTINGS.get('promo_wait', False)   # 챔스 승급 대기: 슈퍼챌린저에서 다음 판 이기면 승급이면 멈추고 자정 지나 재개
PROMO_TIER = '슈퍼챌린저'                      # 챔스 바로 아래 티어
MIDNIGHT_RESUME_SEC = 30                       # 자정 지나 이만큼 뒤에 재개 (00:00:30)
PROMO_GAP = 3                                  # 승점 막대에서 초록 선(승격선)까지 이 점수(칸) 이내면 멈춤 = 다음 판 이기면 승급
PROMO_LINE_FALLBACK = 12                       # 승격선을 못 읽으면 낮은 쪽(12)으로 보고 일찍 멈춤 (자정 전에 올라가는 것 방지)
WEBHOOK = SETTINGS['webhook']                # 디스코드 웹훅 주소 (비어 있으면 알림 안 보냄)
OCR_MAX_FAIL = 3             # 챔스 홈 화면 점수 인식이 연속 이 횟수만큼 실패하면 안전하게 정지
HISTORY_SHOW = 10            # 화면에 보여줄 최근 기록 수
SAME_GAME_SEC = 90           # 공식경기를 눌렀는데 VS 화면 없이 이 시간 안에 홈으로 오면 '클릭 재시도' (판수 안 셈)
SAMPLE_MAX = 100             # 못 읽은 판의 VS 화면 이미지 최대 저장 수 (rank_samples 폴더)
STALL_STATIC_MIN = 10        # 게임 화면이 이 시간(분) 동안 전혀 안 바뀌면 '멈춤' 알림
NO_GAME_MIN = 30             # 이 시간(분) 동안 새 판이 시작되지 않으면 알림
GAME_WINDOW_TITLE = 'FC ONLINE'
GAME_CLIENT_SIZE = (1280, 720)   # 버튼 이미지가 맞춰진 게임 화면 크기
CONT_GRACE_SEC = 120         # 시작 직후 이 시간 안에 뜬 VS 화면은 '연속 진행' 판단에서 제외

# 속도 (v1.5: 원본은 4초마다 확인 + 버튼마다 화면을 새로 찍음)
LOOP_SEC = 0.5               # 화면 확인 주기 (화면 1장으로 모든 버튼을 찾음)
S_LOOP_SEC = 0.3             # 스킵(S) 확인 주기
CLICK_HOVER_SEC = 0.2        # 버튼 위에 마우스를 올린 뒤 누르기까지 (원본 0.5초)
AFTER_CLICK_SEC = 0.8        # 클릭 후 화면이 바뀔 때까지 다음 동작 대기
SAME_BUTTON_SEC = 2.5        # 같은 버튼을 이 시간 안에 다시 누르지 않음 (화면 전환 중 두 번 클릭 방지)
VS_HOLD_SEC = 6              # VS 화면에서 점수·순위를 읽을 때까지 진행 버튼을 누르지 않고 기다리는 최대 시간
VS_READ_FAILS = 10           # VS 화면 글씨가 보이는데 이만큼 못 읽으면 그 판은 빈칸 (이미지 저장)
SCORE_JUMP_MAX = 300         # VS 점수가 직전 판보다 이만큼 넘게 다르면 잘못 읽은 것으로 보고 버림
TIER_DX, TIER_DY, TIER_W, TIER_H = -790, -478, 250, 46   # 홈 화면 티어명('마스터 3부 감독') 영역 (공식경기 버튼 기준)
TIER_SAMPLE_MAX = 60

# ── 실행 로그 (macro.log, 1MB씩 최대 3개) ─────────────────
LOG = logging.getLogger('macro')
LOG.setLevel(logging.INFO)
try:
    _h = logging.handlers.RotatingFileHandler('macro.log', maxBytes=1_000_000, backupCount=2, encoding='utf-8')
    _h.setFormatter(logging.Formatter('%(asctime)s %(levelname)-7s %(message)s', '%Y-%m-%d %H:%M:%S'))
    LOG.addHandler(_h)
except Exception:
    pass
last_error = ''              # 콘솔 표시용 마지막 오류
for _m in _MIGRATE_MSGS:
    LOG.info('기록 이전: %s', _m)
if _BACKUP:
    LOG.info('기록 백업: %s', _BACKUP)


def set_interval(func, sec):
    def func_wrapper():
        set_interval(func, sec)
        try:
            func()
        except Exception:
            note_error(func.__name__)
    t = threading.Timer(sec, func_wrapper)
    t.daemon = True          # 매크로 종료 시 타이머가 프로그램을 붙잡지 않게
    try:
        t.start()
    except RuntimeError:     # 종료 중이면 다음 예약을 조용히 생략
        return None
    return t


is_manager_mode = False      # 자동진행 중 (F9 시작 ~ F12/정지 조건)
is_paused = False            # F10 일시정지 (클릭·S키 입력 모두 멈춤, 기록은 유지)

# 진행 기록 (F9 시작 때 초기화, 멈춰도 화면에는 남김)
# champions_history 한 줄: [게임번호, 점수|None, 'HH:MM:SS', 순위|None, epoch초, 비고, 기록시각(ts), 결과('승'/'무'/'패'|None), 챔스 여부]
H_NO, H_SCORE, H_TIME, H_RANK, H_EPOCH, H_NOTE, H_TS, H_RES, H_CHAMP = range(9)
champions_game_count = 0
champions_history = []
champions_status = ''
champions_status_kind = 'info'   # run / warn / stop / done / info  (콘솔 색)
champions_fail_count = 0
champions_last_game_time = 0.0  # 마지막으로 판수를 센 시각
champions_session_start = 0.0
champions_final_score = None    # 정지 시점에 읽은 점수 (마지막 판 결과 확정용)
end_stop_at = None              # 종료 시각(epoch) 이후 새 판 시작 안 함 (None = 없음)
end_stop_label = ''
end_stop_text = None            # 설정창에 다시 보여줄 'HH:MM'
last_rank = None                # 이번 세션에서 가장 최근에 읽은 내 순위 (목표 순위 판단)
last_known_score = None         # 가장 최근에 읽은 내 점수 (VS 점수 오인 걸러내기)
wait_until = None               # 이 시각(epoch)까지 대기 (시작 예약 / 챔스 승급 대기)
wait_reason = ''                # 'start' / 'promo'
wait_info = ''                  # 화면 표시용 설명
start_text = None               # 설정창에 다시 보여줄 시작 시각 'HH:MM'
promo_released_date = None      # 자정 재개한 날 (그날은 승급 대기를 다시 걸지 않음)
strip_last = None               # 마지막으로 읽은 결과 칸 ['승','패',...] (챔스 아래 티어 승/무/패 판정)

# VS 화면
vs_visible = False
vs_expect = False               # 공식경기를 눌렀고 아직 VS 화면을 못 봄
vs_seen_at = 0.0
vs_warned = False
cont_count = 0
vs_pending = None               # 점수·순위를 아직 못 읽은 판

# 티어 변화 (홈 화면 티어명 글씨 비교)
tier_last_mask = None
tier_last_champ = None
popup_hint = None               # 승급/강등 확인 팝업을 누른 경우 그 이름 (방향 참고)

loop_lock = threading.Lock()  # main_loop가 길어져도 동시에 두 번 돌지 않게 함
draw_lock = threading.Lock()
notify_status = ''           # 마지막 디스코드 전송 결과 (콘솔 표시용)
check_lines = []             # [(True/False/None, 문구)] 점검 결과 (F7)
always_on_top = bool(target_dialog.get_option('topmost', False))   # F6: 매크로 창 항상 위
_last_click = {}             # 버튼별 마지막 클릭 시각
_next_action_at = [0.0]      # 클릭 직후 화면이 바뀔 때까지 대기

# ── 콘솔 색 (Windows 10 이상 콘솔/터미널) ─────────────────
if os.name == 'nt':
    os.system('')            # 콘솔 색상 코드(VT) 사용 켜기
C = {'reset': '\x1b[0m', 'g': '\x1b[92m', 'y': '\x1b[93m', 'r': '\x1b[91m', 'c': '\x1b[96m',
     'b': '\x1b[94m', 'dim': '\x1b[90m', 'bold': '\x1b[1m', 'm': '\x1b[95m'}
KIND_COLOR = {'run': C['g'], 'warn': C['y'], 'stop': C['r'], 'done': C['bold'] + C['g'], 'info': C['c']}


def col(text, key):
    return C[key] + text + C['reset']


_err_seen = {}   # 같은 오류 반복 시 로그 폭주 방지: {(위치, 오류 마지막 줄): [처음 기록 시각, 이후 반복 횟수]}


def note_error(where):
    """반복 작업 중 예외: 로그에 전체 내용 기록(같은 오류는 10분에 한 번만), 콘솔에는 한 줄 표시 (매크로는 계속 동작)"""
    global last_error
    tb = traceback.format_exc()
    key = (where, tb.strip().splitlines()[-1] if tb.strip() else '')
    now = time.time()
    rec = _err_seen.get(key)
    if rec is None or now - rec[0] >= 600:
        extra = (' (지난 기록 이후 %d번 더 반복됨)' % rec[1]) if rec and rec[1] else ''
        LOG.error('%s 오류%s\n%s', where, extra, tb)
        _err_seen[key] = [now, 0]
    else:
        rec[1] += 1
    last_error = '%s 오류 발생 [%s] - macro.log 참고' % (where, time.strftime('%H:%M:%S'))


def set_status(text, kind='info'):
    global champions_status, champions_status_kind
    if text != champions_status:
        (LOG.warning if kind in ('warn', 'stop') else LOG.info)('상태: %s', text)
    champions_status = text
    champions_status_kind = kind


def current_stats():
    return session_stats.compute(champions_history, TARGET_SCORE, champions_final_score)


def fmt_num(v, unit=''):
    return '-' if v is None else format(v, ',') + unit


def stop_conditions_text():
    parts = []
    if TARGET_SCORE is not None:
        parts.append('점수 %s점 이상' % format(TARGET_SCORE, ','))
    if TARGET_RANK is not None:
        parts.append('순위 %s위 이내' % format(TARGET_RANK, ','))
    if PROMO_WAIT:
        parts.append('챔스 승급 대기(자정 재개)')
    if LOSE_STREAK:
        parts.append('%d연패 %s' % (LOSE_STREAK, '일시정지' if LOSE_PAUSE else '알림'))
    if end_stop_at and is_manager_mode:
        parts.append('%s 이후' % end_stop_label)
    elif end_stop_text and not is_manager_mode:
        parts.append('%s 이후' % end_stop_text)
    return ' / '.join(parts) if parts else '없음 (계속 진행)'


def draw_ui():
    L = []
    L.append(col('FC온라인 감독모드 매크로 - ' + VERSION, 'c'))
    L.append(col('-' * 60, 'dim'))
    L.append('F6  - 매크로 창 항상 위 (지금: %s)' % ('켜짐' if always_on_top else '꺼짐'))
    L.append('F7  - 점검 / 화면 인식 테스트')
    L.append('F8  - 설정 변경 (진행 중이면 기록 유지)')
    L.append('F9  - 자동진행 시작 (설정창)')
    L.append('F10 - 일시정지 / 재개')
    L.append('F11 - 기록 차트 (랭킹점수·순위·승급/강등)')
    L.append('F12 - 자동진행 종료')
    L.append(col('기록 폴더: ' + DATA_DIR, 'dim'))
    L.append(col('-' * 60, 'dim'))
    L.append('')
    if is_manager_mode and is_paused:
        L.append(col('❚❚ 일시정지 중 - F10으로 재개 (버튼 클릭·S키 입력 멈춤, 기록은 이어짐)', 'y'))
    elif is_manager_mode and wait_until is not None:
        left = max(0, wait_until - time.time())
        L.append(col('⏳ 대기 중 - %s · %s에 자동 %s (남은 시간 %s)' % (
            wait_info, time.strftime('%H:%M', time.localtime(wait_until)), '시작' if wait_reason == 'start' else '재개',
            session_stats.fmt_minutes(left / 60)), 'y'))
    elif is_manager_mode:
        L.append(col('● 자동진행 중', 'g'))
    else:
        L.append(col('○ 대기 중 - F9로 시작', 'dim'))
    L.append('  정지 조건: ' + stop_conditions_text())
    if last_error:
        L.append(col('  ! ' + last_error, 'y'))
    if check_lines and not is_manager_mode:
        L.append('')
        L.append(col('[점검]', 'bold') + col('  (F7로 다시 점검)', 'dim'))
        for ok, text in check_lines:
            mark = col('  ✔ ', 'g') if ok is True else (col('  ✖ ', 'r') if ok is False else col('  · ', 'dim'))
            L.append(mark + text)
    if champions_status or champions_history:
        L.append('')
        L.append(col('[진행 기록]', 'bold'))
        if champions_status:
            L.append('  상태  : ' + KIND_COLOR.get(champions_status_kind, '') + champions_status + C['reset'])
        st = current_stats()
        if tier_now or tier_last_mask is not None or tier_events:
            t = tier_now or col('이름 미등록 (기록 폴더\\tier_samples 의 이름없음 파일 이름을 바꿔 주세요)', 'dim')
            ups = sum(1 for _t, e in tier_events if e == '승급')
            dns = sum(1 for _t, e in tier_events if e == '강등')
            ev = ''
            if tier_events:
                lt, le = tier_events[-1]
                ev = ' · ' + col('▲승급 %d' % ups, 'g') + ' ' + col('▼강등 %d' % dns, 'r') + \
                    col(' (마지막: %s %s%s)' % (lt, {'승급': '▲', '강등': '▼'}.get(le, '◆'), le), 'dim')
            L.append('  티어  : ' + t + ev)
        L.append('  통계  : ' + session_stats.summary_line(st))
        td = today_summary()
        if td:
            L.append('  오늘  : ' + td['line'])
            if td['flow']:
                L.append('  흐름  : ' + ' '.join(col(r, {'승': 'g', '무': 'y', '패': 'r'}[r]) for r in td['flow'])
                         + col('  (최근 %d판 · %s)' % (len(td['flow']), td['streak']), 'dim'))
        if TARGET_SCORE is not None:
            L.append('  예상  : ' + col(session_stats.eta_line(st, TARGET_SCORE), 'm'))
        L.append('  알림  : ' + ((col('디스코드 켜짐', 'g') + (col('  (' + notify_status + ')', 'dim') if notify_status else ''))
                                if WEBHOOK else col('디스코드 꺼짐 (F8 설정창에서 웹훅 입력)', 'dim')))
        if BOT is not None:
            L.append('  봇    : ' + col(BOT.status, 'g' if BOT.ok else ('r' if BOT.ok is False else 'dim')))
        if champions_history:
            L.append(col('  ---- 최근 기록 ----', 'dim'))
            hist = champions_history
            for i in range(len(hist) - 1, max(-1, len(hist) - 1 - HISTORY_SHOW), -1):
                h = hist[i]
                s = h[H_SCORE]
                nxt = hist[i + 1][H_SCORE] if i + 1 < len(hist) else champions_final_score
                d = (nxt - s) if (s is not None and nxt is not None) else None
                ds = (' %+d' % d) if d is not None else ''
                if h[H_RES]:
                    res = col(' ' + h[H_RES] + ds, {'승': 'g', '무': 'y', '패': 'r'}[h[H_RES]])
                elif i == len(hist) - 1 and is_manager_mode:
                    res = col(' 진행중', 'dim')
                else:
                    res = '      '
                note = col(' ' + h[H_NOTE], 'm') if h[H_NOTE] else ''
                L.append('  %4d번째 | %7s점 | %9s | %s |%s%s'
                         % (h[H_NO], fmt_num(s), rank_text(h[H_RANK]), h[H_TIME], res, note))
    _last_lines[0] = L
    out = '\x1b[H' + '\n'.join(line + '\x1b[K' for line in L) + '\n\x1b[J'
    with draw_lock:
        print(out, end='', flush=True)
    update_title_and_tray()


_last_lines = [[]]
_ANSI = __import__('re').compile(r'\x1b\[[0-9;]*[A-Za-z]')


# ── 디스코드 봇 (원격 조작) ───────────────────────────
BOT = None


def bot_status_lines():
    """매크로 창 내용(메뉴 제외)을 글자만 뽑아서"""
    draw_ui()
    plain = [_ANSI.sub('', l).rstrip() for l in _last_lines[0]]
    seps = [i for i, l in enumerate(plain) if l.startswith('-----')]
    body = plain[seps[1] + 1:] if len(seps) >= 2 else plain
    return [l for l in body if l.strip() and not l.strip().startswith('봇 ')][:30]


def _cmd_status(_args):
    return {'title': '📋 지금 상황 [%s]' % time.strftime('%H:%M:%S'), 'lines': ['```'] + bot_status_lines() + ['```'],
            'kind': 'warn' if is_paused or wait_until else ('done' if is_manager_mode else 'info'),
            'image_fn': grab_game_jpeg, 'image_name': 'screen.jpg'}


def _cmd_chart(_args):
    recs = score_log.read_records()
    if not recs:
        return {'title': '아직 기록이 없습니다', 'kind': 'info'}
    return {'title': '📈 최근 기록 (최대 40판)', 'lines': [session_stats.summary_line(current_stats())],
            'image_fn': lambda: chart_png_bytes('최근 기록 (최대 40개)'), 'image_name': 'chart.png'}


def _cmd_pause(_args):
    if not is_manager_mode:
        return {'title': '자동진행 중이 아닙니다', 'kind': 'info'}
    if is_paused:
        return {'title': '이미 일시정지 중입니다', 'lines': ['!재개 로 다시 진행'], 'kind': 'warn'}
    on_press_f10(None)
    return {'title': '❚❚ 일시정지했습니다', 'lines': ['!재개 로 다시 진행'], 'kind': 'warn'}


def _cmd_resume(_args):
    if not is_manager_mode:
        return {'title': '자동진행 중이 아닙니다', 'lines': ['종료된 상태에서는 PC에서 F9로 시작해 주세요'], 'kind': 'info'}
    if not is_paused:
        extra = ['지금은 %s · %s에 자동 %s' % (wait_info, time.strftime('%H:%M', time.localtime(wait_until)),
                 '시작' if wait_reason == 'start' else '재개')] if wait_until else []
        return {'title': '일시정지 상태가 아닙니다', 'lines': extra, 'kind': 'info'}
    on_press_f10(None)
    return {'title': '▶ 다시 진행합니다', 'kind': 'done'}


def _cmd_stop(_args):
    if not is_manager_mode:
        return {'title': '이미 멈춰 있습니다', 'kind': 'info'}
    on_press_f12(None)
    return {'title': '⏹ 자동진행을 종료했습니다', 'lines': ['다시 시작은 PC에서 F9'], 'kind': 'stop'}


# ── 하루 결산 ───────────────────────────────────────
def day_summary(day):
    """day(date)의 기록 요약 -> (제목, 줄 목록, 그날 기록) / 기록 없으면 (None, [], [])"""
    key = day.strftime('%Y-%m-%d')
    recs = [r for r in score_log.read_records() if r[0].startswith(key)]
    games = [r for r in recs if not score_log.is_stop_row(r)]
    if not games:
        return None, [], recs
    res = [r[5] for r in games if r[5] in ('승', '무', '패')]
    w, d, l = res.count('승'), res.count('무'), res.count('패')
    known = [r[2] for r in recs if r[2] is not None]
    ranks = [r[3] for r in recs if r[3] is not None]
    notes = [p for r in games for p in (r[4] or '').split(', ')]
    best_w = best_l = cur = 0
    last = None
    for x in res:
        cur = cur + 1 if x == last else 1
        last = x
        if x == '승':
            best_w = max(best_w, cur)
        elif x == '패':
            best_l = max(best_l, cur)
    lines = ['🎮 %d판 · %d승 %d무 %d패%s' % (len(games), w, d, l, (' (승률 %d%%)' % round(w * 100 / len(res))) if res else '')]
    if known:
        lines.append('📈 랭킹점수 %s → %s (%+d) · 최고 %s / 최저 %s' % (format(known[0], ','), format(known[-1], ','),
                     known[-1] - known[0], format(max(known), ','), format(min(known), ',')))
    if ranks:
        lines.append('🏅 순위 %s위 → %s위 · 최고 %s위' % (format(ranks[0], ','), format(ranks[-1], ','), format(min(ranks), ',')))
    if notes.count('승급') or notes.count('강등'):
        lines.append('🔺 승급 %d번 · 🔻 강등 %d번' % (notes.count('승급'), notes.count('강등')))
    if res:
        lines.append('🔁 최장 연승 %d · 최장 연패 %d' % (best_w, best_l))
    lines.append('⏱ %s ~ %s' % (games[0][0][11:16], recs[-1][0][11:16]))
    title = '📅 %s 결산' % ('%d/%d(%s)' % (day.month, day.day, '월화수목금토일'[day.weekday()]))
    return title, lines, recs


def daily_report_check():
    """자정이 지나면 전날 결산을 한 번 보냄 (설정에서 켰을 때)"""
    if not (DAILY_REPORT and WEBHOOK):
        return
    yesterday = datetime.date.today() - datetime.timedelta(days=1)
    if target_dialog.get_option('daily_last') == yesterday.isoformat():
        return
    target_dialog.set_option('daily_last', yesterday.isoformat())
    title, lines, recs = day_summary(yesterday)
    if title is None:
        LOG.info('하루 결산: %s 기록 없음 - 보내지 않음', yesterday)
        return
    LOG.info('하루 결산 전송: %s', yesterday)
    notify.send(WEBHOOK, title, lines, 'info', on_done=_notify_done,
                image_fn=lambda: chart_png.render(recs[-60:], TARGET_SCORE, '%s 기록' % yesterday.strftime('%m/%d')),
                image_name='day.png')


def _cmd_day(args):
    day = datetime.date.today() - datetime.timedelta(days=1) if args.strip() == '어제' else datetime.date.today()
    title, lines, recs = day_summary(day)
    if title is None:
        return {'title': '%s 기록이 없습니다' % ('어제' if args.strip() == '어제' else '오늘'), 'kind': 'info'}
    return {'title': title + ('' if args.strip() == '어제' else ' (지금까지)'), 'lines': lines, 'kind': 'info',
            'image_fn': lambda: chart_png.render(recs[-60:], TARGET_SCORE, day.strftime('%m/%d 기록')), 'image_name': 'day.png'}


# ── !설정 (디스코드에서 설정 바꾸기) ─────────────────────────
SET_HELP = ['!설정 → 지금 설정 보기',
            '!설정 점수 4500 / 없음      목표 점수', '!설정 순위 20 / 없음        목표 순위',
            '!설정 종료 07:00 / 없음     종료 시각', '!설정 연패 5 / 없음         연패 경고',
            '!설정 연패정지 켜기/끄기    연패 때 일시정지', '!설정 대기 켜기/끄기        챔스 승급 대기',
            '!설정 결산 켜기/끄기        하루 결산 리포트']
_OFF = ('없음', '끄기', '꺼', 'off', '0', '-')
_ON = ('켜기', '켜', 'on', '1')


def settings_lines():
    return ['목표 점수: %s' % target_text_or('점', TARGET_SCORE), '목표 순위: %s' % target_text_or('위', TARGET_RANK),
            '종료 시각: %s' % (end_stop_label if (is_manager_mode and end_stop_at) else (end_stop_text or '없음')),
            '연패 경고: %s' % (('%d연패 %s' % (LOSE_STREAK, '+ 일시정지' if LOSE_PAUSE else '알림')) if LOSE_STREAK else '끔'),
            '챔스 승급 대기: %s' % ('켜짐' if PROMO_WAIT else '끔'), '하루 결산: %s' % ('켜짐' if DAILY_REPORT else '끔')]


def target_text_or(unit, v):
    return '없음' if v is None else format(v, ',') + unit


def _cmd_settings(args):
    global TARGET_SCORE, TARGET_RANK, PROMO_WAIT, end_stop_text
    parts = args.split()
    if not parts:
        return {'title': '⚙ 지금 설정', 'lines': settings_lines() + ['', '바꾸기: !설정 도움'], 'kind': 'info'}
    key, val = parts[0], ' '.join(parts[1:]).strip()
    off = val.lower() in _OFF
    on = val.lower() in _ON
    if key in ('점수', '목표점수'):
        v = None if off else target_dialog.parse_target(val)
        if v is None and not off:
            return {'title': '숫자로 입력해 주세요', 'lines': ['예: !설정 점수 4500  /  !설정 점수 없음'], 'kind': 'warn'}
        TARGET_SCORE = v
    elif key in ('순위', '목표순위'):
        v = None if off else target_dialog.parse_rank(val)
        if v is None and not off:
            return {'title': '숫자로 입력해 주세요', 'lines': ['예: !설정 순위 20  /  !설정 순위 없음'], 'kind': 'warn'}
        TARGET_RANK = v
    elif key in ('종료', '종료시각'):
        st, hhmm = target_dialog.parse_stop_time('' if off else val)
        if st != 'ok':
            return {'title': '시각 형식이 아닙니다', 'lines': ['예: !설정 종료 07:00  /  !설정 종료 없음'], 'kind': 'warn'}
        if is_manager_mode:
            set_end_time(hhmm)
        else:
            end_stop_text = hhmm
    elif key == '연패':
        v = None if off else target_dialog.parse_streak(val)
        if v is None and not off:
            return {'title': '2~30 사이 숫자로 입력해 주세요', 'lines': ['예: !설정 연패 5  /  !설정 연패 없음'], 'kind': 'warn'}
        set_extra_options(v, LOSE_PAUSE, DAILY_REPORT)
    elif key in ('연패정지', '대기', '승급대기', '결산') and (on or off):
        if key == '연패정지':
            set_extra_options(LOSE_STREAK, on, DAILY_REPORT)
        elif key == '결산':
            set_extra_options(LOSE_STREAK, LOSE_PAUSE, on)
        else:
            PROMO_WAIT = on
            if not on and wait_reason == 'promo':
                end_wait()
    else:
        return {'title': '설정 명령', 'lines': SET_HELP, 'kind': 'info'}
    target_dialog.save_settings(TARGET_SCORE, WEBHOOK, TARGET_RANK, PROMO_WAIT)
    LOG.info('디스코드에서 설정 변경: %s %s', key, val)
    set_status('디스코드에서 설정 변경됨 - 정지 조건: %s [%s]' % (stop_conditions_text(), time.strftime('%H:%M:%S')), 'info')
    draw_ui()
    return {'title': '✅ 설정을 바꿨습니다', 'lines': settings_lines(), 'kind': 'done'}


BOT_HANDLERS = {'상태': _cmd_status, '차트': _cmd_chart, '정지': _cmd_pause, '일시정지': _cmd_pause,
                '재개': _cmd_resume, '종료': _cmd_stop, '설정': _cmd_settings, '결산': _cmd_day, '오늘': _cmd_day}


def start_bot():
    """봇 토큰이 있으면 (다시) 시작"""
    global BOT
    if BOT is not None:
        BOT.stop()
        BOT = None
    token = target_dialog.get_option('bot_token', '') or ''
    if not token.strip():
        return
    BOT = discord_bot.Bot(token, WEBHOOK, target_dialog.get_option('bot_owner'), BOT_HANDLERS,
                          on_owner=lambda uid, name: target_dialog.set_option('bot_owner', uid),
                          log=lambda m: LOG.info(m))
    BOT.start()


_today_cache = {'key': None, 'val': None}


def today_summary():
    """오늘 기록(ranking_log.csv) 누적: 판수·승무패·승률·점수 변화·승급/강등 + 최근 20판 결과 흐름. 파일이 바뀔 때만 다시 계산"""
    try:
        st = os.stat(score_log.LOG_FILE)
        key = (st.st_mtime, st.st_size, datetime.date.today())
    except OSError:
        return None
    if _today_cache['key'] == key:
        return _today_cache['val']
    val = None
    try:
        day = datetime.date.today().strftime('%Y-%m-%d')
        recs = [r for r in score_log.read_records() if r[0].startswith(day)]
        games = [r for r in recs if not score_log.is_stop_row(r)]
        if games:
            res = [r[5] for r in games if r[5] in ('승', '무', '패')]
            w, d, l = res.count('승'), res.count('무'), res.count('패')
            known = [r[2] for r in recs if r[2] is not None]
            notes = [p for r in games for p in (r[4] or '').split(', ')]
            line = '%d판' % len(games)
            if res:
                line += ' · %d승 %d무 %d패 (승률 %d%%)' % (w, d, l, round(w * 100 / len(res)))
            if len(known) >= 2:
                line += ' · %+d점' % (known[-1] - known[0])
            if notes.count('승급') or notes.count('강등'):
                line += ' · ▲승급 %d ▼강등 %d' % (notes.count('승급'), notes.count('강등'))
            val = {'line': line, 'flow': res[-20:], 'streak': session_stats.streak_text(res)}
    except Exception:
        note_error('오늘 기록 요약')
    _today_cache['key'], _today_cache['val'] = key, val
    return val


def short_status():
    """작업표시줄 제목/트레이 툴팁용 한 줄"""
    if is_manager_mode and is_paused:
        return '일시정지 · %d판' % champions_game_count, 'warn'
    if is_manager_mode:
        s = '자동진행 중 · %d판' % champions_game_count
        last = next((h[H_SCORE] for h in reversed(champions_history) if h[H_SCORE] is not None), None)
        if last is not None:
            s += ' · %s점' % format(last, ',')
        return s, ('warn' if champions_status_kind == 'warn' else 'run')
    if champions_status:
        return '정지 · ' + champions_status[:60], champions_status_kind
    return '대기 중', 'idle'


def update_title_and_tray():
    text, kind = short_status()
    if os.name == 'nt':
        try:
            import ctypes
            ctypes.windll.kernel32.SetConsoleTitleW('FC 매크로 · ' + text)
        except Exception:
            pass
    tray.update(kind, 'FC 매크로 · ' + text)


def rank_text(r):
    if r is None:
        return '-'
    return format(r, ',') + '위'


# ── 디스코드 알림 ─────────────────────────────────────
def _notify_done(ok, msg):
    global notify_status
    now = time.strftime('%H:%M')
    notify_status = ('마지막 알림 전송 성공 ' + now) if ok else ('마지막 알림 전송 실패 ' + now + ' - ' + msg)
    (LOG.info if ok else LOG.warning)('디스코드 알림: %s', 'OK' if ok else msg)
    draw_ui()


def grab_game_jpeg():
    """게임 창(없으면 전체 화면) 캡처 -> JPEG 바이트"""
    reg = game_region()
    shot = pyautogui.screenshot(region=reg) if reg else pyautogui.screenshot()
    buf = io.BytesIO()
    shot.convert('RGB').save(buf, 'JPEG', quality=82)
    return buf.getvalue()


def chart_png_bytes(title):
    return chart_png.render(score_log.read_records()[-40:], TARGET_SCORE, title)


def alert(kind, title, extra=(), image=None):
    """디스코드로 알림 (웹훅이 없으면 아무것도 안 함). image: 'screen'=게임 화면 / 'chart'=그래프"""
    LOG.info('알림: %s', title)
    if not WEBHOOK:
        return
    st = current_stats()
    lines = list(extra)
    if champions_history or champions_final_score is not None:
        lines += ['', '📊 ' + session_stats.summary_line(st)]
        if TARGET_SCORE is not None:
            lines.append('🎯 ' + session_stats.eta_line(st, TARGET_SCORE))
        if last_rank is not None:
            lines.append('🏅 최근 순위 %s위' % format(last_rank, ','))
    if image == 'screen':
        notify.send(WEBHOOK, title, lines, kind, on_done=_notify_done, image_fn=grab_game_jpeg, image_name='screen.jpg')
    elif image == 'chart':
        notify.send(WEBHOOK, title, lines, kind, on_done=_notify_done,
                    image_fn=lambda: chart_png_bytes('최근 기록 (최대 40개)'), image_name='chart.png')
    else:
        notify.send(WEBHOOK, title, lines, kind, on_done=_notify_done)


# ── 단축키 ───────────────────────────────────────────
settings_dialog_open = False


def on_press_f8(_):
    """설정 변경: 진행 중이면 [적용](기록 유지), 멈춰 있으면 [저장]"""
    open_settings('apply' if is_manager_mode else 'save')


def on_press_f9(_):
    """자동진행 시작: 설정창 -> [시작]"""
    LOG.info('F9 - 자동진행 시작 요청')
    if is_manager_mode:
        set_status('이미 자동진행 중 - F9 무시됨 (설정 변경은 F8, 일시정지는 F10) [%s]' % time.strftime('%H:%M:%S'), 'warn')
        draw_ui()
        return
    open_settings('start')


def open_settings(mode):
    """설정창을 띄움 (키보드 감지 스레드를 막지 않도록 별도 스레드). 이미 떠 있으면 무시"""
    global settings_dialog_open
    if settings_dialog_open:
        return
    settings_dialog_open = True
    threading.Thread(target=_settings_thread, args=(mode,), daemon=True).start()


def _test_send(url):
    return notify.send_now(url, '✅ FC 매크로 알림 테스트',
                           ['이 메시지가 보이면 디스코드 알림이 정상입니다.',
                            '주차 완료 / 종료 시각 / 승급·강등 / 오류 정지 / 멈춤 감지 때 알림이 옵니다.'], 'info')


def _settings_thread(mode):
    global settings_dialog_open, TARGET_SCORE, TARGET_RANK, WEBHOOK, end_stop_text, PROMO_WAIT, start_text
    try:
        v = target_dialog.ask_settings({'target': TARGET_SCORE, 'rank': TARGET_RANK, 'webhook': WEBHOOK, 'promo_wait': PROMO_WAIT,
                                        'bot_token': target_dialog.get_option('bot_token', '') or '',
                                        'lose_streak': LOSE_STREAK, 'lose_pause': LOSE_PAUSE, 'daily_report': DAILY_REPORT,
                                        'stop_at': end_stop_text if is_manager_mode else None,
                                        'start_at': start_text if (is_manager_mode and wait_reason == 'start') else None},
                                       focus_click=lambda x, y: pyautogui.click(x, y),
                                       test_send=_test_send, mode=mode)
    except Exception as e:
        v = None
        set_status('설정창 오류: %s' % e, 'stop')
    finally:
        settings_dialog_open = False
    if v is None:          # Esc/취소 -> 아무것도 바꾸지 않음
        draw_ui()
        return
    old_hook, old_token = WEBHOOK, target_dialog.get_option('bot_token', '') or ''
    TARGET_SCORE, TARGET_RANK, WEBHOOK = v['target'], v.get('rank'), v['webhook']
    PROMO_WAIT = bool(v.get('promo_wait'))
    target_dialog.save_settings(TARGET_SCORE, WEBHOOK, TARGET_RANK, PROMO_WAIT)
    set_extra_options(v.get('lose_streak'), v.get('lose_pause', False), v.get('daily_report', False))
    if v.get('bot_token', old_token) != old_token or (WEBHOOK != old_hook and v.get('bot_token')):
        target_dialog.set_option('bot_token', v.get('bot_token', ''))
        start_bot()                                    # 토큰/웹훅이 바뀌면 봇 다시 연결
    if mode == 'start' and not is_manager_mode:
        start_session(v.get('stop_at'), v.get('start_at'))
    elif is_manager_mode:
        set_end_time(v.get('stop_at'))
        if wait_reason == 'start' or v.get('start_at'):
            set_start_wait(v.get('start_at'))      # 아직 시작 전이면 시작 시각 변경 (비우면 바로 시작)
        if wait_reason == 'promo' and not PROMO_WAIT:
            end_wait()                             # 승급 대기를 끄면 바로 재개
        LOG.info('설정 변경 (진행 중) - %s', stop_conditions_text())
        set_status('설정 적용됨 - 정지 조건: %s [%s]' % (stop_conditions_text(), time.strftime('%H:%M:%S')), 'run')
        draw_ui()
    else:
        end_stop_text = v.get('stop_at')
        set_status('설정 저장됨 - F9로 시작하면 적용됩니다 [%s]' % time.strftime('%H:%M:%S'), 'info')
        draw_ui()


def set_extra_options(lose_streak, lose_pause, daily_report):
    """연패 경고 / 하루 결산 설정 저장 (결산을 새로 켜면 다음 자정부터 보냄)"""
    global LOSE_STREAK, LOSE_PAUSE, DAILY_REPORT
    if daily_report and not DAILY_REPORT:
        target_dialog.set_option('daily_last', (datetime.date.today() - datetime.timedelta(days=1)).isoformat())
    LOSE_STREAK, LOSE_PAUSE, DAILY_REPORT = lose_streak, bool(lose_pause), bool(daily_report)
    target_dialog.set_option('lose_streak', LOSE_STREAK)
    target_dialog.set_option('lose_pause', LOSE_PAUSE)
    target_dialog.set_option('daily_report', DAILY_REPORT)


def _next_time_of_day(hhmm):
    """'07:00' -> 지금 이후 처음 오는 07:00의 epoch초 (이미 지났으면 내일)"""
    h, m = map(int, hhmm.split(':'))
    now = datetime.datetime.now()
    t = now.replace(hour=h, minute=m, second=0, microsecond=0)
    if t <= now:
        t += datetime.timedelta(days=1)
    return t.timestamp(), t


def set_end_time(stop_at):
    global end_stop_at, end_stop_label, end_stop_text
    end_stop_text = stop_at
    if stop_at:
        end_stop_at, t = _next_time_of_day(stop_at)
        end_stop_label = ('%d/%d ' % (t.month, t.day) if t.date() != datetime.date.today() else '오늘 ') + stop_at
    else:
        end_stop_at, end_stop_label = None, ''


def start_session(stop_at=None, start_at=None):
    global is_manager_mode, is_paused, check_lines, last_rank, last_known_score, strip_last
    global champions_game_count, champions_history, champions_fail_count
    global champions_last_game_time, champions_session_start, champions_final_score
    global vs_visible, vs_expect, vs_warned, cont_count, vs_pending, tier_last_mask, tier_last_champ, popup_hint, tier_now
    global wait_until, wait_reason, wait_info, promo_released_date
    wait_until, wait_reason, wait_info = None, '', ''
    check_lines = []
    set_end_time(stop_at)
    LOG.info('자동진행 시작 - 정지 조건: %s, 디스코드 %s', stop_conditions_text(), '켜짐' if WEBHOOK else '꺼짐')
    champions_game_count = 0
    champions_history = []
    champions_fail_count = 0
    champions_last_game_time = 0.0
    champions_session_start = time.time()
    champions_final_score = None
    last_rank = None
    last_known_score = None
    strip_last = None
    vs_visible = vs_expect = vs_warned = False
    cont_count = 0
    vs_pending = None
    tier_last_mask = tier_last_champ = popup_hint = tier_now = None
    tier_events.clear()
    last_bar.clear()
    set_start_wait(start_at)
    _last_click.clear()
    watchdog_reset()
    is_paused = False
    is_manager_mode = True
    if wait_until is not None:
        set_status('⏳ %s - 그때 자동으로 시작합니다' % wait_info, 'info')
    else:
        set_status('진행 중 - 정지 조건: %s' % stop_conditions_text(), 'run')
    draw_ui()


def set_start_wait(start_at):
    """시작 시각 예약 (None이면 바로 시작)"""
    global wait_until, wait_reason, wait_info, start_text
    start_text = start_at
    if start_at:
        wait_until, t = _next_time_of_day(start_at)
        wait_reason = 'start'
        wait_info = '%s%s 시작 예약' % ('' if t.date() == datetime.date.today() else '%d/%d ' % (t.month, t.day), start_at)
    elif wait_reason == 'start':
        wait_until, wait_reason, wait_info = None, '', ''


def on_press_f10(_):
    """일시정지 / 재개 (누르는 즉시)"""
    global is_paused, vs_visible
    if not is_manager_mode:
        return
    is_paused = not is_paused
    LOG.info('F10 - %s', '일시정지' if is_paused else '재개')
    if is_paused:
        set_status('일시정지 [%s] - F10으로 재개' % time.strftime('%H:%M:%S'), 'warn')
    else:
        vs_visible = False
        watchdog_reset()
        set_status('재개 [%s]' % time.strftime('%H:%M:%S'), 'run')
    draw_ui()


def on_press_f11(_):
    """기록 차트 열기"""
    try:
        path = score_log.build_chart(TARGET_SCORE)
        if path is None:
            set_status('차트: 아직 기록이 없습니다 (F9로 진행하면 쌓입니다)', 'info')
        else:
            os.startfile(path)
    except Exception as e:
        set_status('차트 생성 실패: %s' % e, 'warn')
    draw_ui()


def on_press_f12(_):
    global is_manager_mode, is_paused
    LOG.info('F12 - 자동진행 종료')
    was = is_manager_mode
    is_manager_mode = False
    is_paused = False
    if was:
        set_status('F12로 종료됨 [%s]' % time.strftime('%H:%M:%S'), 'stop')
    draw_ui()


def safe_log(game_no, score, note=''):
    try:
        return score_log.append_record(game_no, score, note)
    except Exception:
        note_error('기록 저장')
        return None  # 기록 실패가 매크로 진행을 막지 않게 함


def safe_update(ts, game_no, **fields):
    if not ts:
        return
    try:
        score_log.update_fields(ts, game_no, **fields)
    except Exception:
        note_error('기록 수정')


keyboard.on_press_key('F6', lambda _: threading.Thread(target=toggle_topmost, daemon=True).start())
keyboard.on_press_key('F7', lambda _: threading.Thread(target=run_checks, args=(True,), daemon=True).start())
keyboard.on_press_key('F8', on_press_f8)
keyboard.on_press_key('F9', on_press_f9)
keyboard.on_press_key('F10', on_press_f10)
keyboard.on_press_key('F11', on_press_f11, suppress=True)   # 다른 프로그램(터미널 전체화면 등)에 F11이 전달되지 않게 막음
keyboard.on_press_key('F12', on_press_f12)
print('\x1b[2J', end='')
LOG.info('===== 매크로 실행 %s (폴더: %s · 코드: %s) =====', VERSION, paths.APP_DIR, paths.CODE_DIR)
draw_ui()


def stop_all(status=None, kind='stop'):
    global is_manager_mode, is_paused
    is_manager_mode = False
    is_paused = False
    if status is not None:
        set_status(status, kind)


# ── 화면 인식: 한 번 찍은 화면(frame)에서 모든 버튼을 찾음 ─────────────
_win_cache = {'t': 0.0, 'w': None}
Box = collections.namedtuple('Box', 'left top width height')
_tls = threading.local()


def game_window():
    """FC ONLINE 창 (2초간 캐시)"""
    now = time.time()
    if now - _win_cache['t'] > 2:
        _win_cache['w'] = find_game_window()
        _win_cache['t'] = now
    return _win_cache['w']


def game_region():
    """게임 창 영역 (left, top, width, height). 못 찾거나 최소화면 None -> 전체 화면 사용"""
    w = game_window()
    if w is None:
        return None
    try:
        if getattr(w, 'isMinimized', False):
            return None
        left, top = max(0, int(w.left)), max(0, int(w.top))
        width = int(w.left) + int(w.width) - left
        height = int(w.top) + int(w.height) - top
        if width < 200 or height < 200:
            return None
        return (left, top, width, height)
    except Exception:
        return None


def grab_frame():
    """게임 창 화면 1장 -> {'ox','oy': 화면상 위치, 'rgb', 'gray'}"""
    reg = game_region()
    shot = pyautogui.screenshot(region=reg) if reg else pyautogui.screenshot()
    rgb = np.array(shot.convert('RGB'))
    return {'ox': reg[0] if reg else 0, 'oy': reg[1] if reg else 0, 'rgb': rgb,
            'gray': cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)}


def use_frame(f):
    _tls.frame = f


def cur_frame():
    return getattr(_tls, 'frame', None)


def crop(frame, region):
    """화면 좌표 영역 -> frame 안의 RGB 조각 (벗어나면 None)"""
    x, y, w, h = region
    x -= frame['ox']
    y -= frame['oy']
    if x < 0 or y < 0:
        return None
    a = frame['rgb'][y:y + h, x:x + w]
    return a if a.shape[0] == h and a.shape[1] == w else None


_img_cache = {}


def needle(name):
    """버튼 이미지를 한 번만 읽어서 보관 (한글 경로 대응). 못 읽으면 예외 -> 화면에 오류로 표시됨"""
    img = _img_cache.get(name)
    if img is None:
        path = paths.img(name)
        img = paths.imread(path)
        if img is None:
            raise IOError('이미지 파일을 읽을 수 없음: %s' % path)
        _img_cache[name] = img
    return img


def needle_gray(name):
    key = name + '#g'
    g = _img_cache.get(key)
    if g is None:
        g = cv2.cvtColor(needle(name), cv2.COLOR_BGR2GRAY)
        _img_cache[key] = g
    return g


def _match(f, name, nd, g):
    """(최고 유사도, 위치). 큰 버튼은 절반 크기 화면에서 대략 찾고 그 주변만 원래 크기로 확인 (약 4배 빠름)"""
    if min(nd.shape) < 24:                               # 작은 아이콘(S 등)은 원래 크기로 전체 검색
        r = cv2.matchTemplate(g, nd, cv2.TM_CCOEFF_NORMED)
        _mn, mx, _l, loc = cv2.minMaxLoc(r)
        return mx, loc
    if 'half' not in f:
        f['half'] = cv2.resize(g, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
    key = name + '#h'
    nh = _img_cache.get(key)
    if nh is None:
        nh = cv2.resize(nd, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
        _img_cache[key] = nh
    gh = f['half']
    if gh.shape[0] < nh.shape[0] or gh.shape[1] < nh.shape[1]:
        return 0.0, None
    r = cv2.matchTemplate(gh, nh, cv2.TM_CCOEFF_NORMED)
    _mn, mx, _l, loc = cv2.minMaxLoc(r)
    if not (mx >= 0.55):
        return mx, None
    x0, y0 = max(0, loc[0] * 2 - 4), max(0, loc[1] * 2 - 4)
    sub = g[y0:loc[1] * 2 + nd.shape[0] + 4, x0:loc[0] * 2 + nd.shape[1] + 4]
    if sub.shape[0] < nd.shape[0] or sub.shape[1] < nd.shape[1]:
        return 0.0, None
    r = cv2.matchTemplate(sub, nd, cv2.TM_CCOEFF_NORMED)
    _mn, mx, _l, l2 = cv2.minMaxLoc(r)
    return mx, (l2[0] + x0, l2[1] + y0)


def locate(name, confidence, frame=None):
    """화면(frame, 없으면 새로 찍음)에서 이미지를 찾음. 못 찾으면 ImageNotFoundException"""
    try:
        f = frame or cur_frame() or grab_frame()
        nd = needle_gray(name)
        g = f['gray']
        if g.shape[0] < nd.shape[0] or g.shape[1] < nd.shape[1]:
            raise pyautogui.ImageNotFoundException(name)
        mx, loc = _match(f, name, nd, g)
        if loc is None or not (mx >= confidence) or mx > 1.01:
            raise pyautogui.ImageNotFoundException(name)
        return Box(loc[0] + f['ox'], loc[1] + f['oy'], nd.shape[1], nd.shape[0])
    except pyautogui.ImageNotFoundException:
        raise
    except Exception:
        note_error('이미지 인식(%s)' % name)      # '못 찾음'이 아닌 진짜 오류는 화면/로그에 표시
        raise


CLICKED, WAITING = 1, 2


def click_image(name, dy=10, confidence=0.95):
    """버튼을 찾아 클릭 -> CLICKED / 방금 누른 버튼이 아직 보이면 WAITING(다시 안 누름) / 못 찾으면 0"""
    try:
        b = locate(name, confidence)
    except Exception:
        return 0
    now = time.time()
    if now - _last_click.get(name, 0) < SAME_BUTTON_SEC:
        return WAITING
    macro_input()
    pyautogui.moveTo(x=b.left + 10, y=b.top + dy)
    time.sleep(CLICK_HOVER_SEC)
    pyautogui.mouseDown()
    pyautogui.mouseUp()
    time.sleep(0.05)
    pyautogui.moveTo(x=b.left + 10, y=b.top - 200)
    macro_input()
    _last_click[name] = time.time()
    _next_action_at[0] = time.time() + AFTER_CLICK_SEC
    return CLICKED


def press_key(key):
    macro_input()
    pydirectinput.keyDown(key)
    time.sleep(0.1)
    pydirectinput.keyUp(key)
    macro_input()


# ── 사람 입력 감지 (이적시장 자동 닫기용): 매크로가 한 클릭·키 입력은 빼고 ─────────
_macro_input_at = [0.0]
_user_input_at = [time.time()]
_last_input_tick = [None]


def macro_input():
    _macro_input_at[0] = time.time()


def track_user_input():
    """Windows가 알려주는 '마지막 입력 시각'이 매크로 입력 직후가 아니면 사람 입력으로 봄"""
    if os.name != 'nt':
        return
    try:
        ctypes, wt, u, k = w32()
        li = _LASTINPUTINFO()
        li.cbSize = ctypes.sizeof(_LASTINPUTINFO)
        if not u.GetLastInputInfo(ctypes.byref(li)):
            return
        if li.dwTime == _last_input_tick[0]:
            return
        _last_input_tick[0] = li.dwTime
        ago = ((k.GetTickCount() - li.dwTime) & 0xFFFFFFFF) / 1000.0
        t = time.time() - ago
        if _macro_input_at[0] - 0.5 <= t <= _macro_input_at[0] + 1.5:
            return                                        # 매크로가 한 입력
        _user_input_at[0] = max(_user_input_at[0], t)
    except Exception:
        note_error('입력 감지')


def user_idle_sec():
    if os.name != 'nt':
        return float(os.environ.get('FCMACRO_TEST_IDLE', '9999'))   # 윈도우가 아니면(테스트) 항상 자리 비움
    return time.time() - _user_input_at[0]


_market_note = [0.0]


def handle_market():
    """이적시장 창이 떠 있으면 True (다른 버튼은 누르지 않음). 사람 입력이 MARKET_IDLE_SEC 없으면 X 클릭"""
    try:
        locate('market_title.png', 0.85)
        bx = locate('market_x.png', 0.85)
    except Exception:
        return False
    idle = user_idle_sec()
    if idle < MARKET_IDLE_SEC:
        if time.time() - _market_note[0] > 10:
            _market_note[0] = time.time()
            set_status('이적시장 창이 열려 있음 - 입력이 %d초 없으면 자동으로 닫습니다 (지금 %d초)' % (MARKET_IDLE_SEC, idle), 'info')
        return True
    macro_input()
    pyautogui.moveTo(x=bx.left + bx.width // 2, y=bx.top + bx.height // 2)
    time.sleep(CLICK_HOVER_SEC)
    pyautogui.mouseDown()
    pyautogui.mouseUp()
    time.sleep(0.05)
    pyautogui.moveTo(x=bx.left + bx.width // 2, y=bx.top + 200)
    macro_input()
    _next_action_at[0] = time.time() + AFTER_CLICK_SEC
    LOG.info('이적시장 창 닫음 (사람 입력 %d초 없음)', idle)
    set_status('이적시장 창을 닫고 계속 진행 (입력 %d초 없음) [%s]' % (idle, time.strftime('%H:%M:%S')), 'run')
    draw_ui()
    return True


def read_score_stable(home_box):
    """점수를 0.5초 간격으로 두 번 읽어 같을 때만 인정 (화면 전환/숫자 애니메이션 대비), 최대 3번 시도"""
    for _ in range(3):
        try:
            a, _d1 = score_ocr.read_score_on_screen(home_box)
            time.sleep(0.5)
            b, _d2 = score_ocr.read_score_on_screen(home_box)
        except Exception:
            a, b = None, None
        if a is not None and a == b:
            return a
        time.sleep(0.4)
    return None


def is_champions_home():
    """챔스 홈 화면('랭킹 점수' 글자가 있음)인지"""
    try:
        locate('champ_label.png', 0.7)
        return True
    except Exception:
        return False


def is_placement_screen():
    """'배치 경기' 화면(시즌 초, 랭킹점수 없음)인지"""
    try:
        locate('placement.png', 0.8)
        return True
    except Exception:
        return False


# ── 홈 화면: 공식경기 누르기 직전 확인 ───────────────────────
def park(note, status, title, lines, score=None):
    """정지 조건 도달: 공식경기를 누르지 않고 멈춤"""
    global champions_final_score
    champions_final_score = score
    if score is not None:
        settle_by_score(len(champions_history) - 1, score)
        safe_log('-', score, note)
    stop_all(status, 'done')
    alert('done', title, lines, image='chart')
    draw_ui()
    return False


def home_check(home_box):
    """공식경기 클릭 직전 호출. True = 클릭해도 됨, False = 클릭하지 말 것"""
    global champions_fail_count, last_known_score
    champ = is_champions_home()
    try:
        check_tier_change(home_box, champ)
    except Exception:
        note_error('티어 변화 확인')
    score = None
    if champ:
        score = read_score_stable(home_box)
        if score is None:
            champions_fail_count += 1
            if champions_fail_count >= OCR_MAX_FAIL:
                stop_all('정지 - 랭킹점수 인식 %d회 연속 실패 (확인 필요)' % champions_fail_count, 'stop')
                alert('stop', '⛔ 매크로 정지 - 랭킹점수 인식 실패',
                      ['랭킹점수를 %d번 연속 읽지 못해 안전하게 멈췄습니다.' % champions_fail_count,
                       '게임 화면을 다른 창이 가리고 있지 않은지 확인해 주세요.'], image='screen')
            else:
                set_status('랭킹점수 인식 실패 %d/%d - 다음 차례에 다시 시도' % (champions_fail_count, OCR_MAX_FAIL), 'warn')
            draw_ui()
            return False
        last_known_score = score
    champions_fail_count = 0
    now = time.strftime('%H:%M:%S')
    cur_strip = None
    if not champ:
        try:
            f = cur_frame() or grab_frame()
            cur_strip = score_ocr.read_result_strip(crop(f, score_ocr.strip_region(home_box, score_ocr.STRIP_HOME)),
                                                    score_ocr.STRIP_HOME)
            apply_strip(cur_strip, len(champions_history) - 1)
            note_bar(3 * cur_strip.count('승') + cur_strip.count('무') if cur_strip is not None else None,
                     score_ocr.read_bar_lines(crop(f, score_ocr.bar_region(home_box))))
        except Exception:
            note_error('결과 칸 읽기')

    # 1) 목표 점수
    if TARGET_SCORE is not None and score is not None and score >= TARGET_SCORE:
        sc = format(score, ',')
        return park('주차', '주차 완료 - 랭킹점수 %s점 (목표 %s점 이상) [%s]' % (sc, format(TARGET_SCORE, ','), now),
                    '🏁 주차 완료! 랭킹점수 %s점' % sc, ['목표 %s점 이상에 도달해서 멈췄습니다.' % format(TARGET_SCORE, ',')], score)
    # 2) 목표 순위 (직전 판 VS 화면에서 읽은 순위)
    if TARGET_RANK is not None and champ and last_rank is not None and last_rank <= TARGET_RANK:
        return park('주차', '주차 완료 - 순위 %s위 (목표 %s위 이내) [%s]' % (format(last_rank, ','), format(TARGET_RANK, ','), now),
                    '🏁 주차 완료! 순위 %s위' % format(last_rank, ','),
                    ['목표 %s위 이내에 들어서 멈췄습니다.' % format(TARGET_RANK, ',')], score)
    # 2-1) 챔스 승급 대기 (슈퍼챌린저에서 다음 판 이기면 승급 -> 자정까지 멈춤)
    if PROMO_WAIT and not champ and promo_check(home_box, cur_strip):
        return False
    # 3) 직전 클릭이 안 먹힌 경우 (VS 화면 없이 금방 다시 홈 화면) -> 새 판으로 세지 않고 클릭만 다시
    if vs_expect and time.time() - champions_last_game_time < SAME_GAME_SEC:
        set_status('공식경기 클릭 재시도 (%d번째 게임)' % champions_game_count, 'warn')
        draw_ui()
        return True
    # 4) 종료 시각
    if end_stop_at and time.time() >= end_stop_at:
        reason = '종료 시각 %s 도달' % end_stop_label
        return park('종료', '종료 시각으로 정지 - %s [%s]' % (reason, now), '⏹ 종료 시각으로 정지 - %s' % end_stop_label,
                    ['현재 랭킹점수 %s' % fmt_num(score, '점')] if score is not None else [], score)
    # 5) 새 판 시작
    placement = (not champ) and is_placement_screen()
    begin_game(score, '배치' if placement else '', from_home=True, champ=champ)
    return True


def _next_midnight():
    t = datetime.datetime.combine(datetime.date.today() + datetime.timedelta(days=1), datetime.time(0, 0))
    return t.timestamp() + MIDNIGHT_RESUME_SEC


def promo_check(home_box, st):
    """챔스 승급 대기 조건이면 대기 시작하고 True"""
    global wait_until, wait_reason, wait_info
    is_promo_tier = tier_rank(tier_now) is not None and tier_rank(tier_now) == tier_rank(PROMO_TIER)
    maybe = tier_now is None and _norm_tier(tier_last_named) in (_norm_tier('챌린저 1부'), _norm_tier(PROMO_TIER))
    if not (is_promo_tier or maybe):
        return False                                   # (이름을 모르는데 직전이 챌린저 1부/슈퍼챌린저면 안전하게 확인)
    if promo_released_date == datetime.date.today():
        return False                                   # 오늘 자정에 이미 풀었음 -> 계속 진행 (오늘 하루 강등 보호)
    lines = {}
    try:
        f = cur_frame() or grab_frame()
        lines = score_ocr.read_bar_lines(crop(f, score_ocr.bar_region(home_box)))
    except Exception:
        note_error('승격선 읽기')
    if st is not None:
        pts = 3 * st.count('승') + st.count('무')    # 결과 칸 (승 3, 무 1)
    elif 'fill' in lines:
        pts = lines['fill']                           # 막대 파란 채움
    else:
        return False
    line = lines.get('green', PROMO_LINE_FALLBACK)
    LOG.info('승급 대기 확인 - 승점 %d (결과 칸 %s), 막대 %s -> 승격선(초록) %d', pts, ''.join(st or []) or '-', lines or '못 읽음', line)
    if line - pts > PROMO_GAP:
        return False
    if datetime.datetime.now().hour == 0:
        LOG.info('승급 대기 조건이지만 이미 자정 직후(0시대) -> 그대로 진행')
        return False
    wait_until = _next_midnight()
    wait_reason = 'promo'
    wait_info = '챔스 승급 대기 (승점 %d / 승격선 %d · 다음 판 이기면 승급)' % (pts, line)
    set_status('⏳ %s - 자정 지나면 자동 재개 [%s]' % (wait_info, time.strftime('%H:%M:%S')), 'warn')
    alert('info', '⏳ 챔스 승급 대기 - 자정에 자동 재개',
          ['%s 티어 승점 %d점, 승격선 %d점' % (PROMO_TIER, pts, line), '다음 판을 이기면 챔피언스 승급이라 자정까지 멈춥니다.'])
    draw_ui()
    return True


def end_wait():
    """대기 시각이 됨 -> 진행 시작/재개"""
    global wait_until, wait_reason, wait_info, promo_released_date, champions_session_start
    global champions_last_game_time, vs_expect
    reason = wait_reason
    wait_until, wait_reason, wait_info = None, '', ''
    if champions_last_game_time:
        champions_last_game_time = time.time()        # 대기한 시간은 '새 판 없음' 감시에서 빼기
    vs_expect = False
    _last_click.clear()
    watchdog_reset()
    if reason == 'promo':
        promo_released_date = datetime.date.today()
        set_status('자정 - 챔스 승급 대기 끝, 자동 재개 [%s]' % time.strftime('%H:%M:%S'), 'run')
        alert('info', '▶ 자정 - 자동 재개', ['다음 판을 이기면 챔피언스 승급입니다.'])
    else:
        champions_session_start = time.time()
        set_status('예약 시각 - 자동진행 시작 [%s] · 정지 조건: %s' % (time.strftime('%H:%M:%S'), stop_conditions_text()), 'run')
    LOG.info('대기 끝(%s) - 진행', reason)
    draw_ui()


def begin_game(score, note='', from_home=True, champ=None):
    """새 판 기록 시작 (홈 화면에서 공식경기 누를 때 / 연속 진행이면 VS 화면에서)"""
    global champions_game_count, champions_last_game_time, vs_expect, vs_pending
    finish_vs()                                       # 직전 판에서 읽어 둔 값이 있으면 기록
    champions_game_count += 1
    champions_last_game_time = time.time()
    watchdog_new_game()
    if from_home:
        vs_expect = True
    n = champions_game_count
    ts = safe_log(n, score, note)
    h = [n, score, time.strftime('%H:%M:%S'), None, champions_last_game_time, note, ts, None, champ]
    champions_history.append(h)
    if score is not None:
        settle_by_score(len(champions_history) - 2, score)   # 직전 판 결과 (챔스: 점수 변화)
    vs_pending = {'h': h, 'got': {}, 'last': {}, 'tries': 0, 'after': 0}
    LOG.info('%d번째 게임 시작 - 점수 %s%s', n, fmt_num(score), (' (%s)' % note) if note else '')
    if note == '배치':
        set_status('진행 중 - %d번째 게임 (배치 경기)' % n, 'run')
    elif score is not None:
        set_status('진행 중 - %d번째 게임 시작 (직전 랭킹점수 %s점)' % (n, format(score, ',')), 'run')
    elif from_home:
        set_status('진행 중 - %d번째 게임 시작 (점수는 VS 화면에서 읽음)' % n, 'run')
    draw_ui()


# ── 승/무/패 판정 ──────────────────────────────────────────
def set_result(i, res, how):
    """i번째(세션 안) 판의 결과 기록 (이미 있으면 그대로)"""
    if i < 0 or i >= len(champions_history) or res is None:
        return
    h = champions_history[i]
    if h[H_RES] is not None:
        return
    h[H_RES] = res
    safe_update(h[H_TS], h[H_NO], 결과=res)
    LOG.info('%d번째 게임 결과: %s (%s)', h[H_NO], res, how)
    try:
        check_lose_streak()
    except Exception:
        note_error('연패 확인')


_streak_alerted = [None]          # 이미 알린 연패의 시작 게임번호 (같은 연패는 한 번만)


def current_lose_streak():
    """(연패 수, 연패 시작 게임번호) - 이번 세션 기록의 끝에서부터 (결과 미정인 판은 건너뜀)"""
    n, start = 0, None
    for h in reversed(champions_history):
        if h[H_RES] is None:
            if n == 0:
                continue
            break
        if h[H_RES] != '패':
            break
        n, start = n + 1, h[H_NO]
    return n, start


def check_lose_streak():
    global is_paused
    if not LOSE_STREAK:
        return
    n, start = current_lose_streak()
    if n < LOSE_STREAK or _streak_alerted[0] == start:
        return
    _streak_alerted[0] = start
    paused = False
    if LOSE_PAUSE and is_manager_mode and not is_paused:
        is_paused = paused = True
    msg = '%d연패 (%d번째 게임부터)%s' % (n, start, ' - 일시정지함 (F10 또는 !재개)' if paused else '')
    LOG.warning('연패 경고: %s', msg)
    set_status('⚠ ' + msg + ' [%s]' % time.strftime('%H:%M:%S'), 'warn')
    alert('warn', '⚠️ %d연패%s' % (n, ' - 일시정지했습니다' if paused else ''),
          ['%d번째 게임부터 %d판 연속 패배' % (start, n)] + (['다시 진행: PC에서 F10 또는 디스코드 !재개'] if paused else []),
          image='chart')
    draw_ui()


def settle_by_score(i, next_score):
    """다음 판 시작 점수와 비교해 결과 판정 (챔스: 무승부 없음 / 챔스 아래 티어는 결과 칸을 못 읽었을 때만)"""
    if i < 0 or i >= len(champions_history) or next_score is None:
        return
    h = champions_history[i]
    if h[H_RES] is not None or h[H_SCORE] is None:
        return
    d = next_score - h[H_SCORE]
    if d > 0:
        set_result(i, '승', '점수 변화')
    elif d < 0:
        set_result(i, '패', '점수 변화')
    elif h[H_CHAMP] is False:
        set_result(i, '무', '점수 변화')


def apply_strip(st, i):
    """결과 칸을 읽음 -> 직전에 본 결과 칸보다 1칸 늘었으면 그 칸이 i번째 판의 결과"""
    global strip_last
    if not st:
        return
    prev = strip_last
    strip_last = list(st)
    if prev is not None and len(st) == len(prev) + 1 and st[:-1] == prev:
        set_result(i, st[-1], '결과 칸')


def result_counts(hist):
    w = sum(1 for h in hist if h[H_RES] == '승')
    d = sum(1 for h in hist if h[H_RES] == '무')
    l = sum(1 for h in hist if h[H_RES] == '패')
    return w, d, l


# ── 승급 / 강등: 홈 화면 티어명 글씨가 바뀌었는지 비교 ─────────────────
def _tier_mask(frame, home_box):
    a = crop(frame, (int(home_box.left) + TIER_DX, int(home_box.top) + TIER_DY, TIER_W, TIER_H))
    if a is None:
        return None, None
    m = cv2.cvtColor(a, cv2.COLOR_RGB2GRAY) > 200
    if m.mean() < 0.02:          # 글씨 없음 (배치 경기 화면 등)
        return None, a
    return m, a


def _iou(a, b):
    u = (a | b).sum()
    return (a & b).sum() / u if u else 1.0


_K3 = np.ones((3, 3), np.uint8)
TIER_SAME_MAX = 20        # 글씨 모양이 이 픽셀 수 이하로만 다르면 같은 티어 (숫자 한 글자만 달라도 80px 이상 차이)


def tier_diff(a, b):
    """두 티어명 글씨 모양의 차이(픽셀 수). 1px 어긋남은 무시. '챌린저 3부'와 '챌린저 1부'처럼 숫자만 달라도 구분됨"""
    if a is None or b is None or a.shape != b.shape:
        return 10 ** 6
    da = cv2.dilate(a.astype(np.uint8), _K3).astype(bool)
    db = cv2.dilate(b.astype(np.uint8), _K3).astype(bool)
    return int((a & ~db).sum() + (b & ~da).sum())


def check_tier_change(home_box, champ):
    """티어명이 바뀌었으면 직전 판에 승급/강등 표시. 처음 본 홈 화면은 기준으로만 저장"""
    global tier_last_mask, tier_last_champ, popup_hint, strip_last, tier_now, tier_last_named
    f = cur_frame() or grab_frame()
    m1, img = _tier_mask(f, home_box)
    if m1 is None:
        return
    time.sleep(0.3)                                  # 화면 등장 연출 중이면 글씨가 변하므로 한 번 더 보고 같을 때만
    m2, _ = _tier_mask(grab_frame(), home_box)
    if m2 is None or tier_diff(m1, m2) > TIER_SAME_MAX:
        tier_log('티어명 글씨가 아직 움직이는 중 -> 다음 홈 화면에서 다시 확인')
        return
    name = tier_name_of(m1, champ)
    changed = tier_last_mask is not None and tier_diff(m1, tier_last_mask) > TIER_SAME_MAX
    if name is None and changed:
        name = guess_tier_name(tier_now, season_direction())   # 처음 보는 티어: 순서상 이웃 티어로 추정
    if not tier_sample_exists(m1):
        save_tier_sample(img, name)                  # 처음 보는 티어 -> 이름을 알면 그 이름으로, 모르면 '이름없음_...png'
    tier_log('티어명 확인: %s%s' % (name or '이름 모름', ' (바뀜)' if changed else ''))
    if changed:
        r_old, r_new = tier_rank(tier_now), tier_rank(name)
        if r_old is not None and r_new is not None and r_old != r_new:
            ev = '승급' if r_new > r_old else '강등'
        elif season_direction():
            ev = season_direction()
        elif champ and tier_last_champ is False:
            ev = '승급'
        elif tier_last_champ and not champ:
            ev = '강등'
        elif popup_hint:
            ev = popup_hint
        else:
            ev = '티어 변경'
        mark_event(ev, tier_now, name)
        strip_last = []                       # 새 티어: 결과 칸이 비어서 다시 시작
        last_bar.clear()
    if name:
        tier_last_named = name
    tier_last_mask, tier_last_champ, popup_hint, tier_now = m1, champ, None, name


# 티어 이름: tier_samples 폴더의 이미지 파일 이름 (사용자가 '이름없음_...' 파일을 '마스터 3부.png' 처럼 바꿔 둠)
# 아래 -> 위: 월드클래스 3부 > 2부 > 1부 > 마스터 3~1부 > 챌린저 3~1부 > 슈퍼챌린저 > 챔피언스 (+ 그 아래/위 티어)
TIER_ORDER = ['아마추어', '세미프로', '프로', '월드클래스', '마스터', '챌린저', '슈퍼챌린저', '챔피언스', '슈퍼챔피언스']
TIER_FAMILIES = sorted(TIER_ORDER, key=len, reverse=True)     # 긴 이름부터 비교 ('슈퍼챌린저'가 '챌린저'보다 먼저)
tier_now = None                  # 지금 티어 이름 (모르면 None)
_tier_lib = {'key': None, 'items': []}


def tier_rank(name):
    """'마스터 3부' -> 비교용 숫자 (높을수록 위 티어). 모르는 이름이면 None"""
    if not name:
        return None
    n = name.replace('감독', '').replace(' ', '')
    for fam in TIER_FAMILIES:
        if n.startswith(fam):
            rest = n[len(fam):]
            div = int(rest[:-1]) if rest.endswith('부') and rest[:-1].isdigit() else 0
            return TIER_ORDER.index(fam) * 10 + (9 - div if div else 9)
    return None


_tier_log_last = ['']


def tier_log(msg):
    """티어 확인 결과를 로그에 (같은 내용 반복은 생략)"""
    if msg != _tier_log_last[0]:
        _tier_log_last[0] = msg
        LOG.info(msg)


TIER_LIST = ['월드클래스 3부', '월드클래스 2부', '월드클래스 1부', '마스터 3부', '마스터 2부', '마스터 1부',
             '챌린저 3부', '챌린저 2부', '챌린저 1부', '슈퍼챌린저', '챔피언스']        # 아래 -> 위 (한 칸씩)


def _norm_tier(n):
    return (n or '').replace('감독', '').replace(' ', '')


last_bar = {}                    # 챔스 아래 티어 마지막 홈 화면의 {'pts': 승점, 'green': 승격선} (승급/강등 방향 판단)
tier_last_named = None           # 마지막으로 이름을 안 티어


def note_bar(pts, lines):
    if pts is not None:
        last_bar['pts'] = pts
    if lines.get('green'):
        last_bar['green'] = lines['green']


def season_direction():
    """시즌 마지막 홈 화면의 승점으로 방향 판단: 이미 승격선 이상이면 '승급', 마지막 판을 이겨도 못 닿으면 '강등', 애매하면 None"""
    p, g = last_bar.get('pts'), last_bar.get('green')
    if p is None or g is None:
        return None
    if p >= g:
        return '승급'
    if p + 3 < g:
        return '강등'
    return None


def guess_tier_name(old, direction=None):
    """직전 티어(old)의 위/아래 이웃 티어로 이름 추정 (예: 챌린저 1부에서 승급 -> 슈퍼챌린저).
    방향을 알면 그쪽 이웃, 모르면 이웃 중 아직 견본 없는 티어가 하나뿐일 때만"""
    key = [_norm_tier(t) for t in TIER_LIST]
    if _norm_tier(old) not in key:
        return None
    i = key.index(_norm_tier(old))
    if direction in ('승급', '강등'):
        j = i + 1 if direction == '승급' else i - 1
        if 0 <= j < len(TIER_LIST):
            LOG.info('처음 보는 티어 이름 추정: %s (%s에서 %s)', TIER_LIST[j], old, direction)
            return TIER_LIST[j]
        return None
    known = {_norm_tier(n) for n, _m in _tier_library() if n}
    cands = [TIER_LIST[j] for j in (i - 1, i + 1) if 0 <= j < len(TIER_LIST) and key[j] not in known]
    if len(cands) == 1:
        LOG.info('처음 보는 티어 이름 추정: %s (직전 %s의 이웃 중 견본 없는 티어)', cands[0], old)
        return cands[0]
    return None


def _tier_library():
    """티어명 견본 [(이름 또는 None, 글씨 모양)]: 기록 폴더 tier_samples + 프로그램 내장(images/tier_names). 바뀔 때만 다시 읽음"""
    d = 'tier_samples'
    bundled = paths.resource(os.path.join('images', 'tier_names'))
    try:
        files = sorted(os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith('.png')) if os.path.isdir(d) else []
        if os.path.isdir(bundled):
            files += sorted(os.path.join(bundled, f) for f in os.listdir(bundled) if f.lower().endswith('.png'))
        key = tuple((f, os.path.getmtime(f)) for f in files)
    except OSError:
        return []
    if _tier_lib['key'] == key:
        return _tier_lib['items']
    items = []
    for path in files:
        fn = os.path.basename(path)
        img = paths.imread(path, cv2.IMREAD_GRAYSCALE)
        if img is None or img.shape != (TIER_H, TIER_W):
            continue
        stem = fn[:-4]
        named = not (stem.startswith('이름없음') or stem[:8].isdigit())   # 예전 형식(날짜_...)도 이름 없음
        items.append((stem.strip() if named else None, img > 200))
    _tier_lib['key'], _tier_lib['items'] = key, items
    return items


def tier_name_of(mask, champ=False):
    best, best_d = None, 10 ** 6
    for name, m in _tier_library():
        if name:
            d = tier_diff(mask, m)
            if d < best_d:
                best, best_d = name, d
    if best_d <= TIER_SAME_MAX:
        return best
    return '챔피언스' if champ else None


def tier_sample_exists(mask):
    return any(tier_diff(mask, m) <= TIER_SAME_MAX for _n, m in _tier_library())


tier_events = []                 # 이번 세션 [(시각, '승급'/'강등'/'티어 변경')]


def mark_event(ev, old=None, new=None):
    """직전 판(방금 끝난 판)에 승급/강등 표시 + 알림"""
    if not champions_history:
        return
    h = champions_history[-1]
    h[H_NOTE] = (h[H_NOTE] + ', ' + ev) if h[H_NOTE] else ev
    safe_update(h[H_TS], h[H_NO], 비고=ev)
    tier_events.append((time.strftime('%H:%M'), ev))
    move = (' (%s → %s)' % (old or '?', new or '?')) if (old or new) else ''
    LOG.info('%s - %d번째 게임 결과%s', ev, h[H_NO], move)
    icon = {'승급': '▲', '강등': '▼'}.get(ev, '◆')
    set_status('%s %s!%s (%d번째 게임 후) [%s]' % (icon, ev, move, h[H_NO], time.strftime('%H:%M:%S')), 'info')
    alert('info', '%s %s!%s (%d번째 게임 후)' % (icon, ev, move, h[H_NO]),
          ['랭킹점수 %s' % fmt_num(last_known_score, '점')] if last_known_score is not None else [])
    draw_ui()


def save_tier_sample(img, name=None):
    """처음 보는 티어명 이미지 저장: 이름을 알면 '이름.png', 모르면 '이름없음_날짜시간.png' (파일 이름을 바꾸면 그 이름으로 표시)"""
    try:
        os.makedirs('tier_samples', exist_ok=True)
        if len(os.listdir('tier_samples')) >= TIER_SAMPLE_MAX:
            return
        fn = ('%s.png' % name) if name and not os.path.exists(os.path.join('tier_samples', '%s.png' % name)) \
            else '이름없음_%s.png' % time.strftime('%Y%m%d_%H%M%S')
        paths.imwrite(os.path.join('tier_samples', fn), cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        LOG.info('티어명 이미지 저장: %s', fn)
        _tier_lib['key'] = None
    except Exception:
        pass


def note_popup(ev):
    """승급/강등 확인 팝업을 누름 -> 다음 홈 화면에서 티어가 바뀌었으면 이 방향으로 표시"""
    global popup_hint
    popup_hint = ev
    LOG.info('팝업 확인 버튼(%s) 클릭', ev)


# ── VS 화면: 점수·순위 기록 (+ 연속 진행 감지) ──────────────────────
def handle_vs(frame):
    """VS 화면이면 기록 처리. True = 이번 차례는 진행 버튼을 누르지 말고 기다림(점수·순위 읽는 중)"""
    global vs_visible, vs_expect, vs_seen_at, vs_warned, cont_count
    try:
        vb = locate('vs_team.png', 0.9)
    except Exception:
        if vs_visible and vs_pending is not None and vs_pending['got']:
            finish_vs()                               # VS 화면이 지나감 -> 읽어 둔 값 기록
        vs_visible = False
        return False
    now = time.time()
    if not vs_visible:                                 # VS 화면이 새로 나타남
        vs_visible = True
        vs_seen_at = now
        if vs_expect:
            vs_expect = False                          # 정상: 공식경기를 누른 판
        elif now - champions_session_start > CONT_GRACE_SEC:
            cont_count += 1
            LOG.warning('홈 화면을 거치지 않은 경기 시작 (%d회째) - 연속 진행', cont_count)
            begin_game(None, '연속 진행', from_home=False)
            set_status('연속 진행 중 (%d판) - 기록은 계속, 정지 조건은 홈 화면을 거칠 때만 확인됩니다' % cont_count, 'warn')
            if not vs_warned:
                vs_warned = True
                alert('warn', '⚠️ 연속 진행 중입니다',
                      ['홈 화면(공식경기)을 거치지 않고 다음 경기가 시작됐습니다.',
                       '기록은 계속 남지만, 목표 점수·순위·종료 시각 정지는 홈 화면을 거칠 때만 됩니다.'], image='screen')
            draw_ui()
    if vs_pending is not None:
        read_vs(frame, vb)
        if vs_pending is not None and now - vs_seen_at < VS_HOLD_SEC:
            return True
    return False


def read_vs(frame, vb):
    """VS 화면에서 내 점수·순위를 읽음. 같은 값이 2번 연속 나와야 인정"""
    p = vs_pending
    vals = {}
    text_visible = False
    g = crop(frame, score_ocr.rank_region(vb, 'mine'))
    if g is not None:
        g = cv2.cvtColor(g, cv2.COLOR_RGB2GRAY)
        if int(g.max()) > score_ocr.RANK_TEXT_TH:
            r, _d = score_ocr.read_rank_from_gray(g)
            if r is not None:
                vals['rank_mine'] = r
    if 'rank_mine' not in vals and not p.get('strip_done'):
        st = score_ocr.read_result_strip(crop(frame, score_ocr.strip_region(vb, score_ocr.STRIP_VS)), score_ocr.STRIP_VS)
        if st:                                             # 챔스 아래 티어: 결과 칸으로 직전 판 승/무/패
            if p.get('strip') == st:
                p['strip_done'] = True
                h = p['h']
                i = champions_history.index(h) if h in champions_history else -1
                if i >= 0:
                    h[H_CHAMP] = False
                    apply_strip(st, i - 1)
            p['strip'] = st
    a = crop(frame, score_ocr.vs_score_region(vb, 'mine'))
    if a is not None and int(a[..., 2].max()) > score_ocr.VS_TEXT_TH:
        text_visible = True
        s, _d = score_ocr.read_vs_score(a)
        if s is not None:
            vals['score_mine'] = s
    ref = last_known_score
    if 'score_mine' in vals and ref is not None and abs(vals['score_mine'] - ref) > SCORE_JUMP_MAX:
        vals.pop('score_mine')                           # 직전 판과 너무 다름 -> 잘못 읽은 것
    for k, v in vals.items():
        if p['last'].get(k) == v:
            p['got'][k] = v
        p['last'][k] = v
    if not text_visible:
        return                                           # 글씨가 아직 안 나타남 (등장 연출 중) -> 시도로 세지 않음
    p['tries'] += 1
    got = p['got']
    if 'score_mine' in got:
        p['after'] += 1
    done = ('score_mine' in got and ('rank_mine' in got or p['after'] >= 3)) or p['tries'] >= VS_READ_FAILS
    if not done:
        return
    if 'score_mine' not in got and 'rank_mine' not in got:
        save_vs_samples(frame, vb, p['h'][H_NO])
    finish_vs()


def finish_vs():
    """읽은 값(확인된 것만)을 기록하고 이 판의 VS 읽기를 끝냄. VS 화면이 지나가거나 다음 판이 시작될 때도 호출"""
    global vs_pending, last_rank, last_known_score
    p = vs_pending
    if p is None:
        return
    vs_pending = None
    got = p['got']
    h = p['h']
    fields = {}
    if h[H_SCORE] is None and 'score_mine' in got:
        h[H_SCORE] = got['score_mine']
        fields['랭킹점수'] = got['score_mine']
        i = champions_history.index(h) if h in champions_history else -1
        if i > 0:
            settle_by_score(i - 1, h[H_SCORE])               # 결과 칸으로 못 정한 직전 판은 점수 변화로
    if 'score_mine' in got:
        last_known_score = got['score_mine']
    if 'rank_mine' in got:
        h[H_RANK] = last_rank = got['rank_mine']
        fields['순위'] = got['rank_mine']
        h[H_CHAMP] = True
    if fields:
        safe_update(h[H_TS], h[H_NO], **fields)
    LOG.info('VS 화면 - %d번째 게임: %s', h[H_NO], fields or '못 읽음')
    draw_ui()


def save_vs_samples(frame, vb, game_no):
    """점수·순위를 못 읽은 판의 VS 화면 글씨 부분 저장 (인식 개선용, rank_samples 폴더)"""
    try:
        os.makedirs('rank_samples', exist_ok=True)
        if len(os.listdir('rank_samples')) >= SAMPLE_MAX:
            return
        stamp = time.strftime('%Y%m%d_%H%M%S')
        x, y = int(vb.left) - 120, int(vb.top) + 225
        a = crop(frame, (x, y, 520, 75))
        if a is not None:
            paths.imwrite(os.path.join('rank_samples', '%s_g%s_vs.png' % (stamp, game_no)), cv2.cvtColor(a, cv2.COLOR_RGB2BGR))
    except Exception:
        pass


# ── 메인 루프 (원본 버튼 순서 유지) ───────────────────────────
def main_loop():
    if not loop_lock.acquire(blocking=False):
        return
    try:
        main_loop_body()
    finally:
        loop_lock.release()


_last_draw = [0.0]


def main_loop_body():
    if time.time() - _last_draw[0] >= 1.0:              # 화면 표시는 1초에 한 번
        _last_draw[0] = time.time()
        draw_ui()
        try:
            daily_report_check()
        except Exception:
            note_error('하루 결산')
    track_user_input()
    if not is_manager_mode or is_paused:
        return
    if wait_until is not None:
        if time.time() < wait_until:
            return
        end_wait()
    if time.time() < _next_action_at[0]:
        return
    f = grab_frame()
    use_frame(f)
    try:
        main_steps(f)
    finally:
        use_frame(None)


def main_steps(f):
    # [이적시장] 창이 열려 있으면: 사람 입력이 1분 없을 때만 X로 닫음 (쓰는 중이면 그대로 둠)
    if handle_market():
        return

    # [VS 화면] 점수·순위 기록 (읽는 동안 최대 몇 초 진행 보류)
    if handle_vs(f):
        return

    # [알림] 원본 동작 그대로: 클릭 후 return 하지 않고 다음 단계 계속 검사
    try:
        b = locate('alert.png', 0.95)
        macro_input()
        pyautogui.moveTo(x=b.left - 200, y=b.top + 200)
        time.sleep(CLICK_HOVER_SEC)
        pyautogui.mouseDown()
        pyautogui.mouseUp()
        time.sleep(0.2)
        use_frame(grab_frame())                         # 화면이 바뀌었으니 다시 찍음
    except Exception:
        pass

    if click_image('pt2.png'): return
    if click_image('pt.png'): return
    if click_image('check.png'): return
    r = click_image('demote.png')
    if r:
        if r == CLICKED:
            note_popup('강등')
        return
    if click_image('x.png'): return

    try:
        locate('esc.png', 0.95)
        press_key('esc')
        time.sleep(2)
        press_key('space')
        _next_action_at[0] = time.time() + AFTER_CLICK_SEC
        return
    except Exception:
        pass

    try:
        b = locate('skip.png', 0.7)
        press_key('space')
        macro_input()
        pyautogui.moveTo(x=b.left + 10, y=b.top + 10)
        time.sleep(CLICK_HOVER_SEC)
        pyautogui.mouseDown()
        pyautogui.mouseUp()
        time.sleep(0.05)
        pyautogui.moveTo(x=b.left + 10, y=b.top - 200)
        _next_action_at[0] = time.time() + AFTER_CLICK_SEC
        return
    except Exception:
        pass

    if click_image('gameover.png'): return

    # [공식경기] 누르기 직전에 정지 조건 확인 + 판 기록
    try:
        home_box = locate('home.png', 0.95)
    except Exception:
        home_box = None
    if home_box is not None:
        if time.time() - _last_click.get('home.png', 0) < SAME_BUTTON_SEC:
            return                                       # 방금 눌렀음 -> 화면 전환 기다림
        if not home_check(home_box):
            return
        if not is_manager_mode:
            return
        use_frame(grab_frame())
        if click_image('home.png', dy=3): return

    if click_image('squad.png', dy=5): return
    if click_image('uniform.png'): return
    r = click_image('levelup.png')
    if r:
        if r == CLICKED:
            note_popup('승급')
        return
    if click_image('pk.png'): return


set_interval(main_loop, LOOP_SEC)


# ── 멈춤 감지 ──────────────────────────────────────────
wd_prev = None
wd_static_since = 0.0
wd_alert_static = False
wd_alert_nogame = False
wd_missing = 0


def watchdog_reset():
    global wd_prev, wd_static_since, wd_alert_static, wd_alert_nogame, wd_missing
    wd_prev, wd_static_since = None, time.time()
    wd_alert_static = wd_alert_nogame = False
    wd_missing = 0


def watchdog_new_game():
    global wd_alert_nogame
    wd_alert_nogame = False


class GameWin:
    def __init__(self, hwnd, title, left, top, right, bottom, minimized):
        self._hWnd, self.title = hwnd, title
        self.left, self.top = left, top
        self.width, self.height = right - left, bottom - top
        self.isMinimized = minimized


def find_game_window():
    """제목이 정확히 'FC ONLINE'인 보이는 창 (직접 Windows에 물어봄). 없으면 None. 오류는 로그에 기록"""
    if os.name != 'nt':
        try:   # 윈도우가 아닌 환경(테스트용)
            wins = [w for w in pyautogui.getWindowsWithTitle(GAME_WINDOW_TITLE) if w.width > 300 and w.height > 300]
            exact = [w for w in wins if w.title.strip() == GAME_WINDOW_TITLE]
            return (exact or wins or [None])[0]
        except Exception:
            return None
    try:
        ctypes, wt, u, k = w32()
        found = []

        def cb(hwnd, _lp):
            try:
                if not u.IsWindowVisible(hwnd):
                    return True
                n = u.GetWindowTextLengthW(hwnd)
                if n <= 0 or n > 200:
                    return True
                buf = ctypes.create_unicode_buffer(n + 1)
                u.GetWindowTextW(hwnd, buf, n + 1)
                if buf.value.strip() != GAME_WINDOW_TITLE:
                    return True
                rc = wt.RECT()
                if not u.GetWindowRect(hwnd, ctypes.byref(rc)):
                    return True
                if rc.right - rc.left > 300 and rc.bottom - rc.top > 300:
                    found.append(GameWin(hwnd, buf.value, rc.left, rc.top, rc.right, rc.bottom, bool(u.IsIconic(hwnd))))
            except Exception:
                pass
            return True
        u.EnumWindows(_ENUM_PROC(cb), 0)
        return found[0] if found else None
    except Exception:
        note_error('게임 창 찾기')
        return None


def screen_changed(prev, cur):
    """축소한 게임 화면 두 장 비교: 어딘가 확실히 바뀐 부분이 있으면 True"""
    if prev is None or prev.shape != cur.shape:
        return True
    return int(np.abs(cur.astype(np.int16) - prev.astype(np.int16)).max()) > 30


def watchdog_loop():
    """30초마다: 게임 창이 사라졌는지 / 화면이 오래 그대로인지 / 새 판이 오래 시작 안 됐는지 확인"""
    global wd_prev, wd_static_since, wd_alert_static, wd_alert_nogame, wd_missing
    if not is_manager_mode or is_paused or wait_until is not None:
        watchdog_reset()
        return
    now = time.time()
    win = find_game_window()
    if win is None:
        wd_missing += 1
        if wd_missing == 2:      # 1분 연속 게임 창 없음
            set_status('게임 창을 찾을 수 없습니다 (게임 종료/튕김?) [%s]' % time.strftime('%H:%M:%S'), 'warn')
            alert('warn', '⚠️ 게임 창이 사라졌습니다', ['FC ONLINE 창을 1분째 찾을 수 없습니다. 게임이 종료되었거나 튕겼을 수 있습니다.'])
            draw_ui()
        return
    wd_missing = 0
    try:
        shot = pyautogui.screenshot(region=(max(0, win.left), max(0, win.top), win.width, win.height))
        cur = np.array(shot.convert('L').resize((160, 90)))
    except Exception:
        return
    if screen_changed(wd_prev, cur):
        wd_static_since = now
        wd_alert_static = False
    wd_prev = cur
    if not wd_alert_static and now - wd_static_since >= STALL_STATIC_MIN * 60:
        wd_alert_static = True
        set_status('멈춤 감지 - 게임 화면이 %d분째 그대로입니다 [%s]' % (STALL_STATIC_MIN, time.strftime('%H:%M:%S')), 'warn')
        alert('warn', '⚠️ 멈춤 감지 - 화면이 %d분째 그대로입니다' % STALL_STATIC_MIN,
              ['매크로가 모르는 팝업이나 접속 문제일 수 있습니다. 아래는 지금 게임 화면입니다.'], image='screen')
        draw_ui()
    if not wd_alert_nogame:
        ref = champions_last_game_time or champions_session_start
        if ref and now - ref >= NO_GAME_MIN * 60:
            wd_alert_nogame = True
            set_status('%d분 넘게 새 판이 시작되지 않았습니다 [%s]' % (NO_GAME_MIN, time.strftime('%H:%M:%S')), 'warn')
            alert('warn', '⚠️ %d분 넘게 새 판이 시작되지 않음' % NO_GAME_MIN,
                  ['마지막 판 시작: %s' % (time.strftime('%H:%M', time.localtime(ref)))], image='screen')
            draw_ui()


set_interval(watchdog_loop, 30)


# ── 점검 (실행 시 자동 + F7) ────────────────────────────
LABELS = {'home.png': '공식경기(홈)', 'squad.png': '스쿼드 진행', 'uniform.png': '유니폼 선택완료', 'vs_team.png': 'VS 화면',
          'gameover.png': '경기 종료 다음', 'check.png': '확인', 'pt.png': '확인→', 'pt2.png': '확인→(2)', 'demote.png': '강등 확인',
          'levelup.png': '승급 확인', 'pk.png': '준비완료', 'x.png': '닫기 X', 'esc.png': 'ESC', 'skip.png': 'SKIP', 'alert.png': '알림',
          's.png': 'S 아이콘', 'placement.png': '배치 경기', 'champ_label.png': '챔스 홈(랭킹 점수)'}
CONF = {'skip.png': 0.7, 's.png': 0.7, 'vs_team.png': 0.9, 'placement.png': 0.8, 'champ_label.png': 0.7}


def _win32_rects(win):
    """(게임 창 클라이언트 크기, 게임 창 사각형, 매크로 콘솔 창 사각형) - Windows 전용"""
    ctypes, wt, u, k = w32()
    client = None
    try:
        rc = wt.RECT()
        u.GetClientRect(wt.HWND(win._hWnd), ctypes.byref(rc))
        client = (rc.right - rc.left, rc.bottom - rc.top)
    except Exception:
        pass
    game = (int(win.left), int(win.top), int(win.left) + int(win.width), int(win.top) + int(win.height))
    cons = None
    try:
        h = console_hwnd()[0]       # 기본 콘솔 / Windows 터미널 모두
        if h and u.IsWindowVisible(h):
            rc = wt.RECT()
            u.GetWindowRect(h, ctypes.byref(rc))
            if rc.right - rc.left > 50 and rc.bottom - rc.top > 50:
                cons = (rc.left, rc.top, rc.right, rc.bottom)
    except Exception:
        pass
    return client, game, cons


def run_checks(screen_test=False):
    global check_lines
    res = []
    try:
        imgdir = paths.resource('images')
        n_btn = len([f for f in os.listdir(imgdir) if f.endswith('.png')])
        n_dig = len(os.listdir(paths.resource(os.path.join('images', 'digits'))))
        n_rank = len(os.listdir(paths.resource(os.path.join('images', 'rank_digits'))))
        res.append((n_btn >= 20 and n_dig >= 10, '이미지: 버튼 %d개, 점수 숫자 %d개, 순위 숫자 %d개 (%s)'
                    % (n_btn, n_dig, n_rank, paths.source_of('images'))))
        bad = []
        for f in sorted(os.listdir(imgdir)):
            if f.endswith('.png'):
                try:
                    needle(f)
                except Exception:
                    bad.append(f)
        try:
            score_ocr.load_templates()
            nr = sum(len(v) for v in score_ocr.load_rank_templates().values())
        except Exception as e:
            bad.append('숫자 견본(%s)' % e)
            nr = 0
        res.append((not bad and nr > 0, '이미지 읽기: ' + ('모두 정상' if not bad and nr > 0 else '실패 - ' + ', '.join(bad[:5]))))
    except Exception as e:
        res.append((False, '이미지 폴더를 읽을 수 없음: %s' % e))
    win = find_game_window()
    if win is None:
        res.append((False, '게임 창(FC ONLINE)을 찾을 수 없음 - 게임을 먼저 켜 주세요'))
    else:
        client, game, cons = (None, None, None)
        if os.name == 'nt':
            try:
                client, game, cons = _win32_rects(win)
            except Exception:
                pass
        if client:
            ok = tuple(client) == GAME_CLIENT_SIZE
            res.append((ok, '게임 화면 크기 %dx%d %s' % (client[0], client[1],
                        '(정상)' if ok else '- 1280x720 창모드로 바꿔 주세요')))
        else:
            res.append((True, '게임 창 찾음 (%dx%d)' % (win.width, win.height)))
        if cons and game:
            ix = min(cons[2], game[2]) - max(cons[0], game[0])
            iy = min(cons[3], game[3]) - max(cons[1], game[1])
            overlap = ix > 0 and iy > 0
            res.append((not overlap, '매크로 창이 게임 창을 가림 - 옆으로 옮겨 주세요' if overlap else '매크로 창과 게임 창 겹침 없음'))
    res.append((None, '디스코드 알림: ' + ('켜짐' if WEBHOOK else '꺼짐 (F8 설정창에서 웹훅 입력)')))
    res.append((None, '디스코드 봇: ' + (BOT.status if BOT is not None else '꺼짐 (설정창에 봇 토큰을 넣으면 !상태 등 명령 가능)')))
    for m in _MIGRATE_MSGS:
        res.append((None, '기록 이전: ' + m))
    if _BACKUP:
        res.append((True, '오늘 기록 백업 완료 (기록 폴더\\백업)'))
    if screen_test:
        found = []
        home_box = vs_box = None
        try:
            frame = grab_frame()
        except Exception:
            frame = None
        for name in ['home.png', 'champ_label.png', 'placement.png', 'squad.png', 'uniform.png', 'vs_team.png', 'gameover.png',
                     'check.png', 'pt.png', 'pt2.png', 'demote.png', 'levelup.png', 'pk.png', 'x.png', 'esc.png', 'skip.png',
                     'alert.png']:
            try:
                b = locate(name, CONF.get(name, 0.95), frame=frame)
                found.append(LABELS[name])
                if name == 'home.png':
                    home_box = b
                if name == 'vs_team.png':
                    vs_box = b
            except Exception:
                pass
        res.append((bool(found), '지금 화면에서 찾은 것: ' + (', '.join(found) if found else '없음 (게임 메뉴 화면에서 다시 해 보세요)')))
        if home_box is not None:
            if '챔스 홈(랭킹 점수)' in found:
                try:
                    v, _d = score_ocr.read_score_on_screen(home_box)
                except Exception:
                    v = None
                res.append((v is not None, '랭킹점수 읽기: ' + (format(v, ',') + '점' if v is not None else '실패')))
            elif '배치 경기' in found:
                res.append((True, '배치 경기 화면 - 점수 없이 진행합니다'))
            else:
                res.append((True, '챔스 아래 티어 홈 화면 - 점수는 VS 화면에서 읽습니다'))
        if vs_box is not None and frame is not None:
            for side, label in (('mine', '내'),):
                try:
                    g = crop(frame, score_ocr.rank_region(vs_box, side))
                    g = cv2.cvtColor(g, cv2.COLOR_RGB2GRAY) if g is not None else None
                    rv = score_ocr.read_rank_from_gray(g)[0] if g is not None and int(g.max()) > score_ocr.RANK_TEXT_TH else None
                    a = crop(frame, score_ocr.vs_score_region(vs_box, side))
                    sv = score_ocr.read_vs_score(a)[0] if a is not None else None
                except Exception:
                    rv = sv = None
                res.append((sv is not None, '%s 점수·순위 읽기: %s / %s' % (
                    label, format(sv, ',') + '점' if sv is not None else '점수 실패 (글씨가 나타난 뒤 다시 시도)',
                    format(rv, ',') + '위' if rv is not None else '순위 없음(챔스 아래 티어) 또는 실패')))
        if home_box is None and vs_box is None:
            res.append((None, '점수/순위 읽기 테스트는 홈 화면(공식경기) 또는 VS 화면에서 F7을 누르면 됩니다'))
    check_lines = res
    LOG.info('점검: %s', ' | '.join(('OK ' if ok else ('NG ' if ok is False else '')) + t for ok, t in res))
    draw_ui()


# ── 매크로 창 항상 위 (F6) ─────────────────────────────
_W32 = None
_ENUM_PROC = None
_LASTINPUTINFO = None


def w32():
    """
    Windows API 함수들 (64비트에서 창 핸들이 잘리지 않게 인자/반환 형식을 명시).
    ※ 공용 ctypes.windll.user32 에 형식을 지정하면 pyautogui(pygetwindow) 등 다른 라이브러리의
      같은 함수까지 바뀌어 오류가 나므로, 이 매크로 전용 사본(WinDLL)을 따로 불러서 사용
    """
    global _W32
    if _W32 is None:
        import ctypes
        import ctypes.wintypes as wt
        u = ctypes.WinDLL('user32', use_last_error=True)
        k = ctypes.WinDLL('kernel32', use_last_error=True)
        k.GetConsoleWindow.restype = wt.HWND
        k.GetConsoleWindow.argtypes = []
        u.IsWindowVisible.argtypes = [wt.HWND]
        u.IsWindowVisible.restype = wt.BOOL
        u.SetWindowPos.argtypes = [wt.HWND, wt.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        u.SetWindowPos.restype = wt.BOOL
        u.GetWindowRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]
        u.GetClientRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]
        u.FindWindowW.argtypes = [wt.LPCWSTR, wt.LPCWSTR]
        u.FindWindowW.restype = wt.HWND
        u.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
        u.GetWindowTextLengthW.argtypes = [wt.HWND]
        u.IsIconic.argtypes = [wt.HWND]
        global _ENUM_PROC
        _ENUM_PROC = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
        u.EnumWindows.argtypes = [_ENUM_PROC, wt.LPARAM]
        global _LASTINPUTINFO

        class _LASTINPUTINFO(ctypes.Structure):
            _fields_ = [('cbSize', wt.UINT), ('dwTime', wt.DWORD)]
        u.GetLastInputInfo.argtypes = [ctypes.POINTER(_LASTINPUTINFO)]
        u.GetLastInputInfo.restype = wt.BOOL
        k.GetTickCount.restype = wt.DWORD
        _W32 = (ctypes, wt, u, k)
    return _W32


def console_hwnd():
    """매크로(콘솔) 창 핸들 -> (핸들, 찾은 방법). 기본 콘솔: GetConsoleWindow / Windows 터미널: 창 제목"""
    if os.name != 'nt':
        return None, '윈도우 아님'
    ctypes, wt, u, k = w32()
    h = k.GetConsoleWindow()
    if h and u.IsWindowVisible(h):
        return h, '콘솔 창'
    title = 'FC 매크로 · ' + short_status()[0]
    h2 = u.FindWindowW(None, title)
    if h2:
        return h2, '창 제목(정확히)'
    try:
        ws = [w for w in pyautogui.getWindowsWithTitle('FC 매크로 ·') if w.title.startswith('FC 매크로 ·')]
        if ws:
            return ws[0]._hWnd, '창 제목(검색)'
    except Exception:
        pass
    return None, '못 찾음 (GetConsoleWindow=%s)' % (h,)


def apply_topmost():
    """현재 always_on_top 값을 창에 적용 -> (성공 여부, 설명)"""
    h, how = console_hwnd()
    if not h:
        return False, '매크로 창을 찾지 못함 - ' + how
    try:
        ctypes, wt, u, k = w32()
        HWND_TOPMOST, HWND_NOTOPMOST = wt.HWND(-1), wt.HWND(-2)
        SWP_NOSIZE, SWP_NOMOVE, SWP_NOACTIVATE = 0x0001, 0x0002, 0x0010
        ctypes.set_last_error(0)
        ok = u.SetWindowPos(h, HWND_TOPMOST if always_on_top else HWND_NOTOPMOST,
                            0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)
        if ok:
            return True, '적용됨 (%s)' % how
        return False, '창은 찾았지만(%s) 설정 실패 - 오류 코드 %s' % (how, ctypes.get_last_error())
    except Exception as e:
        return False, '설정 중 오류: %s' % e


def toggle_topmost():
    global always_on_top, last_error
    always_on_top = not always_on_top
    target_dialog.set_option('topmost', always_on_top)
    ok, why = apply_topmost()
    (LOG.info if ok else LOG.warning)('매크로 창 항상 위 %s: %s', '켜기' if always_on_top else '끄기', why)
    if os.name == 'nt':
        last_error = '' if ok else '항상 위 %s 실패 - %s [%s]' % ('켜기' if always_on_top else '끄기', why,
                                                             time.strftime('%H:%M:%S'))
    if always_on_top:
        run_checks(False)        # 게임 창을 가리는지 바로 점검 (가리면 버튼 인식이 안 됨)
        overlap = [t for ok_, t in check_lines if ok_ is False and '가림' in t]
        if overlap:
            last_error = '항상 위가 켜진 매크로 창이 게임 창을 가리고 있습니다 - 창을 옆으로 옮겨 주세요'
    draw_ui()


def open_data_folder():
    try:
        os.startfile(DATA_DIR)
    except Exception as e:
        LOG.warning('기록 폴더 열기 실패: %s', e)


def quit_app():
    LOG.info('트레이 메뉴에서 종료')
    tray.stop()
    os._exit(0)


if tray.start(paths.img('icon.png'), on_graph=lambda: on_press_f11(None), on_stop=lambda: on_press_f12(None),
              on_quit=quit_app, on_topmost=lambda: threading.Thread(target=toggle_topmost, daemon=True).start(),
              is_topmost=lambda: always_on_top, on_open_folder=open_data_folder,
              on_pause=lambda: on_press_f10(None), is_paused=lambda: is_paused):
    LOG.info('트레이 아이콘 시작')


def _startup():
    msg = os.environ.get('FCMACRO_UPDATE_MSG', '')
    if msg:
        LOG.info('업데이트: %s', msg)
        set_status(msg, 'info')
    try:
        start_bot()
    except Exception:
        note_error('디스코드 봇 시작')
    if always_on_top:
        ok, why = apply_topmost()
        LOG.info('시작 시 항상 위 적용: %s', why)
    run_checks()


_st = threading.Timer(1.0, _startup)
_st.daemon = True
_st.start()


def sub_loop():
    """스킵(S) 아이콘이 보이면 바로 S키 (게임 창이 앞에 있을 때만, 일시정지 중엔 안 누름)"""
    if not is_manager_mode or is_paused or wait_until is not None:
        return
    fore = pyautogui.getActiveWindow()
    searchStr = 'FC ONLINE'
    if fore is None or searchStr not in fore.title:
        return
    if time.time() - _last_s[0] < 1.0:          # 방금 눌렀으면 잠깐 기다림 (연타 방지)
        return
    try:
        locate('s.png', 0.7)
    except Exception:
        return
    press_key('s')
    _last_s[0] = time.time()


_last_s = [0.0]


set_interval(sub_loop, S_LOOP_SEC)


paths.mark_update_ok(DATA_DIR)          # 여기까지 오류 없이 왔으면 새 버전 정상 -> 실행기가 되돌리지 않음


# 메인 스레드를 계속 살려 둠.
# (Python 3.12 일부 버전은 메인 코드가 끝나면 '종료 중'으로 보고 새 타이머 생성을 거부함
#  -> "can't create new thread at interpreter shutdown" 오류가 반복되며 매크로가 멈춤)
if __name__ == '__main__':
    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        os._exit(0)
