# -*- coding: utf-8 -*-
# FC온라인 감독모드 매크로 v2.0
#  - v0.2(2024-05-31) 원본의 버튼 순서를 그대로 유지한 자동 진행
#  - v1.5: F9 하나로 자동진행(모든 티어·배치 경기) + 매판 기록 + 정지 조건(목표 점수 / 목표 순위 / 종료 시각)
#          F8 설정 변경, F10 일시정지, F11 기록 차트, 화면 1장으로 모든 버튼 인식(빠른 반응)
#  - 기록: 챔스 홈 화면 랭킹점수 + VS 화면 점수·순위, 승급/강등, 연속 진행
#  - v1.6: 디스코드 봇 원격 조작 (!상태 !차트 !정지 !재개 !종료)
#  - v1.7: 연패 경고/자동 일시정지, 하루 결산(자정), !설정 명령, F11 패턴 분석, 이적시장 자동 닫기
#  - v2.0: 실행기(exe) + 코드 패키지 분리 -> GitHub에서 자동 업데이트 (launcher.py)
#  - v2.1: 챔스 1승당 15 FC 계산 (매크로 창·차트·결산), 기록에 티어 칸 추가
#  - v2.2: 상대/내 포메이션 인식 + 포메이션별 승률, 텔레그램 알림·명령 메뉴, 챔스 무승부 기록
#  - v2.3: 원격 모드(원격 PC 화면 안의 게임 창 자동 인식), 포메이션 오인식 수정 (라인업 화면 = 상대)
#  - v2.4: 막판종료 (이번 판까지 하고 로비에서 매크로 정지 + 게임 창 닫기 + 알림)
#  - v3.0: 버튼식 매크로 창(gui.py), 단축키 직접 설정, 창 배치 저장(원격 모드는 제목줄 끌어서 이동)
#  - 단일 exe, 게임 창 영역만 인식, macro.log, 디스코드 알림, 멈춤 감지, 점검(F7), 트레이 아이콘
import keyboard
import threading
import pyautogui
import time
import pydirectinput
import os
import sys
import datetime

import numpy as np
import logging
import logging.handlers
import io
import traceback
import collections
import re

import cv2

import paths
DATA_DIR = paths.data_dir()                 # 문서\FC매크로_기록 (exe 폴더와 분리)
_MIGRATE_MSGS = paths.migrate_old_files(DATA_DIR)
os.chdir(DATA_DIR)                          # 기록/설정/로그는 모두 기록 폴더에 저장
_BACKUP = paths.backup_log(DATA_DIR)

import score_ocr
import score_log
import target_dialog
import notify
import session_stats
import chart_png
import tray
import discord_bot
import telegram_bot
import formation_ocr
import tactics                     # v3.2: 전술 자동 변경
import rest                        # v3.3: 쉬는 시간
try:
    import gui                      # v3.0 버튼식 매크로 창 (tkinter)
except Exception:                   # tkinter 가 없으면 예전 글자 창으로
    gui = None
import admin                        # v3.1: 관리자 권한이 아니면 관리자로 다시 켜기 (게임이 클릭을 무시하지 않게)
admin.ensure(DATA_DIR, enabled=target_dialog.get_option('run_as_admin', True) is not False,
             mark_ok=paths.mark_update_ok)          # 관리자로 다시 켜졌으면 여기서 이 프로세스는 끝남
admin.single_instance(DATA_DIR)          # v3.4.1: 이미 켜진 매크로가 있으면 물어보고 예전 것을 끔 (텔레그램이 예전 매크로로 대답하던 문제)
if formation_ocr.migrate_v23():
    _MIGRATE_MSGS.append('포메이션 숫자 견본을 새 기준으로 다시 배웁니다 (예전 견본은 formation_digits_v22 폴더)')

VERSION = 'v3.5 (2026-11-17)'

# ── 설정 ─────────────────────────────────────────────
SETTINGS = target_dialog.load_settings(4500)   # macro_settings.json (목표 점수·순위, 디스코드 웹훅)
TARGET_SCORE = SETTINGS['target']            # 랭킹점수가 이 점수 '이상'이면 정지 (None = 조건 없음)
TARGET_RANK = SETTINGS['rank']               # 순위가 이 순위 '이내'면 정지 (None = 조건 없음)
LOSE_STREAK = SETTINGS.get('lose_streak')     # N연패면 디스코드 알림 (None = 끔)
LOSE_PAUSE = SETTINGS.get('lose_pause', False)  # 연패 경고 때 일시정지도
DAILY_REPORT = SETTINGS.get('daily_report', False)   # 매일 자정 하루 결산 리포트
MARKET_IDLE_SEC = 60                           # 이적시장 창이 열려 있고 사람 입력이 이 시간(초) 없으면 X로 닫음
PROMO_WAIT = SETTINGS.get('promo_wait', False)   # 챔스 승급 대기: 슈퍼챌린저에서 다음 판 이기면 승급이면 멈추고 자정 지나 재개
PROMO_TIER = '슈퍼챌린저'                      # 챔스 바로 아래 티어
MIDNIGHT_RESUME_SEC = 30                       # 자정 지나 이만큼 뒤에 재개 (00:00:30)
PROMO_GAP = 3                                  # 승점 막대에서 초록 선(승격선)까지 이 점수(칸) 이내면 멈춤 = 다음 판 이기면 승급
PROMO_LINE_FALLBACK = 12                       # 승격선을 못 읽으면 낮은 쪽(12)으로 보고 일찍 멈춤 (자정 전에 올라가는 것 방지)
WEBHOOK = SETTINGS['webhook']                # 디스코드 웹훅 주소 (비어 있으면 알림 안 보냄)
OCR_MAX_FAIL = 3             # 챔스 홈 화면 점수 인식이 연속 이 횟수만큼 실패하면 안전하게 정지
HISTORY_SHOW = 10            # (글자 창) 화면에 보여줄 최근 기록 수
GUI_ROWS = 20                # (매크로 창) 최근 기록 표 줄 수
SAME_GAME_SEC = 90           # 공식경기를 눌렀는데 VS 화면 없이 이 시간 안에 홈으로 오면 '클릭 재시도' (판수 안 셈)
SAMPLE_MAX = 100             # 못 읽은 판의 VS 화면 이미지 최대 저장 수 (rank_samples 폴더)
STALL_STATIC_MIN = 10        # 게임 화면이 이 시간(분) 동안 전혀 안 바뀌면 '멈춤' 알림
NO_GAME_MIN = 30             # 이 시간(분) 동안 새 판이 시작되지 않으면 알림
GAME_WINDOW_TITLE = 'FC ONLINE'
GAME_CLIENT_SIZE = (1280, 720)   # 버튼 이미지가 맞춰진 게임 화면 크기
CONT_GRACE_SEC = 120         # 시작 직후 이 시간 안에 뜬 VS 화면은 '연속 진행' 판단에서 제외

# 속도 (v1.5: 원본은 4초마다 확인 + 버튼마다 화면을 새로 찍음)
LOOP_SEC = 0.5               # 화면 확인 주기 (화면 1장으로 모든 버튼을 찾음)
S_LOOP_SEC = 0.3             # 스킵(S) 확인 주기
CLICK_HOVER_SEC = 0.5        # 버튼 위에 마우스를 올린 뒤 누르기까지 (원본과 같게. v1.5~2.0의 0.2초는 느린 PC에서 클릭이 씹힘)
CLICK_HOLD_SEC = 0.05        # 마우스 누른 채로 있는 시간
CLICK_AFTER_SEC = 0.1        # 뗀 뒤 마우스를 치우기까지 (원본과 같게)
AFTER_CLICK_SEC = 0.8        # 클릭 후 화면이 바뀔 때까지 다음 동작 대기
SAME_BUTTON_SEC = 2.5        # 같은 버튼을 이 시간 안에 다시 누르지 않음 (화면 전환 중 두 번 클릭 방지)
VS_HOLD_SEC = 6              # VS 화면에서 점수·순위를 읽을 때까지 진행 버튼을 누르지 않고 기다리는 최대 시간
VS_READ_FAILS = 10           # VS 화면 글씨가 보이는데 이만큼 못 읽으면 그 판은 빈칸 (이미지 저장)
SCORE_JUMP_MAX = 300         # VS 점수가 직전 판보다 이만큼 넘게 다르면 잘못 읽은 것으로 보고 버림
TIER_DX, TIER_DY, TIER_W, TIER_H = -790, -478, 250, 46   # 홈 화면 티어명('마스터 3부 감독') 영역 (공식경기 버튼 기준)
TIER_SAMPLE_MAX = 60
FORM_LABEL_CONF = 0.85       # 라인업 화면 '포메이션' 라벨 인식 기준
FORM_ATTACH_SEC = 360        # 판 시작 후 이 시간 안에 읽은 포메이션만 그 판에 붙임 (늦으면 다음 판용으로 보관)
FORM_PENDING_SEC = 180       # 보관한 포메이션은 이 시간 안에 다음 판이 시작되면 그 판에 붙임 (연속 진행 대비)
FORM_GONE_SEC = 4            # 라인업 화면이 이 시간 넘게 안 보이면 다음에 보이는 것은 새 화면
FORM_FAIL_SAVE = 4           # 같은 화면에서 이만큼 못 읽으면 글씨 부분 저장 + 그 판은 '?'(미인식)

# ── 실행 로그 (macro.log, 1MB씩 최대 3개) ─────────────────
LOG = logging.getLogger('macro')
LOG.setLevel(logging.INFO)
try:
    _h = logging.handlers.RotatingFileHandler('macro.log', maxBytes=1_000_000, backupCount=2, encoding='utf-8')
    _h.setFormatter(logging.Formatter('%(asctime)s %(levelname)-7s %(message)s', '%Y-%m-%d %H:%M:%S'))
    LOG.addHandler(_h)
except Exception:
    pass
last_error = ''              # 콘솔 표시용 마지막 오류
GUI_ON = False               # v3.0 매크로 창(버튼식)이 떠 있으면 True (글자 창 출력은 안 함)
for _m in _MIGRATE_MSGS:
    LOG.info('기록 이전: %s', _m)
if _BACKUP:
    LOG.info('기록 백업: %s', _BACKUP)


def set_interval(func, sec):
    def func_wrapper():
        set_interval(func, sec)
        try:
            func()
        except Exception:
            note_error(func.__name__)
    t = threading.Timer(sec, func_wrapper)
    t.daemon = True          # 매크로 종료 시 타이머가 프로그램을 붙잡지 않게
    try:
        t.start()
    except RuntimeError:     # 종료 중이면 다음 예약을 조용히 생략
        return None
    return t


is_manager_mode = False      # 자동진행 중 (F9 시작 ~ F12/정지 조건)
is_paused = False            # F10 일시정지 (클릭·S키 입력 모두 멈춤, 기록은 유지)

# 진행 기록 (F9 시작 때 초기화, 멈춰도 화면에는 남김)
# champions_history 한 줄: [게임번호, 점수|None, 'HH:MM:SS', 순위|None, epoch초, 비고, 기록시각(ts), 결과('승'/'무'/'패'|None), 챔스 여부,
#                          상대 포메이션|None, 내 포메이션|None]
H_NO, H_SCORE, H_TIME, H_RANK, H_EPOCH, H_NOTE, H_TS, H_RES, H_CHAMP, H_OPP, H_MINE, H_TAC = range(12)
champions_game_count = 0
champions_history = []
champions_status = ''
champions_status_kind = 'info'   # run / warn / stop / done / info  (콘솔 색)
champions_fail_count = 0
champions_last_game_time = 0.0  # 마지막으로 판수를 센 시각
champions_session_start = 0.0
champions_final_score = None    # 정지 시점에 읽은 점수 (마지막 판 결과 확정용)
end_stop_at = None              # 종료 시각(epoch) 이후 새 판 시작 안 함 (None = 없음)
end_stop_label = ''
end_stop_text = None            # 설정창에 다시 보여줄 'HH:MM'
last_rank = None                # 이번 세션에서 가장 최근에 읽은 내 순위 (목표 순위 판단)
last_known_score = None         # 가장 최근에 읽은 내 점수 (VS 점수 오인 걸러내기)
wait_until = None               # 이 시각(epoch)까지 대기 (시작 예약 / 챔스 승급 대기)
last_game = {'on': False, 't': 0.0, 'game': 0, 'warned': False, 'by': ''}   # 막판종료 예약 (이번 판 끝나고 로비에서 끝)
wait_reason = ''                # 'start' / 'promo'
wait_info = ''                  # 화면 표시용 설명
start_text = None               # 설정창에 다시 보여줄 시작 시각 'HH:MM'
promo_released_date = None      # 자정 재개한 날 (그날은 승급 대기를 다시 걸지 않음)
strip_last = None               # 마지막으로 읽은 결과 칸 ['승','패',...] (챔스 아래 티어 승/무/패 판정)

# VS 화면
vs_visible = False
vs_expect = False               # 공식경기를 눌렀고 아직 VS 화면을 못 봄
vs_seen_at = 0.0
vs_warned = False
cont_count = 0
vs_pending = None               # 점수·순위를 아직 못 읽은 판

# 티어 변화 (홈 화면 티어명 글씨 비교)
tier_last_mask = None
tier_last_champ = None
popup_hint = None               # 승급/강등 확인 팝업을 누른 경우 그 이름 (방향 참고)

loop_lock = threading.Lock()  # main_loop가 길어져도 동시에 두 번 돌지 않게 함
draw_lock = threading.Lock()
notify_status = ''           # 마지막 디스코드 전송 결과 (콘솔 표시용)
check_lines = []             # [(True/False/None, 문구)] 점검 결과 (F7)
always_on_top = bool(target_dialog.get_option('topmost', False))   # F6: 매크로 창 항상 위
_last_click = {}             # 버튼별 마지막 클릭 시각
_next_action_at = [0.0]      # 클릭 직후 화면이 바뀔 때까지 대기

# ── 콘솔 색 (Windows 10 이상 콘솔/터미널) ─────────────────
if os.name == 'nt':
    os.system('')            # 콘솔 색상 코드(VT) 사용 켜기
C = {'reset': '\x1b[0m', 'g': '\x1b[92m', 'y': '\x1b[93m', 'r': '\x1b[91m', 'c': '\x1b[96m',
     'b': '\x1b[94m', 'dim': '\x1b[90m', 'bold': '\x1b[1m', 'm': '\x1b[95m'}
KIND_COLOR = {'run': C['g'], 'warn': C['y'], 'stop': C['r'], 'done': C['bold'] + C['g'], 'info': C['c']}


def col(text, key):
    return C[key] + text + C['reset']


_err_seen = {}   # 같은 오류 반복 시 로그 폭주 방지: {(위치, 오류 마지막 줄): [처음 기록 시각, 이후 반복 횟수]}


def note_error(where):
    """반복 작업 중 예외: 로그에 전체 내용 기록(같은 오류는 10분에 한 번만), 콘솔에는 한 줄 표시 (매크로는 계속 동작)"""
    global last_error
    tb = traceback.format_exc()
    key = (where, tb.strip().splitlines()[-1] if tb.strip() else '')
    now = time.time()
    rec = _err_seen.get(key)
    if rec is None or now - rec[0] >= 600:
        extra = (' (지난 기록 이후 %d번 더 반복됨)' % rec[1]) if rec and rec[1] else ''
        LOG.error('%s 오류%s\n%s', where, extra, tb)
        _err_seen[key] = [now, 0]
    else:
        rec[1] += 1
    last_error = '%s 오류 발생 [%s] - macro.log 참고' % (where, time.strftime('%H:%M:%S'))


def set_status(text, kind='info'):
    global champions_status, champions_status_kind
    if text != champions_status:
        (LOG.warning if kind in ('warn', 'stop') else LOG.info)('상태: %s', text)
    champions_status = text
    champions_status_kind = kind


def current_stats():
    return session_stats.compute(champions_history, TARGET_SCORE, champions_final_score)


def fmt_num(v, unit=''):
    return '-' if v is None else format(v, ',') + unit


def stop_conditions_text():
    parts = []
    if TARGET_SCORE is not None:
        parts.append('점수 %s점 이상' % format(TARGET_SCORE, ','))
    if TARGET_RANK is not None:
        parts.append('순위 %s위 이내' % format(TARGET_RANK, ','))
    if PROMO_WAIT:
        parts.append('챔스 승급 대기(자정 재개)')
    if LOSE_STREAK:
        parts.append('%d연패 %s' % (LOSE_STREAK, '일시정지' if LOSE_PAUSE else '알림'))
    if end_stop_at and is_manager_mode:
        parts.append('%s 이후' % end_stop_label)
    elif end_stop_text and not is_manager_mode:
        parts.append('%s 이후' % end_stop_text)
    return ' / '.join(parts) if parts else '없음 (계속 진행)'


def draw_ui():
    L = []
    L.append(col('FC온라인 감독모드 매크로 - ' + VERSION, 'c'))
    L.append(col('-' * 60, 'dim'))
    for aid, name, _d, _f in globals().get('ACTIONS', []):
        k = HOTKEYS.get(aid)
        if not k:
            continue
        extra = (' (지금: %s)' % ('켜짐' if always_on_top else '꺼짐')) if aid == 'topmost' else ''
        L.append('%-9s - %s%s' % (key_label(k), name, extra))
    L.append(col('기록 폴더: ' + DATA_DIR, 'dim'))
    L.append(col('-' * 60, 'dim'))
    L.append('')
    if is_manager_mode and is_paused:
        L.append(col('❚❚ 일시정지 중 - F10으로 재개 (버튼 클릭·S키 입력 멈춤, 기록은 이어짐)', 'y'))
    elif is_manager_mode and wait_until is not None:
        left = max(0, wait_until - time.time())
        L.append(col('⏳ 대기 중 - %s · %s에 자동 %s (남은 시간 %s)' % (
            wait_info, time.strftime('%H:%M', time.localtime(wait_until)), '시작' if wait_reason == 'start' else '재개',
            session_stats.fmt_minutes(left / 60)), 'y'))
    elif is_manager_mode and last_game['on']:
        L.append(col('● 자동진행 중 - 🏁 막판종료 예약: %d번째 게임이 끝나고 로비로 오면 정지 + 게임 창 닫기' % last_game['game'], 'y'))
    elif is_manager_mode:
        L.append(col('● 자동진행 중', 'g'))
    else:
        L.append(col('○ 대기 중 - F9로 시작', 'dim'))
    L.append('  정지 조건: ' + stop_conditions_text())
    if last_error:
        L.append(col('  ! ' + last_error, 'y'))
    if check_lines and (not is_manager_mode or time.time() - _check_shown[0] < 30):   # F7 결과는 진행 중에도 30초 표시
        L.append('')
        L.append(col('[점검]', 'bold') + col('  (F7로 다시 점검)', 'dim'))
        for ok, text in check_lines:
            mark = col('  ✔ ', 'g') if ok is True else (col('  ✖ ', 'r') if ok is False else col('  · ', 'dim'))
            L.append(mark + text)
    if champions_status or champions_history:
        L.append('')
        L.append(col('[진행 기록]', 'bold'))
        if champions_status:
            L.append('  상태  : ' + KIND_COLOR.get(champions_status_kind, '') + champions_status + C['reset'])
        st = current_stats()
        if tier_now or tier_last_mask is not None or tier_events:
            t = tier_now or col('이름 미등록 (기록 폴더\\tier_samples 의 이름없음 파일 이름을 바꿔 주세요)', 'dim')
            ups = sum(1 for _t, e in tier_events if e == '승급')
            dns = sum(1 for _t, e in tier_events if e == '강등')
            ev = ''
            if tier_events:
                lt, le = tier_events[-1]
                ev = ' · ' + col('▲승급 %d' % ups, 'g') + ' ' + col('▼강등 %d' % dns, 'r') + \
                    col(' (마지막: %s %s%s)' % (lt, {'승급': '▲', '강등': '▼'}.get(le, '◆'), le), 'dim')
            L.append('  티어  : ' + t + ev)
        L.append('  통계  : ' + session_stats.summary_line(st))
        td = today_summary()
        fc_line = fc_text(td)
        if fc_line:
            L.append('  FC    : ' + col(fc_line, 'y'))
        if td:
            L.append('  오늘  : ' + td['line'])
            if td['flow']:
                L.append('  흐름  : ' + ' '.join(col(r, {'승': 'g', '무': 'y', '패': 'r'}[r]) for r in td['flow'])
                         + col('  (최근 %d판 · %s)' % (len(td['flow']), td['streak']), 'dim'))
        if TARGET_SCORE is not None:
            L.append('  예상  : ' + col(session_stats.eta_line(st, TARGET_SCORE), 'm'))
        if remote['on']:
            L.append('  화면  : ' + col('원격 모드', 'c') + col(' - 원격 화면 안의 게임 창을 읽는 중 (ESC는 화면 클릭, S키는 원격 창이 앞일 때)', 'dim'))
        L.append('  알림  : ' + ((col('디스코드 켜짐', 'g') + (col('  (' + notify_status + ')', 'dim') if notify_status else ''))
                                if WEBHOOK else col('디스코드 꺼짐 (F8 설정창에서 웹훅 입력)', 'dim')))
        if BOT is not None:
            L.append('  봇    : ' + col(BOT.status, 'g' if BOT.ok else ('r' if BOT.ok is False else 'dim')))
        if TG is not None:
            L.append('  텔레  : ' + col(TG.status, 'g' if TG.ok else ('r' if TG.ok is False else 'dim'))
                     + (col('  (' + TG.last_send + ')', 'dim') if TG.last_send else ''))
        if champions_history:
            L.append(col('  ---- 최근 기록 ----', 'dim'))
            hist = champions_history
            for i in range(len(hist) - 1, max(-1, len(hist) - 1 - HISTORY_SHOW), -1):
                h = hist[i]
                s = h[H_SCORE]
                nxt = hist[i + 1][H_SCORE] if i + 1 < len(hist) else champions_final_score
                d = (nxt - s) if (s is not None and nxt is not None) else None
                ds = (' %+d' % d) if d is not None else ''
                if h[H_RES]:
                    res = col(' ' + h[H_RES] + ds, {'승': 'g', '무': 'y', '패': 'r'}[h[H_RES]])
                elif i == len(hist) - 1 and is_manager_mode:
                    res = col(' 진행중', 'dim')
                else:
                    res = '      '
                note = col(' ' + h[H_NOTE], 'm') if h[H_NOTE] else ''
                of = h[H_OPP] if len(h) > H_OPP else None
                fm = col(' vs ' + form_text(of), 'c') if of else ''
                L.append('  %4d번째 | %7s점 | %9s | %s |%s%s%s'
                         % (h[H_NO], fmt_num(s), rank_text(h[H_RANK]), h[H_TIME], res, fm, note))
    _last_lines[0] = L
    if not GUI_ON:                                   # 버튼식 창이 떠 있으면 글자 창은 숨겨져 있음
        out = '\x1b[H' + '\n'.join(line + '\x1b[K' for line in L) + '\n\x1b[J'
        with draw_lock:
            print(out, end='', flush=True)
    update_title_and_tray()


_last_lines = [[]]
_ANSI = __import__('re').compile(r'\x1b\[[0-9;]*[A-Za-z]')


# ── 디스코드 봇 (원격 조작) ───────────────────────────
BOT = None


def bot_status_lines():
    """매크로 창 내용(메뉴 제외)을 글자만 뽑아서"""
    draw_ui()
    plain = [_ANSI.sub('', l).rstrip() for l in _last_lines[0]]
    seps = [i for i, l in enumerate(plain) if l.startswith('-----')]
    body = plain[seps[1] + 1:] if len(seps) >= 2 else plain
    return [l for l in body if l.strip() and not l.strip().startswith(('봇 ', '텔레 '))][:30]


def _cmd_status(_args):
    return {'title': '📋 지금 상황 [%s]' % time.strftime('%H:%M:%S'), 'lines': ['```'] + bot_status_lines() + ['```'],
            'kind': 'warn' if is_paused or wait_until else ('done' if is_manager_mode else 'info'),
            'image_fn': grab_game_jpeg, 'image_name': 'screen.jpg'}


def _cmd_chart(_args):
    recs = score_log.read_records()
    if not recs:
        return {'title': '아직 기록이 없습니다', 'kind': 'info'}
    return {'title': '📈 최근 기록 (최대 40판)', 'lines': [session_stats.summary_line(current_stats())],
            'image_fn': lambda: chart_png_bytes('최근 기록 (최대 40개)'), 'image_name': 'chart.png'}


def _cmd_pause(_args):
    if not is_manager_mode:
        return {'title': '자동진행 중이 아닙니다', 'kind': 'info'}
    if is_paused:
        return {'title': '이미 일시정지 중입니다', 'lines': ['!재개 로 다시 진행'], 'kind': 'warn'}
    on_press_f10(None)
    return {'title': '❚❚ 일시정지했습니다', 'lines': ['!재개 로 다시 진행'], 'kind': 'warn'}


def _cmd_resume(_args):
    if not is_manager_mode:
        return {'title': '자동진행 중이 아닙니다', 'lines': ['종료된 상태에서는 PC에서 F9로 시작해 주세요'], 'kind': 'info'}
    if not is_paused:
        extra = ['지금은 %s · %s에 자동 %s' % (wait_info, time.strftime('%H:%M', time.localtime(wait_until)),
                 '시작' if wait_reason == 'start' else '재개')] if wait_until else []
        return {'title': '일시정지 상태가 아닙니다', 'lines': extra, 'kind': 'info'}
    on_press_f10(None)
    return {'title': '▶ 다시 진행합니다', 'kind': 'done'}


LAST_GAME_WARN_SEC = 40 * 60   # 막판종료 예약 후 이 시간 넘게 로비가 안 나오면 알림 (한 번)
LAST_GAME_CLOSE_SEC = 8         # 창 닫기 요청 후 기다리는 시간 (안 닫히면 강제 종료)
LAST_GAME_KILL_SEC = 12         # 강제 종료 후 확인 시간


def request_last_game(by=''):
    """막판종료 예약 -> (제목, 줄 목록, kind)"""
    global is_paused, wait_until, wait_reason, wait_info
    if not is_manager_mode:
        return '자동진행 중이 아닙니다', ['막판종료는 자동진행 중에만 예약할 수 있어요.'], 'info'
    if last_game['on']:
        return '이미 막판종료 예약 중입니다', ['%d번째 게임이 끝나고 로비로 돌아오면 게임 창을 닫습니다.' % last_game['game'],
                                         "취소: '!막판종료 취소'"], 'info'
    last_game.update(on=True, t=time.time(), game=champions_game_count, warned=False, by=by)
    lines = []
    if is_paused:
        is_paused = False                               # 일시정지 중이면 풀어야 로비까지 진행됨
        lines.append('일시정지를 풀고 진행합니다.')
    if wait_until is not None:
        wait_until, wait_reason, wait_info = None, '', ''   # 대기 중(로비) -> 바로 로비 확인으로
        lines.append('대기를 끝내고 바로 정리합니다.')
    LOG.info('막판종료 예약 (%s) - %d번째 게임 중', by or 'PC', champions_game_count)
    set_status('막판종료 예약 - 이번 판이 끝나고 로비로 오면 매크로 정지 + 게임 창 닫기', 'warn')
    draw_ui()
    lines = ['지금 판(%d번째)은 끝까지 진행하고, 로비로 돌아오면 공식경기를 누르지 않고' % champions_game_count,
             '매크로를 멈춘 뒤 게임 창을 닫습니다. 닫히면 다시 알려 드려요.'] + lines + ["취소: '!막판종료 취소'"]
    if remote['on']:
        lines.append('※ 원격 모드라 게임 창은 직접 닫아야 합니다 (매크로 정지까지만 자동)')
    return '🏁 막판종료 예약 - 이번 판까지만 합니다', lines, 'warn'


def cancel_last_game():
    if not last_game['on']:
        return '막판종료 예약이 없습니다', [], 'info'
    last_game['on'] = False
    LOG.info('막판종료 예약 취소')
    set_status('막판종료 예약 취소 - 계속 진행', 'ok')
    draw_ui()
    return '막판종료를 취소했습니다', ['자동진행을 계속합니다.'], 'done'


def _cmd_last_game(args):
    if args.strip() in ('취소', 'cancel', '해제'):
        t, l, k = cancel_last_game()
        return {'title': t, 'lines': l, 'kind': k}
    t, l, k = request_last_game('원격 명령')
    r = {'title': t, 'lines': l, 'kind': k}
    if last_game['on']:
        r['buttons'] = [('막판종료 취소', '막판종료 취소')]       # 텔레그램: 메시지 아래 취소 버튼
    return r


def finish_last_game(score, champ):
    """막판종료: 로비 도착 -> 마지막 판 정리, 매크로 정지, 게임 창 닫기 (닫기는 따로 스레드에서)"""
    global champions_final_score
    champions_final_score = score
    idx = len(champions_history) - 1
    if score is not None:
        settle_by_score(idx, score)
    safe_log('-', score, '막판종료')
    last = champions_history[idx] if idx >= 0 else None
    last_game['on'] = False
    shot = None
    try:
        shot = grab_game_jpeg()                         # 닫기 전 마지막 로비 화면
    except Exception:
        pass
    stop_all('막판종료 - 매크로 정지, 게임 창 닫는 중 [%s]' % time.strftime('%H:%M:%S'), 'done')
    LOG.info('막판종료: 로비 도착 -> 매크로 정지 (점수 %s)', score)
    draw_ui()
    threading.Thread(target=_close_and_report, args=(last, score, shot), daemon=True).start()
    return False


def _close_and_report(last, score, shot):
    try:
        ok, how = close_game_window()
    except Exception as e:
        ok, how = False, '닫기 오류: %s' % e
    LOG.info('막판종료: 게임 창 %s - %s', '닫힘' if ok else '못 닫음', how)
    lines = []
    if last is not None:
        res = last[H_RES] or '결과 미확인'
        lines.append('🎮 마지막 판(%d번째): %s%s' % (last[H_NO], res,
                     (' · 랭킹점수 %s점' % format(score, ',')) if score is not None else ''))
    try:
        _t, day_lines, _r = day_summary(datetime.date.today())
        lines += ['오늘 ' + x for x in day_lines[:2]]
    except Exception:
        pass
    if ok:
        set_status('막판종료 완료 - 게임 창 닫음 (%s) [%s]' % (how, time.strftime('%H:%M:%S')), 'done')
        alert('done', '✅ 막판종료 완료 - 게임 창을 닫았습니다', ['이제 다른 곳에서 피파에 접속해도 됩니다.', ''] + lines, image=shot)
    else:
        set_status('막판종료 - 매크로는 멈췄지만 게임 창을 못 닫음 (%s)' % how, 'warn')
        alert('warn', '⚠️ 막판종료 - 매크로는 멈췄지만 게임 창을 못 닫았습니다',
              [how, '로비에서 멈춰 있으니 게임만 직접 닫아 주세요.', ''] + lines, image=shot)
    draw_ui()


def close_game_window():
    """FC ONLINE 창 닫기 -> (성공 여부, 방법/이유). 1) 창 닫기 요청 2) 안 닫히면 그 프로그램 강제 종료 3) taskkill"""
    if remote['on'] or (find_game_window() is None and remote_region(force=True) is not None):
        return False, '원격 모드 - 원격 PC의 게임은 아직 자동으로 닫지 못함'
    win = find_game_window()
    if win is None:
        return True, '이미 닫혀 있음'
    if os.name != 'nt':
        return False, '윈도우가 아님'
    import ctypes
    import ctypes.wintypes as wt
    u = ctypes.WinDLL('user32', use_last_error=True)
    k = ctypes.WinDLL('kernel32', use_last_error=True)
    u.PostMessageW.argtypes = [wt.HWND, wt.UINT, wt.WPARAM, wt.LPARAM]
    u.IsWindow.argtypes = [wt.HWND]
    u.GetWindowThreadProcessId.argtypes = [wt.HWND, ctypes.POINTER(wt.DWORD)]
    k.OpenProcess.restype = wt.HANDLE
    k.OpenProcess.argtypes = [wt.DWORD, wt.BOOL, wt.DWORD]
    k.TerminateProcess.argtypes = [wt.HANDLE, wt.UINT]
    k.CloseHandle.argtypes = [wt.HANDLE]
    hwnd = win._hWnd
    pid = wt.DWORD(0)
    u.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))

    def gone(sec):
        end = time.time() + sec
        while time.time() < end:
            if not u.IsWindow(hwnd):
                _win_cache['t'] = 0
                return True
            time.sleep(0.5)
        return not u.IsWindow(hwnd)

    u.PostMessageW(hwnd, 0x0010, 0, 0)                   # WM_CLOSE (정상 닫기 요청)
    if gone(3):
        return True, '정상 종료'
    try:
        fw = pyautogui.getActiveWindow()                 # 게임이 '종료할까요?' 확인 창을 띄웠으면 Enter로 확인
        if fw is not None and GAME_WINDOW_TITLE in (fw.title or ''):
            press_key('enter')
    except Exception:
        pass
    if gone(LAST_GAME_CLOSE_SEC):
        return True, '정상 종료'
    if pid.value:
        h = k.OpenProcess(0x0001 | 0x00100000, False, pid.value)   # PROCESS_TERMINATE | SYNCHRONIZE
        if h:
            k.TerminateProcess(h, 0)
            k.CloseHandle(h)
            if gone(LAST_GAME_KILL_SEC):
                return True, '강제 종료 (닫기 확인 창이 떠서)'
        try:
            import subprocess
            subprocess.run(['taskkill', '/PID', str(pid.value), '/F', '/T'], capture_output=True, timeout=15,
                           creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0))
        except Exception:
            pass
        if gone(LAST_GAME_KILL_SEC):
            return True, '강제 종료 (taskkill)'
    return False, '창이 닫히지 않음 (매크로를 관리자 권한으로 실행하면 닫을 수 있음)'


def last_game_watch():
    """막판종료 예약 후 오래 로비가 안 나오면 한 번 알림 (게임은 그대로 둠)"""
    if not (last_game['on'] and is_manager_mode) or last_game['warned']:
        return
    if time.time() - last_game['t'] >= LAST_GAME_WARN_SEC:
        last_game['warned'] = True
        alert('warn', '⚠️ 막판종료 예약 후 %d분째 로비가 안 나옵니다' % (LAST_GAME_WARN_SEC // 60),
              ['게임이 멈췄거나 다른 화면에 있을 수 있어요. 게임 창은 닫지 않았습니다.', '화면을 확인해 주세요.'],
              image='screen')


def _cmd_stop(_args):
    if not is_manager_mode:
        return {'title': '이미 멈춰 있습니다', 'kind': 'info'}
    on_press_f12(None)
    return {'title': '⏹ 자동진행을 종료했습니다', 'lines': ['다시 시작은 PC에서 F9'], 'kind': 'stop'}


# ── 하루 결산 ───────────────────────────────────────
def day_summary(day):
    """day(date)의 기록 요약 -> (제목, 줄 목록, 그날 기록) / 기록 없으면 (None, [], [])"""
    key = day.strftime('%Y-%m-%d')
    recs = [r for r in score_log.read_records() if r[0].startswith(key)]
    games = [r for r in recs if not score_log.is_stop_row(r)]
    if not games:
        return None, [], recs
    res = [r[5] for r in games if r[5] in ('승', '무', '패')]
    w, d, l = res.count('승'), res.count('무'), res.count('패')
    known = [r[2] for r in recs if r[2] is not None]
    ranks = [r[3] for r in recs if r[3] is not None]
    notes = [p for r in games for p in (r[4] or '').split(', ')]
    best_w = best_l = cur = 0
    last = None
    for x in res:
        cur = cur + 1 if x == last else 1
        last = x
        if x == '승':
            best_w = max(best_w, cur)
        elif x == '패':
            best_l = max(best_l, cur)
    lines = ['🎮 %d판 · %d승 %d무 %d패%s' % (len(games), w, d, l, (' (승률 %d%%)' % round(w * 100 / len(res))) if res else '')]
    if known:
        lines.append('📈 랭킹점수 %s → %s (%+d) · 최고 %s / 최저 %s' % (format(known[0], ','), format(known[-1], ','),
                     known[-1] - known[0], format(max(known), ','), format(min(known), ',')))
    if ranks:
        lines.append('🏅 순위 %s위 → %s위 · 최고 %s위' % (format(ranks[0], ','), format(ranks[-1], ','), format(min(ranks), ',')))
    if notes.count('승급') or notes.count('강등'):
        lines.append('🔺 승급 %d번 · 🔻 강등 %d번' % (notes.count('승급'), notes.count('강등')))
    if res:
        lines.append('🔁 최장 연승 %d · 최장 연패 %d' % (best_w, best_l))
    fw, fc = score_log.fc_of(games)
    if fw or any(score_log.is_champs(r) for r in games):
        lines.append('💰 챔스 %d승 → %s FC (1승당 %d FC)' % (fw, format(fc, ','), score_log.FC_PER_WIN))
    ft = [x for x in score_log.formation_table(recs) if x[0] != '미인식']
    if ft:
        lines.append('⚔ 상대 포메이션: ' + ' · '.join('%s %d승%d무%d패' % (f, w, d, l) for f, _n, w, d, l in ft[:3]))
    lines.append('⏱ %s ~ %s' % (games[0][0][11:16], recs[-1][0][11:16]))
    title = '📅 %s 결산' % ('%d/%d(%s)' % (day.month, day.day, '월화수목금토일'[day.weekday()]))
    return title, lines, recs


def daily_report_check():
    """자정이 지나면 전날 결산을 한 번 보냄 (설정에서 켰을 때)"""
    if not (DAILY_REPORT and any_notify()):
        return
    yesterday = datetime.date.today() - datetime.timedelta(days=1)
    if target_dialog.get_option('daily_last') == yesterday.isoformat():
        return
    target_dialog.set_option('daily_last', yesterday.isoformat())
    title, lines, recs = day_summary(yesterday)
    if title is None:
        LOG.info('하루 결산: %s 기록 없음 - 보내지 않음', yesterday)
        return
    LOG.info('하루 결산 전송: %s', yesterday)
    notify_all(title, lines, 'info',
               image_fn=lambda: chart_png.render(recs[-60:], TARGET_SCORE, '%s 기록' % yesterday.strftime('%m/%d')),
               image_name='day.png')


def _cmd_day(args):
    day = datetime.date.today() - datetime.timedelta(days=1) if args.strip() == '어제' else datetime.date.today()
    title, lines, recs = day_summary(day)
    if title is None:
        return {'title': '%s 기록이 없습니다' % ('어제' if args.strip() == '어제' else '오늘'), 'kind': 'info'}
    return {'title': title + ('' if args.strip() == '어제' else ' (지금까지)'), 'lines': lines, 'kind': 'info',
            'image_fn': lambda: chart_png.render(recs[-60:], TARGET_SCORE, day.strftime('%m/%d 기록')), 'image_name': 'day.png'}


# ── !설정 (디스코드에서 설정 바꾸기) ─────────────────────────
SET_HELP = ['!설정 → 지금 설정 보기',
            '!설정 점수 4500 / 없음      목표 점수', '!설정 순위 20 / 없음        목표 순위',
            '!설정 종료 07:00 / 없음     종료 시각', '!설정 연패 5 / 없음         연패 경고',
            '!설정 연패정지 켜기/끄기    연패 때 일시정지', '!설정 대기 켜기/끄기        챔스 승급 대기',
            '!설정 결산 켜기/끄기        하루 결산 리포트']
_OFF = ('없음', '끄기', '꺼', 'off', '0', '-')
_ON = ('켜기', '켜', 'on', '1')


def settings_lines():
    return ['목표 점수: %s' % target_text_or('점', TARGET_SCORE), '목표 순위: %s' % target_text_or('위', TARGET_RANK),
            '종료 시각: %s' % (end_stop_label if (is_manager_mode and end_stop_at) else (end_stop_text or '없음')),
            '연패 경고: %s' % (('%d연패 %s' % (LOSE_STREAK, '+ 일시정지' if LOSE_PAUSE else '알림')) if LOSE_STREAK else '끔'),
            '챔스 승급 대기: %s' % ('켜짐' if PROMO_WAIT else '끔'), '하루 결산: %s' % ('켜짐' if DAILY_REPORT else '끔')]


def target_text_or(unit, v):
    return '없음' if v is None else format(v, ',') + unit


def _cmd_settings(args):
    global TARGET_SCORE, TARGET_RANK, PROMO_WAIT, end_stop_text
    parts = args.split()
    if not parts:
        return {'title': '⚙ 지금 설정', 'lines': settings_lines() + ['', '바꾸기: !설정 도움'], 'kind': 'info'}
    key, val = parts[0], ' '.join(parts[1:]).strip()
    off = val.lower() in _OFF
    on = val.lower() in _ON
    if key in ('점수', '목표점수'):
        v = None if off else target_dialog.parse_target(val)
        if v is None and not off:
            return {'title': '숫자로 입력해 주세요', 'lines': ['예: !설정 점수 4500  /  !설정 점수 없음'], 'kind': 'warn'}
        TARGET_SCORE = v
    elif key in ('순위', '목표순위'):
        v = None if off else target_dialog.parse_rank(val)
        if v is None and not off:
            return {'title': '숫자로 입력해 주세요', 'lines': ['예: !설정 순위 20  /  !설정 순위 없음'], 'kind': 'warn'}
        TARGET_RANK = v
    elif key in ('종료', '종료시각'):
        st, hhmm = target_dialog.parse_stop_time('' if off else val)
        if st != 'ok':
            return {'title': '시각 형식이 아닙니다', 'lines': ['예: !설정 종료 07:00  /  !설정 종료 없음'], 'kind': 'warn'}
        if is_manager_mode:
            set_end_time(hhmm)
        else:
            end_stop_text = hhmm
    elif key == '연패':
        v = None if off else target_dialog.parse_streak(val)
        if v is None and not off:
            return {'title': '2~30 사이 숫자로 입력해 주세요', 'lines': ['예: !설정 연패 5  /  !설정 연패 없음'], 'kind': 'warn'}
        set_extra_options(v, LOSE_PAUSE, DAILY_REPORT)
    elif key in ('연패정지', '대기', '승급대기', '결산') and (on or off):
        if key == '연패정지':
            set_extra_options(LOSE_STREAK, on, DAILY_REPORT)
        elif key == '결산':
            set_extra_options(LOSE_STREAK, LOSE_PAUSE, on)
        else:
            PROMO_WAIT = on
            if not on and wait_reason == 'promo':
                end_wait()
    else:
        return {'title': '설정 명령', 'lines': SET_HELP, 'kind': 'info'}
    target_dialog.save_settings(TARGET_SCORE, WEBHOOK, TARGET_RANK, PROMO_WAIT)
    LOG.info('디스코드에서 설정 변경: %s %s', key, val)
    set_status('디스코드에서 설정 변경됨 - 정지 조건: %s [%s]' % (stop_conditions_text(), time.strftime('%H:%M:%S')), 'info')
    draw_ui()
    return {'title': '✅ 설정을 바꿨습니다', 'lines': settings_lines(), 'kind': 'done'}


def _cmd_formation(args):
    """상대 포메이션별 승률 (전체 기록)"""
    rows = score_log.formation_table(score_log.read_records(), 7)
    if not rows:
        return {'title': '아직 포메이션 기록이 없습니다', 'lines': ['경기 전 라인업 화면에서 상대 포메이션을 읽어 기록합니다.'], 'kind': 'info'}
    lines = ['```']
    for f, n, w, d, l in rows[:15]:
        lines.append('%-10s %3d판  %2d승 %d무 %2d패  승률 %3d%%' % (f, n, w, d, l, round(w * 100 / n)))
    if len(rows) > 15:
        lines.append('… 외 %d개 (전체는 F11 차트)' % (len(rows) - 15))
    lines.append('```')
    lines.append('5판 미만은 참고만')
    return {'title': '⚔ 상대 포메이션별 승률', 'lines': lines, 'kind': 'info'}


BOT_HANDLERS = {'상태': _cmd_status, '차트': _cmd_chart, '정지': _cmd_pause, '일시정지': _cmd_pause,
                '재개': _cmd_resume, '종료': _cmd_stop, '설정': _cmd_settings, '결산': _cmd_day, '오늘': _cmd_day,
                '포메이션': _cmd_formation, '막판종료': _cmd_last_game, '막판': _cmd_last_game,
                '막판종료취소': lambda a: _cmd_last_game('취소'), '전술': lambda a: _cmd_tactics(a),
                '쉬는시간': lambda a: _cmd_rest(a)}


TG = None


def start_tg():
    """텔레그램 봇 토큰이 있으면 (다시) 시작"""
    global TG
    if TG is not None:
        TG.stop()
        TG = None
    token = target_dialog.get_option('tg_token', '') or ''
    if not token.strip():
        return
    TG = telegram_bot.Bot(token, target_dialog.get_option('tg_chat'), BOT_HANDLERS,
                          on_owner=lambda cid, name: target_dialog.set_option('tg_chat', cid),
                          log=lambda m: LOG.info(m))
    TG.start()


def tg_ready():
    return TG is not None and bool(TG.chat_id)


def notify_all(title, lines, kind='info', image_fn=None, image_name='image.png', buttons=None):
    """디스코드(웹훅) + 텔레그램 둘 다 (설정된 것만)"""
    if WEBHOOK:
        notify.send(WEBHOOK, title, lines, kind, on_done=_notify_done, image_fn=image_fn, image_name=image_name)
    if tg_ready():
        TG.send_async(title, lines, kind, image_fn=image_fn, image_name=image_name, on_done=_tg_done, buttons=buttons)


def _tg_done(ok, msg):
    (LOG.info if ok else LOG.warning)('텔레그램 알림: %s', 'OK' if ok else msg)


def any_notify():
    return bool(WEBHOOK) or tg_ready()


def start_bot():
    """봇 토큰이 있으면 (다시) 시작"""
    global BOT
    if BOT is not None:
        BOT.stop()
        BOT = None
    token = target_dialog.get_option('bot_token', '') or ''
    if not token.strip():
        return
    BOT = discord_bot.Bot(token, WEBHOOK, target_dialog.get_option('bot_owner'), BOT_HANDLERS,
                          on_owner=lambda uid, name: target_dialog.set_option('bot_owner', uid),
                          log=lambda m: LOG.info(m))
    BOT.start()


_today_cache = {'key': None, 'val': None}


def today_summary():
    """오늘 기록(ranking_log.csv) 누적: 판수·승무패·승률·점수 변화·승급/강등 + 최근 20판 결과 흐름. 파일이 바뀔 때만 다시 계산"""
    try:
        st = os.stat(score_log.LOG_FILE)
        key = (st.st_mtime, st.st_size, datetime.date.today())
    except OSError:
        return None
    if _today_cache['key'] == key:
        return _today_cache['val']
    val = None
    try:
        day = datetime.date.today().strftime('%Y-%m-%d')
        recs = [r for r in score_log.read_records() if r[0].startswith(day)]
        games = [r for r in recs if not score_log.is_stop_row(r)]
        if games:
            res = [r[5] for r in games if r[5] in ('승', '무', '패')]
            w, d, l = res.count('승'), res.count('무'), res.count('패')
            known = [r[2] for r in recs if r[2] is not None]
            notes = [p for r in games for p in (r[4] or '').split(', ')]
            line = '%d판' % len(games)
            if res:
                line += ' · %d승 %d무 %d패 (승률 %d%%)' % (w, d, l, round(w * 100 / len(res)))
            if len(known) >= 2:
                line += ' · %+d점' % (known[-1] - known[0])
            if notes.count('승급') or notes.count('강등'):
                line += ' · ▲승급 %d ▼강등 %d' % (notes.count('승급'), notes.count('강등'))
            val = {'line': line, 'flow': res[-20:], 'streak': session_stats.streak_text(res),
                   'fc': score_log.fc_of(games)}
    except Exception:
        note_error('오늘 기록 요약')
    _today_cache['key'], _today_cache['val'] = key, val
    return val


def session_fc():
    """이번 세션 챔스 승수, FC"""
    w = sum(1 for h in champions_history if h[H_RES] == '승' and h[H_CHAMP])
    return w, w * score_log.FC_PER_WIN


def fc_text(td):
    """'이번 3승 → 45 FC · 오늘 8승 → 120 FC' (챔스 기록이 없으면 빈칸)"""
    sw, sf = session_fc()
    tw, tf = (td or {}).get('fc', (0, 0))
    in_champs = any(h[H_CHAMP] for h in champions_history) or (tier_now or '').replace(' ', '').startswith('챔피언스')
    if not (sw or tw or in_champs):
        return ''
    return '이번 %d승 → %s FC · 오늘 %d승 → %s FC  (챔스 1승당 %d FC)' % (
        sw, format(sf, ','), tw, format(tf, ','), score_log.FC_PER_WIN)


def short_status():
    """작업표시줄 제목/트레이 툴팁용 한 줄"""
    if is_manager_mode and is_paused:
        return '일시정지 · %d판' % champions_game_count, 'warn'
    if is_manager_mode:
        s = '자동진행 중 · %d판' % champions_game_count
        last = next((h[H_SCORE] for h in reversed(champions_history) if h[H_SCORE] is not None), None)
        if last is not None:
            s += ' · %s점' % format(last, ',')
        return s, ('warn' if champions_status_kind == 'warn' else 'run')
    if champions_status:
        return '정지 · ' + champions_status[:60], champions_status_kind
    return '대기 중', 'idle'


def update_title_and_tray():
    text, kind = short_status()
    if os.name == 'nt':
        try:
            if not GUI_ON:
                import ctypes
                ctypes.windll.kernel32.SetConsoleTitleW('FC 매크로 · ' + text)
        except Exception:
            pass
    tray.update(kind, 'FC 매크로 · ' + text)


def rank_text(r):
    if r is None:
        return '-'
    return format(r, ',') + '위'


# ── 디스코드 알림 ─────────────────────────────────────
def _notify_done(ok, msg):
    global notify_status
    now = time.strftime('%H:%M')
    notify_status = ('마지막 알림 전송 성공 ' + now) if ok else ('마지막 알림 전송 실패 ' + now + ' - ' + msg)
    (LOG.info if ok else LOG.warning)('디스코드 알림: %s', 'OK' if ok else msg)
    draw_ui()


def grab_game_jpeg():
    """게임 창(없으면 전체 화면) 캡처 -> JPEG 바이트"""
    reg = game_region()
    shot = pyautogui.screenshot(region=reg) if reg else pyautogui.screenshot()
    buf = io.BytesIO()
    shot.convert('RGB').save(buf, 'JPEG', quality=82)
    return buf.getvalue()


def chart_png_bytes(title):
    return chart_png.render(score_log.read_records()[-40:], TARGET_SCORE, title)


def alert(kind, title, extra=(), image=None, buttons=None):
    """디스코드·텔레그램으로 알림 (둘 다 없으면 아무것도 안 함). image: 'screen'=게임 화면 / 'chart'=그래프"""
    LOG.info('알림: %s', title)
    if not any_notify():
        return
    st = current_stats()
    lines = list(extra)
    if champions_history or champions_final_score is not None:
        lines += ['', '📊 ' + session_stats.summary_line(st)]
        if TARGET_SCORE is not None:
            lines.append('🎯 ' + session_stats.eta_line(st, TARGET_SCORE))
        if last_rank is not None:
            lines.append('🏅 최근 순위 %s위' % format(last_rank, ','))
    if image == 'screen':
        notify_all(title, lines, kind, image_fn=grab_game_jpeg, image_name='screen.jpg')
    elif image == 'chart':
        notify_all(title, lines, kind, image_fn=lambda: chart_png_bytes('최근 기록 (최대 40개)'), image_name='chart.png')
    elif isinstance(image, (bytes, bytearray)):
        notify_all(title, lines, kind, image_fn=lambda: image, image_name='screen.jpg')   # 미리 찍어 둔 화면
    else:
        notify_all(title, lines, kind, buttons=buttons)


# ── 단축키 ───────────────────────────────────────────
settings_dialog_open = False


def on_press_f8(_):
    """설정 변경: 진행 중이면 [적용](기록 유지), 멈춰 있으면 [저장]"""
    open_settings('apply' if is_manager_mode else 'save')


def on_press_f9(_):
    """자동진행 시작: 설정창 -> [시작]"""
    LOG.info('F9 - 자동진행 시작 요청')
    if is_manager_mode:
        set_status('이미 자동진행 중 - F9 무시됨 (설정 변경은 F8, 일시정지는 F10) [%s]' % time.strftime('%H:%M:%S'), 'warn')
        draw_ui()
        return
    open_settings('start')


def open_settings(mode):
    """설정창을 띄움 (키보드 감지 스레드를 막지 않도록 별도 스레드). 이미 떠 있으면 무시"""
    global settings_dialog_open
    if settings_dialog_open:
        return
    settings_dialog_open = True
    threading.Thread(target=_settings_thread, args=(mode,), daemon=True).start()


def _test_send(url):
    return notify.send_now(url, '✅ FC 매크로 알림 테스트',
                           ['이 메시지가 보이면 디스코드 알림이 정상입니다.',
                            '주차 완료 / 종료 시각 / 승급·강등 / 오류 정지 / 멈춤 감지 때 알림이 옵니다.'], 'info')


def _test_tg(token):
    """설정창 텔레그램 [테스트]: 매크로가 이미 이 봇으로 연결돼 있으면 그걸로, 아니면 직접 확인"""
    token = (token or '').strip()
    if TG is not None and TG.token == token and TG.ok:
        if not TG.chat_id:
            return False, '텔레그램에서 @%s 에게 /start 를 보내면 바로 등록됩니다' % (TG.username or '봇')
        return TG.send('✅ FC 매크로 텔레그램 알림 테스트', ['이 메시지가 보이면 텔레그램 알림이 정상입니다.'], 'info')
    same_bot = token.split(':')[0] == (target_dialog.get_option('tg_token', '') or '').split(':')[0]
    ok, msg, cid, name = telegram_bot.test_connection(token, target_dialog.get_option('tg_chat') if same_bot else None)
    if ok and cid:
        _tg_test[0] = (token.split(':')[0], cid)       # [적용]을 누르면 이 대화를 주인으로 저장
        LOG.info('텔레그램 테스트 성공 - 대화 %s (%s)', cid, name or '')
    return ok, msg


_tg_test = [None]


def _ui_dialog(make):
    """설정창 등: 매크로 창이 있으면 그 창의 스레드에서 하위 창으로, 없으면 예전처럼 따로 띄움. make(master) -> 결과"""
    if GUI_ON:
        return gui.call_in_ui(lambda: make(gui._root))
    return make(None)


def _settings_thread(mode):
    global settings_dialog_open, TARGET_SCORE, TARGET_RANK, WEBHOOK, end_stop_text, PROMO_WAIT, start_text
    try:
        v = _ui_dialog(lambda m: target_dialog.ask_settings({'target': TARGET_SCORE, 'rank': TARGET_RANK, 'webhook': WEBHOOK, 'promo_wait': PROMO_WAIT,
                                        'bot_token': target_dialog.get_option('bot_token', '') or '',
                                        'tg_token': target_dialog.get_option('tg_token', '') or '',
                                        'ui_mode': target_dialog.get_option('ui_mode') or 'gui',
                                        'run_as_admin': target_dialog.get_option('run_as_admin', True) is not False,
                                        'lose_streak': LOSE_STREAK, 'lose_pause': LOSE_PAUSE, 'daily_report': DAILY_REPORT,
                                        'stop_at': end_stop_text if is_manager_mode else None,
                                        'start_at': start_text if (is_manager_mode and wait_reason == 'start') else None},
                                       focus_click=lambda x, y: pyautogui.click(x, y),
                                       test_send=_test_send, test_tg=_test_tg, mode=mode, master=m))
    except Exception as e:
        v = None
        set_status('설정창 오류: %s' % e, 'stop')
    finally:
        settings_dialog_open = False
    if v is None:          # Esc/취소 -> 아무것도 바꾸지 않음
        draw_ui()
        return
    if v.get('ui_mode') and v['ui_mode'] != (target_dialog.get_option('ui_mode') or 'gui'):
        target_dialog.set_option('ui_mode', v['ui_mode'])
        LOG.info('매크로 창 방식: %s (다음 실행부터)', '버튼식' if v['ui_mode'] == 'gui' else '글자 창')
        set_status('매크로 창 방식을 바꿨어요 - 매크로를 다시 켜면 %s으로 나옵니다' % ('버튼식 창' if v['ui_mode'] == 'gui' else '글자 창'), 'info')
    if 'run_as_admin' in v and v['run_as_admin'] != (target_dialog.get_option('run_as_admin', True) is not False):
        target_dialog.set_option('run_as_admin', bool(v['run_as_admin']))
        LOG.info('관리자 권한으로 켜기: %s (다음 실행부터)', '켬' if v['run_as_admin'] else '끔')
        set_status('관리자 권한으로 켜기를 %s - 다음에 매크로를 켤 때부터 적용' % ('켰어요' if v['run_as_admin'] else '껐어요'), 'info')
    old_hook, old_token = WEBHOOK, target_dialog.get_option('bot_token', '') or ''
    TARGET_SCORE, TARGET_RANK, WEBHOOK = v['target'], v.get('rank'), v['webhook']
    PROMO_WAIT = bool(v.get('promo_wait'))
    target_dialog.save_settings(TARGET_SCORE, WEBHOOK, TARGET_RANK, PROMO_WAIT)
    set_extra_options(v.get('lose_streak'), v.get('lose_pause', False), v.get('daily_report', False))
    if v.get('bot_token', old_token) != old_token or (WEBHOOK != old_hook and v.get('bot_token')):
        target_dialog.set_option('bot_token', v.get('bot_token', ''))
        start_bot()                                    # 토큰/웹훅이 바뀌면 봇 다시 연결
    old_tg = target_dialog.get_option('tg_token', '') or ''
    new_tg = v.get('tg_token', old_tg) or ''
    tested = _tg_test[0]
    if new_tg != old_tg or (tested and not target_dialog.get_option('tg_chat')):
        target_dialog.set_option('tg_token', new_tg)
        bot_id = new_tg.split(':')[0]
        if not new_tg or old_tg.split(':')[0] != bot_id:
            target_dialog.set_option('tg_chat', None)  # 다른 봇으로 바꾸면 주인 다시 등록
        if new_tg and tested and tested[0] == bot_id:
            target_dialog.set_option('tg_chat', tested[1])   # 설정창 [테스트]로 찾은 대화
        start_tg()
    _tg_test[0] = None
    if mode == 'start' and not is_manager_mode:
        start_session(v.get('stop_at'), v.get('start_at'))
    elif is_manager_mode:
        set_end_time(v.get('stop_at'))
        if wait_reason == 'start' or v.get('start_at'):
            set_start_wait(v.get('start_at'))      # 아직 시작 전이면 시작 시각 변경 (비우면 바로 시작)
        if wait_reason == 'promo' and not PROMO_WAIT:
            end_wait()                             # 승급 대기를 끄면 바로 재개
        LOG.info('설정 변경 (진행 중) - %s', stop_conditions_text())
        set_status('설정 적용됨 - 정지 조건: %s [%s]' % (stop_conditions_text(), time.strftime('%H:%M:%S')), 'run')
        draw_ui()
    else:
        end_stop_text = v.get('stop_at')
        set_status('설정 저장됨 - F9로 시작하면 적용됩니다 [%s]' % time.strftime('%H:%M:%S'), 'info')
        draw_ui()


def set_extra_options(lose_streak, lose_pause, daily_report):
    """연패 경고 / 하루 결산 설정 저장 (결산을 새로 켜면 다음 자정부터 보냄)"""
    global LOSE_STREAK, LOSE_PAUSE, DAILY_REPORT
    if daily_report and not DAILY_REPORT:
        target_dialog.set_option('daily_last', (datetime.date.today() - datetime.timedelta(days=1)).isoformat())
    LOSE_STREAK, LOSE_PAUSE, DAILY_REPORT = lose_streak, bool(lose_pause), bool(daily_report)
    target_dialog.set_option('lose_streak', LOSE_STREAK)
    target_dialog.set_option('lose_pause', LOSE_PAUSE)
    target_dialog.set_option('daily_report', DAILY_REPORT)


def _next_time_of_day(hhmm):
    """'07:00' -> 지금 이후 처음 오는 07:00의 epoch초 (이미 지났으면 내일)"""
    h, m = map(int, hhmm.split(':'))
    now = datetime.datetime.now()
    t = now.replace(hour=h, minute=m, second=0, microsecond=0)
    if t <= now:
        t += datetime.timedelta(days=1)
    return t.timestamp(), t


def set_end_time(stop_at):
    global end_stop_at, end_stop_label, end_stop_text
    end_stop_text = stop_at
    if stop_at:
        end_stop_at, t = _next_time_of_day(stop_at)
        end_stop_label = ('%d/%d ' % (t.month, t.day) if t.date() != datetime.date.today() else '오늘 ') + stop_at
    else:
        end_stop_at, end_stop_label = None, ''


def start_session(stop_at=None, start_at=None):
    global is_manager_mode, is_paused, check_lines, last_rank, last_known_score, strip_last
    global champions_game_count, champions_history, champions_fail_count
    global champions_last_game_time, champions_session_start, champions_final_score
    global vs_visible, vs_expect, vs_warned, cont_count, vs_pending, tier_last_mask, tier_last_champ, popup_hint, tier_now
    global wait_until, wait_reason, wait_info, promo_released_date
    wait_until, wait_reason, wait_info = None, '', ''
    check_lines = []
    set_end_time(stop_at)
    LOG.info('자동진행 시작 - 정지 조건: %s, 디스코드 %s', stop_conditions_text(), '켜짐' if WEBHOOK else '꺼짐')
    champions_game_count = 0
    champions_history = []
    champions_fail_count = 0
    champions_last_game_time = 0.0
    champions_session_start = time.time()
    champions_final_score = None
    last_rank = None
    last_known_score = None
    strip_last = None
    vs_visible = vs_expect = vs_warned = False
    cont_count = 0
    vs_pending = None
    tier_last_mask = tier_last_champ = popup_hint = tier_now = None
    tier_events.clear()
    last_bar.clear()
    form_pending.clear()
    form_screen['side'] = None
    last_game['on'] = False
    set_start_wait(start_at)
    _last_click.clear()
    watchdog_reset()
    is_paused = False
    is_manager_mode = True
    if wait_until is not None:
        set_status('⏳ %s - 그때 자동으로 시작합니다' % wait_info, 'info')
    else:
        set_status('진행 중 - 정지 조건: %s' % stop_conditions_text(), 'run')
    draw_ui()


def set_start_wait(start_at):
    """시작 시각 예약 (None이면 바로 시작)"""
    global wait_until, wait_reason, wait_info, start_text
    start_text = start_at
    if start_at:
        wait_until, t = _next_time_of_day(start_at)
        wait_reason = 'start'
        wait_info = '%s%s 시작 예약' % ('' if t.date() == datetime.date.today() else '%d/%d ' % (t.month, t.day), start_at)
    elif wait_reason == 'start':
        wait_until, wait_reason, wait_info = None, '', ''


def on_press_f10(_):
    """일시정지 / 재개 (누르는 즉시)"""
    global is_paused, vs_visible
    if not is_manager_mode:
        return
    is_paused = not is_paused
    LOG.info('F10 - %s', '일시정지' if is_paused else '재개')
    if is_paused:
        set_status('일시정지 [%s] - F10으로 재개' % time.strftime('%H:%M:%S'), 'warn')
    else:
        vs_visible = False
        watchdog_reset()
        set_status('재개 [%s]' % time.strftime('%H:%M:%S'), 'run')
    draw_ui()


def on_press_f11(_):
    """기록 차트 열기"""
    try:
        path = score_log.build_chart(TARGET_SCORE)
        if path is None:
            set_status('차트: 아직 기록이 없습니다 (F9로 진행하면 쌓입니다)', 'info')
        else:
            os.startfile(path)
    except Exception as e:
        set_status('차트 생성 실패: %s' % e, 'warn')
    draw_ui()


def on_press_f12(_):
    global is_manager_mode, is_paused
    LOG.info('F12 - 자동진행 종료')
    was = is_manager_mode
    is_manager_mode = False
    is_paused = False
    if was:
        set_status('F12로 종료됨 [%s]' % time.strftime('%H:%M:%S'), 'stop')
    draw_ui()


def safe_log(game_no, score, note='', tier=''):
    try:
        return score_log.append_record(game_no, score, note, tier=tier)
    except Exception:
        note_error('기록 저장')
        return None  # 기록 실패가 매크로 진행을 막지 않게 함


def safe_update(ts, game_no, **fields):
    if not ts:
        return
    try:
        score_log.update_fields(ts, game_no, **fields)
    except Exception:
        note_error('기록 수정')


_key_last = {}


def hotkey(key, fn, suppress=False, name=None):
    """단축키 등록 -> 해제용 핸들. 키를 받으면 실제 작업은 별도 스레드에서 하고 바로 돌려줌.
    (키 감지 안에서 오래 걸리면 Windows가 매크로의 키 감지를 말없이 꺼 버려서 모든 F키가 안 먹히게 됨)
    키를 꾹 누르고 있을 때 반복 입력은 0.4초 안이면 무시"""
    tag = name or key

    def cb(_e):
        now = time.time()
        if now - _key_last.get(tag, 0) < 0.4:
            _key_last[tag] = now
            return
        _key_last[tag] = now
        threading.Thread(target=_run_key, args=(tag, fn), daemon=True).start()
    return keyboard.on_press_key(key, cb, suppress=suppress)


def _run_key(key, fn):
    try:
        fn(None)
    except Exception:
        note_error('단축키/버튼 ' + str(key))


# ── v3.0: 기능 목록 (버튼 · 단축키 공통) ─────────────────
# (id, 이름, 기본 단축키, 실행 함수)  - 단축키는 설정에서 바꿀 수 있음 (keyboard 라이브러리 이름: 'f6', 'ctrl+f12')
ACTIONS = [
    ('topmost', '항상 위', 'f6', lambda: toggle_topmost()),
    ('check', '점검', 'f7', lambda: run_checks(True)),
    ('settings', '설정', 'f8', lambda: on_press_f8(None)),
    ('start', '시작', 'f9', lambda: on_press_f9(None)),
    ('pause', '일시정지 / 재개', 'f10', lambda: on_press_f10(None)),
    ('chart', '차트', 'f11', lambda: on_press_f11(None)),
    ('stop', '종료', 'f12', lambda: on_press_f12(None)),
    ('lastgame', '막판종료 / 취소', 'ctrl+f12', lambda: toggle_last_game()),
    ('tactics', '전술 자동 변경', '', lambda: open_tactics()),
    ('layout', '창 배치 저장', '', lambda: layout_button()),
    ('today', '오늘 결산', '', lambda: show_today()),
    ('formation', '포메이션 · 전술', '', lambda: show_formation()),
    ('folder', '기록 폴더 열기', '', lambda: open_data_folder()),
]
ACTION_FN = {a: f for a, _n, _d, f in ACTIONS}
ACTION_NAME = {a: n for a, n, _d, _f in ACTIONS}
DEFAULT_KEYS = {a: d for a, _n, d, _f in ACTIONS}
HOTKEYS = dict(DEFAULT_KEYS)
_hk_handles = []
_hk_lock = threading.Lock()


def key_label(k):
    """'ctrl+f12' -> 'Ctrl + F12'"""
    if not k:
        return '없음'
    out = []
    for p in k.split('+'):
        p = p.strip()
        if re.fullmatch(r'f\d{1,2}', p):
            out.append(p.upper())
        elif len(p) == 1 or p in ('ctrl', 'alt', 'shift'):
            out.append(p.capitalize() if len(p) > 1 else p.upper())
        else:
            out.append(p.title())
    return ' + '.join(out)


def load_hotkeys():
    saved = target_dialog.get_option('hotkeys') or {}
    keys = dict(DEFAULT_KEYS)
    if isinstance(saved, dict):
        for a, k in saved.items():
            if a in keys and isinstance(k, str):
                keys[a] = k.strip().lower()
    return keys


def unbind_hotkeys():
    with _hk_lock:
        for kind, h in _hk_handles:
            try:
                if kind == 'hook':
                    keyboard.unhook(h)
                else:
                    keyboard.remove_hotkey(h)
            except Exception:
                pass
        _hk_handles.clear()


def bind_hotkeys():
    """HOTKEYS 대로 단축키 등록 (먼저 전부 해제). 등록 못 한 키는 로그"""
    unbind_hotkeys()
    with _hk_lock:
        for aid, k in HOTKEYS.items():
            if not k:
                continue
            fn = ACTION_FN[aid]
            try:
                if '+' not in k:
                    # 키 하나: 예전 방식 그대로 (F11 은 글자 창일 때 터미널 전체화면으로 안 넘어가게 막음)
                    h = hotkey(k, lambda _e, f=fn: f(), suppress=(k == 'f11' and not GUI_ON), name=aid)
                    _hk_handles.append(('hook', h))
                else:
                    h = keyboard.add_hotkey(k, _hotkey_cb(aid, fn), suppress=False)
                    _hk_handles.append(('hot', h))
            except Exception as e:
                LOG.warning('단축키 등록 실패 %s (%s): %s', ACTION_NAME[aid], k, e)


def _hotkey_cb(aid, fn):
    def cb():
        now = time.time()
        if now - _key_last.get(aid, 0) < 0.4:
            _key_last[aid] = now
            return
        _key_last[aid] = now
        threading.Thread(target=_run_key, args=(aid, lambda _x: fn()), daemon=True).start()
    return cb


def run_action(aid):
    """버튼/단축키 공통 실행 (별도 스레드)"""
    fn = ACTION_FN.get(aid)
    if fn is None:
        return
    threading.Thread(target=_run_key, args=(aid, lambda _x: fn()), daemon=True).start()


HOTKEYS = load_hotkeys()
bind_hotkeys()


def set_hotkeys(new):
    """단축키 설정 창 [저장] -> (성공, 메시지)"""
    global HOTKEYS
    used = {}
    for a, k in new.items():
        if not k:
            continue
        if k in used:
            return False, '%s 가 두 기능에 겹쳐요 (%s, %s)' % (key_label(k), ACTION_NAME[used[k]], ACTION_NAME[a])
        used[k] = a
    HOTKEYS = {a: (new.get(a) or '') for a in DEFAULT_KEYS}
    target_dialog.set_option('hotkeys', HOTKEYS)
    bind_hotkeys()
    LOG.info('단축키 변경: %s', ', '.join('%s=%s' % (ACTION_NAME[a], key_label(k)) for a, k in HOTKEYS.items() if k))
    draw_ui()
    return True, '저장했어요'


def open_hotkey_dialog():
    if not GUI_ON:
        return
    unbind_hotkeys()                  # 설정하는 동안 단축키가 실행되지 않게

    def make():
        w = gui.hotkey_dialog([(a, ACTION_NAME[a]) for a, _n, _d, _f in ACTIONS], HOTKEYS, DEFAULT_KEYS, set_hotkeys)
        w.bind('<Destroy>', lambda e: (bind_hotkeys() if e.widget is w else None))
        return w
    gui.call_in_ui(make, wait=False)


def toggle_last_game():
    if last_game['on']:
        t, _l, _k = cancel_last_game()
    else:
        t, _l, _k = request_last_game('매크로 창')
    LOG.info('막판종료 버튼: %s', t)
    if not is_manager_mode and GUI_ON:
        gui.call_in_ui(lambda: gui.ask('막판종료', '자동진행 중일 때만 예약할 수 있어요.', 'info'), wait=False)


def _popup(title, lines, mono=False):
    if GUI_ON:
        gui.call_in_ui(lambda: gui.show_text(title, lines, mono), wait=False)
    else:
        LOG.info('%s\n%s', title, '\n'.join(lines))


def show_today():
    try:
        title, lines, _r = day_summary(datetime.date.today())
    except Exception as e:
        title, lines = '오늘 결산', ['결산을 만들지 못했어요: %s' % e]
    _popup(title, lines)


def show_formation():
    recs = score_log.read_records()
    rows = score_log.formation_table(recs, 7)
    trows = score_log.formation_table(recs, 9)                     # v3.2: 내 전술별
    if not GUI_ON:
        r = _cmd_formation('')
        _popup(r['title'], r.get('lines', []))
        return
    data = [(f, n, w, d, l, '%d%%' % round(w * 100 / n)) for f, n, w, d, l in rows]
    if trows:
        data += [('', '', '', '', '', ''), ('[내 전술]', '', '', '', '', '')]
        data += [(f, n, w, d, l, '%d%%' % round(w * 100 / n)) for f, n, w, d, l in trows]
    note = '5판 미만은 참고만 · 판수 많은 순' if rows else '아직 포메이션 기록이 없어요 (경기 전 라인업 화면에서 읽음)'
    gui.call_in_ui(lambda: gui.show_table('상대 포메이션 · 내 전술별 승률', ['상대 포메이션 / 전술', '판수', '승', '무', '패', '승률'],
                                          data, note), wait=False)


def open_tactics():
    """[전술 자동 변경] 창"""
    if not GUI_ON:
        r = _cmd_tactics('')
        _popup(r['title'], r.get('lines', []))
        return

    def snap():
        d = tac_snapshot()
        for i, sl in enumerate(d['slots']):
            if sl:
                sl['png'] = png_b64(('tac', i, sl['id']), sl.pop('img'), gui.px(127), gui.px(22))
        return d
    gui.call_in_ui(lambda: gui.tactics_dialog(snap, tac_api), wait=False)


# ── v3.0: 창 배치 저장 / 적용 ──────────────────────────
# 저장: {'screen': [w, h], 'macro': [x, y, w, h], 'game': [x, y] | None, 'remote': [x, y] | None, 'topmost': bool}
layout_state = {'hwnd': None, 'remote_done': False, 'busy': False}
REMOTE_DRAG_SEC = 0.8


def _screen_size():
    try:
        w, h = pyautogui.size()
        return [int(w), int(h)]
    except Exception:
        return None


def _win_rect(h):
    if os.name != 'nt' or not h:
        return None
    ctypes, wt, u, k = w32()
    rc = wt.RECT()
    if not u.GetWindowRect(h, ctypes.byref(rc)):
        return None
    return [rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top]


def save_layout():
    """지금 창 배치 저장 -> 설명 문구"""
    lay = {'screen': _screen_size(), 'macro': None, 'game': None, 'remote': None, 'topmost': always_on_top}
    h, _how = console_hwnd()
    lay['macro'] = _win_rect(h)
    w = find_game_window()
    if w is not None:
        lay['game'] = [int(w.left), int(w.top)]
    else:
        reg = remote_region(force=True)
        if reg is not None:
            lay['remote'] = [int(reg[0]), int(reg[1])]
    target_dialog.set_option('layout', lay)
    parts = []
    if lay['macro']:
        parts.append('매크로 창 %d,%d (%dx%d)' % tuple(lay['macro']))
    parts.append(('게임 창 %d,%d' % tuple(lay['game'])) if lay['game'] else
                 (('원격 화면 속 게임 창 %d,%d' % tuple(lay['remote'])) if lay['remote'] else '게임 창 없음 (게임 위치는 저장 안 함)'))
    LOG.info('창 배치 저장: %s', lay)
    layout_state['hwnd'] = w._hWnd if w is not None and hasattr(w, '_hWnd') else layout_state['hwnd']
    layout_state['remote_done'] = True
    return ' / '.join(parts)


def layout_button():
    lay = target_dialog.get_option('layout')
    if GUI_ON:
        if lay:
            r = gui.call_in_ui(lambda: gui.ask('창 배치 저장',
                                               '지금 창 배치로 저장할까요?\n\n예: 지금 배치로 저장 (덮어쓰기)\n아니오: 저장된 배치 지우기 (자동 배치 끔)\n취소: 그대로',
                                               'yesnocancel'))
            if r is None:
                return
            if r is False:
                target_dialog.set_option('layout', None)
                LOG.info('창 배치 지움')
                set_status('창 배치를 지웠어요 - 다음부터 창을 자동으로 옮기지 않음', 'info')
                return
        msg = save_layout()
        set_status('창 배치 저장 - ' + msg, 'info')
        gui.call_in_ui(lambda: gui.ask('창 배치 저장', '저장했어요.\n\n' + msg.replace(' / ', '\n') +
                                       '\n\n다음부터 매크로를 켜거나 게임 창이 새로 나타나면 이 자리로 옮깁니다.', 'info'),
                       wait=False)
    else:
        set_status('창 배치 저장 - ' + save_layout(), 'info')


def _layout_ok(lay):
    return bool(lay) and lay.get('screen') == _screen_size()


def apply_macro_layout():
    """매크로 창을 저장한 위치·크기로 (창 스레드에서 호출)"""
    lay = target_dialog.get_option('layout')
    if not _layout_ok(lay) or not lay.get('macro') or os.name != 'nt':
        return
    h, _how = console_hwnd()
    if not h:
        return
    ctypes, wt, u, k = w32()
    x, y, w, hh = lay['macro']
    u.SetWindowPos(h, None, x, y, w, hh, 0x0004 | 0x0010)        # NOZORDER | NOACTIVATE
    LOG.info('창 배치: 매크로 창 %s', lay['macro'])


def layout_watch():
    """게임 창이 새로 나타나면 한 번 저장 위치로 (메인 루프에서 계속 호출 · 가벼움)"""
    lay = target_dialog.get_option('layout')
    if not _layout_ok(lay) or layout_state['busy']:
        return
    w = game_window()
    if w is not None and lay.get('game') and os.name == 'nt' and not getattr(w, 'isMinimized', False):
        hw = getattr(w, '_hWnd', None)
        if hw and hw != layout_state['hwnd']:
            layout_state['hwnd'] = hw
            gx, gy = lay['game']
            if abs(w.left - gx) > 2 or abs(w.top - gy) > 2:
                ctypes, wt, u, k = w32()
                u.SetWindowPos(hw, None, gx, gy, 0, 0, 0x0001 | 0x0004 | 0x0010)   # NOSIZE | NOZORDER | NOACTIVATE
                _win_cache['t'] = 0
                LOG.info('창 배치: 게임 창 (%d,%d) -> (%d,%d)', w.left, w.top, gx, gy)
        return
    if w is None and remote['on'] and lay.get('remote') and not layout_state['remote_done']:
        layout_state['remote_done'] = True
        reg = remote['region']
        if reg and (abs(reg[0] - lay['remote'][0]) > 4 or abs(reg[1] - lay['remote'][1]) > 4):
            layout_state['busy'] = True
            _next_action_at[0] = time.time() + 6               # 옮기는 동안 버튼 클릭 쉬기
            threading.Thread(target=_drag_remote, args=(tuple(lay['remote']),), daemon=True).start()


def _drag_remote(dst):
    """원격 모드: 원격 화면 속 게임 창 제목줄을 마우스로 끌어 저장 위치로 (최대 2번)"""
    try:
        for n in range(2):
            reg = remote_region(force=True)
            if reg is None:
                return
            if abs(reg[0] - dst[0]) <= 4 and abs(reg[1] - dst[1]) <= 4:
                LOG.info('창 배치: 원격 게임 창 위치 맞음 %s', reg[:2])
                return
            grab = (reg[0] + 320, reg[1] + 14)                # 제목줄 빈 곳 (아이콘·글씨·버튼 피해서)
            to = (dst[0] + 320, dst[1] + 14)
            LOG.info('창 배치: 원격 게임 창 끌어 옮김 %s -> %s (%d번째)', reg[:2], dst, n + 1)
            macro_input()
            pyautogui.moveTo(*grab)
            time.sleep(0.2)
            pyautogui.mouseDown()
            time.sleep(0.2)
            pyautogui.moveTo(*to, duration=REMOTE_DRAG_SEC)
            time.sleep(0.3)
            pyautogui.mouseUp()
            macro_input()
            time.sleep(1.5)                                   # 원격 영상이 따라올 때까지
        reg = remote_region(force=True)
        ok = reg is not None and abs(reg[0] - dst[0]) <= 4 and abs(reg[1] - dst[1]) <= 4
        (LOG.info if ok else LOG.warning)('창 배치: 원격 게임 창 %s', '옮김' if ok else '못 옮김 (위치 %s)' % (str(reg[:2]) if reg else '-',))
    except Exception:
        note_error('원격 게임 창 옮기기')
    finally:
        layout_state['busy'] = False
        _next_action_at[0] = time.time() + 1
print('\x1b[2J', end='')
LOG.info('===== 매크로 실행 %s (폴더: %s · 코드: %s) =====', VERSION, paths.APP_DIR, paths.CODE_DIR)
draw_ui()


def stop_all(status=None, kind='stop'):
    global is_manager_mode, is_paused
    is_manager_mode = False
    is_paused = False
    last_game['on'] = False
    if status is not None:
        set_status(status, kind)


# ── 화면 인식: 한 번 찍은 화면(frame)에서 모든 버튼을 찾음 ─────────────
_win_cache = {'t': 0.0, 'w': None}
Box = collections.namedtuple('Box', 'left top width height')
_tls = threading.local()


def game_window():
    """FC ONLINE 창 (2초간 캐시)"""
    now = time.time()
    if now - _win_cache['t'] > 2:
        _win_cache['w'] = find_game_window()
        _win_cache['t'] = now
    return _win_cache['w']


# ── 원격 모드: 이 PC에 게임 창이 없고, 화면(원격 PC 프로그램) 안에 'FC ONLINE' 창 제목줄이 보이면 그 영역을 게임 창으로 씀 ──
REMOTE_TITLE_CONF = 0.75     # 제목줄(아이콘 + FC ONLINE 글씨) 인식 기준
REMOTE_CHECK_SEC = 3         # 제목줄 위치를 다시 찾는 간격 (매 화면마다 제자리에 있는지는 확인)
REMOTE_CONF_DROP = 0.07      # 원격 모드에서 버튼 인식 기준(0.95 -> 0.88)을 낮춤 (압축 때문에 점수가 떨어짐, 다른 버튼 오인식은 0.85 미만)
REMOTE_KEY_HOLD = 0.15       # 원격 모드 키 누르는 시간 (짧으면 원격 프로그램이 놓침)
TITLE_DX, TITLE_DY = 6, 4    # 제목줄 견본(fc_title.png)의 창 왼쪽 위 기준 위치
GAME_WIN_W, GAME_WIN_H = 1282, 752   # 1280x720 창모드 게임 창 크기 (테두리·제목줄 포함)
remote = {'on': False, 'region': None, 't': 0.0, 'score': 0.0, 'scale_warn': None, 'viewer': None, 'viewer_hwnd': None}


def _find_title(gray, scales=(1.0,)):
    """화면(gray)에서 FC ONLINE 제목줄 -> (유사도, (x, y), 배율). 견본 2개: 비활성(회색 바탕) / 활성(흰 바탕) 창"""
    best = (0.0, None, 1.0)
    for name in ('fc_title.png', 'fc_title2.png'):
        t = needle_gray(name)
        for sc in scales:
            tt = t if sc == 1.0 else cv2.resize(t, None, fx=sc, fy=sc, interpolation=cv2.INTER_AREA)
            if gray.shape[0] < tt.shape[0] or gray.shape[1] < tt.shape[1]:
                continue
            r = cv2.matchTemplate(gray, tt, cv2.TM_CCOEFF_NORMED)
            _mn, mx, _l, loc = cv2.minMaxLoc(r)
            if mx <= 1.01 and mx > best[0]:
                best = (mx, loc, sc)
    return best


def remote_region(force=False):
    """원격 화면 안의 게임 창 영역 (몇 초 캐시). 없으면 None"""
    now = time.time()
    if not force and now - remote['t'] < REMOTE_CHECK_SEC:
        return remote['region']
    remote['t'] = now
    try:
        shot = pyautogui.screenshot()
        g = cv2.cvtColor(np.array(shot.convert('RGB')), cv2.COLOR_RGB2GRAY)
    except Exception:
        return remote['region']
    H, W = g.shape
    if W <= GAME_WIN_W + 10 and H <= GAME_WIN_H + 10:
        remote['region'] = None                           # 화면 전체가 게임 창 크기 -> 전체 화면 그대로 사용
        return None
    mx, loc, _sc = _find_title(g)
    remote['score'] = mx
    # 원격 화면이 줄어 있는지 (원격 프로그램이 전체화면이 아니면 게임이 작게 보여 버튼 크기가 안 맞음)
    new_pos = loc is not None and remote['region'] is not None and (loc[0] - TITLE_DX, loc[1] - TITLE_DY) == remote['region'][:2]
    if new_pos and mx >= REMOTE_TITLE_CONF:
        mx2, loc2, sc2 = 0.0, None, 1.0                   # 같은 자리 그대로 -> 배율 다시 볼 필요 없음
    else:
        mx2, loc2, sc2 = _find_title(g, (0.97, 0.95, 0.92, 0.9, 0.85, 0.8))
    scaled = loc2 is not None and mx2 >= REMOTE_TITLE_CONF and mx2 > mx + 0.05
    if loc is None or mx < REMOTE_TITLE_CONF or scaled:
        remote['scale_warn'] = sc2 if scaled or (loc2 is not None and mx2 >= REMOTE_TITLE_CONF) else None
        if remote['region'] is not None:
            LOG.info('원격 모드: 원격 화면 안의 게임 창을 놓침 (유사도 %.2f)', mx)
        remote['region'] = None
        return None
    remote['scale_warn'] = None
    left, top = max(0, loc[0] - TITLE_DX), max(0, loc[1] - TITLE_DY)
    reg = (left, top, min(GAME_WIN_W, W - left), min(GAME_WIN_H, H - top))
    if reg != remote['region']:
        LOG.info('원격 모드: 원격 화면 안 게임 창 %s (제목줄 유사도 %.2f)', reg, mx)
    remote['region'] = reg
    remote['last_region'] = reg
    return reg


def is_remote():
    return remote['on']


def game_region():
    """게임 창 영역 (left, top, width, height). 못 찾거나 최소화면 None -> 전체 화면 사용
    이 PC에 게임 창이 없으면 원격 모드: 화면 안에 비치는 원격 PC의 게임 창 영역"""
    w = game_window()
    if w is None:
        reg = remote_region()
        if reg is not None and not remote['on']:
            LOG.info('원격 모드 켜짐 (이 PC에는 게임 창이 없고 원격 화면 안에 게임 창이 있음)')
        remote['on'] = reg is not None
        return reg
    if remote['on']:
        LOG.info('원격 모드 꺼짐 (이 PC에서 게임 창을 찾음)')
    remote['on'] = False
    try:
        if getattr(w, 'isMinimized', False):
            return None
        left, top = max(0, int(w.left)), max(0, int(w.top))
        width = int(w.left) + int(w.width) - left
        height = int(w.top) + int(w.height) - top
        if width < 200 or height < 200:
            return None
        return (left, top, width, height)
    except Exception:
        return None


def _grab(reg):
    shot = pyautogui.screenshot(region=reg) if reg else pyautogui.screenshot()
    rgb = np.array(shot.convert('RGB'))
    return rgb, cv2.cvtColor(rgb, cv2.COLOR_RGB2GRAY)


def grab_frame():
    """게임 창 화면 1장 -> {'ox','oy': 화면상 위치, 'rgb', 'gray', 'remote'}"""
    reg = game_region()
    rgb, gray = _grab(reg)
    if reg and remote['on']:
        # 원격 화면 안 게임 창이 움직였는지: 맨 위 제목줄이 제자리에 없으면 바로 다시 찾아서 다시 찍음
        top = gray[:40, :140]
        mx = _find_title(top)[0] if top.shape[0] >= 20 and top.shape[1] >= 90 else 0.0
        if mx < REMOTE_TITLE_CONF:
            remote['t'] = 0.0
            reg = game_region()
            rgb, gray = _grab(reg)
    rem = bool(reg) and remote['on']
    return {'ox': reg[0] if reg else 0, 'oy': reg[1] if reg else 0, 'rgb': rgb, 'gray': gray, 'remote': rem}


def use_frame(f):
    _tls.frame = f


def cur_frame():
    return getattr(_tls, 'frame', None)


def crop(frame, region):
    """화면 좌표 영역 -> frame 안의 RGB 조각 (벗어나면 None)"""
    x, y, w, h = region
    x -= frame['ox']
    y -= frame['oy']
    if x < 0 or y < 0:
        return None
    a = frame['rgb'][y:y + h, x:x + w]
    return a if a.shape[0] == h and a.shape[1] == w else None


_img_cache = {}


def needle(name):
    """버튼 이미지를 한 번만 읽어서 보관 (한글 경로 대응). 못 읽으면 예외 -> 화면에 오류로 표시됨"""
    img = _img_cache.get(name)
    if img is None:
        path = paths.img(name)
        img = paths.imread(path)
        if img is None:
            raise IOError('이미지 파일을 읽을 수 없음: %s' % path)
        _img_cache[name] = img
    return img


def needle_gray(name):
    key = name + '#g'
    g = _img_cache.get(key)
    if g is None:
        g = cv2.cvtColor(needle(name), cv2.COLOR_BGR2GRAY)
        _img_cache[key] = g
    return g


def _match(f, name, nd, g):
    """(최고 유사도, 위치). 큰 버튼은 절반 크기 화면에서 대략 찾고 그 주변만 원래 크기로 확인 (약 4배 빠름)
    원격 모드: 압축으로 흐려진 화면은 절반 크기에서 버튼을 놓치기 쉬워서 처음부터 원래 크기로 전체 검색
    (흐리게 처리하는 방법은 비슷한 다른 버튼까지 높게 나와서 쓰지 않음)"""
    if f.get('remote'):
        r = cv2.matchTemplate(g, nd, cv2.TM_CCOEFF_NORMED)
        _mn, mx, _l, loc = cv2.minMaxLoc(r)
        return mx, loc
    if min(nd.shape) < 24:                               # 작은 아이콘(S 등)은 원래 크기로 전체 검색
        r = cv2.matchTemplate(g, nd, cv2.TM_CCOEFF_NORMED)
        _mn, mx, _l, loc = cv2.minMaxLoc(r)
        return mx, loc
    if 'half' not in f:
        f['half'] = cv2.resize(g, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
    key = name + '#h'
    nh = _img_cache.get(key)
    if nh is None:
        nh = cv2.resize(nd, None, fx=0.5, fy=0.5, interpolation=cv2.INTER_AREA)
        _img_cache[key] = nh
    gh = f['half']
    if gh.shape[0] < nh.shape[0] or gh.shape[1] < nh.shape[1]:
        return 0.0, None
    r = cv2.matchTemplate(gh, nh, cv2.TM_CCOEFF_NORMED)
    _mn, mx, _l, loc = cv2.minMaxLoc(r)
    if not (mx >= 0.55):
        return mx, None
    x0, y0 = max(0, loc[0] * 2 - 4), max(0, loc[1] * 2 - 4)
    sub = g[y0:loc[1] * 2 + nd.shape[0] + 4, x0:loc[0] * 2 + nd.shape[1] + 4]
    if sub.shape[0] < nd.shape[0] or sub.shape[1] < nd.shape[1]:
        return 0.0, None
    r = cv2.matchTemplate(sub, nd, cv2.TM_CCOEFF_NORMED)
    _mn, mx, _l, l2 = cv2.minMaxLoc(r)
    return mx, (l2[0] + x0, l2[1] + y0)


def locate(name, confidence, frame=None):
    """화면(frame, 없으면 새로 찍음)에서 이미지를 찾음. 못 찾으면 ImageNotFoundException"""
    try:
        f = frame or cur_frame() or grab_frame()
        nd = needle_gray(name)
        g = f['gray']
        if g.shape[0] < nd.shape[0] or g.shape[1] < nd.shape[1]:
            raise pyautogui.ImageNotFoundException(name)
        mx, loc = _match(f, name, nd, g)
        if f.get('remote') and confidence >= 0.9:
            confidence -= REMOTE_CONF_DROP                # 엄격한 버튼(0.95)만 조금 낮춤 (S 아이콘 등 원래 낮은 기준은 그대로)
        if loc is None or not (mx >= confidence) or mx > 1.01:
            raise pyautogui.ImageNotFoundException(name)
        return Box(loc[0] + f['ox'], loc[1] + f['oy'], nd.shape[1], nd.shape[0])
    except pyautogui.ImageNotFoundException:
        raise
    except Exception:
        note_error('이미지 인식(%s)' % name)      # '못 찾음'이 아닌 진짜 오류는 화면/로그에 표시
        raise


CLICKED, WAITING = 1, 2


def click_image(name, dy=10, confidence=0.95):
    """버튼을 찾아 클릭 -> CLICKED / 방금 누른 버튼이 아직 보이면 WAITING(다시 안 누름) / 못 찾으면 0"""
    try:
        b = locate(name, confidence)
    except Exception:
        return 0
    now = time.time()
    if now - _last_click.get(name, 0) < SAME_BUTTON_SEC:
        return WAITING
    macro_input()
    pyautogui.moveTo(x=b.left + 10, y=b.top + dy)
    time.sleep(CLICK_HOVER_SEC)
    pyautogui.mouseDown()
    time.sleep(CLICK_HOLD_SEC)
    pyautogui.mouseUp()
    time.sleep(CLICK_AFTER_SEC)
    pyautogui.moveTo(x=b.left + 10, y=b.top - 200)
    macro_input()
    remember_viewer()
    _last_click[name] = time.time()
    _next_action_at[0] = time.time() + AFTER_CLICK_SEC
    return CLICKED


_key_log = {}


def key_log(what, how):
    """v3.4.1 진단용: 같은 화면에서 키를 누른 횟수를 30초마다 로그 (같은 화면이 안 넘어가면 반복 횟수가 쌓임)"""
    now = time.time()
    k = _key_log.setdefault(what, {'n': 0, 't': 0.0, 'first': now})
    if now - k['t'] > 120:                                  # 2분 넘게 안 눌렀으면 새로 셈
        k.update(n=0, first=now, t=0.0)
    k['n'] += 1
    if k['t'] == 0.0 or now - k['t'] >= 30:
        k['t'] = now
        LOG.info('%s 누름: %s (%d번째, %d초째 · %s)', what, how, k['n'], now - k['first'],
                 '원격' if remote['on'] else '보통')


_focus = {'t': 0.0, 'fail': 0}
FOCUS_RETRY_SEC = 3            # 제목줄 클릭은 3초에 한 번만 (두 번 연속 누르면 창 최대화될 수 있어서)


def focus_ok(fw):
    """키를 보내도 되는 창이 앞에 있는지: 이 PC에 게임 창이 있으면 그 창, 없으면 원격 프로그램 창"""
    if fw is None:
        return False
    t = fw.title or ''
    if game_window() is not None:
        return GAME_WINDOW_TITLE in t
    return is_viewer(fw)


def _focus_point():
    """앞으로 가져올 때 누를 자리 = 게임 창 맨 위 제목줄 (게임 안 버튼이 없는 곳, 오른쪽 끝 닫기 버튼과 먼 곳)"""
    w = game_window()
    if w is not None:
        return int(w.left) + 300, int(w.top) + 12
    reg = remote['region'] or remote.get('last_region')
    if reg:
        return reg[0] + 300, reg[1] + 12
    return None


def ensure_focus(why):
    """v3.4.1: 키(S·ESC·스페이스)를 보내기 전에 게임 창이 앞에 있는지 보고, 아니면 제목줄을 한 번 눌러 앞으로"""
    try:
        fw = pyautogui.getActiveWindow()
    except Exception:
        fw = None
    if focus_ok(fw):
        _focus['fail'] = 0
        return True
    now = time.time()
    if now - _focus['t'] < (FOCUS_RETRY_SEC if _focus['fail'] < 3 else 30):    # 3번 실패하면 30초에 한 번만
        return False
    _focus['t'] = now
    pt = _focus_point()
    if pt is None:
        return False
    before = ((fw.title if fw is not None else '') or '없음')[:30]
    click_at(*pt)
    time.sleep(0.3)
    try:
        fw2 = pyautogui.getActiveWindow()
    except Exception:
        fw2 = None
    if remote['on'] or game_window() is None:
        remember_viewer()
    ok = focus_ok(fw2)
    _focus['fail'] = 0 if ok else _focus['fail'] + 1
    LOG.info('%s 전에 게임 창 제목줄 클릭 (앞 창이 "%s"였음) -> %s', why, before, '게임 창 앞으로 옴' if ok else '그래도 안 옴')
    return ok


def press_key(key, focus=True):
    if focus and key in ('s', 'esc', 'space'):
        ensure_focus(key.upper() if key != 'space' else '스페이스')
    macro_input()
    pydirectinput.keyDown(key)
    time.sleep(REMOTE_KEY_HOLD if remote['on'] else 0.1)
    pydirectinput.keyUp(key)
    macro_input()


def _title_key(t):
    """창 제목 비교용: 숫자는 무시 (리피시 제목의 '남은시간: 2836분'이 1분마다 바뀜)"""
    return re.sub(r'\d+', '#', (t or '').strip())


def is_viewer(fw):
    """앞에 있는 창이 원격 프로그램 창인지 (창 핸들 같거나, 숫자 뺀 제목이 같으면)"""
    if fw is None:
        return False
    t = (fw.title or '').strip()
    if not t or t.startswith('FC 매크로'):
        return False
    if not remote['viewer']:
        return True                                         # 아직 모르면 매크로 창만 아니면
    h = getattr(fw, '_hWnd', None)
    if h and remote.get('viewer_hwnd') and h == remote['viewer_hwnd']:
        return True
    return _title_key(t) == _title_key(remote['viewer'])


def remember_viewer():
    """원격 모드: 게임 화면을 클릭한 뒤 앞에 온 창 = 원격 PC 프로그램 창 (S키는 이 창이 앞에 있을 때만)"""
    if not remote['on']:
        return
    try:
        fw = pyautogui.getActiveWindow()
        t = (fw.title or '').strip() if fw is not None else ''
        if t and not t.startswith('FC 매크로'):
            same = remote['viewer'] and _title_key(t) == _title_key(remote['viewer'])
            remote['viewer'] = t
            remote['viewer_hwnd'] = getattr(fw, '_hWnd', None)
            if not same:
                LOG.info('원격 모드: 원격 프로그램 창 = %s', t[:60])
    except Exception:
        pass


def click_at(x, y):
    """화면 좌표 클릭 (버튼 클릭과 같은 타이밍)"""
    macro_input()
    pyautogui.moveTo(x=x, y=y)
    time.sleep(CLICK_HOVER_SEC)
    pyautogui.mouseDown()
    time.sleep(CLICK_HOLD_SEC)
    pyautogui.mouseUp()
    time.sleep(CLICK_AFTER_SEC)
    macro_input()
    remember_viewer()


# ── 사람 입력 감지 (이적시장 자동 닫기용): 매크로가 한 클릭·키 입력은 빼고 ─────────
_macro_input_at = [0.0]
_user_input_at = [time.time()]
_last_input_tick = [None]


def macro_input():
    _macro_input_at[0] = time.time()


def track_user_input():
    """Windows가 알려주는 '마지막 입력 시각'이 매크로 입력 직후가 아니면 사람 입력으로 봄"""
    if os.name != 'nt':
        return
    try:
        ctypes, wt, u, k = w32()
        li = _LASTINPUTINFO()
        li.cbSize = ctypes.sizeof(_LASTINPUTINFO)
        if not u.GetLastInputInfo(ctypes.byref(li)):
            return
        if li.dwTime == _last_input_tick[0]:
            return
        _last_input_tick[0] = li.dwTime
        ago = ((k.GetTickCount() - li.dwTime) & 0xFFFFFFFF) / 1000.0
        t = time.time() - ago
        if _macro_input_at[0] - 0.5 <= t <= _macro_input_at[0] + 1.5:
            return                                        # 매크로가 한 입력
        _user_input_at[0] = max(_user_input_at[0], t)
    except Exception:
        note_error('입력 감지')


def user_idle_sec():
    if os.name != 'nt':
        return float(os.environ.get('FCMACRO_TEST_IDLE', '9999'))   # 윈도우가 아니면(테스트) 항상 자리 비움
    return time.time() - _user_input_at[0]


_market_note = [0.0]
# v3.4.1: 이적시장 '열림' 상태를 기억하고, 안 보이면 0.5초 뒤 한 번 더 봐서 두 번 연속 안 보일 때만 '닫힘'
_mk = {'open': False, 'since': 0.0, 'seen_at': 0.0, 'tries': 0, 'next_try': 0.0, 'alerted': False, 'long_sent': False}
MARKET_CONF = 0.85
MARKET_LONG_SEC = 180                  # 이적시장 대기가 이만큼 이어지면 알림 (한 번)
MARKET_LOST_SEC = 5                    # 안전장치: '열림'인데 이만큼 안 보이면 강제 해제
MARKET_X_TRIES = 3                     # X를 눌러도 안 닫히면 이 횟수 뒤 멈추고 알림 (1분 뒤 다시)
_PROGRESS = (('s.png', 0.7), ('skip.png', 0.7), ('esc.png', 0.95), ('home.png', 0.95), ('gameover.png', 0.95))


def _mk_score(f, name):
    """(점수, 상자) - 못 찾으면 (점수, None)"""
    try:
        nd = needle_gray(name)
        g = f['gray']
        if g.shape[0] < nd.shape[0] or g.shape[1] < nd.shape[1]:
            return 0.0, None
        mx, loc = _match(f, name, nd, g)
        mx = float(mx or 0.0)
        if loc is None or mx > 1.01:
            return mx, None
        return mx, Box(loc[0] + f['ox'], loc[1] + f['oy'], nd.shape[1], nd.shape[0])
    except Exception:
        return 0.0, None


def _market_seen(f):
    """이적시장 창이 보이는지 -> (보임, X 상자, '제목 0.93 · X 0.91')"""
    ts, _ = _mk_score(f, 'market_title.png')
    xs, xb = _mk_score(f, 'market_x.png')
    return (ts >= MARKET_CONF and xs >= MARKET_CONF and xb is not None), xb, '제목 %.2f · X %.2f' % (ts, xs)


def _progress_seen(f):
    """경기 진행 화면(S·SKIP·ESC·홈·경기 끝)이 보이면 그 이름"""
    for name, conf in _PROGRESS:
        try:
            locate(name, conf, f)
            return name
        except Exception:
            pass
    return None


def _market_release(why):
    held = time.time() - _mk['since'] if _mk['open'] else 0
    _mk.update(open=False, tries=0, next_try=0.0, alerted=False, long_sent=False)
    LOG.info('이적시장 닫힘 판정 - %s (대기 %d초)', why, held)
    set_status('이적시장 닫힘 - 이어서 진행 [%s]' % time.strftime('%H:%M:%S'), 'run')
    draw_ui()


def handle_market(f=None):
    """이적시장 창이 떠 있으면 True (다른 버튼은 누르지 않음).
    - 이적시장(제목+X)이 또렷이 보이면 이적시장 우선 (쓰는 중에 뒤쪽 ESC 표시 등을 누르지 않게)
    - '열림' 상태에서 안 보이면: 경기 진행 화면(S·SKIP·ESC·홈·경기 끝)이 보이면 바로 '닫힘',
      아니면 0.5초 뒤 한 번 더 확인해 두 번 연속 안 보일 때만 '닫힘' (원격 화면 뭉개짐 대비)
    - 자동 닫기: 이적시장이 실제로 보인 시간과 사람 입력 없는 시간이 둘 다 MARKET_IDLE_SEC 넘을 때만 X"""
    f = f or cur_frame() or grab_frame()
    now = time.time()
    seen, xb, why = _market_seen(f)
    if not seen:
        if not _mk['open']:
            return False
        prog = _progress_seen(f)
        if prog:
            _market_release('진행 화면 보임 (%s) · %s' % (prog, why))
            return False
        if now - _mk['seen_at'] > MARKET_LOST_SEC:
            _market_release('%d초 넘게 안 보여서 강제 해제 · %s' % (now - _mk['seen_at'], why))
            return False
        time.sleep(0.5)                                   # 한 번만 안 보이면 무시 -> 0.5초 뒤 다시
        f2 = grab_frame()
        seen2, xb2, why2 = _market_seen(f2)
        prog2 = _progress_seen(f2)
        if seen2:
            _mk['seen_at'] = time.time()
            return True
        _market_release('두 번 연속 안 보임 · 1차 %s / 2차 %s%s' % (why, why2, (' · ' + prog2) if prog2 else ''))
        use_frame(f2)
        return False
    # 보임
    if not _mk['open']:
        _mk.update(open=True, since=now, tries=0, next_try=0.0, alerted=False, long_sent=False)
        LOG.info('이적시장 열림 판정 - %s', why)
    _mk['seen_at'] = now
    shown = now - _mk['since']
    idle = min(user_idle_sec(), shown)                   # 이적시장이 실제로 보인 시간만 셈
    if shown >= MARKET_LONG_SEC and not _mk['long_sent']:
        _mk['long_sent'] = True
        try:
            alert('info', '🛒 이적시장 대기 %d분째' % (shown // 60),
                  ['이적시장 창이 열려 있어 진행을 멈추고 기다리는 중입니다.',
                   '직접 닫으면 바로 이어서 진행 / 입력이 %d초 없으면 자동으로 닫음' % MARKET_IDLE_SEC], image='screen')
        except Exception:
            note_error('이적시장 알림')
    if idle < MARKET_IDLE_SEC:
        if now - _market_note[0] > 10:
            _market_note[0] = now
            set_status('이적시장 대기 - 직접 닫으면 바로 이어서 진행 (입력 없음 %d초 · %d초 되면 자동으로 닫음)'
                       % (idle, MARKET_IDLE_SEC), 'info')
        return True
    if now < _mk['next_try']:
        return True
    if _mk['tries'] >= MARKET_X_TRIES:                   # X를 여러 번 눌러도 안 닫힘 -> 1분 쉬고 다시
        if not _mk['alerted']:
            _mk['alerted'] = True
            LOG.warning('이적시장 X를 %d번 눌러도 안 닫힘 - %s', _mk['tries'], why)
            set_status('이적시장 창이 안 닫힘 - 직접 닫아 주세요 (1분 뒤 다시 시도)', 'warn')
            try:
                alert('warn', '⚠ 이적시장 창이 안 닫힘', ['X를 %d번 눌렀는데 그대로입니다. 직접 닫아 주세요.' % _mk['tries']], image='screen')
            except Exception:
                note_error('이적시장 알림')
        _mk.update(tries=0, next_try=now + 60)
        return True
    macro_input()
    pyautogui.moveTo(x=xb.left + xb.width // 2, y=xb.top + xb.height // 2)
    time.sleep(CLICK_HOVER_SEC)
    pyautogui.mouseDown()
    time.sleep(CLICK_HOLD_SEC)
    pyautogui.mouseUp()
    time.sleep(CLICK_AFTER_SEC)
    pyautogui.moveTo(x=xb.left + xb.width // 2, y=xb.top + 200)
    macro_input()
    remember_viewer()
    _mk['tries'] += 1
    _mk['next_try'] = time.time() + 3                    # 닫히는지 3초 지켜봄 (예전엔 2초마다 계속 누름)
    _next_action_at[0] = time.time() + AFTER_CLICK_SEC
    LOG.info('이적시장 X 클릭 %d번째 (사람 입력 %d초 없음 · %s)', _mk['tries'], idle, why)
    set_status('이적시장 창을 닫는 중 (입력 %d초 없음) [%s]' % (idle, time.strftime('%H:%M:%S')), 'run')
    draw_ui()
    return True


def read_score_stable(home_box):
    """점수를 0.5초 간격으로 두 번 읽어 같을 때만 인정 (화면 전환/숫자 애니메이션 대비), 최대 3번 시도"""
    for _ in range(3):
        try:
            a, _d1 = score_ocr.read_score_on_screen(home_box)
            time.sleep(0.5)
            b, _d2 = score_ocr.read_score_on_screen(home_box)
        except Exception:
            a, b = None, None
        if a is not None and a == b:
            return a
        time.sleep(0.4)
    return None


def is_champions_home():
    """챔스 홈 화면('랭킹 점수' 글자가 있음)인지"""
    try:
        locate('champ_label.png', 0.7)
        return True
    except Exception:
        return False


def is_placement_screen():
    """'배치 경기' 화면(시즌 초, 랭킹점수 없음)인지"""
    try:
        locate('placement.png', 0.8)
        return True
    except Exception:
        return False


# ── 홈 화면: 공식경기 누르기 직전 확인 ───────────────────────
def park(note, status, title, lines, score=None):
    """정지 조건 도달: 공식경기를 누르지 않고 멈춤"""
    global champions_final_score
    champions_final_score = score
    if score is not None:
        settle_by_score(len(champions_history) - 1, score)
        safe_log('-', score, note)
    stop_all(status, 'done')
    alert('done', title, lines, image='chart')
    draw_ui()
    return False


def home_check(home_box):
    """공식경기 클릭 직전 호출. True = 클릭해도 됨, False = 클릭하지 말 것"""
    global champions_fail_count, last_known_score
    champ = is_champions_home()
    try:
        check_tier_change(home_box, champ)
    except Exception:
        note_error('티어 변화 확인')
    score = None
    if champ:
        score = read_score_stable(home_box)
        if score is None and last_game['on']:
            return finish_last_game(None, champ)        # 막판종료: 점수를 못 읽어도 끝냄
        if score is None:
            champions_fail_count += 1
            if champions_fail_count >= OCR_MAX_FAIL:
                stop_all('정지 - 랭킹점수 인식 %d회 연속 실패 (확인 필요)' % champions_fail_count, 'stop')
                alert('stop', '⛔ 매크로 정지 - 랭킹점수 인식 실패',
                      ['랭킹점수를 %d번 연속 읽지 못해 안전하게 멈췄습니다.' % champions_fail_count,
                       '게임 화면을 다른 창이 가리고 있지 않은지 확인해 주세요.'], image='screen')
            else:
                set_status('랭킹점수 인식 실패 %d/%d - 다음 차례에 다시 시도' % (champions_fail_count, OCR_MAX_FAIL), 'warn')
            draw_ui()
            return False
        last_known_score = score
    champions_fail_count = 0
    now = time.strftime('%H:%M:%S')
    cur_strip = None
    if not champ:
        try:
            f = cur_frame() or grab_frame()
            cur_strip = score_ocr.read_result_strip(crop(f, score_ocr.strip_region(home_box, score_ocr.STRIP_HOME)),
                                                    score_ocr.STRIP_HOME)
            apply_strip(cur_strip, len(champions_history) - 1)
            bar_lines = score_ocr.read_bar_lines(crop(f, score_ocr.bar_region(home_box)))
            note_bar(3 * cur_strip.count('승') + cur_strip.count('무') if cur_strip is not None else None, bar_lines)
            promo_update(cur_strip, bar_lines, champ)                 # v3.2: 승강전
        except Exception:
            note_error('결과 칸 읽기')
    else:
        promo_update(None, {}, champ)
    try:
        emblem_check(home_box, champ)                                 # v3.2: 티어 엠블럼
    except Exception:
        note_error('티어 엠블럼')

    # 0) 막판종료 예약: 로비 도착 -> 공식경기 누르지 않고 끝냄
    if last_game['on']:
        return finish_last_game(score, champ)
    # 1) 목표 점수
    if TARGET_SCORE is not None and score is not None and score >= TARGET_SCORE:
        sc = format(score, ',')
        return park('주차', '주차 완료 - 랭킹점수 %s점 (목표 %s점 이상) [%s]' % (sc, format(TARGET_SCORE, ','), now),
                    '🏁 주차 완료! 랭킹점수 %s점' % sc, ['목표 %s점 이상에 도달해서 멈췄습니다.' % format(TARGET_SCORE, ',')], score)
    # 2) 목표 순위 (직전 판 VS 화면에서 읽은 순위)
    if TARGET_RANK is not None and champ and last_rank is not None and last_rank <= TARGET_RANK:
        return park('주차', '주차 완료 - 순위 %s위 (목표 %s위 이내) [%s]' % (format(last_rank, ','), format(TARGET_RANK, ','), now),
                    '🏁 주차 완료! 순위 %s위' % format(last_rank, ','),
                    ['목표 %s위 이내에 들어서 멈췄습니다.' % format(TARGET_RANK, ',')], score)
    # 2-1) 챔스 승급 대기 (슈퍼챌린저에서 다음 판 이기면 승급 -> 자정까지 멈춤)
    if PROMO_WAIT and not champ and promo_check(home_box, cur_strip):
        return False
    # 3) 직전 클릭이 안 먹힌 경우 (VS 화면 없이 금방 다시 홈 화면) -> 새 판으로 세지 않고 클릭만 다시
    if vs_expect and time.time() - champions_last_game_time < SAME_GAME_SEC:
        set_status('공식경기 클릭 재시도 (%d번째 게임)' % champions_game_count, 'warn')
        draw_ui()
        return True
    # 4) 종료 시각
    if end_stop_at and time.time() >= end_stop_at:
        reason = '종료 시각 %s 도달' % end_stop_label
        return park('종료', '종료 시각으로 정지 - %s [%s]' % (reason, now), '⏹ 종료 시각으로 정지 - %s' % end_stop_label,
                    ['현재 랭킹점수 %s' % fmt_num(score, '점')] if score is not None else [], score)
    # 4-1) v3.3 쉬는 시간 (승률 낮은 시간대) -> 로비에서 대기, 끝나면 자동 재개
    try:
        if rest_check(score):
            return False
    except Exception:
        note_error('쉬는 시간')
    # 5) 새 판 시작
    placement = (not champ) and is_placement_screen()
    begin_game(score, '배치' if placement else '', from_home=True, champ=champ)
    return True


def _next_midnight():
    t = datetime.datetime.combine(datetime.date.today() + datetime.timedelta(days=1), datetime.time(0, 0))
    return t.timestamp() + MIDNIGHT_RESUME_SEC


def promo_check(home_box, st):
    """챔스 승급 대기 조건이면 대기 시작하고 True"""
    global wait_until, wait_reason, wait_info
    is_promo_tier = tier_rank(tier_now) is not None and tier_rank(tier_now) == tier_rank(PROMO_TIER)
    maybe = tier_now is None and _norm_tier(tier_last_named) in (_norm_tier('챌린저 1부'), _norm_tier(PROMO_TIER))
    if not (is_promo_tier or maybe):
        return False                                   # (이름을 모르는데 직전이 챌린저 1부/슈퍼챌린저면 안전하게 확인)
    if promo_released_date == datetime.date.today():
        return False                                   # 오늘 자정에 이미 풀었음 -> 계속 진행 (오늘 하루 강등 보호)
    lines = {}
    try:
        f = cur_frame() or grab_frame()
        lines = score_ocr.read_bar_lines(crop(f, score_ocr.bar_region(home_box)))
    except Exception:
        note_error('승격선 읽기')
    if st is not None:
        pts = 3 * st.count('승') + st.count('무')    # 결과 칸 (승 3, 무 1)
    elif 'fill' in lines:
        pts = lines['fill']                           # 막대 파란 채움
    else:
        return False
    line = lines.get('green', PROMO_LINE_FALLBACK)
    LOG.info('승급 대기 확인 - 승점 %d (결과 칸 %s), 막대 %s -> 승격선(초록) %d', pts, ''.join(st or []) or '-', lines or '못 읽음', line)
    if line - pts > PROMO_GAP:
        return False
    if datetime.datetime.now().hour == 0:
        LOG.info('승급 대기 조건이지만 이미 자정 직후(0시대) -> 그대로 진행')
        return False
    wait_until = _next_midnight()
    wait_reason = 'promo'
    wait_info = '챔스 승급 대기 (승점 %d / 승격선 %d · 다음 판 이기면 승급)' % (pts, line)
    set_status('⏳ %s - 자정 지나면 자동 재개 [%s]' % (wait_info, time.strftime('%H:%M:%S')), 'warn')
    alert('info', '⏳ 챔스 승급 대기 - 자정에 자동 재개',
          ['%s 티어 승점 %d점, 승격선 %d점' % (PROMO_TIER, pts, line), '다음 판을 이기면 챔피언스 승급이라 자정까지 멈춥니다.'])
    draw_ui()
    return True


def end_wait():
    """대기 시각이 됨 -> 진행 시작/재개"""
    global wait_until, wait_reason, wait_info, promo_released_date, champions_session_start
    global champions_last_game_time, vs_expect
    reason = wait_reason
    wait_until, wait_reason, wait_info = None, '', ''
    if champions_last_game_time:
        champions_last_game_time = time.time()        # 대기한 시간은 '새 판 없음' 감시에서 빼기
    vs_expect = False
    _last_click.clear()
    watchdog_reset()
    if reason == 'promo':
        promo_released_date = datetime.date.today()
        set_status('자정 - 챔스 승급 대기 끝, 자동 재개 [%s]' % time.strftime('%H:%M:%S'), 'run')
        alert('info', '▶ 자정 - 자동 재개', ['다음 판을 이기면 챔피언스 승급입니다.'])
    elif reason == 'rest':                                # v3.3 쉬는 시간 끝 ('지금 계속'으로 끝낸 경우는 알림 안 함)
        LOG.info('쉬는 시간 끝 - 다시 시작')
        set_status('쉬는 시간 끝 - 다시 시작', 'info')
        if rest_cfg().get('notify') and time.time() >= _rest.get('skip_until', 0) - 1:
            alert('info', '▶ 쉬는 시간 끝 - 다시 시작', ['자동진행을 이어 갑니다.'])
    else:
        champions_session_start = time.time()
        set_status('예약 시각 - 자동진행 시작 [%s] · 정지 조건: %s' % (time.strftime('%H:%M:%S'), stop_conditions_text()), 'run')
    LOG.info('대기 끝(%s) - 진행', reason)
    draw_ui()


def begin_game(score, note='', from_home=True, champ=None):
    """새 판 기록 시작 (홈 화면에서 공식경기 누를 때 / 연속 진행이면 VS 화면에서)"""
    global champions_game_count, champions_last_game_time, vs_expect, vs_pending
    finish_vs()                                       # 직전 판에서 읽어 둔 값이 있으면 기록
    champions_game_count += 1
    champions_last_game_time = time.time()
    watchdog_new_game()
    if from_home:
        vs_expect = True
    n = champions_game_count
    tier = '챔피언스' if champ else (tier_now or '')
    ts = safe_log(n, score, note, tier)
    h = [n, score, time.strftime('%H:%M:%S'), None, champions_last_game_time, note, ts, None, champ, None, None, None]
    champions_history.append(h)
    tac_begin(h, from_home)
    form_take_pending(h)
    if score is not None:
        settle_by_score(len(champions_history) - 2, score)   # 직전 판 결과 (챔스: 점수 변화)
    vs_pending = {'h': h, 'got': {}, 'last': {}, 'tries': 0, 'after': 0}
    LOG.info('%d번째 게임 시작 - 점수 %s%s', n, fmt_num(score), (' (%s)' % note) if note else '')
    if note == '배치':
        set_status('진행 중 - %d번째 게임 (배치 경기)' % n, 'run')
    elif score is not None:
        set_status('진행 중 - %d번째 게임 시작 (직전 랭킹점수 %s점)' % (n, format(score, ',')), 'run')
    elif from_home:
        set_status('진행 중 - %d번째 게임 시작 (점수는 VS 화면에서 읽음)' % n, 'run')
    draw_ui()


# ── 승/무/패 판정 ──────────────────────────────────────────
def set_result(i, res, how):
    """i번째(세션 안) 판의 결과 기록 (이미 있으면 그대로)"""
    if i < 0 or i >= len(champions_history) or res is None:
        return
    h = champions_history[i]
    if h[H_RES] is not None:
        return
    h[H_RES] = res
    safe_update(h[H_TS], h[H_NO], 결과=res)
    if len(h) > H_TAC and h[H_TAC] is not None:
        TAC.sync_results({_tac_key(h[H_TS], h[H_NO]): res})      # v3.2: 전술별 승률 바로 반영
    LOG.info('%d번째 게임 결과: %s (%s)', h[H_NO], res, how)
    try:
        check_lose_streak()
    except Exception:
        note_error('연패 확인')


_streak_alerted = [None]          # 이미 알린 연패의 시작 게임번호 (같은 연패는 한 번만)


def current_lose_streak():
    """(연패 수, 연패 시작 게임번호) - 이번 세션 기록의 끝에서부터 (결과 미정인 판은 건너뜀)"""
    n, start = 0, None
    for h in reversed(champions_history):
        if h[H_RES] is None:
            if n == 0:
                continue
            break
        if h[H_RES] != '패':
            break
        n, start = n + 1, h[H_NO]
    return n, start


def check_lose_streak():
    global is_paused
    if not LOSE_STREAK:
        return
    n, start = current_lose_streak()
    if n < LOSE_STREAK or _streak_alerted[0] == start:
        return
    _streak_alerted[0] = start
    paused = False
    if LOSE_PAUSE and is_manager_mode and not is_paused:
        is_paused = paused = True
    msg = '%d연패 (%d번째 게임부터)%s' % (n, start, ' - 일시정지함 (F10 또는 !재개)' if paused else '')
    LOG.warning('연패 경고: %s', msg)
    set_status('⚠ ' + msg + ' [%s]' % time.strftime('%H:%M:%S'), 'warn')
    alert('warn', '⚠️ %d연패%s' % (n, ' - 일시정지했습니다' if paused else ''),
          ['%d번째 게임부터 %d판 연속 패배' % (start, n)] + (['다시 진행: PC에서 F10 또는 디스코드 !재개'] if paused else []),
          image='chart')
    draw_ui()


def settle_by_score(i, next_score):
    """다음 판 시작 점수와 비교해 결과 판정 (챔스 / 챔스 아래 티어는 결과 칸을 못 읽었을 때만).
    v2.2: 챔스도 상대가 챔스가 아니면 승부차기 없이 무승부가 있음 -> 점수 변화 0 = 무"""
    if i < 0 or i >= len(champions_history) or next_score is None:
        return
    h = champions_history[i]
    if h[H_RES] is not None or h[H_SCORE] is None:
        return
    d = next_score - h[H_SCORE]
    if d > 0:
        set_result(i, '승', '점수 변화')
    elif d < 0:
        set_result(i, '패', '점수 변화')
    else:
        set_result(i, '무', '점수 변화')


def apply_strip(st, i):
    """결과 칸을 읽음 -> 직전에 본 결과 칸보다 1칸 늘었으면 그 칸이 i번째 판의 결과"""
    global strip_last
    if not st:
        return
    prev = strip_last
    strip_last = list(st)
    if prev is not None and len(st) == len(prev) + 1 and st[:-1] == prev:
        set_result(i, st[-1], '결과 칸')


def result_counts(hist):
    w = sum(1 for h in hist if h[H_RES] == '승')
    d = sum(1 for h in hist if h[H_RES] == '무')
    l = sum(1 for h in hist if h[H_RES] == '패')
    return w, d, l


# ── 승급 / 강등: 홈 화면 티어명 글씨가 바뀌었는지 비교 ─────────────────
def _tier_mask(frame, home_box):
    a = crop(frame, (int(home_box.left) + TIER_DX, int(home_box.top) + TIER_DY, TIER_W, TIER_H))
    if a is None:
        return None, None
    m = cv2.cvtColor(a, cv2.COLOR_RGB2GRAY) > 200
    if m.mean() < 0.02:          # 글씨 없음 (배치 경기 화면 등)
        return None, a
    return m, a


def _iou(a, b):
    u = (a | b).sum()
    return (a & b).sum() / u if u else 1.0


_K3 = np.ones((3, 3), np.uint8)
TIER_SAME_MAX = 20        # 글씨 모양이 이 픽셀 수 이하로만 다르면 같은 티어 (숫자 한 글자만 달라도 80px 이상 차이)


def tier_diff(a, b):
    """두 티어명 글씨 모양의 차이(픽셀 수). 1px 어긋남은 무시. '챌린저 3부'와 '챌린저 1부'처럼 숫자만 달라도 구분됨"""
    if a is None or b is None or a.shape != b.shape:
        return 10 ** 6
    da = cv2.dilate(a.astype(np.uint8), _K3).astype(bool)
    db = cv2.dilate(b.astype(np.uint8), _K3).astype(bool)
    return int((a & ~db).sum() + (b & ~da).sum())


def check_tier_change(home_box, champ):
    """티어명이 바뀌었으면 직전 판에 승급/강등 표시. 처음 본 홈 화면은 기준으로만 저장"""
    global tier_last_mask, tier_last_champ, popup_hint, strip_last, tier_now, tier_last_named
    f = cur_frame() or grab_frame()
    m1, img = _tier_mask(f, home_box)
    if m1 is None:
        return
    time.sleep(0.3)                                  # 화면 등장 연출 중이면 글씨가 변하므로 한 번 더 보고 같을 때만
    m2, _ = _tier_mask(grab_frame(), home_box)
    if m2 is None or tier_diff(m1, m2) > TIER_SAME_MAX:
        tier_log('티어명 글씨가 아직 움직이는 중 -> 다음 홈 화면에서 다시 확인')
        return
    name = tier_name_of(m1, champ)
    changed = tier_last_mask is not None and tier_diff(m1, tier_last_mask) > TIER_SAME_MAX
    if name is None and changed:
        name = guess_tier_name(tier_now, season_direction())   # 처음 보는 티어: 순서상 이웃 티어로 추정
    if not tier_sample_exists(m1):
        save_tier_sample(img, name)                  # 처음 보는 티어 -> 이름을 알면 그 이름으로, 모르면 '이름없음_...png'
    tier_log('티어명 확인: %s%s' % (name or '이름 모름', ' (바뀜)' if changed else ''))
    if changed:
        r_old, r_new = tier_rank(tier_now), tier_rank(name)
        if r_old is not None and r_new is not None and r_old != r_new:
            ev = '승급' if r_new > r_old else '강등'
        elif season_direction():
            ev = season_direction()
        elif champ and tier_last_champ is False:
            ev = '승급'
        elif tier_last_champ and not champ:
            ev = '강등'
        elif popup_hint:
            ev = popup_hint
        else:
            ev = '티어 변경'
        mark_event(ev, tier_now, name)
        strip_last = []                       # 새 티어: 결과 칸이 비어서 다시 시작
        last_bar.clear()
    if name:
        tier_last_named = name
    tier_last_mask, tier_last_champ, popup_hint, tier_now = m1, champ, None, name


# 티어 이름: tier_samples 폴더의 이미지 파일 이름 (사용자가 '이름없음_...' 파일을 '마스터 3부.png' 처럼 바꿔 둠)
# 아래 -> 위: 월드클래스 3부 > 2부 > 1부 > 마스터 3~1부 > 챌린저 3~1부 > 슈퍼챌린저 > 챔피언스 (+ 그 아래/위 티어)
TIER_ORDER = ['아마추어', '세미프로', '프로', '월드클래스', '마스터', '챌린저', '슈퍼챌린저', '챔피언스', '슈퍼챔피언스']
TIER_FAMILIES = sorted(TIER_ORDER, key=len, reverse=True)     # 긴 이름부터 비교 ('슈퍼챌린저'가 '챌린저'보다 먼저)
tier_now = None                  # 지금 티어 이름 (모르면 None)
_tier_lib = {'key': None, 'items': []}


def tier_rank(name):
    """'마스터 3부' -> 비교용 숫자 (높을수록 위 티어). 모르는 이름이면 None"""
    if not name:
        return None
    n = name.replace('감독', '').replace(' ', '')
    for fam in TIER_FAMILIES:
        if n.startswith(fam):
            rest = n[len(fam):]
            div = int(rest[:-1]) if rest.endswith('부') and rest[:-1].isdigit() else 0
            return TIER_ORDER.index(fam) * 10 + (9 - div if div else 9)
    return None


_tier_log_last = ['']


def tier_log(msg):
    """티어 확인 결과를 로그에 (같은 내용 반복은 생략)"""
    if msg != _tier_log_last[0]:
        _tier_log_last[0] = msg
        LOG.info(msg)


TIER_LIST = ['월드클래스 3부', '월드클래스 2부', '월드클래스 1부', '마스터 3부', '마스터 2부', '마스터 1부',
             '챌린저 3부', '챌린저 2부', '챌린저 1부', '슈퍼챌린저', '챔피언스']        # 아래 -> 위 (한 칸씩)


def _norm_tier(n):
    return (n or '').replace('감독', '').replace(' ', '')


last_bar = {}                    # 챔스 아래 티어 마지막 홈 화면의 {'pts': 승점, 'green': 승격선} (승급/강등 방향 판단)
tier_last_named = None           # 마지막으로 이름을 안 티어


def note_bar(pts, lines):
    if pts is not None:
        last_bar['pts'] = pts
    if lines.get('green'):
        last_bar['green'] = lines['green']


def season_direction():
    """시즌 마지막 홈 화면의 승점으로 방향 판단: 이미 승격선 이상이면 '승급', 마지막 판을 이겨도 못 닿으면 '강등', 애매하면 None"""
    p, g = last_bar.get('pts'), last_bar.get('green')
    if p is None or g is None:
        return None
    if p >= g:
        return '승급'
    if p + 3 < g:
        return '강등'
    return None


def guess_tier_name(old, direction=None):
    """직전 티어(old)의 위/아래 이웃 티어로 이름 추정 (예: 챌린저 1부에서 승급 -> 슈퍼챌린저).
    방향을 알면 그쪽 이웃, 모르면 이웃 중 아직 견본 없는 티어가 하나뿐일 때만"""
    key = [_norm_tier(t) for t in TIER_LIST]
    if _norm_tier(old) not in key:
        return None
    i = key.index(_norm_tier(old))
    if direction in ('승급', '강등'):
        j = i + 1 if direction == '승급' else i - 1
        if 0 <= j < len(TIER_LIST):
            LOG.info('처음 보는 티어 이름 추정: %s (%s에서 %s)', TIER_LIST[j], old, direction)
            return TIER_LIST[j]
        return None
    known = {_norm_tier(n) for n, _m in _tier_library() if n}
    cands = [TIER_LIST[j] for j in (i - 1, i + 1) if 0 <= j < len(TIER_LIST) and key[j] not in known]
    if len(cands) == 1:
        LOG.info('처음 보는 티어 이름 추정: %s (직전 %s의 이웃 중 견본 없는 티어)', cands[0], old)
        return cands[0]
    return None


def _tier_library():
    """티어명 견본 [(이름 또는 None, 글씨 모양)]: 기록 폴더 tier_samples + 프로그램 내장(images/tier_names). 바뀔 때만 다시 읽음"""
    d = 'tier_samples'
    bundled = paths.resource(os.path.join('images', 'tier_names'))
    try:
        files = sorted(os.path.join(d, f) for f in os.listdir(d) if f.lower().endswith('.png')) if os.path.isdir(d) else []
        if os.path.isdir(bundled):
            files += sorted(os.path.join(bundled, f) for f in os.listdir(bundled) if f.lower().endswith('.png'))
        key = tuple((f, os.path.getmtime(f)) for f in files)
    except OSError:
        return []
    if _tier_lib['key'] == key:
        return _tier_lib['items']
    items = []
    for path in files:
        fn = os.path.basename(path)
        img = paths.imread(path, cv2.IMREAD_GRAYSCALE)
        if img is None or img.shape != (TIER_H, TIER_W):
            continue
        stem = fn[:-4]
        named = not (stem.startswith('이름없음') or stem[:8].isdigit())   # 예전 형식(날짜_...)도 이름 없음
        items.append((stem.strip() if named else None, img > 200))
    _tier_lib['key'], _tier_lib['items'] = key, items
    return items


def tier_name_of(mask, champ=False):
    best, best_d = None, 10 ** 6
    for name, m in _tier_library():
        if name:
            d = tier_diff(mask, m)
            if d < best_d:
                best, best_d = name, d
    if best_d <= TIER_SAME_MAX:
        return best
    return '챔피언스' if champ else None


def tier_sample_exists(mask):
    return any(tier_diff(mask, m) <= TIER_SAME_MAX for _n, m in _tier_library())


tier_events = []                 # 이번 세션 [(시각, '승급'/'강등'/'티어 변경')]


def mark_event(ev, old=None, new=None):
    """직전 판(방금 끝난 판)에 승급/강등 표시 + 알림"""
    if not champions_history:
        return
    h = champions_history[-1]
    h[H_NOTE] = (h[H_NOTE] + ', ' + ev) if h[H_NOTE] else ev
    safe_update(h[H_TS], h[H_NO], 비고=ev)
    tier_events.append((time.strftime('%H:%M'), ev))
    move = (' (%s → %s)' % (old or '?', new or '?')) if (old or new) else ''
    LOG.info('%s - %d번째 게임 결과%s', ev, h[H_NO], move)
    icon = {'승급': '▲', '강등': '▼'}.get(ev, '◆')
    set_status('%s %s!%s (%d번째 게임 후) [%s]' % (icon, ev, move, h[H_NO], time.strftime('%H:%M:%S')), 'info')
    alert('info', '%s %s!%s (%d번째 게임 후)' % (icon, ev, move, h[H_NO]),
          ['랭킹점수 %s' % fmt_num(last_known_score, '점')] if last_known_score is not None else [])
    draw_ui()


def save_tier_sample(img, name=None):
    """처음 보는 티어명 이미지 저장: 이름을 알면 '이름.png', 모르면 '이름없음_날짜시간.png' (파일 이름을 바꾸면 그 이름으로 표시)"""
    try:
        os.makedirs('tier_samples', exist_ok=True)
        if len(os.listdir('tier_samples')) >= TIER_SAMPLE_MAX:
            return
        fn = ('%s.png' % name) if name and not os.path.exists(os.path.join('tier_samples', '%s.png' % name)) \
            else '이름없음_%s.png' % time.strftime('%Y%m%d_%H%M%S')
        paths.imwrite(os.path.join('tier_samples', fn), cv2.cvtColor(img, cv2.COLOR_RGB2BGR))
        LOG.info('티어명 이미지 저장: %s', fn)
        _tier_lib['key'] = None
    except Exception:
        pass


def note_popup(ev):
    """승급/강등 확인 팝업을 누름 -> 다음 홈 화면에서 티어가 바뀌었으면 이 방향으로 표시"""
    global popup_hint
    popup_hint = ev
    LOG.info('팝업 확인 버튼(%s) 클릭', ev)


# ── VS 화면: 점수·순위 기록 (+ 연속 진행 감지) ──────────────────────
def handle_vs(frame):
    """VS 화면이면 기록 처리. True = 이번 차례는 진행 버튼을 누르지 말고 기다림(점수·순위 읽는 중)"""
    global vs_visible, vs_expect, vs_seen_at, vs_warned, cont_count
    try:
        vb = locate('vs_team.png', 0.9)
    except Exception:
        if vs_visible and vs_pending is not None and vs_pending['got']:
            finish_vs()                               # VS 화면이 지나감 -> 읽어 둔 값 기록
        vs_visible = False
        return False
    now = time.time()
    if not vs_visible:                                 # VS 화면이 새로 나타남
        vs_visible = True
        vs_seen_at = now
        if vs_expect:
            vs_expect = False                          # 정상: 공식경기를 누른 판
        elif now - champions_session_start > CONT_GRACE_SEC:
            cont_count += 1
            LOG.warning('홈 화면을 거치지 않은 경기 시작 (%d회째) - 연속 진행', cont_count)
            begin_game(None, '연속 진행', from_home=False)
            set_status('연속 진행 중 (%d판) - 기록은 계속, 정지 조건은 홈 화면을 거칠 때만 확인됩니다' % cont_count, 'warn')
            if not vs_warned:
                vs_warned = True
                alert('warn', '⚠️ 연속 진행 중입니다',
                      ['홈 화면(공식경기)을 거치지 않고 다음 경기가 시작됐습니다.',
                       '기록은 계속 남지만, 목표 점수·순위·종료 시각 정지는 홈 화면을 거칠 때만 됩니다.'], image='screen')
            draw_ui()
    if vs_pending is not None:
        read_vs(frame, vb)
        if vs_pending is not None and now - vs_seen_at < VS_HOLD_SEC:
            return True
    return False


def read_vs(frame, vb):
    """VS 화면에서 내 점수·순위를 읽음. 같은 값이 2번 연속 나와야 인정"""
    p = vs_pending
    vals = {}
    text_visible = False
    g = crop(frame, score_ocr.rank_region(vb, 'mine'))
    if g is not None:
        g = cv2.cvtColor(g, cv2.COLOR_RGB2GRAY)
        if int(g.max()) > score_ocr.RANK_TEXT_TH:
            r, _d = score_ocr.read_rank_from_gray(g)
            if r is not None:
                vals['rank_mine'] = r
    if 'rank_mine' not in vals and not p.get('strip_done'):
        st = score_ocr.read_result_strip(crop(frame, score_ocr.strip_region(vb, score_ocr.STRIP_VS)), score_ocr.STRIP_VS)
        if st:                                             # 챔스 아래 티어: 결과 칸으로 직전 판 승/무/패
            if p.get('strip') == st:
                p['strip_done'] = True
                h = p['h']
                i = champions_history.index(h) if h in champions_history else -1
                if i >= 0:
                    h[H_CHAMP] = False
                    apply_strip(st, i - 1)
            p['strip'] = st
    a = crop(frame, score_ocr.vs_score_region(vb, 'mine'))
    if a is not None and int(a[..., 2].max()) > score_ocr.VS_TEXT_TH:
        text_visible = True
        s, _d = score_ocr.read_vs_score(a)
        if s is not None:
            vals['score_mine'] = s
    ref = last_known_score
    if 'score_mine' in vals and ref is not None and abs(vals['score_mine'] - ref) > SCORE_JUMP_MAX:
        vals.pop('score_mine')                           # 직전 판과 너무 다름 -> 잘못 읽은 것
    for k, v in vals.items():
        if p['last'].get(k) == v:
            p['got'][k] = v
        p['last'][k] = v
    if not text_visible:
        return                                           # 글씨가 아직 안 나타남 (등장 연출 중) -> 시도로 세지 않음
    p['tries'] += 1
    got = p['got']
    if 'score_mine' in got:
        p['after'] += 1
    done = ('score_mine' in got and ('rank_mine' in got or p['after'] >= 3)) or p['tries'] >= VS_READ_FAILS
    if not done:
        return
    if 'score_mine' not in got and 'rank_mine' not in got:
        save_vs_samples(frame, vb, p['h'][H_NO])
    finish_vs()


def finish_vs():
    """읽은 값(확인된 것만)을 기록하고 이 판의 VS 읽기를 끝냄. VS 화면이 지나가거나 다음 판이 시작될 때도 호출"""
    global vs_pending, last_rank, last_known_score
    p = vs_pending
    if p is None:
        return
    vs_pending = None
    got = p['got']
    h = p['h']
    fields = {}
    if h[H_SCORE] is None and 'score_mine' in got:
        h[H_SCORE] = got['score_mine']
        fields['랭킹점수'] = got['score_mine']
        i = champions_history.index(h) if h in champions_history else -1
        if i > 0:
            settle_by_score(i - 1, h[H_SCORE])               # 결과 칸으로 못 정한 직전 판은 점수 변화로
    if 'score_mine' in got:
        last_known_score = got['score_mine']
    if 'rank_mine' in got:
        h[H_RANK] = last_rank = got['rank_mine']
        fields['순위'] = got['rank_mine']
        h[H_CHAMP] = True
    if fields:
        safe_update(h[H_TS], h[H_NO], **fields)
    LOG.info('VS 화면 - %d번째 게임: %s', h[H_NO], fields or '못 읽음')
    draw_ui()


def save_vs_samples(frame, vb, game_no):
    """점수·순위를 못 읽은 판의 VS 화면 글씨 부분 저장 (인식 개선용, rank_samples 폴더)"""
    try:
        os.makedirs('rank_samples', exist_ok=True)
        if len(os.listdir('rank_samples')) >= SAMPLE_MAX:
            return
        stamp = time.strftime('%Y%m%d_%H%M%S')
        x, y = int(vb.left) - 120, int(vb.top) + 225
        a = crop(frame, (x, y, 520, 75))
        if a is not None:
            paths.imwrite(os.path.join('rank_samples', '%s_g%s_vs.png' % (stamp, game_no)), cv2.cvtColor(a, cv2.COLOR_RGB2BGR))
    except Exception:
        pass


# ── 라인업 화면: 포메이션 ────────────────────────────────────
form_screen = {'side': None, 'seen': 0.0, 'done': False, 'fails': 0, 'last': None, 'saved': False}
form_pending = {}                # {'opp'/'mine': (포메이션, 읽은 시각)} 지금 판에 붙일 수 없어 다음 판용으로 보관
FORM_IDX = {'opp': H_OPP, 'mine': H_MINE}
FORM_COL = {'opp': '상대포메이션', 'mine': '내포메이션'}
FORM_NAME = {'opp': '상대', 'mine': '내'}


def find_formation_screen(frame):
    """라인업 화면이면 ('opp', 라벨 Box) / 아니면 (None, None). 오른쪽 아래만 찾음 (왼쪽 패널의 'vs 내 포메이션' 글씨 제외)"""
    g = frame['gray']
    H, W = g.shape
    y0, x0 = int(H * 0.6), int(W * 0.6)
    lab = needle_gray('formation_label.png')
    sub = g[y0:, x0:]
    if sub.shape[0] < lab.shape[0] or sub.shape[1] < lab.shape[1]:
        return None, None
    conf = FORM_LABEL_CONF - (0.05 if frame.get('remote') else 0.0)   # 원격 모드: 압축 때문에 조금 낮춤
    r = cv2.matchTemplate(sub, lab, cv2.TM_CCOEFF_NORMED)
    _mn, mx, _l, loc = cv2.minMaxLoc(r)
    if not (conf <= mx <= 1.01):
        return None, None
    box = Box(loc[0] + x0 + frame['ox'], loc[1] + y0 + frame['oy'], lab.shape[1], lab.shape[0])
    # v2.3: 경기 전 라인업 화면은 판마다 1번, 상대 팀 화면 ('상대 기록' 패널은 상대 기록이 있을 때만 보임)
    return 'opp', box


def read_formation(frame, box):
    """-> (formation_ocr.read 결과, 글씨 영역 gray)"""
    a = crop(frame, formation_ocr.area_of(box))
    if a is None:
        return {'text': None, 'why': '화면 밖'}, None
    g = cv2.cvtColor(a, cv2.COLOR_RGB2GRAY)
    return formation_ocr.read(g), g


def handle_formation(frame):
    """라인업 화면이면 포메이션을 읽어 지금 판에 기록 (같은 값 2번 연속이면 확정)"""
    st = form_screen
    now = time.time()
    side, box = find_formation_screen(frame)
    if side is None:
        if st['side'] is not None and now - st['seen'] > FORM_GONE_SEC:
            st['side'] = None                           # 화면이 지나감
        return
    if st['side'] != side or now - st['seen'] > FORM_GONE_SEC:
        st.update(side=side, done=False, fails=0, last=None, saved=False)   # 새 라인업 화면
    st['seen'] = now
    if st['done']:
        return
    r, g = read_formation(frame, box)
    for v, p in r.get('learned', []):
        LOG.info('포메이션 숫자 %d 자동 학습 -> %s', v, p)
    text = r['text']
    if text is None:
        st['fails'] += 1
        st['last'] = None
        if st['fails'] >= FORM_FAIL_SAVE and not st['saved']:
            st['saved'] = True
            p = formation_ocr.save_sample(g, side) if g is not None else None
            LOG.warning('%s 포메이션 못 읽음 (%s) - 글씨 저장: %s', FORM_NAME[side], r.get('why'), p or '-')
            if side == 'opp':
                form_attach(side, '?')                  # 상대 화면은 확실하니 '미인식'으로 남김 (내 화면은 표시만 안 함)
        return
    if st['last'] == text:
        st['done'] = True
        form_attach(side, text)
    st['last'] = text


def form_attach(side, text):
    """읽은 포메이션을 지금 판에 기록 (지금 판에 이미 있거나 너무 오래됐으면 다음 판용으로 보관)"""
    idx = FORM_IDX[side]
    now = time.time()
    h = champions_history[-1] if champions_history else None
    if h is not None and len(h) < 11:
        h.extend([None] * (11 - len(h)))
    if h is not None and (h[idx] is None or (h[idx] == '?' and text != '?')) and now - h[H_EPOCH] < FORM_ATTACH_SEC:
        _form_set(h, side, text)
        return
    if text != '?':
        form_pending[side] = (text, now)
        LOG.info('%s 포메이션 %s - 다음 판용으로 보관', FORM_NAME[side], text)


def _form_set(h, side, text):
    h[FORM_IDX[side]] = text
    safe_update(h[H_TS], h[H_NO], **{FORM_COL[side]: text})
    LOG.info('%d번째 게임 %s 포메이션: %s', h[H_NO], FORM_NAME[side], '미인식' if text == '?' else text)
    draw_ui()


def form_take_pending(h):
    """새 판 시작: 보관한 포메이션이 방금 읽은 것이면 이 판에 붙임"""
    now = time.time()
    for side, (text, t) in list(form_pending.items()):
        if now - t < FORM_PENDING_SEC:
            _form_set(h, side, text)
    form_pending.clear()


def form_text(v):
    return '미인식' if v == '?' else (v or '')


# ── 메인 루프 (원본 버튼 순서 유지) ───────────────────────────
# ── v3.2 전술 자동 변경 (tactics.py) ─────────────────────────────
TAC = tactics.Store(os.path.join(DATA_DIR, 'tactics'))
_tac = {'done_for': None, 'reg': None, 'reg_stop': False, 'msg': '', 'unknown_alerted': False}


class _TacIO:
    """tactics.py 가 화면을 보고 누를 때 쓰는 손발 (테스트에서는 흉내 낸 것으로 바꿈)"""

    def grab(self):
        return grab_frame()

    def crop(self, f, reg):
        return crop(f, reg)

    def anchor(self, f):
        try:
            return locate('squad.png', 0.93, frame=f)
        except Exception:
            return None

    def click(self, x, y):
        click_at(x, y)

    def hover(self, x, y):
        macro_input()
        pyautogui.moveTo(x=x, y=y)

    def sleep(self, s):
        time.sleep(s)

    def mouse_down(self):
        if os.name != 'nt':
            return False
        import ctypes
        return bool(ctypes.windll.user32.GetAsyncKeyState(0x01) & 0x8000)

    def mouse_pos(self):
        if os.name != 'nt':
            return pyautogui.position()
        import ctypes
        import ctypes.wintypes
        pt = ctypes.wintypes.POINT()
        ctypes.windll.user32.GetCursorPos(ctypes.byref(pt))
        return pt.x, pt.y


TAC_IO = _TacIO()


def _tac_results():
    """기록 파일의 결과(승/무/패, 비어 있으면 점수 변화로 판단)를 날짜시간별로"""
    try:
        recs = score_log.read_records()[-400:]
        return {_tac_key(r[0], r[1]): res for r, res in score_log.results_of(recs) if res}
    except Exception:
        return {}


def _tac_key(ts, no):
    return '%s#%s' % (ts, no)


def _tac_tag(h, i):
    """이 판에 쓴 전술을 기록 (기록 파일 '전술' 칸 + 전술별 판 목록)"""
    if h is None or len(h) <= H_TAC or h[H_TAC] is not None:
        return
    h[H_TAC] = TAC.name(i) if i is not None else '기타'
    safe_update(h[H_TS], h[H_NO], 전술=h[H_TAC])
    TAC.on_game(_tac_key(h[H_TS], h[H_NO]), i)


def _tac_read_stable(a):
    """스쿼드 화면이 다 뜰 때까지 기다렸다가 0.5초 간격으로 읽어 두 번 연속 같은 결과 (최대 4번). 못 맞추면 -1"""
    prev = None
    for k in range(4):
        time.sleep(0.5)
        f = grab_frame()
        a2 = TAC_IO.anchor(f) or a
        det = {}
        got = tactics.read(TAC, TAC_IO, f, a2, det)
        LOG.info('전술 칸 읽기 %d: %s -> %s', k + 1, tactics.score_text(TAC, det),
                 '칸 안 보임' if got == -1 else TAC.name(got))
        if got != -1 and got == prev:
            return got
        prev = got
    return -1


def tactic_step():
    """스쿼드 화면([진행] 누르기 직전): 지금 전술 확인 -> 필요하면 전환 -> 이 판 전술 기록. 뭔가 눌렀으면 True"""
    if not TAC.registered() or last_game['on']:
        return False
    if _tac['done_for'] == champions_game_count:
        return False
    try:
        a = locate('squad.png', 0.95)
    except Exception:
        return False
    if time.time() - _last_click.get('squad.png', 0) < SAME_BUTTON_SEC:
        return False
    _tac['done_for'] = champions_game_count
    h = champions_history[-1] if champions_history else None
    try:
        f = cur_frame() or grab_frame()
        if tactics.list_open(crop(f, tactics.list_region(a))):            # 전술 목록이 열려 있음 -> 닫고 다음 차례에
            fx, fy, fw, fh = tactics.field_region(a)
            click_at(fx + fw // 2, fy + fh // 2)
            _tac['done_for'] = None
            return True
        cur = _tac_read_stable(a)                                      # v3.2.1: 화면이 다 뜬 뒤 두 번 읽어 같을 때만
        if cur == -1:
            LOG.warning('전술 칸을 확실히 읽지 못함 - 이번 판은 지금 전술(%s) 그대로로 봄', TAC.name(TAC.s['cur']))
            _tac_tag(h if (h is not None and h[H_NO] == champions_game_count) else None, TAC.s['cur'])
            return False
        if cur is None and TAC.s['cur'] is not None and not TAC.s.get('unknown_once'):
            TAC.s['unknown_once'] = True                                   # 한 번은 잘못 읽었을 수 있음 -> 그대로로 봄
            TAC.save()
            LOG.info('전술 칸이 등록 전술과 다르게 읽힘 (1번째) - 다음 판에도 같으면 등록 안 된 전술로 봄')
            cur = TAC.s['cur']
        elif cur is not None or TAC.s['cur'] is None:
            TAC.s['unknown_once'] = False
        tactics.observe(TAC, cur)
        if cur is None and TAC.settings.get('enabled') and not TAC.s.get('unknown_note'):
            TAC.s['unknown_note'] = True
            TAC.save()
            alert('warn', '⇄ 등록 안 된 전술 사용 중 - 자동 변경 멈춤',
                  ['게임에서 등록하지 않은 전술이 선택돼 있어 그대로 진행합니다.',
                   '등록한 전술(①②③)로 돌려 놓으면 자동 변경이 다시 작동합니다.'])
        TAC.sync_results(_tac_results())
        d = tactics.decide(TAC)
        clicked = False
        if d['kind'] == 'lock_alert':
            tactics.apply_decision(TAC, d)
            alert('warn', '⇄ 고정 전술 연패 중', [d['why'], '%s 그대로 진행합니다.' % TAC.name(cur)])
        elif d['kind'] == 'unlock':
            tactics.apply_decision(TAC, d)
            alert('info', '⇄ 전술 고정 해제 - 처음부터 다시 평가', [TAC.name(cur), d['why']])
        elif d['kind'] and d['to'] is not None:
            to = d['to']
            if to == cur:
                tactics.apply_decision(TAC, d, to)
                if d['kind'] == 'lock':
                    alert('info', '⇄ 전술 고정 - %s' % TAC.name(to), [d['why']])
            else:
                LOG.info('전술 변경: %s -> %s (%s)', TAC.name(cur), TAC.name(to), d['why'])
                ok, got, why = tactics.switch(TAC, TAC_IO, a, to, LOG.info)
                clicked = True
                if ok:
                    tactics.apply_decision(TAC, d, to)
                    set_status('전술 변경: %s → %s' % (TAC.name(cur), TAC.name(to)), 'info')
                    alert('info', '⇄ 전술 변경 %s → %s' % (TAC.name(cur), TAC.name(to)),
                          [d['why'].replace('lock:', ''), '다음 판부터 %s로 진행합니다.' % TAC.name(to)])
                    cur = to
                else:
                    tactics.apply_decision(TAC, d, None)
                    if d['kind'] == 'pending':
                        TAC.s['pending'] = None
                    if got not in (-1, None, cur) and got in TAC.registered():
                        tactics.observe(TAC, got)                    # 다른 등록 전술이 선택됨 -> 그걸로 셈
                        cur = got
                    elif cur is not None and got != cur:
                        back, got2, _w = tactics.switch(TAC, TAC_IO, a, cur, LOG.info)   # 원래 전술로 되돌리기
                        LOG.info('원래 전술로 되돌리기: %s', '성공' if back else '실패')
                        if not back:
                            tactics.observe(TAC, None if got2 == -1 else got2)
                            cur = TAC.s['cur']
                    if '순서' in why:
                        TAC.s['slots'][to]['missing'] = True               # 이 전술은 다시 등록할 때까지 건너뜀
                    TAC.add_log('%s 로 바꾸지 못함 - %s' % (TAC.name(to), why))
                    TAC.save()
                    alert('warn', '⇄ 전술 변경 실패 - %s 그대로 진행' % TAC.name(cur),
                          [why, '[전술 자동 변경] 창에서 그 전술을 다시 등록해 주세요.' if '순서' in why else '다음 판에 다시 시도합니다.'])
        _tac_tag(h if (h is not None and h[H_NO] == champions_game_count) else None, cur)
        draw_ui()
        return clicked
    except Exception:
        note_error('전술 자동 변경')
        return False


def tac_begin(h, from_home):
    """새 판: 연속 진행(스쿼드 화면을 안 거침)이면 마지막으로 확인한 전술로 기록"""
    if TAC.registered() and not from_home:
        _tac_tag(h, TAC.s['cur'])


def _cmd_tactics(args):
    """텔레그램/디스코드: 전술 (상태) / 전술 1·2·3 (다음 판부터) / 전술 자동 (켜기·끄기)"""
    a = (args or '').strip().replace(' ', '')
    if a in ('자동', '자동켜기', '자동끄기', '켜기', '끄기', 'on', 'off'):
        on = (not TAC.settings.get('enabled')) if a == '자동' else a in ('자동켜기', '켜기', 'on')
        TAC.settings['enabled'] = on
        TAC.add_log('자동 변경 %s (원격 명령)' % ('켬' if on else '끔'))
        TAC.save()
        draw_ui()
    elif a[:1] in '123①②③' and a:
        i = '123①②③'.index(a[0]) % 3
        if not TAC.slot(i):
            return {'title': '%s 은 등록돼 있지 않아요' % tactics.MARK[i], 'lines': ['PC의 [전술 자동 변경] 창에서 등록해 주세요.'], 'kind': 'warn'}
        TAC.s['pending'] = {'to': i, 'why': '직접 선택 (원격 명령)'}
        TAC.s['slots'][i]['missing'] = False
        TAC.save()
        draw_ui()
        return {'title': '⇄ 다음 판부터 %s' % TAC.name(i),
                'lines': ['다음 스쿼드 화면에서 바꿉니다.' + (' (연속 진행 중이면 끝난 뒤)' if is_manager_mode else ''),
                          '직접 고르면 전술 고정은 풀립니다.'], 'kind': 'done'}
    lines = [tactics.status_line(TAC), '']
    for i in range(tactics.SLOTS):
        sl = TAC.slot(i)
        if not sl:
            lines.append('%s 비어 있음' % tactics.MARK[i])
            continue
        stt = TAC.stats(i)
        lines.append('%s · %d판%s%s%s' % (TAC.name(i), stt['n'], (' · 승률 %d%%' % round(stt['rate'])) if stt['n'] else '',
                                        ' · 지금 사용' if TAC.s['cur'] == i else '', ' · 못 찾음(다시 등록 필요)' if sl.get('missing') else ''))
    cfg = TAC.settings
    lines += ['', '자동 변경: %s' % ('켜짐' if cfg.get('enabled') else '꺼짐'),
              '기준: %d판 뒤 최근 %d판 승률 %d%% 미만%s' % (cfg['min_games'], cfg['min_games'], cfg['rate'],
                                                  (' · %d연패' % cfg['streak']) if cfg.get('streak_on') else '')]
    if TAC.s['log']:
        lines += ['', '최근: %s %s' % tuple(TAC.s['log'][0])]
    btns = [(TAC.name(i), '전술 %d' % (i + 1)) for i in TAC.registered()]
    btns.append(('자동 변경 끄기' if cfg.get('enabled') else '자동 변경 켜기', '전술 자동'))
    return {'title': '⇄ 전술 자동 변경', 'lines': lines, 'kind': 'info', 'buttons': btns}


def tac_register(i):
    """[전술 등록]: 매크로 일시정지 -> 사용자가 목록을 열고 클릭할 때까지 기다림 (따로 스레드)"""
    if _tac['reg'] is not None:
        return
    if is_manager_mode and not is_paused:
        on_press_f10(None)
    _tac['reg'] = i
    _tac['reg_stop'] = False
    _tac['msg'] = '기다리는 중...'

    def work():
        try:
            cap = tactics.capture_registration(TAC_IO, 45.0, lambda: _tac['reg_stop'], LOG.info)
            if isinstance(cap, str):
                _tac['msg'] = cap
            else:
                TAC.set_slot(i, cap)
                _tac['msg'] = '%s 등록 완료' % TAC.name(i)
                LOG.info('전술 등록: %s', TAC.name(i))
        except Exception:
            note_error('전술 등록')
            _tac['msg'] = '등록 중 오류 - macro.log 참고'
        finally:
            _tac['reg'] = None
    threading.Thread(target=work, daemon=True).start()


def tac_api(cmd, *a):
    """전술 창(gui) -> 매크로"""
    if cmd == 'register':
        tac_register(a[0])
    elif cmd == 'cancel_reg':
        _tac['reg_stop'] = True
    elif cmd == 'delete':
        TAC.delete_slot(a[0])
    elif cmd == 'rename':
        TAC.rename(a[0], a[1])
    elif cmd == 'use':
        _cmd_tactics(str(a[0] + 1))
        if TAC.s.get('pending'):
            TAC.s['pending']['why'] = '직접 선택'
            TAC.save()
    elif cmd == 'settings':
        new = dict(a[0])
        if new.get('enabled') != TAC.settings.get('enabled'):
            TAC.add_log('자동 변경 %s' % ('켬' if new.get('enabled') else '끔'))
        TAC.settings.update(new)
        TAC.save()
        LOG.info('전술 자동 변경 설정: %s', TAC.settings)
    draw_ui()


def tac_snapshot():
    """전술 창이 읽는 상태"""
    slots = []
    for i in range(tactics.SLOTS):
        sl = TAC.slot(i)
        if not sl:
            slots.append(None)
            continue
        s_all, s30 = TAC.stats(i), TAC.stats(i, int(TAC.settings.get('min_games') or 30))
        tag = ''
        if sl.get('missing'):
            tag = ('못 찾음 - 다시 등록', 'red')
        elif TAC.s['cur'] == i:
            tag = ('고정 · 사용 중', 'cyan') if TAC.s.get('locked') == i else ('지금 사용 중', 'cyan')
        elif i in TAC.s.get('evals', {}):
            tag = ('기준 미만 %d%%' % round(TAC.s['evals'][i]), 'red')
        stat = '%d판' % s_all['n']
        if s_all['n']:
            stat += ' · 승률 %d%% · 최근 %d판 %d%%' % (round(s_all['rate']), s30['n'], round(s30['rate']))
        slots.append({'name': sl.get('name') or '', 'img': TAC.image(i, 'field'), 'stat': stat, 'tag': tag,
                      'cur': TAC.s['cur'] == i, 'id': sl.get('id')})
    return {'slots': slots, 'settings': dict(TAC.settings), 'line': tactics.status_line(TAC),
            'log': list(TAC.s['log'][:8]), 'reg': _tac['reg'], 'msg': _tac['msg'],
            'pending': (TAC.s.get('pending') or {}).get('to')}


# ── v3.2 승강전 (챔스 아래 티어 10판) ─────────────────────────────
promo = {'tier': None, 'played': None, 'pts': None, 'red': None, 'green': None, 'strip': None, 'sent': set(),
         'last': None, 't': 0}


def promo_update(strip, lines, champ):
    """로비에서 읽은 결과 칸(strip)·막대(lines)로 승강전 상태 갱신 + 갈림길 알림"""
    if champ:
        promo.update(tier=None, played=None, pts=None, strip=None)
        return
    if strip is None:
        return
    played = len(strip)
    pts = 3 * strip.count('승') + strip.count('무')
    same_tier = promo['tier'] == tier_now
    new_window = (promo['played'] is not None and played < promo['played']) or not same_tier
    if new_window:
        if promo['played'] is not None and same_tier and tier_now and promo['played'] >= 9:
            _promo_final()                                  # 같은 티어로 10판 끝 -> 잔류
        promo.update(red=None, green=None, sent=set())
    if lines.get('red'):
        promo['red'] = lines['red']
    if lines.get('green'):
        promo['green'] = lines['green']
    promo.update(tier=tier_now, played=played, pts=pts, strip=list(strip), t=time.time())
    red, green = promo['red'], promo['green']
    left = 10 - played
    mx = pts + 3 * left
    LOG.info('승강전: %d/10판 %s · %d점 · 잔류선 %s · 승급선 %s · 최대 %d', played, ''.join(strip) or '-', pts, red, green, mx)
    msgs = []
    if green and pts < green <= pts + 3 and left > 0:
        msgs.append(('next_win', '⬆ 다음 판 이기면 승급', ['승점 %d점 · 승급선 %d점 (%d판 남음)' % (pts, green, left)]))
    if green and mx < green and 'no_promo' not in promo['sent'] and played > 0:
        msgs.append(('no_promo', '승강전 - 이번에는 승급 불가', ['남은 %d판을 다 이겨도 최대 %d점 < 승급선 %d점' % (left, mx, green)]))
    if red and mx < red:
        msgs.append(('relegate', '⬇ 승강전 - 강등 확정', ['남은 판을 다 이겨도 최대 %d점 < 잔류선 %d점' % (mx, red)]))
    elif red and left > 0 and pts + 3 * (left - 1) < red <= mx:
        msgs.append(('next_loss', '⚠ 다음 판 지면 강등 확정', ['승점 %d점 · 잔류선 %d점 (%d판 남음)' % (pts, red, left)]))
    for key, title, body in msgs:
        k2 = '%s:%d' % (key, played) if key in ('next_win', 'next_loss') else key
        if k2 in promo['sent']:
            continue
        promo['sent'].add(k2)
        alert('warn' if key in ('relegate', 'next_loss') else 'info', title, body + ['티어: %s' % (tier_now or '-')])


def _promo_final():
    """같은 티어에서 10판이 끝나고 새 승강전이 시작됨 = 잔류 (승급·강등이면 티어가 바뀌어 기존 승급/강등 알림이 감)"""
    pts, red, green = promo['pts'], promo['red'], promo['green']
    alert('info', '승강전 결과: 잔류', ['마지막 판 전 %s점 (잔류선 %s · 승급선 %s)' % (pts, red or '-', green or '-'),
                                     '티어: %s - 새 승강전 10판 시작' % (promo['tier'] or '-')])


def promo_snapshot():
    if promo['played'] is None or (tier_now is not None and promo['tier'] != tier_now):
        return None
    left = 10 - promo['played']
    p = promo['pts']
    mx = p + 3 * left
    g, r = promo['green'], promo['red']
    head = '승급까지 %d점' % (g - p) if g and p < g else ''
    if g and mx < g:
        head = '이번엔 승급 불가'
    if r and mx < r:
        head = '강등 확정'
    hint = []
    if g and p < g <= p + 3 and left:
        hint.append('다음 판 이기면 승급')
    if r and left and p + 3 * (left - 1) < r <= mx:
        hint.append('다음 판 지면 강등 확정')
    elif r and p >= r:
        hint.append('잔류선 넘음')
    return {'played': promo['played'], 'strip': promo['strip'], 'pts': p, 'red': r, 'green': g, 'max': mx,
            'head': head, 'hint': ' · '.join(hint)}


# ── v3.2 티어 엠블럼 (로비 오른쪽 그림을 잘라 배경을 지우고 티어별로 저장) ──────────
EMBLEM_DIR = os.path.join(DATA_DIR, 'tier_emblems')
EMB_DX, EMB_DY, EMB_W, EMB_H = -140, -512, 212, 210     # 공식경기 버튼 기준 (챔피언스·챌린저 1부 캡처에서 측정)
_emb = {'busy': False, 'tried': {}}


def emblem_path(name):
    return os.path.join(EMBLEM_DIR, re.sub(r'[\\/:*?"<>|]', '_', name) + '.png') if name else None


def emblem_check(home_box, champ):
    """이 티어 엠블럼이 아직 없으면 잘라서 저장 (따로 스레드, 티어마다 한 번 · 실패하면 10분 뒤 다시)"""
    name = '챔피언스' if champ else tier_now
    if not name or _emb['busy']:
        return
    if name != target_dialog.get_option('tier_emblem'):
        target_dialog.set_option('tier_emblem', name)
    p = emblem_path(name)
    if os.path.exists(p) or time.time() - _emb['tried'].get(name, 0) < 600:
        return
    f = cur_frame() or grab_frame()
    rgb = crop(f, (int(home_box.left) + EMB_DX, int(home_box.top) + EMB_DY, EMB_W, EMB_H))
    if rgb is None:
        return
    _emb['busy'] = True
    _emb['tried'][name] = time.time()

    def work(img=rgb.copy()):
        try:
            out = cut_emblem(img)
            if out is not None:
                os.makedirs(EMBLEM_DIR, exist_ok=True)
                ok, buf = cv2.imencode('.png', out)
                if ok:
                    buf.tofile(p)
                    LOG.info('티어 엠블럼 저장: %s', name)
            else:
                LOG.info('티어 엠블럼 배경 지우기 실패 (%s) - 나중에 다시', name)
        except Exception:
            note_error('티어 엠블럼')
        finally:
            _emb['busy'] = False
    threading.Thread(target=work, daemon=True).start()


def cut_emblem(rgb):
    """엠블럼 부분(RGB) -> 배경을 지운 BGRA (모양이 이상하면 None)"""
    bgr = cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)
    m = np.zeros(bgr.shape[:2], np.uint8)
    bg, fg = np.zeros((1, 65), np.float64), np.zeros((1, 65), np.float64)
    cv2.grabCut(bgr, m, (12, 8, bgr.shape[1] - 24, bgr.shape[0] - 16), bg, fg, 6, cv2.GC_INIT_WITH_RECT)
    a = np.where((m == 1) | (m == 3), 255, 0).astype(np.uint8)
    a = cv2.morphologyEx(a, cv2.MORPH_OPEN, np.ones((3, 3), np.uint8))
    n, lab, stats, _c = cv2.connectedComponentsWithStats(a)
    if n < 2:
        return None
    big = 1 + int(np.argmax(stats[1:, cv2.CC_STAT_AREA]))
    a = np.where(lab == big, 255, 0).astype(np.uint8)
    frac = a.mean() / 255
    if not 0.25 <= frac <= 0.85:
        return None
    a = cv2.GaussianBlur(a, (3, 3), 0)
    ys, xs = np.where(a > 20)
    out = np.dstack([bgr, a])[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    return out


def emblem_now():
    name = target_dialog.get_option('tier_emblem')
    p = emblem_path(name)
    return (p, name) if p and os.path.exists(p) else (None, name)


# ── v3.3 쉬는 시간 (rest.py) ─────────────────────────────
_rest = {'t': 0, 'st': None, 'avg': None, 'tot': 0, 'autos': set(), 'skip_until': 0, 'pre_sent': None, 'end': None,
         'label': '', 'day': None, 'bad': set(), 'prev': None}


def rest_cfg():
    return rest.cfg_of(target_dialog.get_option('rest'))


def rest_save(cfg):
    target_dialog.set_option('rest', {k: cfg[k] for k in rest.DEFAULTS})
    _rest['t'] = 0


def rest_refresh(force=False):
    """시간대별 승률·자동 칸 다시 계산 (10분마다, 기록 파일 기준)"""
    today = datetime.date.today().isoformat()
    if _rest['day'] != today:                      # 날이 바뀌면 바로 다시 (돌아가며 방식은 하루 한 번 고름)
        force = True
    if not force and time.time() - _rest['t'] < 600 and _rest['st'] is not None:
        return
    _rest['t'] = time.time()
    games = []
    try:
        for r, res in score_log.results_of(score_log.read_records()):
            try:
                games.append((datetime.datetime.strptime(r[0], '%Y-%m-%d %H:%M:%S'), res))
            except ValueError:
                pass
    except Exception:
        note_error('시간대별 승률')
    cfg = rest_cfg()
    st, avg, tot = rest.stats(games, datetime.datetime.now(), int(cfg['days']))
    bad = rest.auto_blocks(st, avg, cfg)
    if cfg['mode'] == 'rotate':
        autos, why = _rest_rotate(st, avg, cfg, today)
    else:
        autos, why = bad, ''
    _rest.update(st=st, avg=avg, tot=tot, autos=autos, bad=bad, day=today)
    _rest_notify_change(autos, cfg, why)


def _rest_rotate(st, avg, cfg, today):
    """v3.5 돌아가며: 하루 한 번(그날 처음 계산할 때) 쉴 칸을 고르고 그날은 고정. 옵션 rest_rot 에 저장(다시 켜도 같은 칸)"""
    rot = target_dialog.get_option('rest_rot') or {}
    if rot.get('date') == today and rot.get('mode') == 'rotate':
        b = rot.get('block')
        _rest['prev'] = rot.get('prev')
        return ({int(b)} if b is not None else set()), ''
    prev = rot.get('block') if rot.get('mode') == 'rotate' else None
    prev = int(prev) if prev is not None else None
    b = rest.rotate_pick(st, avg, cfg, prev)
    target_dialog.set_option('rest_rot', {'date': today, 'block': b, 'prev': prev, 'mode': 'rotate'})
    _rest['prev'] = prev
    if b is None:
        why = '오늘은 쉬는 칸 없음 (조건에 걸리는 시간대 없음)'
    elif b == prev:
        why = '어제와 같은 칸 (다른 시간대는 조건에 안 걸림)'
    elif prev is not None:
        why = '어제 쉰 %s는 오늘 다시 돌림' % rest.label(prev)
    else:
        why = ''
    LOG.info('쉬는 시간(돌아가며): 오늘 %s · 어제 %s · %s', rest.label(b) if b is not None else '없음',
             rest.label(prev) if prev is not None else '-', why or '-')
    return ({b} if b is not None else set()), why


def _rest_desc(b):
    s = _rest['st'][b] if _rest['st'] else None
    if s and s['n']:
        return '%s (%d%%, %d판)' % (rest.label(b), round(s['rate']), s['n'])
    return rest.label(b)


def _rest_notify_change(autos, cfg, why):
    """v3.5: 자동 쉬는 칸이 바뀌면 알림 (매크로를 다시 켜도 같은 내용 반복 안 하게 마지막 알린 칸을 저장)"""
    key = sorted(int(b) for b in autos)
    last = target_dialog.get_option('rest_autos_last')
    if last is None:                               # 처음: 기억만
        target_dialog.set_option('rest_autos_last', key)
        return
    if sorted(last) == key:
        return
    target_dialog.set_option('rest_autos_last', key)
    add = [b for b in key if b not in last]
    gone = [b for b in last if b not in key]
    lines = []
    for b in add:
        lines.append('➕ 쉼: ' + _rest_desc(b))
    for b in gone:
        s = _rest['st'][b] if _rest['st'] else None
        if cfg['mode'] == 'rotate' and b == _rest.get('prev'):
            rs = '어제 쉬었으니 오늘은 다시 돌려 봄'
        elif cfg['mode'] == 'rotate' and b in _rest['bad']:
            rs = '돌아가며 - 하루 한 칸만 쉼'
        elif s and s['n'] < int(cfg['min_games']):
            rs = '기록 %d판 - %d판 미만이라 다시 돌려 봄' % (s['n'], int(cfg['min_games']))
        elif s and s['rate'] is not None:
            rs = '승률 %d%% - 평균(%d%%)과 차이가 줄어 다시 돌림' % (round(s['rate']), round(_rest['avg'] or 0))
        else:
            rs = '다시 돌림'
        lines.append('➖ 다시 돌림: %s · %s' % (rest.label(b), rs))
    if why and not add and not gone:
        lines.append(why)
    lines.append('방식: %s · 지금 쉬는 칸: %s' % ('하루 한 칸 돌아가며' if cfg['mode'] == 'rotate' else '조건 맞는 칸 모두',
                                         ', '.join(rest.label(b) for b in key) or '없음'))
    LOG.info('쉬는 칸 바뀜: %s', ' / '.join(lines))
    if cfg.get('enabled') and cfg.get('notify'):
        try:
            alert('info', '◐ 쉬는 시간대가 바뀌었어요', lines)
        except Exception:
            note_error('쉬는 칸 알림')


def _rest_reason(b):
    s = _rest['st'][b] if _rest['st'] else None
    k = rest.kind(b, rest_cfg(), _rest['autos'])
    if k == 'rest':
        return '%s 직접 지정한 쉬는 시간' % rest.label(b)
    if s and s['rate'] is not None:
        return '%s 승률 %d%% (평균 %d%%)' % (rest.label(b), round(s['rate']), round(_rest['avg'] or 0))
    return rest.label(b)


def rest_check(score):
    """로비(공식경기 누르기 직전): 쉬는 시간이면 대기 시작하고 True"""
    global wait_until, wait_reason, wait_info
    cfg = rest_cfg()
    if not cfg.get('enabled'):
        return False
    rest_refresh()
    now = datetime.datetime.now()
    if time.time() < _rest['skip_until']:
        return False
    end = rest.window_end(now, cfg, _rest['autos'])
    if end is None:
        return False
    b = rest.block_of(now)
    wait_until = end.timestamp()
    wait_reason = 'rest'
    wait_info = '쉬는 시간 · ' + _rest_reason(b)
    _rest.update(end=wait_until, pre_sent=None, label='%s~%s' % (rest.block_start(now).strftime('%H:%M'), end.strftime('%H:%M')))
    LOG.info('쉬는 시간 시작: %s -> %s까지 로비에서 대기', wait_info, end.strftime('%H:%M'))
    set_status('◐ %s - 로비에서 대기, %s에 자동 재개' % (wait_info, end.strftime('%H:%M')), 'warn')
    if cfg.get('notify'):
        alert('info', '◐ 쉬는 시간 시작 (%s)' % _rest['label'],
              [_rest_reason(b) + ' - 로비에서 대기합니다.', '%s에 다시 시작합니다.' % end.strftime('%H:%M')],
              buttons=[('▶ 쉬지 말고 계속', '쉬는시간 계속')])
    draw_ui()
    return True


def rest_watch():
    """쉬는 동안: 다시 시작 N분 전 알림 (한 번)"""
    if wait_reason != 'rest' or wait_until is None or not is_manager_mode:
        return
    cfg = rest_cfg()
    left = wait_until - time.time()
    if cfg.get('notify') and cfg.get('pre_on') and 0 < left <= int(cfg['pre_min']) * 60 and _rest['pre_sent'] != wait_until:
        _rest['pre_sent'] = wait_until
        alert('info', '⏰ %d분 뒤 다시 시작 (%s)' % (max(1, round(left / 60)), time.strftime('%H:%M', time.localtime(wait_until))),
              ['쉬는 시간이 끝나 자동진행을 이어 갑니다.'])


def rest_continue(by=''):
    """'지금 계속': 이번 쉬는 시간만 건너뛰고 바로 진행"""
    global wait_until, wait_reason, wait_info
    cfg = rest_cfg()
    rest_refresh()
    end = rest.window_end(datetime.datetime.now(), cfg, _rest['autos'])
    if wait_reason != 'rest' and end is None:
        return {'title': '지금은 쉬는 시간이 아니에요', 'lines': [rest_status_line()], 'kind': 'info'}
    _rest['skip_until'] = (wait_until if wait_reason == 'rest' and wait_until else (end.timestamp() if end else time.time()))
    LOG.info('쉬는 시간 건너뛰기 (%s) - %s까지', by or 'PC', time.strftime('%H:%M', time.localtime(_rest['skip_until'])))
    if wait_reason == 'rest':
        wait_until = time.time()                       # 다음 차례에 end_wait -> 바로 진행
    set_status('쉬는 시간 건너뜀 - 지금 진행 (다음 쉬는 시간부터는 다시 쉼)', 'info')
    draw_ui()
    return {'title': '▶ 쉬지 않고 계속 진행', 'lines': ['이번 쉬는 시간(%s까지)만 건너뜁니다.' % time.strftime('%H:%M', time.localtime(_rest['skip_until'])),
                                                   '다음 쉬는 시간부터는 다시 쉽니다.'], 'kind': 'done'}


def rest_status_line():
    cfg = rest_cfg()
    if not cfg.get('enabled'):
        return '쉬는 시간: 꺼짐'
    rest_refresh()
    if wait_reason == 'rest' and wait_until:
        return '쉬는 중 · %s에 다시 시작' % time.strftime('%H:%M', time.localtime(wait_until))
    nw = rest.next_window(datetime.datetime.now(), cfg, _rest['autos'])
    cur = rest.window_end(datetime.datetime.now(), cfg, _rest['autos'])
    if cur is not None and time.time() < _rest['skip_until']:
        return '쉬는 시간 건너뛰는 중 (%s까지)' % time.strftime('%H:%M', time.localtime(_rest['skip_until']))
    if cur is not None:
        return '지금 쉬는 시간 - 이번 판 끝나고 쉼 (%s까지)' % cur.strftime('%H:%M')
    rot = ' · 돌아가며(하루 한 칸)' if cfg['mode'] == 'rotate' else ''
    if nw:
        return '다음 쉬는 시간 %s~%s%s' % (nw[0].strftime('%H:%M'), nw[1].strftime('%H:%M'), rot)
    return '쉬는 시간 없음' + rot


def _cmd_rest(args):
    a = (args or '').replace(' ', '')
    if a in ('계속', '건너뛰기', '지금계속'):
        return rest_continue('원격')
    if a in ('켜기', '끄기'):
        cfg = rest_cfg()
        cfg['enabled'] = a == '켜기'
        rest_save(cfg)
        draw_ui()
    rest_refresh(True)
    cfg = rest_cfg()
    lines = [rest_status_line(), '']
    for b, s in enumerate(_rest['st'] or []):
        k = rest.kind(b, cfg, _rest['autos'])
        mark = {'rest': '✖ 쉼', 'auto': '◐ 자동 쉼', 'never': '− 계속'}.get(k, '')
        lines.append('%s  %s  %s' % (rest.label(b), ('%d%% (%d판)' % (round(s['rate']), s['n'])) if s['n'] else '기록 없음', mark))
    lines += ['', '평균 %s · 최근 %d일 · 자동 기준: 평균보다 %s%%p 낮고 %d판 이상' % (
        ('%d%%' % round(_rest['avg'])) if _rest['avg'] is not None else '-', cfg['days'], cfg['gap'], cfg['min_games']),
        '방식: ' + ('하루 한 칸 돌아가며 (조건 맞는 칸: %s)' % (', '.join(rest.label(b) for b in sorted(_rest['bad'])) or '없음')
                  if cfg['mode'] == 'rotate' else '조건 맞는 칸 모두')]
    btns = []
    if wait_reason == 'rest':
        btns.append(('▶ 쉬지 말고 계속', '쉬는시간 계속'))
    btns.append(('쉬는 시간 끄기' if cfg['enabled'] else '쉬는 시간 켜기', '쉬는시간 ' + ('끄기' if cfg['enabled'] else '켜기')))
    return {'title': '◐ 쉬는 시간 (시간대별 승률)', 'lines': lines, 'kind': 'info', 'buttons': btns}


def rest_api(cmd, *a):
    """매크로 창 -> 쉬는 시간"""
    cfg = rest_cfg()
    if cmd == 'cell':
        b = a[0]
        k = rest.kind(b, cfg, _rest['autos'])
        new = rest.cycle(cfg['manual'].get(str(b)) or k)
        if new == 'never' and b not in _rest['autos'] and not cfg['manual'].get(str(b)):
            new = 'never'
        if new:
            cfg['manual'][str(b)] = new
        else:
            cfg['manual'].pop(str(b), None)
        rest_save(cfg)
        LOG.info('쉬는 시간 칸 %s -> %s', rest.label(b), {'rest': '쉼', 'never': '계속', '': '자동/보통'}[new])
    elif cmd == 'settings':
        cfg.update(a[0])
        rest_save(cfg)
        LOG.info('쉬는 시간 설정: %s', {k: cfg[k] for k in rest.DEFAULTS})
        if not cfg['enabled'] and wait_reason == 'rest':
            rest_continue('설정 끔')
    elif cmd == 'continue':
        rest_continue('PC')
    rest_refresh(True)
    draw_ui()


def rest_snapshot():
    rest_refresh()
    cfg = rest_cfg()
    now = datetime.datetime.now()
    cells = []
    for b, s in enumerate(_rest['st'] or [{'n': 0, 'rate': None}] * rest.BLOCKS):
        cells.append({'label': '%02d' % (b * rest.BLOCK_H), 'rate': s['rate'], 'n': s['n'],
                      'kind': rest.kind(b, cfg, _rest['autos']) if cfg['enabled'] else
                      ('off_' + rest.kind(b, cfg, _rest['autos'])), 'now': b == rest.block_of(now)})
    banner = None
    if wait_reason == 'rest' and wait_until and is_manager_mode:
        left = max(0, wait_until - time.time())
        banner = '%s - 로비에서 대기 중\n%s에 자동으로 다시 시작 (%s 남음)' % (
            wait_info.replace('쉬는 시간 · ', ''), time.strftime('%H:%M', time.localtime(wait_until)), session_stats.fmt_minutes(left / 60))
    return {'cells': cells, 'avg': _rest['avg'], 'days': cfg['days'], 'enabled': cfg['enabled'], 'line': rest_status_line(),
            'banner': banner, 'cfg': cfg, 'bad': ['%02d' % (b * rest.BLOCK_H) for b in sorted(_rest['bad'])],
            'prev': _rest.get('prev')}


def open_rest_settings():
    if GUI_ON:
        gui.call_in_ui(lambda: gui.rest_dialog(rest_snapshot, rest_api), wait=False)


def main_loop():
    if not loop_lock.acquire(blocking=False):
        return
    try:
        main_loop_body()
    finally:
        loop_lock.release()


_last_draw = [0.0]


def main_loop_body():
    if time.time() - _last_draw[0] >= 1.0:              # 화면 표시는 1초에 한 번
        _last_draw[0] = time.time()
        draw_ui()
        try:
            daily_report_check()
        except Exception:
            note_error('하루 결산')
    track_user_input()
    try:
        layout_watch()
    except Exception:
        note_error('창 배치')
    try:
        rest_watch()
    except Exception:
        note_error('쉬는 시간')
    if not is_manager_mode or is_paused:
        return
    if wait_until is not None:
        if time.time() < wait_until:
            return
        end_wait()
    if time.time() < _next_action_at[0]:
        return
    f = grab_frame()
    use_frame(f)
    try:
        main_steps(f)
    finally:
        use_frame(None)


def main_steps(f):
    # [이적시장] 창이 열려 있으면: 사람 입력이 1분 없을 때만 X로 닫음 (쓰는 중이면 그대로 둠)
    if handle_market(f):
        return

    # [VS 화면] 점수·순위 기록 (읽는 동안 최대 몇 초 진행 보류)
    if handle_vs(f):
        return

    # [라인업 화면] 포메이션 읽기 (버튼은 누르지 않음 - 진행은 아래 단계 그대로)
    try:
        handle_formation(f)
    except Exception:
        note_error('포메이션 읽기')

    # [알림] 원본 동작 그대로: 클릭 후 return 하지 않고 다음 단계 계속 검사
    try:
        b = locate('alert.png', 0.95)
        macro_input()
        pyautogui.moveTo(x=b.left - 200, y=b.top + 200)
        time.sleep(CLICK_HOVER_SEC)
        pyautogui.mouseDown()
        time.sleep(CLICK_HOLD_SEC)
        pyautogui.mouseUp()
        time.sleep(0.2)
        use_frame(grab_frame())                         # 화면이 바뀌었으니 다시 찍음
    except Exception:
        pass

    if click_image('pt2.png'): return
    if click_image('pt.png'): return
    if click_image('check.png'): return
    r = click_image('demote.png')
    if r:
        if r == CLICKED:
            note_popup('강등')
        return
    if click_image('x.png'): return

    try:
        b = locate('esc.png', 0.95)
        if remote['on']:
            # 원격 모드: ESC 키는 원격 프로그램이 가로채거나 전체화면을 풀어 버릴 수 있음 -> 화면의 ESC 표시를 클릭
            click_at(b.left + b.width // 2, b.top + b.height // 2)
            pyautogui.moveTo(x=b.left + 10, y=b.top - 200)
            key_log('ESC', '화면 ESC 표시 클릭 + 스페이스 (원격)')
        else:
            press_key('esc')
            key_log('ESC', 'ESC 키 + 스페이스')
        time.sleep(2)
        press_key('space')
        _next_action_at[0] = time.time() + AFTER_CLICK_SEC
        return
    except Exception:
        pass

    try:
        b = locate('skip.png', 0.7)
        press_key('space')
        macro_input()
        pyautogui.moveTo(x=b.left + 10, y=b.top + 10)
        time.sleep(CLICK_HOVER_SEC)
        pyautogui.mouseDown()
        time.sleep(CLICK_HOLD_SEC)
        pyautogui.mouseUp()
        time.sleep(CLICK_AFTER_SEC)
        pyautogui.moveTo(x=b.left + 10, y=b.top - 200)
        key_log('SKIP', '스페이스 + SKIP 클릭')
        _next_action_at[0] = time.time() + AFTER_CLICK_SEC
        return
    except Exception:
        pass

    if click_image('gameover.png'): return

    # [공식경기] 누르기 직전에 정지 조건 확인 + 판 기록
    try:
        home_box = locate('home.png', 0.95)
    except Exception:
        home_box = None
    if home_box is not None:
        if time.time() - _last_click.get('home.png', 0) < SAME_BUTTON_SEC:
            return                                       # 방금 눌렀음 -> 화면 전환 기다림
        if not home_check(home_box):
            return
        if not is_manager_mode:
            return
        use_frame(grab_frame())
        if click_image('home.png', dy=3): return

    if tactic_step(): return                         # v3.2: 전술 확인·자동 변경 (바꿨으면 다음 차례에 [진행])
    if click_image('squad.png', dy=5): return
    if click_image('uniform.png'): return
    r = click_image('levelup.png')
    if r:
        if r == CLICKED:
            note_popup('승급')
        return
    if click_image('pk.png'): return


set_interval(main_loop, LOOP_SEC)


# ── 멈춤 감지 ──────────────────────────────────────────
wd_prev = None
wd_static_since = 0.0
wd_alert_static = False
wd_alert_nogame = False
wd_missing = 0


def watchdog_reset():
    global wd_prev, wd_static_since, wd_alert_static, wd_alert_nogame, wd_missing
    wd_prev, wd_static_since = None, time.time()
    wd_alert_static = wd_alert_nogame = False
    wd_missing = 0


def watchdog_new_game():
    global wd_alert_nogame
    wd_alert_nogame = False


class GameWin:
    def __init__(self, hwnd, title, left, top, right, bottom, minimized):
        self._hWnd, self.title = hwnd, title
        self.left, self.top = left, top
        self.width, self.height = right - left, bottom - top
        self.isMinimized = minimized


def find_game_window():
    """제목이 정확히 'FC ONLINE'인 보이는 창 (직접 Windows에 물어봄). 없으면 None. 오류는 로그에 기록"""
    if os.name != 'nt':
        try:   # 윈도우가 아닌 환경(테스트용)
            wins = [w for w in pyautogui.getWindowsWithTitle(GAME_WINDOW_TITLE) if w.width > 300 and w.height > 300]
            exact = [w for w in wins if w.title.strip() == GAME_WINDOW_TITLE]
            return (exact or wins or [None])[0]
        except Exception:
            return None
    try:
        ctypes, wt, u, k = w32()
        found = []

        def cb(hwnd, _lp):
            try:
                if not u.IsWindowVisible(hwnd):
                    return True
                n = u.GetWindowTextLengthW(hwnd)
                if n <= 0 or n > 200:
                    return True
                buf = ctypes.create_unicode_buffer(n + 1)
                u.GetWindowTextW(hwnd, buf, n + 1)
                if buf.value.strip() != GAME_WINDOW_TITLE:
                    return True
                rc = wt.RECT()
                if not u.GetWindowRect(hwnd, ctypes.byref(rc)):
                    return True
                if rc.right - rc.left > 300 and rc.bottom - rc.top > 300:
                    found.append(GameWin(hwnd, buf.value, rc.left, rc.top, rc.right, rc.bottom, bool(u.IsIconic(hwnd))))
            except Exception:
                pass
            return True
        u.EnumWindows(_ENUM_PROC(cb), 0)
        return found[0] if found else None
    except Exception:
        note_error('게임 창 찾기')
        return None


def screen_changed(prev, cur):
    """축소한 게임 화면 두 장 비교: 어딘가 확실히 바뀐 부분이 있으면 True"""
    if prev is None or prev.shape != cur.shape:
        return True
    return int(np.abs(cur.astype(np.int16) - prev.astype(np.int16)).max()) > 30


def watchdog_loop():
    """30초마다: 게임 창이 사라졌는지 / 화면이 오래 그대로인지 / 새 판이 오래 시작 안 됐는지 확인"""
    global wd_prev, wd_static_since, wd_alert_static, wd_alert_nogame, wd_missing
    try:
        last_game_watch()
    except Exception:
        note_error('막판종료 감시')
    if not is_manager_mode or is_paused or wait_until is not None:
        watchdog_reset()
        return
    now = time.time()
    win = find_game_window()
    if win is None and remote_region(force=True) is not None:
        reg = remote['region']
        win = Box(reg[0], reg[1], reg[2], reg[3])
    if win is None:
        wd_missing += 1
        if wd_missing == 2:      # 1분 연속 게임 창 없음
            set_status('게임 창을 찾을 수 없습니다 (게임 종료/튕김?) [%s]' % time.strftime('%H:%M:%S'), 'warn')
            alert('warn', '⚠️ 게임 창이 사라졌습니다', ['FC ONLINE 창을 1분째 찾을 수 없습니다. 게임이 종료되었거나 튕겼을 수 있습니다.'])
            draw_ui()
        return
    wd_missing = 0
    try:
        shot = pyautogui.screenshot(region=(max(0, win.left), max(0, win.top), win.width, win.height))
        cur = np.array(shot.convert('L').resize((160, 90)))
    except Exception:
        return
    if screen_changed(wd_prev, cur):
        wd_static_since = now
        wd_alert_static = False
    wd_prev = cur
    if not wd_alert_static and now - wd_static_since >= STALL_STATIC_MIN * 60:
        wd_alert_static = True
        set_status('멈춤 감지 - 게임 화면이 %d분째 그대로입니다 [%s]' % (STALL_STATIC_MIN, time.strftime('%H:%M:%S')), 'warn')
        alert('warn', '⚠️ 멈춤 감지 - 화면이 %d분째 그대로입니다' % STALL_STATIC_MIN,
              ['매크로가 모르는 팝업이나 접속 문제일 수 있습니다. 아래는 지금 게임 화면입니다.'], image='screen')
        draw_ui()
    if not wd_alert_nogame:
        ref = champions_last_game_time or champions_session_start
        if ref and now - ref >= NO_GAME_MIN * 60:
            wd_alert_nogame = True
            set_status('%d분 넘게 새 판이 시작되지 않았습니다 [%s]' % (NO_GAME_MIN, time.strftime('%H:%M:%S')), 'warn')
            alert('warn', '⚠️ %d분 넘게 새 판이 시작되지 않음' % NO_GAME_MIN,
                  ['마지막 판 시작: %s' % (time.strftime('%H:%M', time.localtime(ref)))], image='screen')
            draw_ui()


set_interval(watchdog_loop, 30)


# ── 점검 (실행 시 자동 + F7) ────────────────────────────
LABELS = {'home.png': '공식경기(홈)', 'squad.png': '스쿼드 진행', 'uniform.png': '유니폼 선택완료', 'vs_team.png': 'VS 화면',
          'gameover.png': '경기 종료 다음', 'check.png': '확인', 'pt.png': '확인→', 'pt2.png': '확인→(2)', 'demote.png': '강등 확인',
          'levelup.png': '승급 확인', 'pk.png': '준비완료', 'x.png': '닫기 X', 'esc.png': 'ESC', 'skip.png': 'SKIP', 'alert.png': '알림',
          's.png': 'S 아이콘', 'placement.png': '배치 경기', 'champ_label.png': '챔스 홈(랭킹 점수)'}
CONF = {'skip.png': 0.7, 's.png': 0.7, 'vs_team.png': 0.9, 'placement.png': 0.8, 'champ_label.png': 0.7}


def _win32_rects(win):
    """(게임 창 클라이언트 크기, 게임 창 사각형, 매크로 콘솔 창 사각형) - Windows 전용"""
    ctypes, wt, u, k = w32()
    client = None
    try:
        rc = wt.RECT()
        u.GetClientRect(wt.HWND(win._hWnd), ctypes.byref(rc))
        client = (rc.right - rc.left, rc.bottom - rc.top)
    except Exception:
        pass
    game = (int(win.left), int(win.top), int(win.left) + int(win.width), int(win.top) + int(win.height))
    cons = None
    try:
        h = console_hwnd()[0]       # 기본 콘솔 / Windows 터미널 모두
        if h and u.IsWindowVisible(h):
            rc = wt.RECT()
            u.GetWindowRect(h, ctypes.byref(rc))
            if rc.right - rc.left > 50 and rc.bottom - rc.top > 50:
                cons = (rc.left, rc.top, rc.right, rc.bottom)
    except Exception:
        pass
    return client, game, cons


_check_shown = [0.0]


def run_checks(screen_test=False):
    global check_lines
    res = []
    if admin.check_line():
        res.append(admin.check_line())          # v3.1: 관리자 권한 (아니면 클릭이 안 먹힘)
    try:
        imgdir = paths.resource('images')
        n_btn = len([f for f in os.listdir(imgdir) if f.endswith('.png')])
        n_dig = len(os.listdir(paths.resource(os.path.join('images', 'digits'))))
        n_rank = len(os.listdir(paths.resource(os.path.join('images', 'rank_digits'))))
        res.append((n_btn >= 20 and n_dig >= 10, '이미지: 버튼 %d개, 점수 숫자 %d개, 순위 숫자 %d개 (%s)'
                    % (n_btn, n_dig, n_rank, paths.source_of('images'))))
        bad = []
        for f in sorted(os.listdir(imgdir)):
            if f.endswith('.png'):
                try:
                    needle(f)
                except Exception:
                    bad.append(f)
        try:
            score_ocr.load_templates()
            nr = sum(len(v) for v in score_ocr.load_rank_templates().values())
        except Exception as e:
            bad.append('숫자 견본(%s)' % e)
            nr = 0
        res.append((not bad and nr > 0, '이미지 읽기: ' + ('모두 정상' if not bad and nr > 0 else '실패 - ' + ', '.join(bad[:5]))))
        try:
            known = sorted(formation_ocr.load_templates(reload=True))
            res.append((None, '포메이션 숫자 견본: %s (나머지는 경기하면서 자동 학습)' % ', '.join(map(str, known))))
        except Exception as e:
            res.append((False, '포메이션 숫자 견본 읽기 실패: %s' % e))
    except Exception as e:
        res.append((False, '이미지 폴더를 읽을 수 없음: %s' % e))
    win = find_game_window()
    if win is None:
        reg = remote_region(force=True)
        if reg is not None:
            res.append((True, '원격 모드: 원격 화면 안의 게임 창 찾음 (위치 %d,%d · 제목줄 유사도 %.2f)' % (reg[0], reg[1], remote['score'])))
            res.append((None, '원격 모드: 버튼 인식 기준을 조금 낮추고, ESC는 화면 표시를 클릭, S키는 원격 창이 앞에 있을 때'))
            if reg[2] < GAME_WIN_W - 4 or reg[3] < GAME_WIN_H - 4:
                res.append((False, '원격 화면 안 게임 창이 화면 밖으로 잘림 - 원격 PC에서 게임 창을 안쪽으로 옮겨 주세요'))
            if os.name == 'nt':
                try:
                    _c, _g, cons = _win32_rects(Box(reg[0], reg[1], reg[2], reg[3]))
                    if cons:
                        ix = min(cons[2], reg[0] + reg[2]) - max(cons[0], reg[0])
                        iy = min(cons[3], reg[1] + reg[3]) - max(cons[1], reg[1])
                        ov = ix > 0 and iy > 0
                        res.append((not ov, '매크로 창이 원격 화면 속 게임 창을 가림 - 옆으로 옮겨 주세요' if ov
                                    else '매크로 창과 게임 창 겹침 없음'))
                except Exception:
                    pass
        elif remote['scale_warn']:
            res.append((False, '원격 화면이 줄어서 보임 (약 %d%%) - 원격 프로그램을 전체화면(내 모니터 해상도 그대로)으로 해 주세요'
                        % round(remote['scale_warn'] * 100)))
        else:
            res.append((False, '게임 창(FC ONLINE)을 찾을 수 없음 - 게임을 먼저 켜 주세요 (원격이면 게임 창 제목줄이 보이게)'))
    else:
        client, game, cons = (None, None, None)
        if os.name == 'nt':
            try:
                client, game, cons = _win32_rects(win)
            except Exception:
                pass
        if client:
            ok = tuple(client) == GAME_CLIENT_SIZE
            res.append((ok, '게임 화면 크기 %dx%d %s' % (client[0], client[1],
                        '(정상)' if ok else '- 1280x720 창모드로 바꿔 주세요')))
        else:
            res.append((True, '게임 창 찾음 (%dx%d)' % (win.width, win.height)))
        if cons and game:
            ix = min(cons[2], game[2]) - max(cons[0], game[0])
            iy = min(cons[3], game[3]) - max(cons[1], game[1])
            overlap = ix > 0 and iy > 0
            res.append((not overlap, '매크로 창이 게임 창을 가림 - 옆으로 옮겨 주세요' if overlap else '매크로 창과 게임 창 겹침 없음'))
    res.append((None, '디스코드 알림: ' + ('켜짐' if WEBHOOK else '꺼짐 (F8 설정창에서 웹훅 입력)')))
    res.append((None, '디스코드 봇: ' + (BOT.status if BOT is not None else '꺼짐 (설정창에 봇 토큰을 넣으면 !상태 등 명령 가능)')))
    res.append((None, '텔레그램: ' + (TG.status if TG is not None else '꺼짐 (설정창에 텔레그램 봇 토큰을 넣으면 알림·명령 가능)')))
    for m in _MIGRATE_MSGS:
        res.append((None, '기록 이전: ' + m))
    if _BACKUP:
        res.append((True, '오늘 기록 백업 완료 (기록 폴더\\백업)'))
    if screen_test:
        found = []
        home_box = vs_box = None
        try:
            frame = grab_frame()
        except Exception:
            frame = None
        for name in ['home.png', 'champ_label.png', 'placement.png', 'squad.png', 'uniform.png', 'vs_team.png', 'gameover.png',
                     'check.png', 'pt.png', 'pt2.png', 'demote.png', 'levelup.png', 'pk.png', 'x.png', 'esc.png', 'skip.png',
                     'alert.png']:
            try:
                b = locate(name, CONF.get(name, 0.95), frame=frame)
                found.append(LABELS[name])
                if name == 'home.png':
                    home_box = b
                if name == 'vs_team.png':
                    vs_box = b
            except Exception:
                pass
        res.append((bool(found), '지금 화면에서 찾은 것: ' + (', '.join(found) if found else '없음 (게임 메뉴 화면에서 다시 해 보세요)')))
        if home_box is not None:
            if '챔스 홈(랭킹 점수)' in found:
                try:
                    v, _d = score_ocr.read_score_on_screen(home_box)
                except Exception:
                    v = None
                res.append((v is not None, '랭킹점수 읽기: ' + (format(v, ',') + '점' if v is not None else '실패')))
            elif '배치 경기' in found:
                res.append((True, '배치 경기 화면 - 점수 없이 진행합니다'))
            else:
                res.append((True, '챔스 아래 티어 홈 화면 - 점수는 VS 화면에서 읽습니다'))
        if vs_box is not None and frame is not None:
            for side, label in (('mine', '내'),):
                try:
                    g = crop(frame, score_ocr.rank_region(vs_box, side))
                    g = cv2.cvtColor(g, cv2.COLOR_RGB2GRAY) if g is not None else None
                    rv = score_ocr.read_rank_from_gray(g)[0] if g is not None and int(g.max()) > score_ocr.RANK_TEXT_TH else None
                    a = crop(frame, score_ocr.vs_score_region(vs_box, side))
                    sv = score_ocr.read_vs_score(a)[0] if a is not None else None
                except Exception:
                    rv = sv = None
                res.append((sv is not None, '%s 점수·순위 읽기: %s / %s' % (
                    label, format(sv, ',') + '점' if sv is not None else '점수 실패 (글씨가 나타난 뒤 다시 시도)',
                    format(rv, ',') + '위' if rv is not None else '순위 없음(챔스 아래 티어) 또는 실패')))
        if frame is not None:
            try:
                side, fbox = find_formation_screen(frame)
                if side is not None:
                    fr, _g = read_formation(frame, fbox)
                    res.append((fr['text'] is not None, '라인업 화면(%s 팀) 포메이션 읽기: %s' % (
                        FORM_NAME[side], fr['text'] or ('실패 - ' + str(fr.get('why'))))))
            except Exception as e:
                res.append((False, '포메이션 읽기 오류: %s' % e))
        if home_box is None and vs_box is None:
            res.append((None, '점수/순위 읽기 테스트는 홈 화면(공식경기) 또는 VS 화면, 포메이션은 경기 전 라인업 화면에서 F7'))
    check_lines = res
    if screen_test:
        _check_shown[0] = time.time()
    LOG.info('점검: %s', ' | '.join(('OK ' if ok else ('NG ' if ok is False else '')) + t for ok, t in res))
    draw_ui()


# ── 매크로 창 항상 위 (F6) ─────────────────────────────
_W32 = None
_ENUM_PROC = None
_LASTINPUTINFO = None


def w32():
    """
    Windows API 함수들 (64비트에서 창 핸들이 잘리지 않게 인자/반환 형식을 명시).
    ※ 공용 ctypes.windll.user32 에 형식을 지정하면 pyautogui(pygetwindow) 등 다른 라이브러리의
      같은 함수까지 바뀌어 오류가 나므로, 이 매크로 전용 사본(WinDLL)을 따로 불러서 사용
    """
    global _W32
    if _W32 is None:
        import ctypes
        import ctypes.wintypes as wt
        u = ctypes.WinDLL('user32', use_last_error=True)
        k = ctypes.WinDLL('kernel32', use_last_error=True)
        k.GetConsoleWindow.restype = wt.HWND
        k.GetConsoleWindow.argtypes = []
        u.IsWindowVisible.argtypes = [wt.HWND]
        u.IsWindowVisible.restype = wt.BOOL
        u.SetWindowPos.argtypes = [wt.HWND, wt.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_uint]
        u.SetWindowPos.restype = wt.BOOL
        u.GetWindowRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]
        u.GetClientRect.argtypes = [wt.HWND, ctypes.POINTER(wt.RECT)]
        u.FindWindowW.argtypes = [wt.LPCWSTR, wt.LPCWSTR]
        u.FindWindowW.restype = wt.HWND
        u.GetWindowTextW.argtypes = [wt.HWND, wt.LPWSTR, ctypes.c_int]
        u.GetWindowTextLengthW.argtypes = [wt.HWND]
        u.IsIconic.argtypes = [wt.HWND]
        global _ENUM_PROC
        _ENUM_PROC = ctypes.WINFUNCTYPE(wt.BOOL, wt.HWND, wt.LPARAM)
        u.EnumWindows.argtypes = [_ENUM_PROC, wt.LPARAM]
        global _LASTINPUTINFO

        class _LASTINPUTINFO(ctypes.Structure):
            _fields_ = [('cbSize', wt.UINT), ('dwTime', wt.DWORD)]
        u.GetLastInputInfo.argtypes = [ctypes.POINTER(_LASTINPUTINFO)]
        u.GetLastInputInfo.restype = wt.BOOL
        k.GetTickCount.restype = wt.DWORD
        _W32 = (ctypes, wt, u, k)
    return _W32


def console_hwnd():
    """매크로(콘솔) 창 핸들 -> (핸들, 찾은 방법). 기본 콘솔: GetConsoleWindow / Windows 터미널: 창 제목"""
    if os.name != 'nt':
        return None, '윈도우 아님'
    if GUI_ON:
        gh = gui.hwnd()
        if gh:
            return gh, '매크로 창'
    ctypes, wt, u, k = w32()
    h = k.GetConsoleWindow()
    if h and u.IsWindowVisible(h):
        return h, '콘솔 창'
    title = 'FC 매크로 · ' + short_status()[0]
    h2 = u.FindWindowW(None, title)
    if h2:
        return h2, '창 제목(정확히)'
    try:
        ws = [w for w in pyautogui.getWindowsWithTitle('FC 매크로 ·') if w.title.startswith('FC 매크로 ·')]
        if ws:
            return ws[0]._hWnd, '창 제목(검색)'
    except Exception:
        pass
    return None, '못 찾음 (GetConsoleWindow=%s)' % (h,)


def apply_topmost():
    """현재 always_on_top 값을 창에 적용 -> (성공 여부, 설명)"""
    h, how = console_hwnd()
    if not h:
        return False, '매크로 창을 찾지 못함 - ' + how
    try:
        ctypes, wt, u, k = w32()
        HWND_TOPMOST, HWND_NOTOPMOST = wt.HWND(-1), wt.HWND(-2)
        SWP_NOSIZE, SWP_NOMOVE, SWP_NOACTIVATE = 0x0001, 0x0002, 0x0010
        ctypes.set_last_error(0)
        ok = u.SetWindowPos(h, HWND_TOPMOST if always_on_top else HWND_NOTOPMOST,
                            0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE)
        if ok:
            return True, '적용됨 (%s)' % how
        return False, '창은 찾았지만(%s) 설정 실패 - 오류 코드 %s' % (how, ctypes.get_last_error())
    except Exception as e:
        return False, '설정 중 오류: %s' % e


def toggle_topmost():
    global always_on_top, last_error
    always_on_top = not always_on_top
    target_dialog.set_option('topmost', always_on_top)
    if GUI_ON:
        on = always_on_top
        gui.call_in_ui(lambda: gui._root.attributes('-topmost', on), wait=False)
    ok, why = apply_topmost()
    (LOG.info if ok else LOG.warning)('매크로 창 항상 위 %s: %s', '켜기' if always_on_top else '끄기', why)
    if os.name == 'nt':
        last_error = '' if ok else '항상 위 %s 실패 - %s [%s]' % ('켜기' if always_on_top else '끄기', why,
                                                             time.strftime('%H:%M:%S'))
    if always_on_top:
        run_checks(False)        # 게임 창을 가리는지 바로 점검 (가리면 버튼 인식이 안 됨)
        overlap = [t for ok_, t in check_lines if ok_ is False and '가림' in t]
        if overlap:
            last_error = '항상 위가 켜진 매크로 창이 게임 창을 가리고 있습니다 - 창을 옆으로 옮겨 주세요'
    draw_ui()


def open_data_folder():
    try:
        os.startfile(DATA_DIR)
    except Exception as e:
        LOG.warning('기록 폴더 열기 실패: %s', e)


def quit_app():
    LOG.info('트레이 메뉴에서 종료')
    tray.stop()
    os._exit(0)


if tray.start(paths.img('icon.png'), on_graph=lambda: on_press_f11(None), on_stop=lambda: on_press_f12(None),
              on_quit=quit_app, on_topmost=lambda: threading.Thread(target=toggle_topmost, daemon=True).start(),
              is_topmost=lambda: always_on_top, on_open_folder=open_data_folder,
              on_pause=lambda: on_press_f10(None), is_paused=lambda: is_paused):
    LOG.info('트레이 아이콘 시작')


def _startup():
    msg = os.environ.get('FCMACRO_UPDATE_MSG', '')
    if msg:
        LOG.info('업데이트: %s', msg)
        set_status(msg, 'info')
    LOG.info('권한: %s', admin.STATE['why'] or '-')
    if admin.SINGLE['why']:
        LOG.warning('이미 켜진 매크로: %s', admin.SINGLE['why'])
    if admin.STATE['admin'] is False:       # v3.1: [아니요]를 눌렀거나 설정에서 끔 -> 클릭이 안 먹힐 수 있음을 바로 알림
        set_status('관리자 권한이 아니에요 - 게임이 클릭을 무시할 수 있어요 (매크로를 다시 켜고 [예])', 'warn')
    try:
        start_bot()
    except Exception:
        note_error('디스코드 봇 시작')
    try:
        start_tg()
    except Exception:
        note_error('텔레그램 시작')
    if always_on_top:
        ok, why = apply_topmost()
        LOG.info('시작 시 항상 위 적용: %s', why)
    run_checks()


_st = threading.Timer(1.0, _startup)
_st.daemon = True
_st.start()


def sub_loop():
    """스킵(S) 아이콘이 보이면 바로 S키 (일시정지 중엔 안 누름)
    v3.4.1: 게임(원격이면 원격 프로그램) 창이 앞에 없으면 게임 창 제목줄을 한 번 눌러 앞으로 가져온 뒤 S
            (예전엔 앞에 없으면 그냥 기다려서, 사람이 화면을 눌러 줘야 넘어갔음)"""
    if not is_manager_mode or is_paused or wait_until is not None:
        return
    if time.time() - _last_s[0] < 1.0:          # 방금 눌렀으면 잠깐 기다림 (연타 방지)
        return
    try:
        locate('s.png', 0.7, grab_frame())
    except Exception:
        _s_block['since'] = 0.0
        return
    if not ensure_focus('S키'):
        _s_blocked()
        return
    press_key('s', focus=False)
    _last_s[0] = time.time()
    _s_block['since'] = 0.0
    key_log('S', 'S키')


_last_s = [0.0]
_s_block = {'since': 0.0, 'noted': 0.0}


def _s_blocked():
    """S 아이콘이 보이는데 창을 앞으로 못 가져와서 못 누르는 중이면 10초 뒤 상태 줄·로그로 알림"""
    now = time.time()
    if not _s_block['since']:
        _s_block['since'] = now
        return
    if now - _s_block['since'] >= 10 and now - _s_block['noted'] > 60:
        _s_block['noted'] = now
        fw = None
        try:
            fw = pyautogui.getActiveWindow()
        except Exception:
            pass
        LOG.warning('S키 못 누름: 게임 창을 앞으로 못 가져옴 (지금 앞 창: %s)', ((fw.title if fw else '') or '없음')[:40])
        set_status('S키 대기 - 게임 화면(원격이면 리피시)을 한 번 눌러 주세요', 'warn')


set_interval(sub_loop, S_LOOP_SEC)


paths.mark_update_ok(DATA_DIR)          # 여기까지 오류 없이 왔으면 새 버전 정상 -> 실행기가 되돌리지 않음


# ── v3.0 매크로 창(gui.py)에 보여 줄 내용 ───────────────────
_rows_cache = {'key': None, 'rows': [], 'note': ''}


def _gui_rows():
    """최근 기록 표 (기록 파일 기준 최근 GUI_ROWS판, 최신이 위)"""
    try:
        st = os.stat(score_log.LOG_FILE)
        fkey = (st.st_mtime, st.st_size)
    except OSError:
        fkey = None
    cur = champions_history[-1] if champions_history else None
    key = (fkey, is_manager_mode, cur[H_TS] if cur else None, cur[H_RES] if cur else None,
           cur[H_OPP] if cur and len(cur) > H_OPP else None, cur[H_TAC] if cur and len(cur) > H_TAC else None,
           datetime.date.today())
    if key == _rows_cache['key']:
        return _rows_cache
    rows = []
    flow = []
    try:
        recs = score_log.read_records()[-(GUI_ROWS * 3):]
        res = score_log.results_of(recs)
        games = [r for r, _x in res]
        today = datetime.date.today().strftime('%Y-%m-%d')
        for k in range(len(res) - 1, -1, -1):
            r, rr = res[k]
            nxt = games[k + 1][2] if k + 1 < len(games) else (champions_final_score if r[0][:10] == today else None)
            cur_row = cur is not None and is_manager_mode and r[0] == cur[H_TS] and k == len(res) - 1
            d = (nxt - r[2]) if (nxt is not None and r[2] is not None and not cur_row) else None
            if cur_row and not rr:
                rtxt, tag = '진행중', 'p'
            elif rr:
                rtxt = rr + ((' %+d' % d) if d is not None and rr != '무' else (' 0' if rr == '무' and d == 0 else ''))
                tag = {'승': 'w', '패': 'l', '무': 'd'}[rr]
            else:
                rtxt, tag = '-', 's'
            when = r[0][11:16] if r[0][:10] == today else r[0][5:10].replace('-', '/')
            opp = '미인식' if r[7] == '?' else (r[7] or '-')
            tac = (r[9] if len(r) > 9 else '') or '-'
            rows.append({'values': (r[1], format(r[2], ',') if r[2] is not None else '-',
                                    (format(r[3], ',') + '위') if r[3] is not None else '-', when, rtxt, opp, tac),
                         'tag': tag})
            if len(rows) >= GUI_ROWS:
                break
        flow = [rr for _r, rr in res if rr][-10:]          # v3.3.1: 제목 옆 최근 10판 (표와 같은 기준이라 항상 일치)
    except Exception:
        note_error('최근 기록 표')
    _rows_cache.update(key=key, rows=rows, flow=flow, note='최근 %d판 · 휠로 스크롤 · 전체는 차트' % len(rows) if rows else '아직 기록 없음')
    return _rows_cache


_png_cache = {}


def png_b64(key, img, max_w, max_h, bg=(32, 32, 42)):
    """numpy 그림(RGB 또는 BGRA) -> 창에 바로 쓰는 PNG(base64). 투명 부분은 카드 배경색과 섞음 (같은 key 는 한 번만)"""
    if img is None:
        return None
    k = (key, max_w, max_h)
    if k in _png_cache:
        return _png_cache[k]
    import base64
    a = img
    if a.ndim == 3 and a.shape[2] == 4:                       # BGRA (엠블럼)
        al = a[..., 3:4].astype(np.float32) / 255.0
        bgr = a[..., :3].astype(np.float32) * al + np.array(bg[::-1], np.float32) * (1 - al)
        a = bgr.astype(np.uint8)
    else:
        a = cv2.cvtColor(a, cv2.COLOR_RGB2BGR) if a.ndim == 3 else a
    sc = min(max_w / a.shape[1], max_h / a.shape[0], 1.0 if max_w < 200 else 9)
    if abs(sc - 1) > 0.01:
        a = cv2.resize(a, (max(1, int(a.shape[1] * sc)), max(1, int(a.shape[0] * sc))), interpolation=cv2.INTER_AREA)
    ok, buf = cv2.imencode('.png', a)
    v = base64.b64encode(buf.tobytes()).decode('ascii') if ok else None
    _png_cache[k] = v
    return v


def emblem_snapshot(size):
    p, name = emblem_now()
    if not p:
        return None, name
    try:
        st = os.stat(p)
        img = cv2.imdecode(np.fromfile(p, np.uint8), cv2.IMREAD_UNCHANGED)
        return png_b64(('emb', p, st.st_mtime), img, size, size), name
    except Exception:
        return None, name


def gui_snapshot():
    """매크로 창이 0.5초마다 읽어 가는 상태 (읽기만 함)"""
    st = current_stats()
    td = today_summary() or {}
    if is_manager_mode and is_paused:
        state, stext = 'warn', '❚❚  일시정지 중'
    elif is_manager_mode and wait_until is not None:
        left = max(0, wait_until - time.time())
        state, stext = 'warn', '대기 중 - %s에 자동 %s (%s 남음)' % (time.strftime('%H:%M', time.localtime(wait_until)),
                                                              '시작' if wait_reason == 'start' else '재개',
                                                              session_stats.fmt_minutes(left / 60))
        if wait_reason == 'rest':
            stext = '◐  쉬는 시간 - %s에 자동 재개' % time.strftime('%H:%M', time.localtime(wait_until))
    elif is_manager_mode:
        state, stext = 'run', '●  자동진행 중'
    else:
        state, stext = 'idle', '○  멈춤 - [시작]을 누르면 진행'
    banner = None
    if last_game['on'] and is_manager_mode:
        banner = '⚑ 막판종료 예약 - %d번째 게임이 끝나고 로비로 오면 정지 + 게임 창 닫기' % last_game['game']
    elif is_manager_mode and wait_until is not None and wait_info and wait_reason != 'rest':
        banner = wait_info                                 # (쉬는 시간은 주황 띠로 따로 보여줌)
    mode = '화면: 원격 모드' if remote['on'] else ('화면: 보통 모드' if game_window() is not None else '게임 창 없음')
    # 큰 숫자
    scores = [h[H_SCORE] for h in champions_history if h[H_SCORE] is not None]
    score = champions_final_score if (champions_final_score is not None and not is_manager_mode) else (scores[-1] if scores else last_known_score)
    if score is None and _rows_cache['rows']:
        try:
            score = int(str(_rows_cache['rows'][0]['values'][1]).replace(',', ''))
        except ValueError:
            score = None
    delta = (score - scores[0]) if (score is not None and scores) else None
    ranks = [h[H_RANK] for h in champions_history if h[H_RANK] is not None]
    sw, sf = session_fc()
    tw, tf = td.get('fc', (0, 0))
    big = {'score': (fmt_num(score), ('이번 %+d' % delta) if delta is not None else '',
                     'up' if (delta or 0) > 0 else ('down' if (delta or 0) < 0 else '')),
           'rank': (rank_text(last_rank) if last_rank is not None else '-',
                    ('최고 ' + rank_text(min(ranks))) if ranks else '', ''),
           'fc': (format(sf, ','), '오늘 %s' % format(tf, ','), '')}
    cond = '정지 조건: ' + stop_conditions_text()
    emb, emb_name = emblem_snapshot(gui.px(84))
    tier_show = emb_name or ('챔피언스' if (champions_history and champions_history[-1][H_CHAMP]) else tier_now) or ''
    eta = session_stats.eta_line(st, TARGET_SCORE) if TARGET_SCORE is not None and champions_history else ''
    rows = _gui_rows()
    # 버튼 (글자, 단축키, 배경, 글자색, 테두리)
    K = lambda a: key_label(HOTKEYS.get(a)) if HOTKEYS.get(a) else ''      # noqa: E731
    btn = {
        'topmost': ('◎ 항상 위' if always_on_top else '○ 항상 위', K('topmost'), '#26333a' if always_on_top else gui.CARD2,
                    gui.CYAN if always_on_top else gui.FG, gui.LINE),
        'check': ('✔ 점검', K('check'), gui.CARD2, gui.FG, gui.LINE),
        'settings': ('⚙ 설정', K('settings'), gui.CARD2, gui.FG, gui.LINE),
        'start': ('▶ 시작', K('start'), gui.CARD2, gui.DIM if is_manager_mode else gui.GREEN, gui.LINE),
        'pause': (('▶ 재개', K('pause'), '#24382c', gui.GREEN, gui.LINE) if (is_manager_mode and is_paused) else
                  ('❚❚ 일시정지', K('pause'), '#3a3424' if is_manager_mode else gui.CARD2,
                   gui.YEL if is_manager_mode else gui.DIM, gui.LINE)),
        'chart': ('↗ 차트', K('chart'), gui.CARD2, gui.FG, gui.LINE),
        'stop': ('■ 종료', K('stop'), '#3a2228' if is_manager_mode else gui.CARD2, gui.RED if is_manager_mode else gui.DIM, gui.LINE),
        'lastgame': (('⚑ 막판 취소', '', '#3a3020', gui.YEL, '#7a6430') if last_game['on'] else
                     ('⚑ 막판종료', '', '#3a3020' if is_manager_mode else gui.CARD2,
                      gui.YEL if is_manager_mode else gui.DIM, gui.LINE)),
        'layout': ('▣ 창 배치 저장', K('layout'), gui.CARD2, gui.FG, gui.LINE),
        'tactics': (('⇄ 전술 자동', '켜짐', '#1f3236', gui.CYAN, gui.CYAN) if TAC.settings.get('enabled') else
                    ('⇄ 전술 자동', '꺼짐' if TAC.registered() else '', gui.CARD2, gui.FG, gui.LINE)),
        'hotkeys': ('⌨ 단축키', '', gui.CARD2, gui.FG, gui.LINE),
        'today': ('☰ 오늘 결산', K('today'), gui.CARD2, gui.FG, gui.LINE),
        'formation': ('⚔ 포메이션', K('formation'), gui.CARD2, gui.FG, gui.LINE),
    }
    # v3.4: 큰 버튼일 때 쓰는 긴 글자 / 아래 줄 (없으면 짧은 글자 + 단축키 그대로)
    BIG = {'lastgame': (btn['lastgame'][0], K('lastgame')),
           'tactics': ('⇄ 전술 자동 변경', btn['tactics'][1] or '전술 등록하기'),
           'hotkeys': ('⌨ 단축키 설정', ''),
           'formation': ('⚔ 포메이션·전술', K('formation'))}
    for a, v in BIG.items():
        btn[a] = btn[a][:5] + (v,)
    # 알림 · 점검
    dis = (None if not WEBHOOK else (False if notify_status.startswith('마지막 알림 전송 실패') else True))
    tgok = None if TG is None else (bool(TG.ok) if TG.ok is not None else None)
    chk = None if not check_lines else (False if any(ok is False for ok, _t in check_lines) else True)
    lines = []
    lines.append((dis, ('디스코드 알림 켜짐' + (' (' + notify_status + ')' if notify_status else '')) if WEBHOOK
                  else '디스코드 알림 꺼짐 (설정에서 웹훅 입력)'))
    if BOT is not None:
        lines.append((BOT.ok, '디스코드 봇: ' + BOT.status))
    lines.append((tgok, ('텔레그램: ' + TG.status + (' (' + TG.last_send + ')' if TG.last_send else '')) if TG is not None
                  else '텔레그램 꺼짐 (설정에서 봇 토큰 입력)'))
    lay = target_dialog.get_option('layout')
    lines.append((None, '창 배치: ' + ('저장됨 (켤 때 자동으로 맞춤)' if _layout_ok(lay) else
                                    ('저장됨 - 화면 해상도가 달라서 적용 안 함' if lay else '저장 안 함'))))
    if check_lines:
        lines.append((None, '── 점검 (%s) ──' % (time.strftime('%H:%M', time.localtime(_check_shown[0])) if _check_shown[0] else '시작 시')))
        lines += list(check_lines)
    return {
        'title': 'FC 매크로 · ' + short_status()[0], 'version': VERSION, 'topmost': always_on_top,
        'state': state, 'state_text': stext, 'mode': mode, 'banner': banner,
        'status': ('' if (banner and (champions_status or '').startswith('막판종료 예약')) else (champions_status or ''),
                   champions_status_kind), 'error': last_error,
        'big': big, 'cond': cond, 'eta': eta,
        'now': session_stats.summary_line(st) if champions_history else '이번에 진행한 판 없음',
        'today': td.get('line', ''), 'flow': _gui_rows().get('flow', []),
        'streak': session_stats.streak_text(_gui_rows().get('flow', [])).replace('현재 ', ''),
        'rows': rows['rows'], 'rows_key': (rows['rows'][0]['values'] if rows['rows'] else None, rows['key']),
        'rows_note': rows['note'], 'buttons': btn, 'data_dir': DATA_DIR,
        'panel_sum': [('디스코드', dis), ('텔레그램', tgok), ('점검', chk)], 'panel_lines': lines,
        'check_time': _check_shown[0], 'check_auto_open': True,
        'emblem': emb, 'tier': tier_show, 'promo': promo_snapshot() if tier_show != '챔피언스' else None,
        'tac_line': tactics.status_line(TAC) if TAC.registered() else '', 'tac_cols': bool(TAC.registered()),
        'rest': rest_snapshot(),
    }


def gui_action(aid):
    """매크로 창 버튼"""
    if aid == 'hotkeys':
        open_hotkey_dialog()
    elif aid == 'tactics':
        open_tactics()
    elif aid.startswith('rest_cell:'):
        rest_api('cell', int(aid.split(':')[1]))
    elif aid == 'rest_settings':
        open_rest_settings()
    elif aid == 'rest_continue':
        rest_api('continue')
    elif aid == 'quit':
        _gui_quit()
    else:
        LOG.info('버튼: %s', ACTION_NAME.get(aid, aid))
        run_action(aid)


def _gui_quit():
    """창 X: 진행 중이면 물어보고 매크로 종료"""
    if is_manager_mode:
        if not gui.ask('매크로 끄기', '자동진행 중이에요. 매크로를 끌까요?\n(경기 중이면 매크로만 꺼지고 경기는 계속됩니다)'):
            return
    LOG.info('매크로 창 닫기 - 종료')
    try:
        tray.stop()
    except Exception:
        pass
    os._exit(0)


def _console_show(show):
    if os.name != 'nt':
        return
    try:
        ctypes, wt, u, k = w32()
        h = k.GetConsoleWindow()
        if h:
            u.ShowWindow.argtypes = [wt.HWND, ctypes.c_int]
            u.ShowWindow(h, 5 if show else 0)
    except Exception:
        pass


def _gui_ready():
    """창이 뜬 직후 (창 스레드): 글자 창 숨기기, 저장 배치·항상 위 적용"""
    _console_show(False)
    try:
        apply_macro_layout()
    except Exception:
        note_error('창 배치 적용')
    if always_on_top:
        gui._root.attributes('-topmost', True)
        apply_topmost()
    LOG.info('매크로 창(버튼식) 시작')


def start_gui():
    """v3.0 매크로 창을 메인 스레드에서 실행 (창이 닫히거나 실패하면 돌아옴) -> 성공적으로 떴었는지"""
    global GUI_ON
    if gui is None or os.environ.get('FCMACRO_NO_GUI') or target_dialog.get_option('ui_mode') == 'console':
        return False
    api = {'snapshot': gui_snapshot, 'action': gui_action, 'log_error': note_error,
           'icon': paths.img('icon.png') if os.path.exists(paths.img('icon.png')) else None,
           'rest_open': lambda: target_dialog.get_option('rest_open', True) is not False,          # v3.3 시간대 칸 펼침
           'rest_open_set': lambda v: target_dialog.set_option('rest_open', bool(v)),
           'ui_get': lambda: target_dialog.get_option('ui_layout', {}) or {},                      # v3.4 손잡이 위치
           'ui_set': lambda v: target_dialog.set_option('ui_layout', dict(v))}
    try:
        GUI_ON = True
        bind_hotkeys()                     # F11 막기 해제 (글자 창이 없으므로)
        gui.run(api, geometry='470x980', on_ready=_gui_ready)
        return True
    except Exception:
        note_error('매크로 창 시작')
        LOG.warning('매크로 창을 띄우지 못해 예전 글자 창으로 진행합니다')
        return False
    finally:
        GUI_ON = False
        _console_show(True)
        bind_hotkeys()
        draw_ui()


# 메인 스레드를 계속 살려 둠.
# (Python 3.12 일부 버전은 메인 코드가 끝나면 '종료 중'으로 보고 새 타이머 생성을 거부함
#  -> "can't create new thread at interpreter shutdown" 오류가 반복되며 매크로가 멈춤)
if __name__ == '__main__':
    try:
        start_gui()                        # v3.0: 버튼식 창 (닫으면 매크로 종료 / 실패하면 아래 글자 창으로)
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        os._exit(0)
