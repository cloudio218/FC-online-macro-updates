# -*- coding: utf-8 -*-
"""v3.8 빅매치: 지정한 구단주를 VS 화면에서 만나면 알림.

등록: 게임의 '구단주 정보' 화면(검색)에서 이름 위에 마우스 -> 그 이름 글자를 잘라 저장
찾기: VS 화면 오른쪽(상대) 이름을 같은 방식으로 정리해서 비교
  - 글자만 남겨 흑백(배경 밝으면 뒤집음) -> 테두리에 붙은 덩어리 빼고 -> 글자 영역만 -> 높이 24로 맞춤
  - 같은 글꼴이라 크기만 맞추면 비교됨 (구단주 정보 ↔ VS 같은 이름 0.84, 다른 이름 0.25 이하 - 2026-11-25 캡처로 확인)
  - 한 번 만나면 그 VS 이름 그림을 저장해서 다음부터는 그것으로 (같은 화면끼리라 받침 하나 차이도 구분)
"""
import base64
import json
import os
import time

import cv2
import numpy as np

H = 24
TH_PROF = 0.60          # 구단주 정보 화면으로 등록한 것
TH_VS = 0.78            # VS 화면 그림으로 바뀐 것 (같은 화면끼리)
RATIO_MIN = 0.85        # 글자 길이 비율
MAX_ENTRIES = 20

# VS 화면 상대 이름 칸 (vs_team.png 위치 기준, 1280x720 게임 창 - shots/vs.png 등에서 잼)
OPP_NAME = (125, 203, 200, 28)        # dx, dy, w, h


def norm(gray, dark_text=None):
    """이름 칸 회색조 -> 높이 H 흑백 글자 그림 (float32) / None"""
    if gray is None or gray.size == 0:
        return None
    g = gray.astype(np.uint8)
    if dark_text is None:
        dark_text = float(np.median(g)) > 128
    if dark_text:
        g = 255 - g
    _, b = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    n, lab, st, _ = cv2.connectedComponentsWithStats(b)
    keep = np.zeros_like(b)
    for i in range(1, n):
        x, y, w, h, a = st[i]
        if a < 3 or x == 0 or x + w >= b.shape[1] or y == 0 and h >= b.shape[0] - 1:
            continue
        keep[lab == i] = 255
    ys, xs = np.where(keep > 0)
    if len(xs) < 8:
        return None
    keep = keep[ys.min():ys.max() + 1, xs.min():xs.max() + 1]
    if keep.shape[0] < 6:
        return None
    w = max(1, int(round(keep.shape[1] * H / keep.shape[0])))
    return cv2.resize(keep, (w, H), interpolation=cv2.INTER_AREA).astype(np.float32)


def sim(a, b):
    """(닮은 정도, 길이 비율)"""
    if a is None or b is None:
        return 0.0, 0.0
    w = max(a.shape[1], b.shape[1])
    ar = cv2.resize(a, (w, H))
    br = cv2.resize(b, (w, H))
    c = float(cv2.matchTemplate(ar, br, cv2.TM_CCOEFF_NORMED).max())
    return c, min(a.shape[1], b.shape[1]) / float(max(a.shape[1], b.shape[1]))


def name_at(gray, x, y):
    """화면의 (x, y)에 있는 이름 한 줄을 잘라 냄 (구단주 정보 화면 등록용) -> (자른 회색조, 정리한 글자) / (None, None)
    마우스가 있는 글자에서 시작해 옆 글자(간격 8px 이하)를 이어 붙임, 아이콘 상자(속이 꽉 찬 덩어리)는 뺌"""
    hgt, wid = gray.shape[:2]
    x0, x1 = max(0, x - 170), min(wid, x + 170)
    y0, y1 = max(0, y - 20), min(hgt, y + 20)
    win = gray[y0:y1, x0:x1].astype(np.uint8)
    if win.size == 0:
        return None, None
    dark = float(np.median(win)) > 128
    g = 255 - win if dark else win
    _, b = cv2.threshold(g, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    n, lab, st, _ = cv2.connectedComponentsWithStats(b)
    cx, cy = x - x0, y - y0
    comps = []
    for i in range(1, n):
        bx, by, bw, bh, a = st[i]
        if a < 2 or bh > 30 or bw > 60:
            continue
        if bw * bh > 120 and a / float(bw * bh) > 0.62:      # 아이콘 상자
            continue
        comps.append([bx, by, bx + bw, by + bh])
    if not comps:
        return None, None
    # 마우스 줄에 걸친 덩어리들
    row = [c for c in comps if c[1] - 3 <= cy <= c[3] + 3]
    if not row:
        return None, None
    start = min(row, key=lambda c: 0 if c[0] <= cx <= c[2] else min(abs(c[0] - cx), abs(c[2] - cx)))
    if not (start[0] - 10 <= cx <= start[2] + 10):
        return None, None
    band = (start[1] - 6, start[3] + 6)
    line = sorted([c for c in comps if c[3] > band[0] and c[1] < band[1]], key=lambda c: c[0])
    L, R = start[0], start[2]
    grew = True
    while grew:
        grew = False
        for c in line:
            if c[0] < L and L - c[2] <= 8 and c[2] >= L - 8:
                L, grew = c[0], True
            if c[2] > R and c[0] - R <= 8:
                R, grew = c[2], True
    sel = [c for c in line if c[0] >= L and c[2] <= R]
    T, B = min(c[1] for c in sel), max(c[3] for c in sel)
    cut = win[max(0, T - 3):min(win.shape[0], B + 3), max(0, L - 3):min(win.shape[1], R + 3)]
    return cut, norm(cut, dark)


def opp_name_gray(gray, vb):
    """VS 화면 상대 이름 칸 (vb = vs_team.png 위치, 화면 좌표가 아니라 frame 안 좌표)"""
    dx, dy, w, h = OPP_NAME
    x, y = int(vb.left + dx), int(vb.top + dy)
    if x < 0 or y < 0:
        return None
    g = gray[y:y + h, x:x + w]
    return g if g.shape[0] == h and g.shape[1] == w else None


def _png64(img):
    ok, buf = cv2.imencode('.png', np.clip(img, 0, 255).astype(np.uint8))
    return base64.b64encode(buf.tobytes()).decode('ascii') if ok else ''


def _from64(s):
    try:
        a = cv2.imdecode(np.frombuffer(base64.b64decode(s), np.uint8), cv2.IMREAD_GRAYSCALE)
        return None if a is None else a.astype(np.float32)
    except Exception:                                   # noqa: BLE001
        return None


class Store:
    def __init__(self, folder):
        self.dir = folder
        os.makedirs(folder, exist_ok=True)
        self.path = os.path.join(folder, 'bigmatch.json')
        self.s = {'list': [], 'games': {}, 'result_alert': True, 'photo': True}
        try:
            with open(self.path, encoding='utf-8') as fp:
                self.s.update(json.load(fp))
        except (OSError, ValueError):
            pass
        self._g = {}

    def save(self):
        try:
            tmp = self.path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as fp:
                json.dump(self.s, fp, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError:
            pass

    def glyph(self, e):
        k = (e['id'], e.get('src'))
        if k not in self._g:
            self._g[k] = _from64(e.get('g', ''))
        return self._g[k]

    def add(self, name, cut, glyph):
        name = (name or '').strip()[:16]
        old = next((e for e in self.s['list'] if name and e['name'] == name), None)
        if old is not None:                               # 같은 이름을 다시 등록 -> 그림만 새로
            old.update(src='prof', g=_png64(glyph), img=_png64(cut))
            old.pop('vs_img', None)
            self._g.clear()
            self.save()
            return old
        if len(self.s['list']) >= MAX_ENTRIES:
            return None
        e = {'id': '%x' % int(time.time() * 1000), 'name': (name or '').strip()[:16] or '이름 없음', 'on': True,
             'src': 'prof', 'g': _png64(glyph), 'img': _png64(cut), 'w': 0, 'd': 0, 'l': 0, 'last': None}
        self.s['list'].append(e)
        self.save()
        return e

    def find(self, glyph):
        """VS 상대 이름 글자 -> (항목, 닮은 정도) / (None, 가장 높은 값)"""
        best = (None, 0.0)
        for e in self.s['list']:
            if not e.get('on', True):
                continue
            c, r = sim(self.glyph(e), glyph)
            th = TH_VS if e.get('src') == 'vs' else TH_PROF
            if c >= th and r >= RATIO_MIN and c > best[1]:
                best = (e, c)
            elif best[0] is None and c > best[1]:
                best = (None, c)
        return best

    def met(self, e, glyph, vs_cut, key):
        """만났음: 처음이면 VS 이름 그림으로 바꿔 저장, 이 판 기록"""
        if e.get('src') != 'vs' and glyph is not None:
            e['src'] = 'vs'
            e['g'] = _png64(glyph)
            if vs_cut is not None:
                e['vs_img'] = _png64(vs_cut)
        self.s['games'][key] = {'id': e['id'], 'res': None}
        if len(self.s['games']) > 400:
            for k in sorted(self.s['games'])[:-400]:
                self.s['games'].pop(k, None)
        self.save()

    def result(self, key, res):
        """빅매치 판 결과 -> (항목, 처음 반영?)"""
        g = self.s['games'].get(key)
        if not g or g.get('res') or res not in ('승', '무', '패'):
            return None, False
        g['res'] = res
        e = next((x for x in self.s['list'] if x['id'] == g['id']), None)
        if e is not None:
            e[{'승': 'w', '무': 'd', '패': 'l'}[res]] = e.get({'승': 'w', '무': 'd', '패': 'l'}[res], 0) + 1
            e['last'] = [time.strftime('%m/%d'), res]
        self.save()
        return e, True

    def remove(self, eid):
        self.s['list'] = [e for e in self.s['list'] if e['id'] != eid]
        self.save()

    def toggle(self, eid):
        for e in self.s['list']:
            if e['id'] == eid:
                e['on'] = not e.get('on', True)
        self.save()

    def is_big(self, key):
        return key in self.s['games']


def record_text(e):
    n = e.get('w', 0) + e.get('d', 0) + e.get('l', 0)
    if not n:
        return '아직 안 만남'
    t = '%d전 %d승%s %d패' % (n, e.get('w', 0), (' %d무' % e['d']) if e.get('d') else '', e.get('l', 0))
    if e.get('last'):
        t += ' · 마지막 %s %s' % (e['last'][0], e['last'][1])
    return t
