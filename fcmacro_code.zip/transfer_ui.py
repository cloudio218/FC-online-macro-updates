# -*- coding: utf-8 -*-
"""v4.0 이적시장 갱신꾼 화면 (감독모드 매크로 창과 같은 디자인, 시안 mock5/mock6)

- TransferView: 매크로 창에서 맨 위 칩을 누르면 감독모드 화면 위에 덮어 보여 주는 갱신꾼 화면
- 프리셋 / 위치 지정 / 갱신 설정 / 갱신 결과: 버튼으로 여는 창 (창 배치 저장에 포함)
값은 ctl.cfg 를 바로 고치고 ctl.save() (진행 중에 바꾼 것은 다음 [예약 시작]부터)
"""
import datetime
import os
import time
import tkinter as tk
from tkinter import messagebox

import gui as G
import transfer_core as T
from transfer_app import STATE_TEXT

NEON_Y = '#e6ff2e'
NEON_B = '#19c8ff'
ORG = '#ff8a3d'
KC = {'dim': G.DIM, 'yel': G.YEL, 'org': ORG, 'green': G.GREEN, 'cyan': G.CYAN, 'red': G.RED}
PILL = {'res': (G.YEL, '#6b5a2a', G.CARD), 'run': (G.GREEN, '#2a5a44', '#183026'), 'off': (G.DIM, G.LINE, G.CARD),
        'org': (ORG, '#6b4026', G.CARD), 'ok': (G.CYAN, '#2c5560', G.CARD), 'red': (G.RED, '#6b2a33', G.CARD),
        'star': (NEON_Y, '#5a6418', G.CARD)}
INBG = '#111118'
F = lambda size, bold=False: (G.FONT, size, 'bold') if bold else (G.FONT, size)      # noqa: E731
PX = G.px


def L(parent, text='', size=9, fg=G.FG, bold=False, bg=G.CARD, **kw):
    return tk.Label(parent, text=text, font=F(size, bold), fg=fg, bg=bg, **kw)


def card(parent, **pack):
    f = tk.Frame(parent, bg=G.CARD, padx=12, pady=8)
    f.pack(fill='x', padx=10, pady=(0, 6), **pack)
    return f


def pill(parent, text='', kind='off', bg=G.CARD, size=8):
    w = tk.Label(parent, text=text, font=F(size), padx=PX(6), pady=0, bd=0, highlightthickness=1, bg=bg)
    set_pill(w, text, kind)
    return w


def set_pill(w, text, kind):
    fg, line, bg = PILL.get(kind, PILL['off'])
    if w.cget('text') != text or w.cget('fg') != fg:
        w.config(text=text, fg=fg, highlightbackground=line, bg=bg)


def button(parent, text, cmd, fg=G.FG, bg=G.CARD2, size=9, bold=True, padx=10, pady=4):
    b = tk.Label(parent, text=text, font=F(size, bold), fg=fg, bg=bg, padx=PX(padx), pady=PX(pady), cursor='hand2',
                 highlightthickness=1, highlightbackground=G.LINE)
    b.bind('<Button-1>', lambda e: cmd())
    b.bind('<Enter>', lambda e: b.config(bg='#34344a'))
    b.bind('<Leave>', lambda e: b.config(bg=bg))
    return b


def entry(parent, var, width=5, justify='center', show=None):
    e = tk.Entry(parent, textvariable=var, width=width, font=F(10), bg=INBG, fg=G.FG, insertbackground=G.FG,
                 relief='flat', justify=justify, highlightthickness=1, highlightbackground=G.LINE, highlightcolor=G.CYAN,
                 disabledbackground=INBG, show=show or '')
    return e


class Toggle(tk.Canvas):
    def __init__(self, parent, on=False, command=None, bg=G.CARD):
        super().__init__(parent, width=PX(32), height=PX(17), bg=bg, highlightthickness=0, cursor='hand2')
        self.on, self.command = bool(on), command
        self.bind('<Button-1>', lambda e: self.toggle())
        self.draw()

    def draw(self):
        self.delete('all')
        w, h = PX(32), PX(17)
        c = '#2a7a58' if self.on else '#3a3a4e'
        r = h / 2
        self.create_oval(0, 0, h, h, fill=c, outline=c)
        self.create_oval(w - h, 0, w, h, fill=c, outline=c)
        self.create_rectangle(r, 0, w - r, h, fill=c, outline=c)
        x = w - h + 2 if self.on else 2
        self.create_oval(x, 2, x + h - 4, h - 2, fill='#ffffff' if self.on else '#b8b8c8', outline='')

    def set(self, on):
        if bool(on) != self.on:
            self.on = bool(on)
            self.draw()

    def toggle(self):
        self.on = not self.on
        self.draw()
        if self.command:
            self.command(self.on)


class Drop(tk.Label):
    """[값 ▾] 누르면 목록"""

    def __init__(self, parent, values, value, command=None, width=None, bg=INBG):
        super().__init__(parent, text='', font=F(10), fg=G.FG, bg=bg, padx=PX(7), pady=PX(2), cursor='hand2',
                         highlightthickness=1, highlightbackground=G.LINE, anchor='w', width=width or 0)
        self.values, self.command = list(values), command
        self.value = value
        self._show()
        self.bind('<Button-1>', self._open)

    def _show(self):
        self.config(text='%s ▾' % self.value)

    def set(self, v):
        self.value = v
        self._show()

    def _open(self, e):
        m = tk.Menu(self, tearoff=0, font=F(10), bg=G.CARD2, fg=G.FG, activebackground='#34344a', activeforeground=G.FG, bd=0)
        for v in self.values:
            m.add_command(label=v, command=lambda vv=v: self._pick(vv))
        try:
            m.tk_popup(self.winfo_rootx(), self.winfo_rooty() + self.winfo_height())
        finally:
            m.grab_release()

    def _pick(self, v):
        self.set(v)
        if self.command:
            self.command(v)


class Seg(tk.Frame):
    """[구매|판매] 눌러서 바꾸기"""

    def __init__(self, parent, values, value, command=None, bg=G.CARD):
        super().__init__(parent, bg=G.LINE, padx=1, pady=1)
        self.command, self.value, self.lbls = command, value, {}
        for v in values:
            lb = tk.Label(self, text=v, font=F(9), padx=PX(8), pady=PX(2), cursor='hand2')
            lb.pack(side='left')
            lb.bind('<Button-1>', lambda e, vv=v: self._pick(vv))
            self.lbls[v] = lb
        self._show()

    def _show(self):
        for v, lb in self.lbls.items():
            on = v == self.value
            lb.config(bg='#2a2a3d' if on else G.CARD, fg=G.FG if on else G.DIM, font=F(9, on))

    def _pick(self, v):
        if v != self.value:
            self.value = v
            self._show()
            if self.command:
                self.command(v)


def dark_top(title, key=None, geometry=None, minsize=None):
    w = tk.Toplevel(G._root)
    w.title(title)
    w.configure(bg=G.BG)
    if geometry:
        w.geometry(geometry)
    if minsize:
        w.minsize(*minsize)
    try:
        if G._root.attributes('-topmost'):
            w.attributes('-topmost', True)
    except tk.TclError:
        pass
    if key:
        try:
            G._remember_pop(w, key)
        except Exception:
            pass
    return w


def _msg(kind, title, text, parent=None):
    fn = {'info': messagebox.showinfo, 'warn': messagebox.showwarning, 'err': messagebox.showerror}[kind]
    fn(title, text, parent=parent or G._root)


# ── 갱신꾼 화면 ──────────────────────────────────────
TR_BTN_DEFAULT = ['friends', 'tr_presets', 'tr_pos', 'tr_start', 'tr_results', 'tr_settings', 'hotkeys', 'tr_stop']


class TransferView(tk.Frame):
    """매크로 창 몸통을 덮는 갱신꾼 화면. api: action(aid), gm_line() -> (글, 색), gm_results() -> ['승',...],
    key_of(aid) -> 단축키 글자, tr_order_get/set"""

    def __init__(self, master, ctl, api):
        super().__init__(master, bg=G.BG)
        self.ctl, self.api = ctl, api
        self._rev = None
        self._hist_rev = None
        self._pv_key = None
        self._log_n = None
        # 감독모드 한 줄 + 최근 10경기
        gm = tk.Frame(self, bg=G.CARD, padx=12, pady=6)
        gm.pack(fill='x', padx=10, pady=(0, 6))
        self.w_gdot = tk.Canvas(gm, width=PX(10), height=PX(10), bg=G.CARD, highlightthickness=0)
        self.w_gdot.pack(side='left', padx=(0, 6))
        self.w_gtxt = L(gm, '', 11)
        self.w_gtxt.pack(side='left')
        self.w_gres = tk.Canvas(gm, height=PX(21), width=PX(10 * 23), bg=G.CARD, highlightthickness=0)
        self.w_gres.pack(side='right')
        self._gres_key = None
        for w in (gm, self.w_gtxt):
            w.config(cursor='hand2')
            w.bind('<Button-1>', lambda e: self.api['action']('view'))
        # 상태
        st = card(self)
        r = tk.Frame(st, bg=G.CARD)
        r.pack(fill='x')
        self.w_dot = tk.Canvas(r, width=PX(13), height=PX(13), bg=G.CARD, highlightthickness=0)
        self.w_dot.pack(side='left', padx=(0, 7))
        self.w_state = L(r, '', 17, G.DIM, True)
        self.w_state.pack(side='left')
        self.w_clock = L(r, '', 10, G.DIM)
        self.w_clock.pack(side='right')
        self.w_sub = L(st, '', 12, G.FG, anchor='w', justify='left', wraplength=PX(420))
        self.w_sub.pack(fill='x', pady=(5, 0))
        self.w_next = L(st, '', 11, G.DIM, anchor='w', justify='left', wraplength=PX(420))
        self.w_next.pack(fill='x', pady=(2, 0))
        self.w_hint = L(st, '', 11, ORG, anchor='w', justify='left', wraplength=PX(420))
        # 캡처 확인
        pc = card(self)
        ph = tk.Frame(pc, bg=G.CARD)
        ph.pack(fill='x')
        L(ph, '캡처 확인', 11, G.DIM).pack(side='left')
        self.w_pvt = L(ph, '', 10, G.DIM, anchor='e')
        self.w_pvt.pack(side='right')
        self.w_prices = tk.Frame(pc, bg=G.CARD)
        self.w_prices.pack(fill='x', pady=(5, 0))
        self.w_pv = tk.Label(pc, bg=G.CARD, bd=0)
        self.w_pv.pack(anchor='w', pady=(5, 0))
        self._pv_photo = None
        # 켜진 선수
        tc = card(self)
        self.w_tbl = tk.Frame(tc, bg=G.CARD)
        self.w_tbl.pack(fill='x')
        self.w_tsum = L(tc, '', 11, G.DIM, anchor='w')
        self.w_tsum.pack(fill='x', pady=(3, 0))
        self.w_tsum.bind('<Button-1>', lambda e: self.api['action']('tr_results'))
        self.w_tsum.config(cursor='hand2')
        self._tbl_key = None
        # 기록 (남는 자리 전부)
        lc = tk.Frame(self, bg=G.CARD, padx=10, pady=6)
        lc.pack(fill='both', expand=True, padx=10, pady=(0, 6))
        self.w_log = tk.Text(lc, bg=G.CARD, fg='#c9c9d6', font=(G.FONT, 11), relief='flat', height=4, wrap='char',
                             highlightthickness=0, padx=0, pady=0, cursor='arrow', spacing1=1)
        self.w_log.pack(fill='both', expand=True)
        for tag, color in (('ok', G.GREEN), ('warn', ORG), ('error', G.RED), ('info', '#c9c9d6'), ('t', G.DIM)):
            self.w_log.tag_configure(tag, foreground=color)
        # 버튼
        bt = tk.Frame(self, bg=G.BG, padx=7)
        bt.pack(fill='x', pady=(0, 8))
        self.bt = bt
        for i in range(4):
            bt.grid_columnconfigure(i, weight=1, uniform='tb')
        self.btns = {}
        order = [a for a in (api.get('tr_order_get', lambda: [])() or []) if a in TR_BTN_DEFAULT]
        self.order = order + [a for a in TR_BTN_DEFAULT if a not in order]
        for aid in self.order:
            b = G.Btn(bt, aid, lambda a: self.api['action'](a))
            b.t.config(font=F(11, True))                 # 갱신꾼 화면은 버튼 글씨 크게 (단축키는 아래 줄)
            b.k.config(font=F(8))
            b.t.pack_forget()
            b.k.pack_forget()
            b.t.pack(side='top')
            b.k.pack(side='top')
            b.inner.pack_configure(pady=PX(5), expand=True)
            b.drag = (self._drag_start, self._drag_move, self._drag_drop, self._btn_menu)
            self.btns[aid] = b
        self._regrid()
        self.refresh()

    # 버튼 끌기 (감독모드 화면과 따로 저장)
    def _regrid(self):
        for n, aid in enumerate(self.order):
            self.btns[aid].grid(row=n // 4, column=n % 4, sticky='nsew', padx=2, pady=2)

    def _drag_start(self, b):
        b.config(highlightbackground=NEON_Y, highlightthickness=2)
        b.lift()

    def _drag_move(self, b, x, y):
        for n, aid in enumerate(self.order):
            o = self.btns[aid]
            if o is not b and o.winfo_rootx() <= x < o.winfo_rootx() + o.winfo_width() and \
                    o.winfo_rooty() <= y < o.winfo_rooty() + o.winfo_height():
                self.order.remove(b.aid)
                self.order.insert(n, b.aid)
                self._regrid()
                return

    def _drag_drop(self, b):
        st, b._state = b._state, None
        b.config(highlightthickness=1, highlightbackground=G.LINE)
        if st:
            b.set(*st)
        if self.api.get('tr_order_set'):
            self.api['tr_order_set'](None if self.order == TR_BTN_DEFAULT else list(self.order))

    def _btn_menu(self, e):
        m = tk.Menu(self, tearoff=0, font=F(9))
        m.add_command(label='버튼 원래 순서로', command=self._btn_reset)
        try:
            m.tk_popup(e.x_root, e.y_root)
        finally:
            m.grab_release()

    def _btn_reset(self):
        self.order[:] = TR_BTN_DEFAULT
        self._regrid()
        if self.api.get('tr_order_set'):
            self.api['tr_order_set'](None)

    # 그리기
    @staticmethod
    def _dot(cv, color, size):
        cv.delete('all')
        cv.create_oval(1, 1, size - 1, size - 1, fill=color, outline=color)

    def refresh(self):
        c = self.ctl
        k = self.api.get('key_of', lambda a: '')
        run = c.running()
        self.btns['friends'].set('♛ 친구 랭킹', k('friends'))
        self.btns['tr_presets'].set('☰ 프리셋', '')
        self.btns['tr_pos'].set('⌖ 위치 지정', '')
        self.btns['tr_start'].set('▶ 예약 시작', k('tr_start'), G.CARD2, G.DIM if run else G.GREEN)
        self.btns['tr_results'].set('◆ 갱신 결과', '')
        self.btns['tr_settings'].set('⚙ 갱신 설정', '')
        self.btns['hotkeys'].set('⌨ 단축키', '')
        self.btns['tr_stop'].set('■ 정지', k('tr_stop'), '#3a2228' if run else G.CARD2, G.RED if run else G.DIM)
        for b in self.btns.values():                  # 단축키 없는 버튼은 글자를 가운데로
            has = bool(b.k.cget('text'))
            if has != bool(b.k.winfo_manager()):
                if has:
                    b.k.pack(side='top')
                else:
                    b.k.pack_forget()
        # 감독모드 줄
        txt, col = self.api['gm_line']() if self.api.get('gm_line') else ('', G.DIM)
        if self.w_gtxt.cget('text') != txt:
            self.w_gtxt.config(text=G.clean(txt))
        self._dot(self.w_gdot, col, PX(10))
        res = list(self.api['gm_results']())[-10:] if self.api.get('gm_results') else []
        if res != self._gres_key:
            self._gres_key = res
            cv = self.w_gres
            cv.delete('all')
            cell, gap = PX(20), PX(3)
            cv.config(width=10 * (cell + gap))
            x = 10 * (cell + gap) - len(res) * (cell + gap)
            for r in res:
                fg, bg = {'승': (G.GREEN, '#1f3a2e'), '패': (G.RED, '#3a1f26')}.get(r, ('#b7b7c9', '#2c2c38'))
                cv.create_rectangle(x, 0, x + cell, cell, fill=bg, outline=bg)
                cv.create_text(x + cell / 2, cell / 2, text=r, fill=fg, font=F(9, True))
                x += cell + gap
        # 상태
        text, kc = STATE_TEXT.get(c.state, (c.state, 'dim'))
        col = KC.get(kc, G.DIM)
        if run and c.state == 'idle':
            text, col = '예약 대기', G.YEL
        self.w_state.config(text=text, fg=col)
        self._dot(self.w_dot, col, PX(13))
        off = float(c.cfg.get('clock_offset', 0) or 0)
        self.w_clock.config(text='시계 %+.2f초 · %s' % (off, time.strftime('%H:%M:%S')))
        sub = c.sub or ('Ctrl+F9로 예약 시작 · 켜진 선수 %d명' % len(c.enabled()) if not run else '')
        if self.w_sub.cget('text') != G.clean(sub):
            self.w_sub.config(text=G.clean(sub))
        nxt = c.next_info()[:2]
        line = ' · '.join('%s %s%s' % (T.hhmm(ts), c.name(i), ' ★' if c.cfg['presets'][i].get('star') else '')
                          for ts, i in nxt)
        self.w_next.config(text=('다음: ' + line) if line else '켜진 선수가 없어요 — [☰ 프리셋]에서 켜 주세요')
        hint = ''
        if c.hints.get('reopen'):
            hint = "이적시장 다시 열기가 %.1f초 걸렸어요 → [⚙ 갱신 설정]에서 '다시 열기'를 늘리는 걸 추천해요" % c.hints['reopen']
        if hint:
            self.w_hint.config(text=hint)
            if not self.w_hint.winfo_ismapped():
                self.w_hint.pack(fill='x', pady=(3, 0))
        elif self.w_hint.winfo_ismapped():
            self.w_hint.pack_forget()
        # 캡처
        pv = c.preview
        if pv is not None and pv is not self._pv_key:
            self._pv_key = pv
            try:
                from PIL import ImageTk
                img = pv[1]
                kk = min(PX(420) / img.width, PX(70) / img.height, 3.0)
                img = img.resize((max(1, int(img.width * kk)), max(1, int(img.height * kk))))
                self._pv_photo = ImageTk.PhotoImage(img)
                self.w_pv.config(image=self._pv_photo)
                self.w_pvt.config(text=G.clean(pv[0])[:48])
            except Exception:
                pass
        elif pv is None and self.w_pvt.cget('text') == '':
            self.w_pvt.config(text='프리셋의 [테스트]나 진행이 시작되면 여기에 보여요')
        pr = c.prices.get('last')
        key = (pr or {}).get('t')
        if key != getattr(self, '_pr_key', None):
            self._pr_key = key
            for w in self.w_prices.winfo_children():
                w.destroy()
            if pr:
                for name, v, fg in (('지금 ' + pr['label'], pr['target'], G.YEL), ('내 등록가', pr['mine'], G.FG)):
                    f = tk.Frame(self.w_prices, bg=INBG, highlightthickness=1, highlightbackground=G.LINE, padx=PX(8), pady=PX(3))
                    f.pack(side='left', padx=(0, 6))
                    L(f, name + ' ', 10, G.DIM, bg=INBG).pack(side='left')
                    L(f, v, 12, fg, True, bg=INBG).pack(side='left')
        # 켜진 선수 표
        en = c.enabled()
        skey = (c.hist_rev, tuple(en), tuple(c.cfg['presets'][i]['name'] for i in en))
        if skey != self._hist_rev:
            self._hist_rev = skey
            self._stats = {i: c.preset_stat(i) for i in en}
            tcnt = c.today_counts()
            self.w_tsum.config(text=('오늘 ' + ' · '.join('%s %d' % (G.clean(T.HIST_KIND[kk]), n) for kk, n in tcnt)
                                     if tcnt else '오늘 기록 없음') + '  ·  ◆ 갱신 결과 보기 ›')
        rows = []
        for i in en:
            p = c.cfg['presets'][i]
            stt, stx = c.pst.get(i, (None, ''))
            succ, tot, _seen = self._stats.get(i, (0, 0, ''))
            rows.append((i, p['name'], '%s %02d분' % (T.PARITY[p['parity']], int(p['minute'])),
                         '%s %s' % (T.SIDE[p.get('side', 'buy')], T.TARGET[p['target']][:2]), '%d/%d' % (succ, tot),
                         stt, stx, bool(p.get('star'))))
        nexts = {i: ts for ts, i in c.next_info()}
        tk_ = tuple(rows) + (tuple(sorted(nexts.items())),)
        if tk_ != self._tbl_key:
            self._tbl_key = tk_
            for w in self.w_tbl.winfo_children():
                w.destroy()
            heads = ('#', '선수', '시간', '목표', '성공', '상태')
            for col, h in enumerate(heads):
                L(self.w_tbl, h, 10, G.DIM).grid(row=0, column=col, sticky='w', padx=(0, PX(10)))
            self.w_tbl.grid_columnconfigure(1, weight=1)
            if not rows:
                L(self.w_tbl, '켜진 선수가 없어요', 12, G.DIM).grid(row=1, column=0, columnspan=6, sticky='w', pady=4)
            for n, (i, nm, tm, tg, sc, stt, stx, star) in enumerate(rows, start=1):
                L(self.w_tbl, str(i + 1), 12).grid(row=n, column=0, sticky='w', pady=2)
                L(self.w_tbl, ('★ ' if star else '') + nm, 12, NEON_Y if star else G.FG, True).grid(row=n, column=1, sticky='w')
                L(self.w_tbl, tm, 12).grid(row=n, column=2, sticky='w', padx=(0, PX(10)))
                L(self.w_tbl, tg, 12).grid(row=n, column=3, sticky='w', padx=(0, PX(10)))
                L(self.w_tbl, sc, 12).grid(row=n, column=4, sticky='w', padx=(0, PX(10)))
                if stt:
                    txt, kind = stx or stt, {'armed': 'res', 'run': 'run', 'limit': 'org', 'success': 'ok',
                                            'timeout': 'off', 'error': 'red', 'idle': 'off'}.get(stt, 'off')
                elif run and i in nexts:
                    txt, kind = '예약 %s' % T.hhmm(nexts[i]), 'res'
                else:
                    txt, kind = '꺼짐' if not run else '-', 'off'
                if star and kind == 'res':
                    kind, txt = 'star', '★ ' + txt
                pill(self.w_tbl, G.clean(txt), kind, size=11).grid(row=n, column=5, sticky='w')
        # 기록
        logs = list(c.logs)[-40:]
        key = (len(c.logs), logs[-1] if logs else None)
        if key != self._log_n:
            self._log_n = key
            t = self.w_log
            t.config(state='normal')
            t.delete('1.0', 'end')
            for n, (hm, m, kind) in enumerate(logs):
                t.insert('end', hm + ' ', 't')
                t.insert('end', G.clean(m).replace('\n', ' ') + ('\n' if n < len(logs) - 1 else ''), kind if kind in ('ok', 'warn', 'error') else 'info')
            t.see('end')
            t.config(state='disabled')


# ── 프리셋 창 ─────────────────────────────────────
_wins = {}


def _single(key):
    w = _wins.get(key)
    if w is not None:
        try:
            w.deiconify()
            w.lift()
            return True
        except tk.TclError:
            _wins.pop(key, None)
    return False


def open_presets(ctl):
    if _single('presets'):
        return
    c = ctl.cfg
    w = dark_top('갱신꾼 프리셋', 'tr_presets', '1380x520', (760, 300))
    _wins['presets'] = w
    keep = w._keep = []                 # Tk 변수는 붙잡아 둬야 함 (안 그러면 사라져서 입력이 저장 안 됨)
    hd = tk.Frame(w, bg=G.BG, padx=16, pady=10)
    hd.pack(fill='x')
    L(hd, '☰ 갱신꾼 프리셋', 12, G.FG, True, bg=G.BG).pack(side='left')
    w_cnt = L(hd, '', 9, G.DIM, bg=G.BG)
    w_cnt.pack(side='left', padx=10)
    L(hd, '우선: 시간이 겹치면 숫자가 작은 선수 먼저 · ★ 최우선: 감독모드가 로비에서 기다렸다가 로비 이적시장으로', 8, G.DIM,
      bg=G.BG).pack(side='right')
    outer = tk.Frame(w, bg=G.LINE, padx=1, pady=1)
    outer.pack(fill='both', expand=True, padx=12, pady=(0, 6))
    cv = tk.Canvas(outer, bg=G.BG, highlightthickness=0)
    hs = tk.Scrollbar(outer, orient='horizontal', command=cv.xview)
    vs = tk.Scrollbar(outer, orient='vertical', command=cv.yview)
    cv.configure(xscrollcommand=hs.set, yscrollcommand=vs.set)
    vs.pack(side='right', fill='y')
    hs.pack(side='bottom', fill='x')
    cv.pack(side='left', fill='both', expand=True)
    tb = tk.Frame(cv, bg=G.BG)
    cv.create_window((0, 0), window=tb, anchor='nw')
    tb.bind('<Configure>', lambda e: cv.configure(scrollregion=cv.bbox('all')))

    def wheel(e):
        cv.yview_scroll(-1 if e.delta > 0 else 1, 'units')
    cv.bind('<Enter>', lambda e: w.bind_all('<MouseWheel>', wheel))
    cv.bind('<Leave>', lambda e: w.unbind_all('<MouseWheel>'))
    heads = ['#', '사용', '★ 최우선', '우선', '선수', '구매/판매', '갱신 시간', '누를 가격', '위치 지정', '상태', '성공', '최근 갱신', '']
    mins = [24, 44, 62, 40, 140, 96, 148, 92, 206, 128, 44, 104, 150]          # 칸 폭 고정 -> 글자가 밀려 내려가지 않음
    for col, (h, mn) in enumerate(zip(heads, mins)):
        tb.grid_columnconfigure(col, minsize=PX(mn))
        L(tb, h, 8, G.DIM, bg=G.BG).grid(row=0, column=col, sticky='w', padx=PX(4), pady=(PX(6), PX(4)))
    rows = {}
    marks = {}

    def save():
        ctl.save()
        refresh()

    def set_(i, k, v):
        c['presets'][i][k] = v
        if k == 'side':
            c['presets'][i]['target'] = 'lower' if v == 'sell' else 'upper'
            rows[i]['target'].set(T.TARGET[c['presets'][i]['target']])
        save()

    def make_row(i):
        p = c['presets'][i]
        r = i + 1
        d = {}
        L(tb, str(i + 1), 10, G.DIM, bg=G.BG).grid(row=r, column=0, sticky='w', padx=PX(4), pady=PX(4))
        d['enabled'] = Toggle(tb, p['enabled'], lambda on, i=i: set_(i, 'enabled', on), bg=G.BG)
        d['enabled'].grid(row=r, column=1, sticky='w', padx=PX(4))
        star = tk.Label(tb, text='★' if p.get('star') else '☆', font=F(14), fg=NEON_Y if p.get('star') else '#44445a',
                        bg=G.BG, cursor='hand2')

        def tstar(e, i=i, s=star):
            on = not c['presets'][i].get('star')
            s.config(text='★' if on else '☆', fg=NEON_Y if on else '#44445a')
            set_(i, 'star', on)
        star.bind('<Button-1>', tstar)
        star.grid(row=r, column=2, sticky='w', padx=PX(10))
        pv = tk.StringVar(value=str(T.prio(p)))
        keep.append(pv)
        e = entry(tb, pv, 3)
        e.grid(row=r, column=3, sticky='w', padx=PX(4))

        def setp(*_a, i=i, v=pv):
            try:
                c['presets'][i]['priority'] = max(1, min(10, int(v.get())))
                ctl.save()
            except ValueError:
                pass
        pv.trace_add('write', setp)
        nv = tk.StringVar(value=p['name'])
        keep.append(nv)
        en = entry(tb, nv, 15, 'left')
        en.grid(row=r, column=4, sticky='w', padx=PX(4))

        def setn(*_a, i=i, v=nv):
            c['presets'][i]['name'] = v.get().strip() or '프리셋 %d' % (i + 1)
            ctl.save()
        nv.trace_add('write', setn)
        d['side'] = Seg(tb, ['구매', '판매'], T.SIDE[p.get('side', 'buy')],
                        lambda v, i=i: set_(i, 'side', 'sell' if v == '판매' else 'buy'), bg=G.BG)
        d['side'].grid(row=r, column=5, sticky='w', padx=PX(4))
        tm = tk.Frame(tb, bg=G.BG)
        tm.grid(row=r, column=6, sticky='w', padx=PX(4))
        rev_par = {v: k for k, v in T.PARITY.items()}
        Drop(tm, list(T.PARITY.values()), T.PARITY[p['parity']], lambda v, i=i: set_(i, 'parity', rev_par[v]), width=6).pack(side='left')
        mv = tk.StringVar(value='%02d' % int(p['minute']))
        keep.append(mv)
        me = entry(tm, mv, 3)
        me.pack(side='left', padx=(PX(4), PX(3)))

        def setm(*_a, i=i, v=mv):
            try:
                m = int(v.get())
                if 0 <= m <= 59:
                    c['presets'][i]['minute'] = m
                    ctl.save()
            except ValueError:
                pass
        mv.trace_add('write', setm)
        L(tm, '분', 10, G.FG, bg=G.BG).pack(side='left')
        rev_tg = {v: k for k, v in T.TARGET.items()}
        d['target'] = Drop(tb, list(T.TARGET.values()), T.TARGET[p['target']], lambda v, i=i: set_(i, 'target', rev_tg[v]), width=6)
        d['target'].grid(row=r, column=7, sticky='w', padx=PX(4))
        pf = tk.Frame(tb, bg=G.BG)
        pf.grid(row=r, column=8, sticky='w', padx=PX(4))
        d['pos'] = {}
        for key, kind, short, _g in T.PRESET_ITEMS:
            b = tk.Label(pf, text=short, font=F(8), padx=PX(6), pady=PX(1), cursor='hand2', bg=G.BG, highlightthickness=1)
            b.pack(side='left', padx=(0, PX(3)))
            b.bind('<Button-1>', lambda e, k=key, i=i: do_pick(k, i))
            d['pos'][key] = b
        d['state'] = pill(tb, '', 'off', bg=G.BG)
        d['state'].grid(row=r, column=9, sticky='w', padx=PX(4))
        d['succ'] = L(tb, '', 10, G.FG, bg=G.BG)
        d['succ'].grid(row=r, column=10, sticky='w', padx=PX(4))
        d['seen'] = L(tb, '', 9, G.DIM, bg=G.BG)
        d['seen'].grid(row=r, column=11, sticky='w', padx=PX(4))
        af = tk.Frame(tb, bg=G.BG)
        af.grid(row=r, column=12, sticky='w', padx=PX(4))
        button(af, '테스트', lambda i=i: start(i, 'test'), size=8, padx=7, pady=2).pack(side='left', padx=(0, 3))
        button(af, '지금', lambda i=i: start(i, 'now'), size=8, padx=7, pady=2).pack(side='left', padx=(0, 3))
        button(af, '복사', lambda i=i: copy(i), size=8, padx=7, pady=2).pack(side='left')
        d['widgets'] = [e, en, me]
        rows[i] = d

    def do_pick(key, i):
        try:
            m = ctl.pick(G._root, key, i)
        except ValueError as ex:
            _msg('warn', '위치 지정', str(ex), w)
            return
        if m:
            refresh()

    def start(i, mode):
        err = ctl.start(mode, i)
        if err:
            _msg('warn', '갱신꾼', err, w)

    def copy(i):
        j, m = ctl.copy_preset(i)
        if j is not None:
            w.destroy()
            _wins.pop('presets', None)
            open_presets(ctl)
        _msg('info', '갱신꾼', m, _wins.get('presets') or G._root)

    for i in range(len(c['presets'])):
        make_row(i)
    foot = tk.Frame(w, bg=G.BG, padx=16)
    foot.pack(fill='x', pady=(0, 10))
    L(foot, '[테스트] 지금 바로 짧게 시험 (확정 안 함) · [지금] 시간 상관없이 바로 20분 · [복사] 빈 줄로 · 위치 지정 칸을 누르면 게임 화면에서 지정',
      8, G.DIM, bg=G.BG).pack(side='left')
    rk = [None]

    def refresh():
        if not w.winfo_exists():
            return
        _, pre = ctl.marks()
        nexts = {i: ts for ts, i in ctl.next_info()}
        n_on = 0
        for i, d in rows.items():
            p = c['presets'][i]
            on = p['enabled']
            n_on += on
            d['enabled'].set(on)
            for key, b in d['pos'].items():
                ok = pre[i].get(key)
                b.config(text=('%s ✓' % b.cget('text').split(' ')[0]) if ok else b.cget('text').split(' ')[0],
                         fg=G.GREEN if ok else (G.DIM if on else '#5a5a70'), highlightbackground='#2a5a44' if ok else G.LINE)
            stt, stx = ctl.pst.get(i, (None, ''))
            if stt:
                kind = {'armed': 'res', 'run': 'run', 'limit': 'org', 'success': 'ok', 'timeout': 'off', 'error': 'red'}.get(stt, 'off')
                txt = stx or stt
            elif on and ctl.running() and i in nexts:
                kind, txt = 'res', '예약 %s' % T.hhmm(nexts[i])
            else:
                kind, txt = ('off', '꺼짐') if not on else ('off', '대기')
            if p.get('star') and on and kind in ('res', 'off'):
                kind, txt = 'star', '★ 로비 ' + (txt.replace('예약 ', '') if kind == 'res' else '대기')
            set_pill(d['state'], G.clean(txt), kind)
            succ, tot, seen = ctl.preset_stat(i)
            d['succ'].config(text='%d/%d' % (succ, tot) if tot else '-', fg=G.GREEN if succ else (G.FG if on else G.DIM))
            d['seen'].config(text=seen or '-')
        w_cnt.config(text='켠 선수 %d / %d' % (n_on, len(rows)))

    def tick():
        if not w.winfo_exists():
            return
        if rk[0] != (ctl.rev, ctl.hist_rev):
            rk[0] = (ctl.rev, ctl.hist_rev)
            refresh()
        w.after(500, tick)
    w.protocol('WM_DELETE_WINDOW', lambda: (ctl.save(), w.destroy(), _wins.pop('presets', None)))
    tick()


# ── 위치 지정 창 ───────────────────────────────────
def open_position(ctl):
    if _single('pos'):
        return
    c = ctl.cfg
    w = dark_top('갱신꾼 위치 지정', 'tr_pos', '760x560', (620, 420))
    _wins['pos'] = w
    hd = tk.Frame(w, bg=G.BG, padx=16, pady=10)
    hd.pack(fill='x')
    L(hd, '⌖ 위치 지정', 12, G.FG, True, bg=G.BG).pack(side='left')
    L(hd, '게임을 1280×720 창 모드로 · 로비 이적시장 거래목록을 띄우고 지정', 8, G.DIM, bg=G.BG).pack(side='right')
    lbls = {}

    def sec(title):
        f = tk.Frame(w, bg=G.CARD, padx=14, pady=10)
        f.pack(fill='x', padx=12, pady=(0, 8))
        L(f, title, 10, G.CYAN, True).pack(anchor='w', pady=(0, 6))
        return f

    def row(parent, key, name, hint, cmd, btn='지정'):
        r = tk.Frame(parent, bg=G.CARD)
        r.pack(fill='x', pady=2)
        L(r, name, 9, G.FG, width=14, anchor='w').pack(side='left')
        lb = L(r, '', 9, G.DIM, width=10, anchor='w')
        lb.pack(side='left')
        lbls[key] = lb
        button(r, btn, cmd, size=8, padx=8, pady=1).pack(side='left', padx=(0, 8))
        L(r, hint, 8, G.DIM, anchor='w').pack(side='left', fill='x')

    def do(fn, *a):
        try:
            m = fn(G._root, *a)
        except ValueError as ex:
            _msg('warn', '위치 지정', str(ex), w)
            return
        if m:
            refresh()

    s1 = sec('이적시장 위치 맞춤 — ① 은 꼭 필요 · ②③ 은 감독모드 창 크기가 로비와 다를 때만')
    mode_row = tk.Frame(s1, bg=G.CARD)
    mode_row.pack(fill='x', pady=(0, 4))
    L(mode_row, '화면 모드', 9).pack(side='left')
    rev = {v: k for k, v in T.SCREEN_MODES.items()}

    def setmode(v):
        c['screen_mode'] = rev[v]
        ctl.save()
    Drop(mode_row, list(T.SCREEN_MODES.values()), T.SCREEN_MODES.get(c.get('screen_mode', 'auto'), '자동 감지'), setmode,
         width=9, bg=INBG).pack(side='left', padx=8)
    w_scale = L(mode_row, '', 8, G.DIM)
    w_scale.pack(side='left')
    row(s1, 'panel_lobby', '① 창 범위 (필수)', '로비 이적시장 창 테두리 드래그 — 감독모드 위치도 자동으로 맞춤',
        lambda: do(ctl.pick_panel, 'lobby'))
    row(s1, 'panel_manager', '② 창 범위 · 감모', '감독모드 창 크기가 로비와 다를 때만', lambda: do(ctl.pick_panel, 'manager'))
    row(s1, 'dialog_manager', '③ 거래 창 · 감모', '②를 했을 때만 — 감독모드에서 구매/판매 창 띄우고 누르기',
        lambda: do(ctl.capture_dialog_manager), '캡처')
    two = tk.Frame(w, bg=G.BG)
    two.pack(fill='x', padx=12)
    fb = tk.Frame(two, bg=G.CARD, padx=14, pady=10)
    fb.pack(side='left', fill='both', expand=True, padx=(0, 4))
    fs = tk.Frame(two, bg=G.CARD, padx=14, pady=10)
    fs.pack(side='left', fill='both', expand=True, padx=(4, 0))
    L(fb, "구매 창 — '구매 중' 선수의 재등록 창을 띄워 두고", 9, G.CYAN, True).pack(anchor='w', pady=(0, 6))
    L(fs, "판매 창 — '판매 중' 선수가 있을 때만", 9, G.CYAN, True).pack(anchor='w', pady=(0, 6))
    for key, kind, name, guide in T.SHARED_ITEMS:
        parent = fs if key in ('dialog_sell', 'sell_upper', 'sell_lower') else fb
        r = tk.Frame(parent, bg=G.CARD)
        r.pack(fill='x', pady=2)
        L(r, name, 9, width=11, anchor='w').pack(side='left')
        lb = L(r, '', 9, G.DIM, width=9, anchor='w')
        lb.pack(side='left')
        lbls[key] = lb
        button(r, '지정', lambda k=key: do(ctl.pick, k, None), size=8, padx=8, pady=1).pack(side='left')
    L(fs, '판매 상한가·하한가는 안 하면\n구매 창 위치에서 29px 아래로 자동', 8, G.DIM, justify='left').pack(anchor='w', pady=(6, 0))
    pvf = tk.Frame(w, bg=G.CARD, padx=14, pady=8)
    pvf.pack(fill='x', padx=12, pady=8)
    w_pvt = L(pvf, '캡처 확인: ③ 캡처를 하면 구매 글자 / 상한가 / 하한가가 여기에 보여요', 8, G.DIM, anchor='w')
    w_pvt.pack(anchor='w')
    w_pv = tk.Label(pvf, bg=G.CARD)
    w_pv.pack(anchor='w', pady=(4, 0))
    st = {'pv': None}

    def refresh():
        if not w.winfo_exists():
            return
        out, _pre = ctl.marks()
        for key, lb in lbls.items():
            v = out.get(key, 'none')
            if key == 'panel_lobby' and v != 'ok':
                lb.config(text='필수!', fg=G.RED)
            elif v == 'ok':
                lb.config(text='✓ 지정됨', fg=G.GREEN)
            elif v == 'auto':
                lb.config(text='자동(+29px)', fg=G.CYAN)
            elif key in ('panel_manager', 'dialog_manager'):
                lb.config(text='필요 없음', fg=G.DIM)
            else:
                lb.config(text='– 미지정', fg=G.DIM)
        t, kc = ctl.scale_text()
        w_scale.config(text=t, fg=KC.get(kc, G.DIM))
        if ctl.preview is not None and ctl.preview is not st['pv']:
            st['pv'] = ctl.preview
            try:
                from PIL import ImageTk
                img = ctl.preview[1]
                kk = min(PX(700) / img.width, PX(90) / img.height, 3.0)
                img = img.resize((max(1, int(img.width * kk)), max(1, int(img.height * kk))))
                st['photo'] = ImageTk.PhotoImage(img)
                w_pv.config(image=st['photo'])
                w_pvt.config(text=G.clean(ctl.preview[0]), fg=G.FG)
            except Exception:
                pass

    rk = [None]

    def tick():
        if not w.winfo_exists():
            return
        if rk[0] != ctl.rev:
            rk[0] = ctl.rev
            refresh()
        w.after(500, tick)
    w.protocol('WM_DELETE_WINDOW', lambda: (w.destroy(), _wins.pop('pos', None)))
    tick()


# ── 갱신 설정 창 ───────────────────────────────────
def open_settings(ctl):
    if _single('settings'):
        return
    c = ctl.cfg
    w = dark_top('갱신 설정', 'tr_settings', '560x760', (520, 480))
    _wins['settings'] = w
    keep = w._keep = []
    hd = tk.Frame(w, bg=G.BG, padx=16, pady=10)
    hd.pack(fill='x')
    L(hd, '⚙ 갱신 설정', 12, G.FG, True, bg=G.BG).pack(side='left')
    L(hd, '저장 위치: 기록 폴더\\갱신꾼', 8, G.DIM, bg=G.BG).pack(side='right')
    outer = tk.Frame(w, bg=G.BG)
    outer.pack(fill='both', expand=True)
    cv = tk.Canvas(outer, bg=G.BG, highlightthickness=0)
    vs = tk.Scrollbar(outer, orient='vertical', command=cv.yview)
    cv.configure(yscrollcommand=vs.set)
    vs.pack(side='right', fill='y')
    cv.pack(side='left', fill='both', expand=True)
    body = tk.Frame(cv, bg=G.BG)
    win_id = cv.create_window((0, 0), window=body, anchor='nw')
    body.bind('<Configure>', lambda e: cv.configure(scrollregion=cv.bbox('all')))
    cv.bind('<Configure>', lambda e: cv.itemconfigure(win_id, width=e.width))
    cv.bind('<Enter>', lambda e: w.bind_all('<MouseWheel>', lambda ev: cv.yview_scroll(-1 if ev.delta > 0 else 1, 'units')))
    cv.bind('<Leave>', lambda e: w.unbind_all('<MouseWheel>'))

    def sec(title):
        f = tk.Frame(body, bg=G.CARD, padx=14, pady=10)
        f.pack(fill='x', padx=10, pady=(0, 8))
        L(f, title, 10, G.CYAN, True).pack(anchor='w', pady=(0, 4))
        return f

    def line(parent):
        r = tk.Frame(parent, bg=G.CARD)
        r.pack(fill='x', pady=3)
        return r

    def num(parent, key, width=4, conv=int, lo=None, hi=None):
        x0 = c.get(key, '')
        if isinstance(x0, float) and x0.is_integer() and key != 'clock_offset':
            x0 = int(x0)
        v = tk.StringVar(value=str(x0))
        keep.append(v)

        def setv(*_a):
            try:
                x = conv(v.get())
                if (lo is None or x >= lo) and (hi is None or x <= hi):
                    c[key] = x
                    ctl.save()
            except ValueError:
                pass
        v.trace_add('write', setv)
        e = entry(parent, v, width)
        e.pack(side='left', padx=3)
        return v

    def check(parent, key, text, default=True, sub=None):
        r = line(parent)
        v = tk.BooleanVar(value=bool(c.get(key, default)))
        keep.append(v)
        cb = tk.Checkbutton(r, variable=v, bg=G.CARD, activebackground=G.CARD, selectcolor=INBG, fg=G.GREEN,
                            highlightthickness=0, bd=0, command=lambda: (c.__setitem__(key, bool(v.get())), ctl.save()))
        cb.pack(side='left')
        L(r, text, 9).pack(side='left')
        if sub:
            L(r, ' ' + sub, 8, G.DIM).pack(side='left')
        return v

    def txt(r, t, dim=False):
        L(r, t, 9, G.DIM if dim else G.FG).pack(side='left')

    s = sec('갱신 시간')
    r = line(s)
    num(r, 'duration_min', 4, float, 1, 120)
    txt(r, '분 동안 · 매 분')
    num(r, 'start_sec', 3, int, 0, 59)
    txt(r, '~')
    num(r, 'end_sec', 3, int, 0, 59)
    txt(r, '초 ·')
    num(r, 'prep_sec', 3, float, 5, 300)
    txt(r, '초 전에 기준가 저장')
    r = line(s)
    txt(r, '시계 보정')
    v_off = num(r, 'clock_offset', 6, float)
    v_off.set('%.2f' % float(c.get('clock_offset', 0) or 0))
    txt(r, '초 · 기준 사이트', True)
    hv = tk.StringVar(value=c.get('time_host', 'fcalrimi.com'))
    keep.append(hv)
    hv.trace_add('write', lambda *_a: (c.__setitem__('time_host', hv.get().strip() or 'fcalrimi.com'), ctl.save()))
    entry(r, hv, 14, 'left').pack(side='left', padx=3)
    button(r, '지금 맞추기', lambda: ctl.sync_now(), size=8, padx=8, pady=1).pack(side='right')
    w_time = L(s, '', 8, G.DIM, anchor='w', justify='left', wraplength=PX(480))
    w_time.pack(fill='x')
    check(s, 'auto_time_sync', '시작할 때 자동으로 맞추기')
    r = line(s)
    txt(r, '테스트 시간')
    num(r, 'test_sec', 3, int, 0, 120)
    txt(r, '초 동안 반복 (0 = 한 번만)', True)

    s = sec('클릭')
    r = line(s)
    v = tk.BooleanVar(value=bool(c.get('spam_click', True)))
    keep.append(v)
    tk.Checkbutton(r, variable=v, bg=G.CARD, activebackground=G.CARD, selectcolor=INBG, highlightthickness=0, bd=0,
                   command=lambda: (c.__setitem__('spam_click', bool(v.get())), ctl.save())).pack(side='left')
    txt(r, '구매 창이 떠 있는 동안 상한가/하한가 연타 ·')
    num(r, 'spam_ms', 4, int, 10, 500)
    txt(r, 'ms (30 = 1초에 약 25번)', True)
    r = line(s)
    txt(r, '호버')
    num(r, 'hover_ms', 4, int, 0, 1000)
    txt(r, 'ms · 창 대기')
    num(r, 'dialog_timeout_ms', 5, int, 300, 10000)
    txt(r, 'ms · 감도')
    num(r, 'sensitivity', 3, int, 1, 100)
    txt(r, 'px')
    r = line(s)
    txt(r, '확정 방식')
    rev = {v2: k2 for k2, v2 in T.CONFIRM_LABELS.items()}
    Drop(r, list(T.CONFIRM_LABELS.values()), T.CONFIRM_LABELS.get(c.get('confirm', 'enter')),
         lambda vv: (c.__setitem__('confirm', rev[vv]), ctl.save()), width=18).pack(side='left', padx=6)
    check(s, 'fast_compare', '빠른 비교', sub='(같은 가격이면 애니메이션 끝까지 안 기다림)')

    s = sec('감독모드와 같이 쓰기')
    check(s, 'auto_market', '감독모드 중이면 예약 시각에 이적시장 자동으로 열기 · 끝나면 닫기')
    check(s, 'close_each_min', '경기 중엔 매 분 갱신이 끝나면 이적시장 닫기', sub='(감독모드가 빨리 돌게)')
    r = line(s)
    txt(r, '다음 분 0초')
    num(r, 'reopen_sec', 3, float, 1, 15)
    txt(r, '초 전에 다시 열기')
    check(s, 'share_screen', '교체 등 감독모드가 화면이 필요한 분은 비켜 주기', sub='(B)')
    tl = tk.Canvas(s, height=PX(20), bg=G.CARD, highlightthickness=0)
    tl.pack(fill='x', pady=(4, 2))

    def draw_tl(e=None):
        tl.delete('all')
        W = max(200, tl.winfo_width())
        a = int(W * max(1, (c.get('end_sec', 20) - c.get('start_sec', 0)) % 60) / 60)
        b = min(int(W * (60 - float(c.get('reopen_sec', 3))) / 60), W - PX(74))
        for x0, x1, bg, fg, t in ((0, a, '#1f3a2e', G.GREEN, '0~20초 갱신'), (a, b, '#1e3550', '#8cc4ff', '닫고 → 감독모드 진행'),
                                  (b, W, '#3a3020', G.YEL, '%g초 전 열기' % float(c.get('reopen_sec', 3)))):
            tl.create_rectangle(x0, 0, x1, PX(20), fill=bg, outline=bg)
            tl.create_text((x0 + x1) / 2, PX(10), text=t, fill=fg, font=F(8, True))
    tl.bind('<Configure>', draw_tl)
    r = line(s)
    txt(r, '★ 최우선 로비 대기 여유')
    num(r, 'star_margin_sec', 4, int, 0, 600)
    txt(r, '초 (경기 평균 시간 + 이만큼 안에 시작하면 로비에서 기다림)', True)

    s = sec('텔레그램 (갱신싸움꾼 봇)')
    r = line(s)
    txt(r, '토큰')
    tv = tk.StringVar(value=c.get('tg_token', ''))
    keep.append(tv)
    tv.trace_add('write', lambda *_a: (c.__setitem__('tg_token', T.tg_clean_token(tv.get())), ctl.save()))
    entry(r, tv, 22, 'left', show='•').pack(side='left', padx=3)
    txt(r, '채팅')
    cvv = tk.StringVar(value=str(c.get('tg_chat', '')))
    keep.append(cvv)
    cvv.trace_add('write', lambda *_a: (c.__setitem__('tg_chat', cvv.get().strip()), ctl.save()))
    entry(r, cvv, 12, 'left').pack(side='left', padx=3)
    r = line(s)

    def tgf():
        try:
            ctl.tg_find()
        except ValueError as ex:
            _msg('warn', '텔레그램', str(ex), w)

    def tgt():
        try:
            ctl.tg_test()
        except ValueError as ex:
            _msg('warn', '텔레그램', str(ex), w)
    button(r, '채팅 ID 찾기', tgf, size=8, padx=8, pady=1).pack(side='left', padx=(0, 4))
    button(r, '테스트', tgt, size=8, padx=8, pady=1).pack(side='left')
    w_tg = L(s, '', 8, G.DIM, anchor='w', justify='left', wraplength=PX(480))
    w_tg.pack(fill='x')
    check(s, 'tg_menu', '메뉴로 원격 조작', sub='(상태·가격 확인·선수 켜기/끄기·시작/정지)')
    check(s, 'tg_daily', '밤 12시 하루 요약')
    check(s, 'tg_ready', '준비 끝 알림', sub='(기준가 사진 · 시간 · 우선순위)')
    check(s, 'end_report', '20분 끝 결과 알림', sub="(못 바꿨으면 창 캡처 + '이번엔 갱신되지 않았어요')")
    r = line(s)
    txt(r, '디스코드 웹훅')
    dv = tk.StringVar(value=c.get('discord_webhook', ''))
    keep.append(dv)
    dv.trace_add('write', lambda *_a: (c.__setitem__('discord_webhook', dv.get().strip()), ctl.save()))
    entry(r, dv, 30, 'left').pack(side='left', padx=3)

    s = sec('예전 갱신 매크로')
    r = line(s)
    txt(r, '예전 갱신 매크로를 쓰던 PC라면 설정 · 위치 · 기록을 한 번에')

    def imp():
        try:
            d = w.tk.call('tk_chooseDirectory', '-parent', str(w), '-title', '예전 갱신 매크로 폴더 (TransferMacro.exe 가 있는 폴더)')
        except tk.TclError:
            d = ''
        if not d:
            return
        try:
            m = ctl.import_settings(str(d))
        except ValueError as ex:
            _msg('warn', '가져오기', str(ex), w)
            return
        _msg('info', '가져오기', m + '\n\n프리셋 창을 열면 바로 보여요.', w)
    button(r, '기존 설정 가져오기…', imp, fg=G.CYAN, size=8, padx=8, pady=2).pack(side='right')
    L(body, '', bg=G.BG).pack(pady=2)
    rk = [None]

    def tick():
        if not w.winfo_exists():
            return
        if rk[0] != ctl.rev:
            rk[0] = ctl.rev
            t, kc = ctl.time_label
            w_time.config(text=t, fg=KC.get(kc, G.DIM))
            t, kc = ctl.tg_label
            w_tg.config(text=t, fg=KC.get(kc, G.DIM))
            if abs(float(v_off.get() or 0) - float(c.get('clock_offset', 0))) > 0.001 if v_off.get().replace('.', '', 1).lstrip('-+').isdigit() else False:
                v_off.set('%.2f' % float(c.get('clock_offset', 0)))
            draw_tl()
        w.after(400, tick)
    w.protocol('WM_DELETE_WINDOW', lambda: (ctl.save(), w.destroy(), _wins.pop('settings', None)))
    tick()


# ── 갱신 결과 창 ───────────────────────────────────
def open_results(ctl):
    if _single('results'):
        return
    w = dark_top('갱신 결과', 'tr_results', '800x660', (600, 440))
    _wins['results'] = w
    hd = tk.Frame(w, bg=G.BG, padx=16, pady=10)
    hd.pack(fill='x')
    L(hd, '◆ 갱신 결과', 12, G.FG, True, bg=G.BG).pack(side='left')
    w_sum = L(hd, '', 9, G.DIM, bg=G.BG)
    w_sum.pack(side='left', padx=10)
    tf = tk.Frame(w, bg=G.CARD, padx=8, pady=8)
    tf.pack(fill='x', padx=12)
    from tkinter import ttk
    cols = ('when', 'name', 'side', 'kind', 'queue', 'seen', 'enter')
    tv = ttk.Treeview(tf, columns=cols, show='headings', height=8, selectmode='browse', style='M.Treeview')
    for col, head, wd in (('when', '시각', 100), ('name', '선수', 130), ('side', '구분', 86), ('kind', '결과', 90),
                          ('queue', '예상 순번', 80), ('seen', '바뀐 시각', 90), ('enter', '감지→Enter', 84)):
        tv.heading(col, text=head)
        tv.column(col, width=PX(wd), anchor='w', stretch=col == 'name')
    sb = ttk.Scrollbar(tf, command=tv.yview, style='M.Vertical.TScrollbar')
    tv.configure(yscrollcommand=sb.set)
    sb.pack(side='right', fill='y')
    tv.pack(side='left', fill='x', expand=True)
    for tag, col in (('success', G.GREEN), ('nochange', G.DIM), ('missed', G.YEL), ('limited', G.RED), ('error', G.RED)):
        tv.tag_configure(tag, foreground=col)
    info = tk.Frame(w, bg=G.BG, padx=14, pady=6)
    info.pack(fill='x')
    w_info = L(info, '위에서 줄을 고르면 그때 캡처한 창이 보여요', 9, G.DIM, bg=G.BG, justify='left', anchor='w')
    w_info.pack(side='left', fill='x', expand=True)
    bb = tk.Frame(info, bg=G.BG)
    bb.pack(side='right')
    img = tk.Label(w, bg=G.CARD, text='', fg=G.DIM, font=F(9))
    img.pack(fill='both', expand=True, padx=12, pady=(0, 12))
    st = {'rows': {}, 'photo': None}

    def openfile():
        sel = tv.selection()
        e = st['rows'].get(sel[0]) if sel else None
        if e and e.get('img') and os.path.exists(e['img']):
            try:
                os.startfile(e['img'])
            except Exception:
                pass
    button(bb, '크게 열기', openfile, size=8, padx=8, pady=1).pack(side='left', padx=(0, 4))
    button(bb, 'captures 폴더', lambda: os.path.isdir(T.CAP_DIR) and os.startfile(T.CAP_DIR), size=8, padx=8, pady=1).pack(side='left')

    def fill():
        tv.delete(*tv.get_children())
        st['rows'] = {}
        for e in ctl.history():
            iid = e['id']
            st['rows'][iid] = e
            tv.insert('', 'end', iid=iid, tags=(e['kind'],), values=(
                '%s %s' % (e.get('day', '')[5:], e.get('hm', '')[:5]), e.get('name', ''),
                ('%s %s' % (T.SIDE.get(e.get('side'), ''), T.TARGET.get(e.get('target'), ''))).strip(),
                G.clean(T.HIST_KIND[e['kind']]), e.get('queue') or '', e.get('seen') or '',
                '%.2f초' % (e['enter_ms'] / 1000) if e.get('enter_ms') is not None else ''))
        tc = ctl.today_counts()
        w_sum.config(text=('오늘 ' + ' · '.join('%s %d' % (G.clean(T.HIST_KIND[k]), n) for k, n in tc)) if tc else '오늘 기록 없음')
        kids = tv.get_children()
        if kids and not tv.selection():
            tv.selection_set(kids[0])

    def show(_e=None):
        sel = tv.selection()
        e = st['rows'].get(sel[0]) if sel else None
        if not e:
            return
        lines = ['%s %s · %s · %s' % (e.get('day'), e.get('hm'), e.get('name'), G.clean(T.HIST_KIND[e['kind']]))]
        for k, lab in (('queue', '예상 순번'), ('price', '등록가'), ('seen_full', '가격대 바뀐 걸 본 시각'), ('note', '메모'), ('attempts', '시도')):
            if e.get(k):
                lines.append('%s: %s' % (lab, e[k]))
        w_info.config(text='\n'.join(lines), fg=G.FG)
        p = e.get('img')
        if p and os.path.exists(p):
            try:
                from PIL import Image, ImageTk
                im = Image.open(p)
                kk = min(1.0, PX(760) / im.width, PX(380) / im.height)
                if kk < 1:
                    im = im.resize((int(im.width * kk), int(im.height * kk)))
                st['photo'] = ImageTk.PhotoImage(im)
                img.config(image=st['photo'], text='')
                return
            except Exception:
                pass
        st['photo'] = None
        img.config(image='', text='(캡처 없음)')
    tv.bind('<<TreeviewSelect>>', show)
    tv.bind('<Double-1>', lambda e: openfile())
    rk = [None]

    def tick():
        if not w.winfo_exists():
            return
        if rk[0] != ctl.hist_rev:
            rk[0] = ctl.hist_rev
            fill()
            show()
        w.after(800, tick)
    w.protocol('WM_DELETE_WINDOW', lambda: (w.destroy(), _wins.pop('results', None)))
    tick()


def show_result(ctl, title, crop, path):
    """갱신 직후 구매 창 캡처 (예상 순번 확인용)"""
    try:
        from PIL import Image, ImageTk
        import numpy as np
        im = Image.fromarray(np.clip(crop, 0, 255).astype(np.uint8)[:, :, ::-1])
        kk = min(1.0, PX(760) / im.width, PX(540) / im.height)
        if kk < 1:
            im = im.resize((int(im.width * kk), int(im.height * kk)))
    except Exception:
        return
    old = _wins.get('result')
    if old is not None:
        try:
            old.destroy()
        except tk.TclError:
            pass
    w = dark_top('갱신 결과 — %s' % G.clean(title))
    w.attributes('-topmost', True)
    _wins['result'] = w
    ph = ImageTk.PhotoImage(im)
    lb = tk.Label(w, image=ph, bg=G.BG)
    lb.image = ph
    lb.pack(padx=10, pady=(10, 4))
    info = L(w, ctl.res_info, 11, G.CYAN, True, bg=G.BG)
    info.pack(padx=10, pady=(0, 4))
    L(w, '저장: %s' % path, 8, G.DIM, bg=G.BG).pack(padx=10, pady=(0, 6))
    button(w, '닫기', w.destroy).pack(pady=(0, 10))

    def tick():
        if not w.winfo_exists():
            return
        if info.cget('text') != ctl.res_info:
            info.config(text=ctl.res_info)
        w.after(500, tick)
    tick()
