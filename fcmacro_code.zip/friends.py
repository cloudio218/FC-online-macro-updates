# -*- coding: utf-8 -*-
"""v3.7 친구 랭킹: 같은 그룹 코드로 매크로를 쓰는 친구들의 점수·순위를 구글 시트(앱스 스크립트 웹 앱)에 모아 서로 봄.

- 매크로를 쓰면 자동 참여 (처음 켤 때 표시 이름 한 번 입력, 비우면 PC 이름)
- 올림: 판마다(VS 화면에서 점수를 읽을 때) 기록 + 1~2분마다 '경기 중/멈춤' 상태
- 받음: 매크로 창 [친구 랭킹] 팝업 (30초마다), 텔레그램 /랭킹
- 인터넷이 안 되거나 주소가 비어 있으면 조용히 건너뜀 (매크로 진행에는 영향 없음)
추가 설치 없음 (파이썬 기본 urllib)
"""
import hashlib
import json
import os
import socket
import threading
import time
import urllib.parse
import urllib.request
import uuid

# 앱스 스크립트 웹 앱 주소 (배포 후 넣음). 비어 있으면 기능 꺼짐
URL = 'https://script.google.com/macros/s/AKfycbwfC4Tnz_8xjPtEQsH37t4yL7q5EyHLBnut1-0sJMLeNFYVeyNCIau-LAaNCvwjM2wc/exec'
URL = os.environ.get('FCMACRO_FRIENDS_URL', URL)          # 시험용 가짜 서버
DEFAULT_GROUP = '쌀먹특공대'
OLD_GROUPS = ('154f590212ab65d6',)   # v3.13: 예전 그룹 이름(섞은 값) -> 새 이름 (서버도 같이 옮김)
UA = 'FCMacroFriends/1.0'
HEARTBEAT_SEC = 90
FRESH_SEC = 5 * 60          # 이 시간 안에 신호가 있으면 '진행 중'으로 봄

_STATE_TEXT = {'run': '진행 중', 'pause': '일시정지', 'rest': '쉬는 중', 'idle': '멈춤', 'off': '꺼짐'}


def state_text(st):
    return _STATE_TEXT.get(st or '', st or '-')


def ago_text(sec):
    sec = max(0, int(sec))
    if sec < 90:
        return '방금'
    if sec < 3600:
        return '%d분 전' % (sec // 60)
    if sec < 86400:
        return '%d시간 전' % (sec // 3600)
    return '%d일 전' % (sec // 86400)


class Friends:
    def __init__(self, data_dir, log=None, url=None):
        self.fill_fn = None
        self.path = os.path.join(data_dir, 'friends.json')
        self.log = log or (lambda m: None)
        self.url = (url if url is not None else URL).strip()
        self.s = {'id': '', 'name': '', 'group': DEFAULT_GROUP, 'asked': False}
        try:
            with open(self.path, encoding='utf-8') as fp:
                self.s.update(json.load(fp))
        except (OSError, ValueError):
            pass
        if not self.s.get('id'):
            self.s['id'] = uuid.uuid4().hex[:16]
            self.save()
        if hashlib.sha256(str(self.s.get('group') or '').encode('utf-8')).hexdigest()[:16] in OLD_GROUPS:
            self.s['group'] = DEFAULT_GROUP
            self.save()
        self.auth_fn = None         # v3.13 등록제: () -> {'mid', 'key'} / None(승인 전 - 보내지도 받지도 않음)
        self._q = []
        self._qlock = threading.Lock()
        self._ev = threading.Event()
        self._cache = {}            # days -> (시각, 결과)
        self._last_beat = 0.0
        self._last_err = ''
        self.last_ok = 0.0
        self._t = None

    # ── 설정 ─────────────────────────
    def save(self):
        try:
            tmp = self.path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as fp:
                json.dump(self.s, fp, ensure_ascii=False)
            os.replace(tmp, self.path)
        except OSError:
            pass

    @property
    def enabled(self):
        return bool(self.url)

    @property
    def group(self):
        return (self.s.get('group') or DEFAULT_GROUP).strip()

    @property
    def name(self):
        return (self.s.get('name') or '').strip() or pc_name()

    def set_name(self, name):
        self.s['name'] = (name or '').strip()[:16]
        self.s['asked'] = True
        self.save()
        self._cache.clear()

    def set_group(self, g):
        g = (g or '').strip()[:30]
        self.s['group'] = g or DEFAULT_GROUP
        self.save()
        self._cache.clear()

    def need_name(self):
        return self.enabled and not self.s.get('asked')

    # ── 보내기 (따로 스레드, 실패해도 조용히) ─────────
    def start(self):
        if self._t is None and self.enabled:
            self._t = threading.Thread(target=self._run, name='friends', daemon=True)
            self._t.start()

    def push(self, info, hist=False):
        """info: score, rank, tier, games, w, dr, l, delta, state, ver, game / hist=True면 판 기록도 한 줄"""
        if not self.enabled:
            return
        d = dict(info)
        d.update(group=self.group, id=self.s['id'], name=self.name, hist=bool(hist))
        with self._qlock:
            if not hist:                            # 상태만 보내는 건 마지막 것만 남김
                self._q = [x for x in self._q if x.get('hist')]
            self._q.append(d)
            if len(self._q) > 50:
                self._q = self._q[-50:]
        self._ev.set()
        self.start()

    def beat_due(self):
        return self.enabled and time.time() - self._last_beat >= HEARTBEAT_SEC

    def beat(self, info):
        self._last_beat = time.time()
        self.push(info, False)

    def _run(self):
        while True:
            self._ev.wait(30)
            self._ev.clear()
            while True:
                with self._qlock:
                    if not self._q:
                        break
                    d = self._q[0]
                ok = self._post(d)
                with self._qlock:
                    if ok and self._q and self._q[0] is d:
                        self._q.pop(0)
                if not ok:
                    time.sleep(20)
                    break

    def _auth(self):
        if self.auth_fn is None:
            return {}
        try:
            return self.auth_fn()
        except Exception:                          # noqa: BLE001
            return None

    def _post(self, d):
        a = self._auth()
        if a is None:
            return True                            # 승인 전: 보내지 않고 버림
        d = dict(d, **a)
        try:
            data = json.dumps(d, ensure_ascii=False).encode('utf-8')
            req = urllib.request.Request(self.url, data=data, method='POST',
                                         headers={'Content-Type': 'text/plain; charset=utf-8', 'User-Agent': UA})
            with urllib.request.urlopen(req, timeout=20) as r:
                body = r.read().decode('utf-8', 'replace')
            ok = '"ok":true' in body.replace(' ', '')
            if ok:
                self.last_ok = time.time()
                self._cache.pop(0, None)
            elif self._last_err != body[:80]:
                self._last_err = body[:80]
                self.log('친구 랭킹 보내기 실패: %s' % body[:80])
            return ok or '"ok":false' in body.replace(' ', '')     # 서버가 거절한 건 다시 안 보냄
        except Exception as e:                                       # noqa: BLE001 - 네트워크는 무엇이든 실패 가능
            msg = '%s' % e
            if self._last_err != msg:
                self._last_err = msg
                self.log('친구 랭킹 보내기 실패 (다시 시도): %s' % msg[:80])
            return False

    def backfill(self, rows, info, chunk=400):
        """v3.7.1: 지난 기록(이 PC의 ranking_log.csv 최근 30일)을 처음 한 번 올림. rows = [[t(ms), score, rank, res, champ]]
        서버가 새 버전이어야 함 (응답에 added). 옛 서버면 다음에 다시 시도 (그동안 info로 최신 상태만 갱신)"""
        if not self.enabled or self.s.get('backfilled'):
            return None
        total = 0
        for i in range(0, len(rows), chunk):
            a = self._auth()
            if a is None:
                return None
            d = dict(info, **a)
            d.update(group=self.group, id=self.s['id'], name=self.name, hist=False, bulk=rows[i:i + chunk])
            try:
                data = json.dumps(d, ensure_ascii=False).encode('utf-8')
                req = urllib.request.Request(self.url, data=data, method='POST',
                                             headers={'Content-Type': 'text/plain; charset=utf-8', 'User-Agent': UA})
                with urllib.request.urlopen(req, timeout=60) as r:
                    res = json.loads(r.read().decode('utf-8', 'replace'))
            except Exception as e:                                       # noqa: BLE001
                self.log('친구 랭킹 지난 기록 올리기 실패 (다음에 다시): %s' % ('%s' % e)[:80])
                return None
            if not res.get('ok') or 'added' not in res:
                self.log('친구 랭킹 서버가 지난 기록 올리기를 아직 지원하지 않음 (서버 스크립트 새 버전 필요)')
                return None
            total += int(res.get('added') or 0)
        self.s['backfilled'] = True
        self.save()
        self._cache.clear()
        return total

    # ── 받기 ─────────────────────────
    def fetch(self, days=0, max_age=25):
        """{'ok', 'now', 'players': [...], 'hist': {id: [[t, score, rank, res], ...]}, 'err'} - 캐시 max_age초"""
        if not self.enabled:
            return {'ok': False, 'err': '아직 친구 랭킹 서버가 연결되지 않았어요', 'players': [], 'hist': {}}
        c = self._cache.get(days)
        if c and time.time() - c[0] < max_age:
            return c[1]
        a = self._auth()
        if a is None:
            return {'ok': False, 'err': '등록 승인 후 볼 수 있어요', 'players': [], 'hist': {}}
        try:
            # v3.13: 열쇠를 주소에 넣지 않도록 POST (서버는 승인된 PC에만 답함)
            d = dict(a, op='get', group=self.group, id=self.s['id'], days=days, r=int(time.time()))
            req = urllib.request.Request(self.url, data=json.dumps(d, ensure_ascii=False).encode('utf-8'), method='POST',
                                         headers={'Content-Type': 'text/plain; charset=utf-8', 'User-Agent': UA})
            with urllib.request.urlopen(req, timeout=45 if days else 20) as r:      # v4.0.2: 기간 기록은 넉넉히
                res = json.loads(r.read().decode('utf-8', 'replace'))
            if not res.get('ok'):
                return {'ok': False, 'err': {'not registered': '등록 승인 후 볼 수 있어요'}.get(res.get('err'), res.get('err') or '서버 응답 이상'), 'players': [], 'hist': {}}
            res.setdefault('players', [])
            res.setdefault('hist', {})
            if self.fill_fn is not None:               # v3.10.1: 내 점 중 점수 빈 것(v3.9.1 이전 강등 구간)을 이 PC 기록으로 채움
                try:
                    self.fill_fn(res)
                except Exception:                      # noqa: BLE001
                    pass
            self._cache[days] = (time.time(), res)
            return res
        except Exception as e:                                       # noqa: BLE001
            if c:
                return c[1]
            return {'ok': False, 'err': '불러오기 실패: %s' % ('%s' % e)[:60], 'players': [], 'hist': {}}

    def table(self, res=None):
        """점수 높은 순 [(등수, player dict, 나?, 진행중?, 갱신 몇 초 전)]"""
        res = res or self.fetch(0)
        now = (res.get('now') or time.time() * 1000) / 1000.0
        hist = res.get('hist') or {}
        for p in res.get('players', []):              # v3.12: 점수가 비어 있으면(예전 버전이 챔스 밖에서 안 보냄) 기록의 마지막 점수
            if p.get('score') is None:
                last = [q[1] for q in hist.get(p.get('id')) or [] if len(q) > 1 and q[1] not in (None, '')]
                p['score_fb'] = last[-1] if last else None
        ps = list(res.get('players', []))
        ps.sort(key=lambda p: -(p.get('score') if p.get('score') is not None else (p.get('score_fb') or -1)))
        out = []
        for i, p in enumerate(ps):
            age = now - (p.get('ts') or 0) / 1000.0
            live = p.get('state') == 'run' and age < FRESH_SEC
            out.append((i + 1, p, p.get('id') == self.s['id'], live, age))
        return out

    def text_lines(self):
        """텔레그램 /랭킹 용 줄들"""
        res = self.fetch(0)
        if not res.get('ok'):
            return [res.get('err') or '불러오기 실패']
        rows = self.table(res)
        if not rows:
            return ['아직 아무도 기록이 없어요 (그룹: %s)' % self.group]
        lines = ['```']
        crown = crown_id(res.get('players', []))
        for n, p, me, live, age in rows:
            sc = '{:,}'.format(p['score']) if p.get('score') is not None else ('{:,}'.format(p['score_fb']) if p.get('score_fb') else '-')
            rk = ('{:,}위'.format(p['rank'])) if p.get('rank') else '-'
            dl = p.get('delta')
            dl = ('%+d' % dl) if isinstance(dl, (int, float)) else ''
            st = '● 진행' if live else ago_text(age)
            fl = flow_text(p.get('streak'))
            lines.append('%d. %s%s%s' % (n, '👑 ' if p.get('id') == crown else '', p.get('name') or '?', ' (나)' if me else ''))
            lines.append('   %s점 · %s · 오늘 %s판 %s승 %s%s · %s' % (sc, rk, p.get('games', 0), p.get('w', 0), dl,
                                                          (' · 🔥' + fl) if (p.get('streak') or 0) >= 3 else (' · ' + fl if fl else ''), st))
        lines.append('```')
        lines.append('그룹: %s · 매크로 창 [♛ 친구 랭킹]에서 그래프' % self.group)
        return lines


def pc_name():
    try:
        return (os.environ.get('COMPUTERNAME') or socket.gethostname() or '이름 없음')[:16]
    except Exception:                                                # noqa: BLE001
        return '이름 없음'


# ── 차트·알림용 계산 (창 없이 시험 가능) ─────────────────
def points_of(rows):
    """서버 hist 줄 [[t(ms), score|None, rank|None, res, champ], ...] -> [(t초, score, rank, res, champ)] 시간순"""
    out = []
    for r in rows or []:
        try:
            out.append((float(r[0]) / 1000.0, r[1] if r[1] not in ('', None) else None,
                        r[2] if len(r) > 2 and r[2] not in ('', None) else None,
                        (r[3] if len(r) > 3 else '') or '', bool(r[4]) if len(r) > 4 else (r[1] not in ('', None))))
        except (TypeError, ValueError, IndexError):
            continue
    out.sort(key=lambda p: p[0])
    return out


def fire_marks(pts, need=3):
    """연승한 판 위치 (같은 줄에 이긴 판이 need판 이상 이어진 구간의 모든 판) -> set(인덱스)"""
    out, run = set(), []
    for i, p in enumerate(pts):
        if p[3] == '승':
            run.append(i)
        else:
            if len(run) >= need:
                out.update(run)
            run = []
    if len(run) >= need:
        out.update(run)
    return out


def fire_marks_key(pts, need=3):
    """v3.7: 불꽃은 기간 중 최다 연승 구간 + 지금 이어지는 연승만 (나머지 연승은 선만) -> set(인덱스)"""
    runs, run = [], []
    for i, p in enumerate(pts):
        if p[3] == '승':
            run.append(i)
        else:
            if run:
                runs.append(run)
            run = []
    live = run if len(run) >= need else []
    if run:
        runs.append(run)
    runs = [r for r in runs if len(r) >= need]
    out = set(live)
    if runs:
        best = max(runs, key=lambda r: (len(r), r[-1]))        # 같으면 나중 것
        out.update(best)
    return out


def best_streak(results):
    best = cur = 0
    for r in results:
        cur = cur + 1 if r == '승' else 0
        best = max(best, cur)
    return best


def flow_text(streak):
    """현재 흐름: +n = n연승, -n = n연패"""
    try:
        n = int(streak or 0)
    except (TypeError, ValueError):
        return ''
    if n >= 2:
        return '%d연승' % n
    if n <= -2:
        return '%d연패' % -n
    return ''


def crown_id(players):
    """오늘 점수를 가장 많이 올린 사람 (0점 이하면 없음)"""
    best = None
    for p in players:
        d = p.get('delta')
        if isinstance(d, (int, float)) and d > 0 and (best is None or d > best[0]):
            best = (d, p.get('id'))
    return best[1] if best else None


def watch_alerts(prev, cur, my_id, hist=None):
    """이전/지금 latest 비교 -> [(종류, 제목, 줄들)] : 추월(나와 관련된 것만), 친구 강등·복귀"""
    out = []
    if not prev:
        return out
    pm = {p.get('id'): p for p in prev}
    cm = {p.get('id'): p for p in cur}
    me0, me1 = pm.get(my_id), cm.get(my_id)
    if me0 and me1 and me0.get('score') is not None and me1.get('score') is not None:
        for fid, f1 in cm.items():
            f0 = pm.get(fid)
            if fid == my_id or not f0 or f0.get('score') is None or f1.get('score') is None:
                continue
            if not (me1.get('champ') and f1.get('champ')):
                continue
            a0, a1 = me0['score'] - f0['score'], me1['score'] - f1['score']
            if a0 < 0 <= a1 and a1 > 0:
                out.append(('overtake', '⚔️ 추월! %s님이 %s님을 앞질렀어요' % (me1.get('name'), f1.get('name')),
                            ['%s %s · %s %s (차이 %d점)' % (me1.get('name'), '{:,}'.format(me1['score']),
                                                         f1.get('name'), '{:,}'.format(f1['score']), a1)]))
            elif a0 > 0 >= a1 and a1 < 0:
                out.append(('overtaken', '⚔️ 추월! %s님이 %s님을 앞질렀어요' % (f1.get('name'), me1.get('name')),
                            ['%s %s · %s %s (차이 %d점)' % (f1.get('name'), '{:,}'.format(f1['score']),
                                                         me1.get('name'), '{:,}'.format(me1['score']), -a1)]))
    for fid, f1 in cm.items():
        f0 = pm.get(fid)
        if fid == my_id or not f0 or 'champ' not in f0 or 'champ' not in f1:
            continue
        nm = f1.get('name') or '?'
        if f0.get('champ') and not f1.get('champ'):
            out.append(('demote', '⬇️ %s님 챔스 강등… 힘내요 💪' % nm,
                        ['%s점 · 오늘 %s판 %s승' % ('{:,}'.format(f0['score']) if f0.get('score') is not None else '-',
                                                 f1.get('games', 0), f1.get('w', 0))]))
        elif not f0.get('champ') and f1.get('champ'):
            line = ''
            pts = points_of((hist or {}).get(fid))
            k = len(pts) - 1                      # 마지막(복귀한 판) 앞에서부터 챔스 밖 판을 셈
            while k > 0 and pts[k - 1][3] in ('휴', '멈'):
                k -= 1
            j = k
            while j > 0 and not pts[j - 1][4]:
                j -= 1
            low = [p[3] for p in pts[j:k + 1] if p[3] in ('승', '무', '패')] if pts else []
            if low:
                line = '강등 후 %d판 만 (%d승 %d패)' % (len(low), low.count('승'), low.count('패'))
            out.append(('promote', '⬆️ %s님 챔스 복귀! 🎉' % nm, [line] if line else []))
    return out


def day_summary(players, hist, day_start, day_end, label):
    """하루 결산 (텔레그램 00시) -> (제목, 줄들) / None"""
    rows = []
    for p in players:
        pts = [x for x in points_of(hist.get(p.get('id'))) if day_start <= x[0] < day_end]
        res = [x[3] for x in pts if x[3] in ('승', '무', '패')]
        sc = [x[1] for x in pts if x[1] is not None]
        if not res and not sc:
            continue
        rows.append({'name': p.get('name') or '?', 'games': len(res), 'w': res.count('승'),
                     'delta': (sc[-1] - sc[0]) if len(sc) >= 2 else 0, 'streak': best_streak(res),
                     'score': p.get('score')})
    if not rows:
        return None
    lines = []
    top = max(rows, key=lambda r: r['delta'])
    if top['delta'] > 0:
        lines.append('👑 오늘의 왕관: %s %+d점' % (top['name'], top['delta']))
    st = max(rows, key=lambda r: r['streak'])
    if st['streak'] >= 2:
        lines.append('🔥 최다 연승: %s %d연승' % (st['name'], st['streak']))
    mg = max(rows, key=lambda r: r['games'])
    lines.append('🎮 가장 많이 돌림: %s %d판' % (mg['name'], mg['games']))
    wr = [r for r in rows if r['games'] >= 10]
    if wr:
        b = max(wr, key=lambda r: r['w'] / r['games'])
        lines.append('📈 승률 1등: %s %d%% (%d판)' % (b['name'], round(b['w'] * 100 / b['games']), b['games']))
    order = sorted([p for p in players if p.get('score') is not None], key=lambda p: -p['score'])
    if order:
        lines.append('')
        lines.append(' · '.join('%d. %s %s' % (i + 1, p.get('name'), '{:,}'.format(p['score'])) for i, p in enumerate(order)))
    return '🌙 %s 오늘의 결산' % label, lines
