# -*- coding: utf-8 -*-
"""
디스코드 봇 원격 조작: 웹훅 알림이 오는 채널에 '!상태' 같은 명령을 치면 매크로가 답함.
 - 추가 설치 없음 (파이썬 기본 urllib). 몇 초마다 채널의 새 메시지를 확인하는 방식(폴링)
 - 채널은 웹훅 주소에서 자동으로 알아냄 -> 설정은 봇 토큰 하나
 - 처음 '!등록'을 친 사람만 명령 가능 (같은 채널을 친구와 같이 써도 남이 내 매크로를 조작 못 함)
"""
import json
import os
import re
import threading
import time
import urllib.error
import urllib.request

import notify

API = os.environ.get('FCMACRO_DISCORD_API', 'https://discord.com/api/v10')   # 테스트 때만 바꿈
USER_AGENT = 'DiscordBot (https://discord.com, 1.7)'
POLL_SEC = 4


class Bot:
    def __init__(self, token, webhook_url, owner_id, handlers, on_owner=None, log=None):
        """
        handlers: {'상태': fn(args) -> dict(title, lines, kind, image_fn, image_name)}  (명령 이름은 '!' 없이)
        on_owner(user_id, name): '!등록' 으로 주인이 정해졌을 때 (설정 저장용)
        """
        self.token = (token or '').strip()
        self.webhook_url = (webhook_url or '').strip()
        self.owner_id = str(owner_id) if owner_id else None
        self.handlers = handlers
        self.on_owner = on_owner
        self.log = log
        self.channel_id = None
        self.last_id = None
        self.status = '연결 준비 중'
        self.ok = None
        self._stop = threading.Event()
        self._thread = None

    # ── HTTP ─────────────────────────────────────
    def _req(self, method, path, body=None, raw=None, ctype=None, auth=True, timeout=15):
        url = path if path.startswith('http') else API + path
        headers = {'User-Agent': USER_AGENT}
        if auth:
            headers['Authorization'] = 'Bot ' + self.token
        data = None
        if raw is not None:
            data, headers['Content-Type'] = raw, ctype
        elif body is not None:
            data, headers['Content-Type'] = json.dumps(body).encode('utf-8'), 'application/json'
        for _ in range(3):
            req = urllib.request.Request(url, data=data, method=method, headers=headers)
            try:
                with urllib.request.urlopen(req, timeout=timeout) as r:
                    txt = r.read().decode('utf-8') or 'null'
                    return json.loads(txt)
            except urllib.error.HTTPError as e:
                if e.code == 429:                      # 너무 자주 요청 -> 잠깐 쉬고 다시
                    try:
                        wait = float(json.loads(e.read().decode('utf-8')).get('retry_after', 2))
                    except Exception:
                        wait = 2.0
                    time.sleep(min(wait, 30))
                    continue
                raise
        raise RuntimeError('디스코드 요청 반복 제한')

    def _webhook_channel(self):
        """웹훅 주소 -> 그 웹훅이 연결된 채널 ID (토큰 없이 조회 가능)"""
        m = re.search(r'/webhooks/(\d+)/([\w-]+)', self.webhook_url)
        if not m:
            raise ValueError('웹훅 주소가 없어서 채널을 알 수 없음 (설정창에 웹훅 주소를 먼저 넣어 주세요)')
        info = self._req('GET', '/webhooks/%s/%s' % (m.group(1), m.group(2)), auth=False)
        return str(info['channel_id'])

    # ── 보내기 ────────────────────────────────────
    def reply(self, title, lines=(), kind='info', image=None, image_name='image.png', ref=None):
        payload = notify._payload(title, list(lines), kind, image_name if image else None)
        payload.pop('username', None)
        if ref:
            payload['message_reference'] = {'message_id': ref, 'fail_if_not_exists': False}
            payload['allowed_mentions'] = {'replied_user': False}
        path = '/channels/%s/messages' % self.channel_id
        if image:
            data, ctype = notify._multipart(payload, image, image_name)
            self._req('POST', path, raw=data, ctype=ctype)
        else:
            self._req('POST', path, body=payload)

    # ── 실행 ─────────────────────────────────────
    def start(self):
        if not self.token:
            self.status, self.ok = '꺼짐 (봇 토큰 없음)', None
            return False
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()
        return True

    def stop(self):
        self._stop.set()

    def _log(self, msg):
        if self.log:
            try:
                self.log(msg)
            except Exception:
                pass

    def _set(self, status, ok):
        if status != self.status:
            self._log('디스코드 봇: ' + status)
        self.status, self.ok = status, ok

    def _run(self):
        backoff = POLL_SEC
        while not self._stop.is_set():
            try:
                if self.channel_id is None:
                    self.channel_id = self._webhook_channel()
                    me = self._req('GET', '/users/@me')
                    msgs = self._req('GET', '/channels/%s/messages?limit=1' % self.channel_id)
                    self.last_id = msgs[0]['id'] if msgs else None    # 켜기 전 메시지는 무시
                    self._set('연결됨 (%s) · %s' % (me.get('username', '봇'),
                              '명령: !상태 !차트 !결산 !설정 !정지 !재개 !종료 !도움' if self.owner_id
                              else "디스코드에서 '!등록'을 치면 내 계정만 명령 가능"), True)
                self._poll()
                backoff = POLL_SEC
            except urllib.error.HTTPError as e:
                hint = {401: '봇 토큰이 틀림', 403: '봇이 이 채널을 볼 권한이 없음 (서버에 초대·채널 권한 확인)',
                        404: '웹훅/채널을 찾을 수 없음'}.get(e.code, '')
                self._set('오류 HTTP %s %s' % (e.code, hint), False)
                self.channel_id = None if e.code in (403, 404) else self.channel_id
                backoff = min(backoff * 2, 120)
            except Exception as e:
                self._set('연결 안 됨 (%s) - 다시 시도 중' % e, False)
                backoff = min(backoff * 2, 120)
            self._stop.wait(backoff)

    def _poll(self):
        path = '/channels/%s/messages?limit=20' % self.channel_id
        if self.last_id:
            path += '&after=%s' % self.last_id
        msgs = self._req('GET', path) or []
        for m in sorted(msgs, key=lambda x: int(x['id'])):     # 오래된 것부터
            self.last_id = m['id']
            author = m.get('author') or {}
            if author.get('bot'):
                continue
            text = (m.get('content') or '').strip()
            if not text.startswith('!'):
                continue
            self._handle(text, str(author.get('id')), author.get('global_name') or author.get('username') or '?', m['id'])

    def _handle(self, text, uid, name, mid):
        cmd, _, args = text[1:].partition(' ')
        cmd = cmd.strip()
        if cmd == '등록':
            if self.owner_id and self.owner_id != uid:
                self.reply('이미 다른 사람이 등록되어 있습니다', ['매크로 주인만 명령할 수 있어요.'], 'warn', ref=mid)
                return
            self.owner_id = uid
            if self.on_owner:
                self.on_owner(uid, name)
            self._log('디스코드 봇: 주인 등록 - %s (%s)' % (name, uid))
            self._set(re.sub(r' · .*$', '', self.status) + ' · 명령: !상태 !차트 !결산 !설정 !정지 !재개 !종료 !도움', True)
            self.reply('✅ %s 님을 매크로 주인으로 등록했습니다' % name,
                       ['이제 이 계정의 명령만 받습니다.', '명령: !상태 !차트 !결산 !설정 !정지 !재개 !종료 !도움'], 'done', ref=mid)
            return
        fn = self.handlers.get(cmd)
        if fn is None:
            if cmd in ('도움', 'help', '명령'):
                self.reply('명령 목록', ['!상태 - 지금 진행 상황 + 게임 화면', '!차트 - 최근 기록 그래프',
                                         '!결산 - 오늘 결산 (지금까지) · !결산 어제',
                                         '!설정 - 설정 보기/바꾸기 (!설정 도움)',
                                         '!정지 - 일시정지 (F10)', '!재개 - 다시 진행 (F10)', '!종료 - 자동진행 종료 (F12)',
                                         '!등록 - 내 계정만 명령 가능하게 (처음 한 번)'], 'info', ref=mid)
            return
        if not self.owner_id:
            self.reply("먼저 '!등록' 을 쳐 주세요", ['등록한 계정의 명령만 받습니다.'], 'warn', ref=mid)
            return
        if uid != self.owner_id:
            return                                       # 다른 사람 명령은 무시
        try:
            r = fn(args.strip()) or {}
            image = None
            if r.get('image_fn'):
                try:
                    image = r['image_fn']()
                except Exception:
                    image = None
            self.reply(r.get('title', '완료'), r.get('lines', ()), r.get('kind', 'info'), image,
                       r.get('image_name', 'image.png'), ref=mid)
            self._log('디스코드 명령 !%s 처리' % cmd)
        except Exception as e:
            self._log('디스코드 명령 !%s 오류: %s' % (cmd, e))
            try:
                self.reply('명령 처리 중 오류', [str(e)], 'stop', ref=mid)
            except Exception:
                pass
