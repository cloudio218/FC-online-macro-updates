# -*- coding: utf-8 -*-
"""v3.9 원터치 업데이트 (매크로 창 맨 위 버전 표시 / 텔레그램 [업데이트])

흐름
  1) 확인: GitHub version.json (켜고 10초 뒤 + 10분마다 + 버전 표시 누를 때)
  2) 받기: 매크로 안에서 zip을 먼저 받아 검증(SHA-256 · 안의 버전 · 파이썬 문법)
           -> 실패하면 지금 버전 그대로 계속 (다시 켜지 않음)
  3) 다시 켜기: 실행기(fifa_macro.exe)를 새로 띄우고 지금 것은 종료
           -> 실행기가 켜질 때 늘 하던 대로 새 버전을 설치 ([예]는 FCMACRO_AUTO_ANSWER 로 자동)
           -> 설치·되돌림(이전 버전 보관, 켜지다 오류 나면 자동 복귀)은 실행기의 검증된 방식 그대로
  4) 새로 켜진 쪽: resume 파일을 읽고 '업데이트됨/실패' 안내, 진행 중이었으면 이어서 진행
     (관리자 권한으로 다시 켜질 때 환경변수가 사라지므로 파일로 넘김)
"""
import hashlib
import io
import json
import os
import subprocess
import sys
import threading
import time
import urllib.request
import zipfile

FALLBACK_URL = 'https://raw.githubusercontent.com/cloudio218/FC-online-macro-updates/main/'
UA = 'FCMacroUpdater/2'
CHECK_EVERY = 10 * 60          # v3.9.3: 10분마다 확인 (예전 1시간)
RESUME_MAX_AGE = 15 * 60       # 다시 켜기 파일은 15분 안에 켜진 것만 이어받음


def vtuple(s):
    return tuple(int(x) for x in str(s).strip().lstrip('v').split()[0].split('.') if x.isdigit()) if s else ()


def vtext(t):
    return 'v' + '.'.join(map(str, t)) if t else '?'


def base_url(code_dir=None):
    """실행기와 같은 순서: 테스트 주소 -> exe 옆 -> 실행 중인 코드 -> exe 내장 코드 -> 기본 주소"""
    if os.environ.get('FCMACRO_UPDATE_URL'):
        u = os.environ['FCMACRO_UPDATE_URL']
        return u if u.endswith('/') else u + '/'
    dirs = []
    if getattr(sys, 'frozen', False):
        dirs.append(os.path.dirname(os.path.abspath(sys.executable)))
    if code_dir:
        dirs.append(code_dir)
    if getattr(sys, '_MEIPASS', None):
        dirs.append(os.path.join(sys._MEIPASS, 'code'))
    for d in dirs:
        try:
            with open(os.path.join(d, 'update_url.txt'), encoding='utf-8-sig') as f:
                for line in f:
                    u = line.strip()
                    if u.startswith('http'):
                        return u if u.endswith('/') else u + '/'
        except OSError:
            pass
    return FALLBACK_URL


def http_get(url, timeout=15, on_pct=None):
    req = urllib.request.Request(url, headers={'User-Agent': UA, 'Cache-Control': 'no-cache'})
    with urllib.request.urlopen(req, timeout=timeout) as r:
        total = int(r.headers.get('Content-Length') or 0)
        buf = io.BytesIO()
        while True:
            chunk = r.read(32768)
            if not chunk:
                break
            buf.write(chunk)
            if on_pct and total:
                on_pct(min(99, buf.tell() * 100 // total))
        return buf.getvalue()


PYI_VARS = ('_MEIPASS2', 'TCL_LIBRARY', 'TK_LIBRARY', 'TCLLIBPATH', 'PYTHONHOME', 'PYTHONPATH')


def clean_env(src):
    """v3.9.2: 새 실행기에 넘길 환경변수 - 지금 exe(PyInstaller)가 풀어 둔 임시 폴더 흔적을 지움
    (그대로 넘기면 새 exe가 '이미 풀어 둔 자식'으로 착각해 지금 임시 폴더를 쓰는데, 지금 것이 끝나면서 그 폴더가 지워져
     Tk(창) 파일이 없어짐 -> 매크로 창 대신 예전 글자 창으로 켜짐. 2026-11-25 실사용 제보)"""
    env = dict(src)
    mei = getattr(sys, '_MEIPASS', None)
    meil = os.path.normcase(os.path.abspath(mei)) if mei else None
    for k in list(env):
        ku = k.upper()
        if ku.startswith('_PYI_') or ku in PYI_VARS or ku in ('FCMACRO_SKIP_UPDATE', 'FCMACRO_UPDATE_MSG', 'FCMACRO_CODE_DIR', 'FCMACRO_GUI_RELAUNCHED'):
            env.pop(k, None)
        elif meil and ku == 'PATH':
            env[k] = os.pathsep.join(p for p in str(env[k]).split(os.pathsep)
                                     if p and not os.path.normcase(os.path.abspath(p)).startswith(meil))
        elif meil and meil in os.path.normcase(str(env[k])):
            env.pop(k, None)
    env['PYINSTALLER_RESET_ENVIRONMENT'] = '1'       # PyInstaller 6.9+ : 새 프로그램으로 처음부터 (그 전 버전은 무시)
    return env


def restart_cmd():
    """다시 띄울 명령 (exe면 실행기부터). 못 하면 None"""
    if os.environ.get('FCMACRO_RESTART_CMD'):
        return json.loads(os.environ['FCMACRO_RESTART_CMD'])
    if getattr(sys, 'frozen', False):
        return [sys.executable]
    return None


class Updater:
    """state: idle(아직 확인 전) / checking / latest / new / reserved(판 끝나면) / down(받는 중) / restart / error"""

    def __init__(self, cur_version, data_dir, code_dir=None, log=None):
        self.cur = vtuple(cur_version)
        self.data = data_dir
        self.app = os.path.join(data_dir, 'app')
        self.code_dir = code_dir
        self.log = log or (lambda m: None)
        self.lock = threading.Lock()
        self.state = 'idle'
        self.info = None            # version.json
        self.remote = ()
        self.pct = 0
        self.err = ''
        self.checked = 0.0
        self.reserved_by = ''
        self.resume_after = True     # 판 끝나고 업데이트한 뒤 이어서 진행
        self.need_exe = False
        self.bad = False
        self.zip = None              # 검증된 zip (다시 켜기 직전까지 보관)

    # ── 확인 ──
    def notes(self):
        n = (self.info or {}).get('notes', '')
        return n if isinstance(n, list) else [x for x in str(n).splitlines() if x.strip()]

    def has_new(self):
        return bool(self.remote) and bool(self.cur) and self.remote > self.cur and not self.need_exe and not self.bad

    def check(self):
        """-> True 새 버전 있음 / False 최신 / None 확인 실패"""
        with self.lock:
            busy = self.state in ('down', 'restart')
            if not busy:
                prev = self.state
                self.state = 'checking'
        if busy:
            return self.has_new()
        try:
            info = json.loads(http_get(base_url(self.code_dir) + 'version.json?t=%d' % time.time(), timeout=8)
                              .decode('utf-8-sig'))
            remote = vtuple(info['version'])
        except Exception as e:                                    # noqa: BLE001
            self.err = '업데이트 확인 실패 (인터넷 확인): %s' % e
            self.log(self.err)
            with self.lock:
                self.state = prev if prev in ('new', 'reserved') else 'error'
            return None
        self.info, self.remote, self.checked = info, remote, time.time()
        self.need_exe = int(info.get('min_launcher', 1) or 1) > 1 and remote > self.cur
        self.bad = False
        try:
            with open(os.path.join(self.app, 'bad_version.txt'), encoding='utf-8') as f:
                self.bad = vtuple(f.read()) == remote
        except OSError:
            pass
        with self.lock:
            if self.has_new():
                self.state = 'reserved' if prev == 'reserved' else 'new'
            elif self.need_exe:
                self.state = 'exe'
                self.reserved_by = ''
            else:
                self.state = 'latest'
                self.reserved_by = ''
        return self.has_new()

    # ── 판 끝나면 ──
    def reserve(self, by=''):
        with self.lock:
            if self.state == 'new':
                self.state = 'reserved'
                self.reserved_by = by
                return True
            return self.state == 'reserved'

    def cancel(self):
        with self.lock:
            if self.state == 'reserved':
                self.state = 'new'
                self.reserved_by = ''
                return True
        return False

    def reserved(self):
        return self.state == 'reserved'

    # ── 받기 + 검증 ──
    def download(self):
        """zip을 받아 검증. 성공하면 True (실패 이유는 self.err)"""
        if time.time() - self.checked > 30:
            self.check()      # 다음 버전: 확인 뒤에 또 새 버전이 올라왔으면 그걸로 (zip 이름이 같아서 예전 정보로 받으면 검증 실패)
        if not self.has_new():
            self.err = '받을 새 버전이 없어요'
            return False
        with self.lock:
            if self.state in ('down', 'restart'):
                self.err = '이미 업데이트 중이에요'
                return False
            self.state, self.pct = 'down', 0
        info = self.info
        try:
            def pct(p):
                self.pct = p
            data = http_get(base_url(self.code_dir) + info['zip'] + '?t=%d' % time.time(), timeout=60, on_pct=pct)
            if info.get('sha256') and hashlib.sha256(data).hexdigest().lower() != info['sha256'].lower():
                raise ValueError('받은 파일이 손상됨 (검증값 불일치)')
            with zipfile.ZipFile(io.BytesIO(data)) as z:
                names = z.namelist()
                prefix = 'code/' if any(n.startswith('code/') for n in names) else ''
                main = z.read(prefix + 'fifa_macro.py').decode('utf-8')
                import re
                m = re.search(r"^VERSION\s*=\s*'v?([\d.]+)", main, re.M)
                if not m or vtuple(m.group(1)) != self.remote:
                    raise ValueError('패키지 안의 버전이 version.json 과 다름')
                for n in names:
                    if n.endswith('.py'):
                        compile(z.read(n).decode('utf-8'), n, 'exec')
            self.zip = data
            self.pct = 100
            return True
        except Exception as e:                                    # noqa: BLE001
            self.err = '받기 실패: %s' % e
            self.log(self.err)
            with self.lock:
                self.state = 'new'
            return False

    # ── 다시 켜기 ──
    def can_restart(self):
        return restart_cmd() is not None

    def restart(self, resume=None, popen=None):
        """새 실행기를 띄움 -> True면 부르는 쪽이 곧바로 종료해야 함. resume: 새로 켜진 쪽에 넘길 것(dict)"""
        cmd = restart_cmd()
        if not cmd:
            self.err = '실행기(fifa_macro.exe)로 켠 경우에만 자동으로 업데이트할 수 있어요'
            return False
        r = dict(resume or {}, expect=vtext(self.remote), old=vtext(self.cur), t=time.time(), notes=self.notes()[:6])
        try:
            os.makedirs(self.app, exist_ok=True)
            with open(self.resume_path(), 'w', encoding='utf-8') as f:
                json.dump(r, f, ensure_ascii=False)
        except OSError as e:
            self.err = '다시 켜기 준비 실패: %s' % e
            return False
        env = clean_env(os.environ)
        env['FCMACRO_AUTO_ANSWER'] = 'y'           # 실행기의 '업데이트할까요?' -> 예
        with self.lock:
            self.state = 'restart'
        try:
            if popen is None:
                # v3.9.2: 새 콘솔로 따로 (지금 매크로의 숨긴 글자 창에 붙지 않게) - 더블클릭으로 켠 것과 같게
                flags = getattr(subprocess, 'CREATE_NEW_CONSOLE', 0) if os.name == 'nt' else 0
                subprocess.Popen(cmd, env=env, cwd=os.path.dirname(os.path.abspath(cmd[0])), creationflags=flags)
            else:
                popen(cmd, env=env, cwd=os.path.dirname(os.path.abspath(cmd[0])))
        except Exception as e:                                    # noqa: BLE001
            self.err = '다시 켜지 못함: %s' % e
            self.log(self.err)
            try:
                os.remove(self.resume_path())
            except OSError:
                pass
            with self.lock:
                self.state = 'new'
            return False
        self.log('업데이트: %s -> %s, 실행기 다시 켬' % (vtext(self.cur), vtext(self.remote)))
        return True

    def resume_path(self):
        return os.path.join(self.app, 'update_resume.json')

    def take_resume(self):
        """새로 켜진 쪽: 업데이트로 다시 켜졌으면 {'ok': 새 버전 맞음?, 'expect', 'old', 'resume', ...} / None"""
        p = self.resume_path()
        try:
            with open(p, encoding='utf-8') as f:
                r = json.load(f)
        except (OSError, ValueError):
            return None
        try:
            os.remove(p)
        except OSError:
            pass
        if time.time() - float(r.get('t', 0)) > RESUME_MAX_AGE:
            return None
        r['ok'] = vtuple(r.get('expect')) == self.cur
        return r

    # ── 표시 ──
    def chip(self):
        """매크로 창 맨 위: (글자, 종류) 종류 = latest/new/reserved/busy/plain"""
        cur = vtext(self.cur)
        s = self.state
        if s == 'checking':
            return '%s · 확인 중' % cur, 'plain'
        if s == 'down':
            return '받는 중 %d%%' % self.pct, 'busy'
        if s == 'restart':
            return '다시 켜는 중', 'busy'
        if s == 'new':
            return '⬆ 업데이트', 'new'            # (맨 위 자리가 좁아 버전은 창에서)
        if s == 'reserved':
            return '◔ 판 끝나고', 'reserved'
        if s == 'latest':
            return '%s ✓ 최신' % cur, 'latest'
        if s == 'exe':
            return '새 exe 필요', 'reserved'
        if s == 'error':
            return '%s · 확인 실패' % cur, 'plain'
        return cur, 'plain'
