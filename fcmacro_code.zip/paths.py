# -*- coding: utf-8 -*-
"""
파일 위치 규칙 (v2.0)
 - 코드와 이미지(버튼/숫자 견본)는 '코드 패키지'에 들어 있음: exe 내장(code 폴더) 또는 업데이트로 받은 것(기록 폴더\\app\\current)
 - 기록/설정/로그는 exe와 따로 '문서\\FC매크로_기록' 폴더에 저장
   (exe 폴더를 지우거나 새 버전으로 바꿔도 기록이 그대로 이어짐)
 - 매크로를 켤 때마다 ranking_log.csv 를 '백업' 폴더에 하루 1개씩 복사 (최근 30개 보관)
"""
import csv
import datetime
import os
import shutil
import sys

FROZEN = getattr(sys, 'frozen', False)
APP_DIR = os.path.dirname(os.path.abspath(sys.executable if FROZEN else __file__))
BUNDLE_DIR = getattr(sys, '_MEIPASS', APP_DIR)
CODE_DIR = os.path.dirname(os.path.abspath(__file__))   # 지금 실행 중인 코드 패키지 폴더 (업데이트되면 기록 폴더\app\current)
DATA_FOLDER_NAME = 'FC매크로_기록'
BACKUP_KEEP = 30
DATA_FILES = ['ranking_log.csv', 'macro_settings.json', 'champions_target.txt']   # 예전 exe 폴더에서 옮겨올 파일


def resource(rel):
    """코드 패키지(업데이트 받은 것 또는 exe 내장) -> exe 내장 -> exe 옆 폴더 순서
    (v2.0부터 견본 이미지도 업데이트로 받으므로, exe 옆에 남은 예전 images 폴더가 새 견본을 가리지 않게 맨 뒤로)"""
    for base in (CODE_DIR, BUNDLE_DIR, APP_DIR):
        p = os.path.join(base, rel)
        if os.path.exists(p):
            return p
    return os.path.join(CODE_DIR, rel)


def img(name):
    return resource(os.path.join('images', name))


def source_of(rel):
    """점검 화면 표시용: '업데이트 받은 코드' / '내장' / '외부 폴더'"""
    if os.path.exists(os.path.join(CODE_DIR, rel)):
        return '업데이트 받은 코드' if os.path.join('app', 'current') in CODE_DIR else '내장'
    return '외부 폴더' if os.path.exists(os.path.join(APP_DIR, rel)) else '내장'


# ───────────── 기록 폴더 ─────────────
def _documents_dir():
    """Windows '문서' 폴더 (OneDrive로 옮겨진 경우도 정확히). 실패하면 사용자 폴더\\Documents"""
    if os.name == 'nt':
        try:
            import ctypes
            import ctypes.wintypes as wt
            import uuid
            fid = uuid.UUID('{FDD39AD0-238F-46AF-ADB4-6C85480369C7}')      # FOLDERID_Documents

            class GUID(ctypes.Structure):
                _fields_ = [('Data1', wt.DWORD), ('Data2', wt.WORD), ('Data3', wt.WORD), ('Data4', wt.BYTE * 8)]
            g = GUID(fid.fields[0], fid.fields[1], fid.fields[2], (wt.BYTE * 8)(*fid.bytes[8:]))
            p = ctypes.c_wchar_p()
            sh = ctypes.WinDLL('shell32')          # 전용 사본 (공용 windll 함수 형식을 바꾸지 않음)
            sh.SHGetKnownFolderPath.argtypes = [ctypes.POINTER(GUID), wt.DWORD, wt.HANDLE, ctypes.POINTER(ctypes.c_wchar_p)]
            if sh.SHGetKnownFolderPath(ctypes.byref(g), 0, None, ctypes.byref(p)) == 0 and p.value:
                path = p.value
                ctypes.WinDLL('ole32').CoTaskMemFree(p)
                return path
        except Exception:
            pass
    return os.path.join(os.path.expanduser('~'), 'Documents')


def data_dir():
    """기록 폴더 경로 (없으면 만듦). FCMACRO_DATA_DIR 환경변수로 바꿀 수 있음. 만들 수 없으면 exe 폴더"""
    d = os.environ.get('FCMACRO_DATA_DIR') or os.path.join(_documents_dir(), DATA_FOLDER_NAME)
    try:
        os.makedirs(d, exist_ok=True)
        return d
    except Exception:
        return APP_DIR


def _merge_csv(old_path, new_path):
    """두 ranking_log.csv 를 (날짜시간, 게임번호) 기준으로 합쳐 new_path에 저장"""
    def load(p):
        with open(p, newline='', encoding='utf-8-sig') as f:
            rd = csv.DictReader(f)
            return rd.fieldnames or [], [dict(r) for r in rd]
    f1, r1 = load(new_path)
    f2, r2 = load(old_path)
    header = ['날짜시간', '게임번호', '랭킹점수', '순위', '결과', '비고']
    seen, rows = set(), []
    for r in r1 + r2:
        key = (r.get('날짜시간', ''), str(r.get('게임번호', '')))
        if key in seen:
            # 같은 판이 양쪽에 있으면 순위가 채워진 쪽을 남김
            if r.get('순위'):
                for x in rows:
                    if (x.get('날짜시간', ''), str(x.get('게임번호', ''))) == key and not x.get('순위'):
                        x['순위'] = r['순위']
            continue
        seen.add(key)
        rows.append(r)
    rows.sort(key=lambda r: r.get('날짜시간', ''))
    tmp = new_path + '.tmp'
    with open(tmp, 'w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f)
        w.writerow(header)
        for r in rows:
            w.writerow([r.get(h, '') or '' for h in header])
    os.replace(tmp, new_path)
    return len(rows)


def migrate_old_files(data):
    """예전처럼 exe 폴더에 있던 기록/설정을 기록 폴더로 옮김 (합친 뒤 원본은 '_옮겨짐'으로 이름 변경). 메시지 목록 반환"""
    msgs = []
    if os.path.normcase(os.path.abspath(data)) == os.path.normcase(os.path.abspath(APP_DIR)):
        return msgs
    for name in DATA_FILES:
        old = os.path.join(APP_DIR, name)
        new = os.path.join(data, name)
        if not os.path.isfile(old):
            continue
        try:
            if not os.path.exists(new):
                shutil.copy2(old, new)
                msgs.append('%s 를 기록 폴더로 옮김' % name)
            elif name == 'ranking_log.csv':
                n = _merge_csv(old, new)
                msgs.append('exe 폴더의 %s 를 기록 폴더 기록과 합침 (총 %d줄)' % (name, n))
            else:
                msgs.append('%s 는 기록 폴더 것을 사용 (exe 폴더 것은 보관만)' % name)
            base, ext = os.path.splitext(old)
            os.replace(old, base + '_옮겨짐' + ext)
        except Exception as e:
            msgs.append('%s 옮기기 실패: %s' % (name, e))
    return msgs


def backup_log(data):
    """ranking_log.csv 를 백업 폴더에 하루 1개 복사, 최근 BACKUP_KEEP개만 보관. 백업 파일 경로 반환"""
    src = os.path.join(data, 'ranking_log.csv')
    if not os.path.isfile(src) or os.path.getsize(src) == 0:
        return None
    bdir = os.path.join(data, '백업')
    try:
        os.makedirs(bdir, exist_ok=True)
        dst = os.path.join(bdir, 'ranking_log_%s.csv' % datetime.date.today().strftime('%Y%m%d'))
        shutil.copy2(src, dst)                      # 같은 날 여러 번 켜면 최신으로 덮어씀
        olds = sorted(f for f in os.listdir(bdir) if f.startswith('ranking_log_') and f.endswith('.csv'))
        for f in olds[:-BACKUP_KEEP]:
            os.remove(os.path.join(bdir, f))
        return dst
    except Exception:
        return None


# ───────────── 한글 경로에서도 되는 이미지 읽기/쓰기 ─────────────
# OpenCV의 cv2.imread / cv2.imwrite 는 Windows에서 경로에 한글이 있으면 실패함 (예: '감모 매크로 개발', 'FC매크로_기록')
# -> 파일을 바이트로 읽어서(numpy.fromfile) 디코딩 / 인코딩한 바이트를 파일로 저장(tofile)
def imread(path, flags=None):
    import cv2
    import numpy as np
    if flags is None:
        flags = cv2.IMREAD_COLOR
    try:
        data = np.fromfile(path, dtype=np.uint8)
    except (OSError, ValueError):
        return None
    if data.size == 0:
        return None
    return cv2.imdecode(data, flags)


def imwrite(path, img):
    import cv2
    ext = os.path.splitext(path)[1] or '.png'
    ok, buf = cv2.imencode(ext, img)
    if not ok:
        return False
    buf.tofile(path)
    return True


# ───────────── 자동 업데이트 (실행기 launcher 와 함께 씀) ─────────────
def update_pending_file(data):
    return os.path.join(data, 'app', 'pending.txt')


def mark_update_ok(data):
    """새로 받은 코드가 정상적으로 켜졌음 -> 실행기가 다음에 되돌리지 않음"""
    try:
        os.remove(update_pending_file(data))
    except OSError:
        pass
