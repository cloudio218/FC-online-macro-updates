# -*- coding: utf-8 -*-
"""
감독모드 홈 화면의 '랭킹 점수' 숫자 인식 모듈

원리
  1) '공식경기' 버튼(images/home.png) 위치를 기준점으로 삼아
     랭킹 점수가 있는 영역(버튼 기준 고정 오프셋)만 캡처
  2) 흰 글씨만 남기고(이진화) 글자 덩어리를 왼쪽부터 분리
     - 높이가 숫자 크기인 덩어리만 숫자로 취급 (쉼표·라벨 글자는 제외)
  3) 각 덩어리를 images/digits/0~9.png 견본과 크기를 맞춰 비교해 가장 닮은 숫자로 판정
     - 유사도가 MIN_SIMILARITY 미만인 글자가 하나라도 있으면 '인식 실패'(None) 처리

1280x720 창모드 기준. 창 크기를 바꾸면 오프셋이 달라지므로 재측정 필요.
"""
import os
import cv2
import numpy as np

import paths

# '공식경기' 버튼(home.png 매칭 위치의 left, top) 기준 랭킹 점수 영역 오프셋
#   측정값: 버튼 (996, 658) / 점수 숫자 x 236~345, y 281~319  (게임 창 캡처 기준)
SCORE_DX = -770      # 영역 왼쪽   = 버튼.left - 770
SCORE_DY = -390      # 영역 위쪽   = 버튼.top  - 390
SCORE_W = 140        # 영역 너비 (오른쪽의 '승률' 배지 앞에서 끊음)
SCORE_H = 60         # 영역 높이

BIN_THRESHOLD = 150        # 이 밝기 초과 = 흰 글씨
DIGIT_MIN_H = 28           # 숫자로 인정할 최소 높이(px) - 쉼표(13px), 라벨(약 13px) 제외
DIGIT_MAX_H = 48
MIN_SIMILARITY = 0.85      # 견본과의 최소 유사도 (같은 숫자 0.91~0.98, 다른 숫자 최대 0.76 측정)
NORM_W, NORM_H = 20, 32    # 비교용 정규화 크기

_templates = None


def _norm(gray_crop):
    f = gray_crop.astype(np.float32)
    f = np.clip((f - 60.0) / (230.0 - 60.0), 0.0, 1.0)
    f = cv2.resize(f, (NORM_W, NORM_H), interpolation=cv2.INTER_AREA)
    f = f - f.mean()
    n = np.sqrt((f * f).sum())
    return f / n if n > 0 else f


def _tight(gray_crop):
    """견본 이미지를 글자 경계에 딱 맞게 자름 (런타임 분리 방식과 동일한 기준)"""
    b = (gray_crop > BIN_THRESHOLD).astype(np.uint8)
    ys, xs = np.nonzero(b)
    if len(xs) == 0:
        return gray_crop
    return gray_crop[ys.min():ys.max() + 1, xs.min():xs.max() + 1]


def load_templates(digit_dir=None):
    global _templates
    t = {}
    for d in range(10):
        # 파일 단위로: exe 옆 images/digits 에 있으면 그것, 없으면 내장
        p = os.path.join(digit_dir, '%d.png' % d) if digit_dir else paths.resource(os.path.join('images', 'digits', '%d.png' % d))
        img = paths.imread(p, cv2.IMREAD_GRAYSCALE)      # 한글 경로에서도 읽힘
        if img is None:
            raise FileNotFoundError(p)
        t[str(d)] = _norm(_tight(img))
    _templates = t
    return t


def read_number_from_gray(gray):
    """
    흑백 이미지(numpy uint8)에서 큰 숫자열을 읽어 (정수 또는 None, 상세정보) 반환
    상세정보: [(숫자, 유사도), ...]  — 디버깅/표시용
    """
    if _templates is None:
        load_templates()
    b = (gray > BIN_THRESHOLD).astype(np.uint8)
    n, _, stats, _ = cv2.connectedComponentsWithStats(b, 8)
    comps = [s for s in stats[1:] if DIGIT_MIN_H <= s[3] <= DIGIT_MAX_H and s[4] >= 60]
    comps.sort(key=lambda s: s[0])
    if not comps:
        return None, []
    digits, detail = '', []
    for x, y, w, h, _a in comps:
        g = _norm(gray[y:y + h, x:x + w])
        best_d, best_s = None, -1.0
        for d, t in _templates.items():
            s = float((g * t).sum())
            if s > best_s:
                best_d, best_s = d, s
        detail.append((best_d, round(best_s, 3)))
        if best_s < MIN_SIMILARITY:
            return None, detail
        digits += best_d
    if not (1 <= len(digits) <= 5):
        return None, detail
    return int(digits), detail


def score_region(home_box):
    """home.png 매칭 결과(Box) -> 점수 캡처 영역 (left, top, width, height)"""
    return (int(home_box.left) + SCORE_DX, int(home_box.top) + SCORE_DY, SCORE_W, SCORE_H)


def read_score_on_screen(home_box):
    """화면에서 랭킹 점수를 1회 읽음 -> (정수 또는 None, 상세정보)"""
    import pyautogui
    region = score_region(home_box)
    if region[0] < 0 or region[1] < 0:
        return None, [('영역이 화면 밖', 0)]
    shot = pyautogui.screenshot(region=region)
    gray = cv2.cvtColor(np.array(shot), cv2.COLOR_RGB2GRAY)
    return read_number_from_gray(gray)


# ───────────────────────── VS 화면 순위(아주 작은 글씨) 인식 ─────────────────────────
# VS 화면('팀 정보' 탭, images/vs_team.png) 기준 순위 막대 영역 오프셋
#   측정값: 탭 기준점 (515,168) / 내 순위 막대 x 442~604, y 411~427 / 상대 막대 x 674~836
RANK_DX_MINE = -73
RANK_DX_OPP = 159
RANK_DY = 243
RANK_W, RANK_H = 162, 16
RANK_MIN_SIM = 0.92        # 숫자 견본 최소 유사도 (위치까지 맞는 견본은 0.99 이상. 애매하면 오인 대신 실패 처리)
RANK_WI_MIN_SIM = 0.90     # '위' 글자 최소 유사도
RANK_MIN_MARGIN = 0.04     # 1등 숫자가 2등(다른 숫자)보다 이만큼은 높아야 인정
# 견본을 소수점 픽셀만큼 옮긴 변형을 자동 생성 (글자가 놓이는 미세 위치 차이 대비)
RANK_SHIFTS = [(dx, dy) for dx in (-2/3, -1/3, 0, 1/3, 2/3) for dy in (-0.5, 0, 0.5)]
RANK_TEXT_TH = 150         # 글씨가 시작되는 열을 찾을 때의 밝기 기준

_rank_t = None


def load_rank_templates(digit_dir=None):
    """
    숫자별 견본을 여러 장 불러옴: '7.png', '7_2.png', '7_3.png' ... 는 모두 숫자 7.
    (글자 간격이 소수점 단위라 같은 숫자도 위치에 따라 픽셀 모양이 달라서 여러 장 필요)
    'wi*.png' = '위' 글자. 아직 견본이 없는 숫자는 읽지 못하고 '인식 실패' 처리.
    """
    global _rank_t
    if digit_dir:
        dirs = [digit_dir]
    else:   # 내장 견본 + exe 옆 images/rank_digits 견본을 합쳐서 사용 (예전 폴더가 있어도 내장 견본이 빠지지 않음)
        rel = os.path.join('images', 'rank_digits')
        dirs = []
        for base in (paths.CODE_DIR, paths.BUNDLE_DIR, paths.APP_DIR):   # 코드 패키지 + 내장 + exe 옆 견본을 합쳐서 사용
            d = os.path.join(base, rel)
            if d not in dirs:
                dirs.append(d)
    t = {}
    seen = set()
    for dd in dirs:
        if not os.path.isdir(dd):
            continue
        for fn in sorted(os.listdir(dd)):
            if not fn.lower().endswith('.png'):
                continue
            name = fn[:-4].split('_')[0]
            if name not in [str(d) for d in range(10)] + ['wi']:
                continue
            img = paths.imread(os.path.join(dd, fn), cv2.IMREAD_GRAYSCALE)
            if img is None:
                continue
            key = (name, img.shape, img.tobytes())
            if key in seen:          # 같은 견본이 양쪽에 있으면 한 번만
                continue
            seen.add(key)
            t.setdefault(name, []).extend(_shifted(img))
    _rank_t = t
    return t


def _shifted(img):
    f = img.astype(np.float32)
    out = []
    for dx, dy in RANK_SHIFTS:
        if dx == 0 and dy == 0:
            out.append(img)
            continue
        m = np.float32([[1, 0, dx], [0, 1, dy]])
        w = cv2.warpAffine(f, m, (img.shape[1], img.shape[0]), flags=cv2.INTER_LINEAR,
                           borderMode=cv2.BORDER_REPLICATE)
        out.append(np.clip(w, 0, 255).astype(np.uint8))
    return out


def read_rank_from_gray(gray):
    """
    순위 막대(흑백)에서 'NNNN위'를 읽어 (정수 또는 None, 상세정보) 반환.
    작은 글씨라 글자를 미리 자르지 않고, 견본을 옆으로 밀며 가장 잘 맞는 위치를 차례로 찾음.
    """
    if _rank_t is None:
        load_rank_templates()
    if 'wi' not in _rank_t:
        return None, [('위 견본 없음', 0)]
    cols = np.where(gray.max(axis=0) > RANK_TEXT_TH)[0]
    if len(cols) == 0:
        return None, [('글씨 없음', 0)]
    scores = {}
    for name, variants in _rank_t.items():
        for t in variants:
            if gray.shape[0] < t.shape[0] or gray.shape[1] < t.shape[1]:
                continue
            r = cv2.matchTemplate(gray, t, cv2.TM_CCOEFF_NORMED).max(axis=0)   # x 위치별 최고 유사도
            if name in scores and len(scores[name]) == len(r):
                scores[name] = np.maximum(scores[name], r)
            else:
                scores[name] = r
    digits, detail = '', []
    lo, hi = int(cols[0]) - 2, int(cols[0]) + 2
    for _ in range(8):
        best_name, best_s, best_x = None, -1.0, None
        per = {}
        for name, sc in scores.items():
            a, b = max(0, lo), min(len(sc) - 1, hi)
            if a > b:
                continue
            x = a + int(np.argmax(sc[a:b + 1]))
            per[name] = float(sc[x])
            if sc[x] > best_s:
                best_name, best_s, best_x = name, float(sc[x]), x
        second = max([v for n, v in per.items() if n != best_name] or [0.0])
        if best_name is None:
            break
        detail.append((best_name, round(best_s, 3)))
        if best_s < (RANK_WI_MIN_SIM if best_name == 'wi' else RANK_MIN_SIM) or best_s - second < RANK_MIN_MARGIN:
            return None, detail                 # 모르는 글자(아직 견본 없는 숫자 등)
        if best_name == 'wi':
            break
        digits += best_name
        lo, hi = best_x + 4, best_x + 7          # 숫자 간격 5~6px
    else:
        return None, detail
    if not digits or detail[-1][0] != 'wi':
        return None, detail
    return int(digits), detail


def rank_region(vs_box, side='mine'):
    dx = RANK_DX_MINE if side == 'mine' else RANK_DX_OPP
    return (int(vs_box.left) + dx, int(vs_box.top) + RANK_DY, RANK_W, RANK_H)


def grab_rank_strip(vs_box, side='mine'):
    """화면에서 순위 막대를 캡처해 흑백 numpy로 반환"""
    import pyautogui
    region = rank_region(vs_box, side)
    if region[0] < 0 or region[1] < 0:
        return None
    shot = pyautogui.screenshot(region=region)
    return cv2.cvtColor(np.array(shot), cv2.COLOR_RGB2GRAY)


# ───────────────────── VS 화면 내 점수 (챔스 아래 티어: 파란 'NNNN점') ─────────────────────
# 챔스 홈 화면의 큰 흰 숫자와 같은 글꼴(크기만 작음) -> 같은 숫자 견본(images/digits)을 크기 맞춰 비교
#   측정값: 탭 기준점 기준 글씨 y +268~284, 내 점수 x -20 부근부터 (상대 점수 영역 함수도 남겨둠)
VS_SCORE_DY, VS_SCORE_H = 260, 32
VS_SCORE_DX_MINE = RANK_DX_MINE - 30
VS_SCORE_DX_OPP = RANK_DX_OPP - 30
VS_SCORE_W = 222
VS_TEXT_TH = 150           # 파란 글씨: RGB의 B 값이 이보다 큰 부분
VS_DIGIT_MIN_H, VS_DIGIT_MAX_H = 12, 24   # '점' 글자 조각(약 9px)은 제외됨
VS_MIN_SIM = 0.70
VS_MIN_MARGIN = 0.06       # 1등 숫자가 2등보다 이만큼은 높아야 인정 (애매하면 빈칸)


def vs_score_region(vs_box, side='mine'):
    dx = VS_SCORE_DX_MINE if side == 'mine' else VS_SCORE_DX_OPP
    return (int(vs_box.left) + dx, int(vs_box.top) + VS_SCORE_DY, VS_SCORE_W, VS_SCORE_H)


def read_vs_score(rgb):
    """VS 화면 점수 영역(RGB numpy) -> (정수 또는 None, 상세정보)"""
    if _templates is None:
        load_templates()
    blue = rgb[..., 2]
    b = (blue > VS_TEXT_TH).astype(np.uint8)
    n, _, stats, _ = cv2.connectedComponentsWithStats(b, 8)
    comps = [s for s in stats[1:] if VS_DIGIT_MIN_H <= s[3] <= VS_DIGIT_MAX_H and s[4] >= 15]
    comps.sort(key=lambda s: s[0])
    if not comps:
        return None, []
    digits, detail, prev_right = '', [], None
    for x, y, w, h, _a in comps:
        if prev_right is not None and x - prev_right > 8:      # 숫자 덩어리 뒤에 떨어진 다른 글자 -> 끝
            break
        g = _norm(blue[y:y + h, x:x + w])
        sims = sorted(((float((g * t).sum()), d) for d, t in _templates.items()), reverse=True)
        (s1, d1), (s2, _d2) = sims[0], sims[1]
        detail.append((d1, round(s1, 3)))
        if s1 < VS_MIN_SIM or s1 - s2 < VS_MIN_MARGIN:
            return None, detail
        digits += d1
        prev_right = x + w
    if not (3 <= len(digits) <= 5):
        return None, detail
    return int(digits), detail


# ───────────────────── 최근 결과 칸 (챔스 아래 티어: 홈 화면 / VS 화면의 [승][패][무]... 10칸) ─────────────────────
# 칸 배경색으로 판정: 초록=승, 밝은 회색=무, 회색=패, 어두움=빈칸 (글자 인식 없이 색만 봄)
#   측정값: 홈 화면은 공식경기 버튼 기준 x -780부터 19.4px 간격, y -383~-350
#           VS 화면은 '팀 정보' 탭 기준 x -75부터 17px 간격, y +244~+260
STRIP_HOME = {'dx': -780, 'dy': -383, 'h': 33, 'pitch': 19.4, 'w': 18}
STRIP_VS = {'dx': -75, 'dy': 244, 'h': 16, 'pitch': 17.0, 'w': 15}


def strip_region(box, geo):
    width = int(round(geo['pitch'] * 9)) + geo['w']
    return (int(box.left) + geo['dx'], int(box.top) + geo['dy'], width, geo['h'])


def read_result_strip(rgb, geo):
    """결과 칸 영역(RGB numpy) -> ['승','패','무',...] (채워진 칸만, 왼쪽부터) 또는 None(결과 칸이 아님/애매)"""
    if rgb is None:
        return None
    out = []
    empty_seen = False
    for i in range(10):
        x = int(round(i * geo['pitch']))
        a = rgb[:, x + 2:x + geo['w'] - 2].reshape(-1, 3).astype(np.int32)
        if a.size == 0:
            return None
        r, g, b = np.median(a, axis=0)
        v = (r + g + b) / 3
        if g > 130 and g - r > 80:
            c = '승'
        elif min(r, g, b) > 150:
            c = '무'
        elif 70 < v < 150 and abs(r - g) < 25 and abs(g - b) < 25:
            c = '패'
        elif v < 70:
            c = None
        else:
            return None                       # 결과 칸 색이 아님 (다른 화면)
        if c is None:
            empty_seen = True
        elif empty_seen:
            return None                       # 빈칸 뒤에 결과가 있으면 결과 칸이 아님
        else:
            out.append(c)
    return out


# ───────────────────── 승점 막대의 기준선 (챔스 아래 티어 홈 화면) ─────────────────────
# 막대: 파란 채움(현재 승점) / 빨간 선(강등선) / 초록 선(승격선) / 흰 점선+▼ -> 선의 x 위치로 몇 점인지 계산
#   측정값(챌린저 1부 원본 캡처): 승점 6 채움 끝 x -442, 빨강 14 x -361, 초록 17 x -330, 흰색 21 x -290 (1점 = 10.2px)
#   화면 문구 '승격까지 11점 남음'(6+11=17) -> 초록 선이 승격선
BAR_DX, BAR_DY, BAR_W, BAR_H = -575, -395, 380, 58
BAR_X0 = -503.4          # 0점 위치 (버튼 기준)
BAR_PPP = 10.2           # 1점당 px


def bar_region(home_box):
    return (int(home_box.left) + BAR_DX, int(home_box.top) + BAR_DY, BAR_W, BAR_H)


def read_bar_lines(rgb):
    """승점 막대(RGB numpy) -> {'fill': 현재 승점, 'green': 승격선, 'white': 점선} (못 찾은 것은 빠짐)"""
    out = {}
    if rgb is None:
        return out
    a = rgb.astype(np.int32)
    r, g, b = a[..., 0], a[..., 1], a[..., 2]
    h = a.shape[0]
    masks = {'green': (g > 140) & (r < 120) & (b < 150) & (g - b > 40),
             'white': np.minimum(np.minimum(r, g), b) > 110}
    for name, m in masks.items():
        c = m.sum(axis=0)
        xs = np.where(c >= h * 0.35)[0]
        if len(xs) == 0 or xs.max() - xs.min() > 6:          # 선이 없거나 여러 개(다른 화면) -> 모름
            continue
        x = BAR_DX + xs.mean()
        v = int(round((x - BAR_X0) / BAR_PPP))
        if 3 <= v <= 30:
            out[name] = v
    blue = ((b > 200) & (r < 80)).sum(axis=0)
    xs = np.where(blue >= h * 0.4)[0]
    if len(xs):
        v = int(round((BAR_DX + xs.max() + 1 - BAR_X0) / BAR_PPP))
        if 0 <= v <= 30:
            out['fill'] = v
    return out
