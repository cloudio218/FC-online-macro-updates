# -*- coding: utf-8 -*-
"""v3.2 전술 자동 변경

게임 스쿼드 화면(경기 전)의 [전술 ▼] 목록에서 미리 등록한 전술(최대 3개)을 번갈아 쓴다.
 - 바꾸는 기준: (지금 전술로 최소 N판 뒤) 최근 N판 승률 < 기준 %  또는  M연패 (판수 상관없이)
 - 모든 전술이 기준 미만이면 승률이 가장 좋았던 전술로 고정, 고정 후 K판 지나면 다시 처음부터 평가
 - 고정 중 연패: '알림만' 또는 '고정 풀고 다음 전술로' (설정)
 - 게임에서 등록 안 된 전술로 직접 바꿔 두면 자동 변경을 멈춤 (등록된 전술로 돌아오면 다시 작동)
 - 연속 진행 중에는 스쿼드 화면을 거치지 않으므로 바꾸지 않고 기다림 (끝난 뒤 첫 [진행] 때)

화면 위치 (진행 버튼 squad.png 왼쪽 위 기준, 게임 1280x720):
 - 전술 칸(닫힌 상태): x -684 ~ +127, y -447 ~ +22   (2026-11-16 캡처 3장에서 측정, 3장 모두 같음)
 - 열린 목록: 전술 칸 바로 아래 약 25.6px 간격 10줄
등록: 사용자가 목록을 열고 전술을 클릭 -> 클릭 위치(전술 칸 기준)와, 고른 뒤 전술 칸 모습(이름 글자)을 저장
전환: 전술 칸 클릭 -> 저장한 위치 클릭 -> 전술 칸 모습이 그 전술과 같은지 확인 (다르면 한 번 더, 그래도 다르면 원래대로)

규칙 계산(decide)은 화면과 상관없는 순수 함수라 시뮬레이션으로 검증함 (tools/sim_tactics.py)
"""
import os
import json
import time
import datetime

import numpy as np
import cv2

SLOTS = 3
MARK = ['①', '②', '③']
DEFAULTS = {'enabled': False, 'min_games': 30, 'rate': 40, 'streak_on': True, 'streak': 6,
            'lock_on': True, 'unlock_after': 100, 'lock_streak': 'alert'}      # lock_streak: 'alert' | 'switch'
FIELD_DX, FIELD_DY, FIELD_W, FIELD_H = -684, -447, 127, 22
TEXT_X0, TEXT_X1 = 3, 95                 # 전술 칸 안에서 이름 글자 부분 (오른쪽 ▼/▲ 화살표 빼고)
LIST_Y0, LIST_Y1 = FIELD_H + 1, FIELD_H + 275   # 열린 목록 (전술 칸 아래)
SAME_MIN = 0.90                          # 전술 칸 이름이 같은 전술이라고 볼 유사도 (같으면 1.0, 다르면 0.4대로 측정)
LOG_MAX = 30


def _now():
    return datetime.datetime.now().strftime('%m/%d %H:%M')


class Store:
    """전술 등록·상태 저장 (기록 폴더\\tactics\\state.json + 이미지)"""

    def __init__(self, folder):
        self.folder = folder
        self.path = os.path.join(folder, 'state.json')
        self.s = {'settings': dict(DEFAULTS), 'slots': [None] * SLOTS, 'cur': None, 'run': [], 'evals': {},
                  'locked': None, 'log': [], 'pending': None, 'unknown_note': False, 'streak_noted': 0}
        self._img = {}
        self.load()

    # ── 저장 ──
    def load(self):
        try:
            with open(self.path, encoding='utf-8') as f:
                d = json.load(f)
            self.s.update(d)
            self.s['settings'] = dict(DEFAULTS, **(d.get('settings') or {}))
            sl = list(self.s.get('slots') or [])
            self.s['slots'] = (sl + [None] * SLOTS)[:SLOTS]
            self.s['evals'] = {int(k): v for k, v in (self.s.get('evals') or {}).items()}
        except (OSError, ValueError):
            pass

    def save(self):
        try:
            os.makedirs(self.folder, exist_ok=True)
            tmp = self.path + '.tmp'
            with open(tmp, 'w', encoding='utf-8') as f:
                json.dump(self.s, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self.path)
        except OSError:
            pass

    @property
    def settings(self):
        return self.s['settings']

    def slot(self, i):
        return self.s['slots'][i] if 0 <= i < SLOTS else None

    def usable(self):
        return [i for i, sl in enumerate(self.s['slots']) if sl and not sl.get('missing')]

    def registered(self):
        return [i for i, sl in enumerate(self.s['slots']) if sl]

    def name(self, i):
        if i is None:
            return '등록 안 된 전술'
        sl = self.slot(i)
        return '%s %s' % (MARK[i], (sl or {}).get('name') or '전술 %d' % (i + 1))

    def add_log(self, text):
        self.s['log'] = ([[_now(), text]] + self.s['log'])[:LOG_MAX]

    # ── 이미지 (전술 칸 모습) ──
    def _img_path(self, i, kind):
        return os.path.join(self.folder, 'slot%d_%s_%s.png' % (i + 1, (self.slot(i) or {}).get('id', 'x'), kind))

    def image(self, i, kind='field'):
        """kind: 'field' = 전술 칸 RGB(화면 표시용), 'text' = 이름 글자 회색(비교용)"""
        key = (i, kind, (self.slot(i) or {}).get('id'))
        if key in self._img:
            return self._img[key]
        p = self._img_path(i, kind)
        a = None
        try:
            if os.path.exists(p):
                a = cv2.imdecode(np.fromfile(p, np.uint8), cv2.IMREAD_UNCHANGED)
                if a is not None and kind == 'field' and a.ndim == 3:
                    a = cv2.cvtColor(a, cv2.COLOR_BGR2RGB)
        except Exception:
            a = None
        self._img[key] = a
        return a

    def set_slot(self, i, cap, name=None):
        """등록 결과(cap: dx, dy, field(RGB), text(gray), item(RGB)) 저장. 다시 등록하면 그 전술 기록은 새로 시작"""
        old = self.slot(i) or {}
        sid = datetime.datetime.now().strftime('%Y%m%d%H%M%S')
        self.s['slots'][i] = {'id': sid, 'name': name or old.get('name') or '전술 %d' % (i + 1),
                              'dx': int(cap['dx']), 'dy': int(cap['dy']), 'games': [], 'missing': False}
        os.makedirs(self.folder, exist_ok=True)
        for kind in ('field', 'text', 'item'):
            a = cap.get(kind)
            if a is None:
                continue
            if a.ndim == 3:
                a = cv2.cvtColor(a, cv2.COLOR_RGB2BGR)
            ok, buf = cv2.imencode('.png', a)
            if ok:
                buf.tofile(self._img_path(i, kind))
        self._img.clear()
        self.s['evals'].pop(i, None)
        if self.s['locked'] == i:
            self.s['locked'] = None
        if self.s['cur'] == i:
            self.s['run'] = []
        self.add_log('%s 등록' % self.name(i))
        self.save()

    def delete_slot(self, i):
        if not self.slot(i):
            return
        self.add_log('%s 삭제' % self.name(i))
        self.s['slots'][i] = None
        self.s['evals'].pop(i, None)
        if self.s['locked'] == i:
            self.s['locked'] = None
        if self.s['cur'] == i:
            self.s['cur'] = None
            self.s['run'] = []
        if (self.s.get('pending') or {}).get('to') == i:
            self.s['pending'] = None
        self._img.clear()
        self.save()

    def rename(self, i, name):
        sl = self.slot(i)
        if sl and name and name != sl.get('name'):
            sl['name'] = name.strip()[:12]
            self.save()

    # ── 판 기록 ──
    def on_game(self, ts, i):
        """새 판 시작 (그 판에 쓴 전술 i, None = 등록 안 된 전술)"""
        if i is None or not self.slot(i):
            return
        sl = self.slot(i)
        if not any(g[0] == ts for g in sl['games']):
            sl['games'].append([ts, None])
            sl['games'] = sl['games'][-500:]
        if self.s['cur'] == i and ts not in self.s['run']:
            self.s['run'].append(ts)
            self.s['run'] = self.s['run'][-500:]
        self.save()

    def sync_results(self, res_by_ts):
        """기록 파일의 결과(승/무/패)를 전술별 판에 채움 (매크로를 다시 켜도 이어짐)"""
        ch = False
        for sl in self.s['slots']:
            if not sl:
                continue
            for g in sl['games']:
                r = res_by_ts.get(g[0])
                if r and g[1] != r:
                    g[1] = r
                    ch = True
        if ch:
            self.save()

    def results(self, i, ts_list=None):
        """전술 i의 결과 목록 (ts_list 가 있으면 그 판들만, 순서대로). 결과 모르는 판은 뺌"""
        sl = self.slot(i)
        if not sl:
            return []
        if ts_list is None:
            return [g[1] for g in sl['games'] if g[1]]
        m = {g[0]: g[1] for g in sl['games']}
        return [m[t] for t in ts_list if m.get(t)]

    def stats(self, i, last=None):
        res = self.results(i)
        if last:
            res = res[-last:]
        n = len(res)
        w, d, l = res.count('승'), res.count('무'), res.count('패')
        return {'n': n, 'w': w, 'd': d, 'l': l, 'rate': (w * 100.0 / n) if n else None}


def run_results(st):
    i = st.s['cur']
    return st.results(i, st.s['run']) if i is not None else []


def lose_streak(res):
    n = 0
    for r in reversed(res):
        if r == '패':
            n += 1
        else:
            break
    return n


def next_slot(st, cur):
    use = st.usable()
    if not use:
        return None
    if cur is None or cur not in use:
        later = [i for i in use if cur is None or i > cur]
        return (later or use)[0]
    k = use.index(cur)
    return use[(k + 1) % len(use)]


def decide(st):
    """지금 전술을 바꿔야 하는지 판단 (상태는 고치지 않음)
    반환 dict: kind('' = 그대로 | pending | streak | rate | lock | unlock | lock_switch | lock_alert), to, why, eval((번호, 승률) | None)"""
    cfg = st.settings
    s = st.s
    out = {'kind': '', 'to': None, 'why': '', 'eval': None}
    pend = s.get('pending')
    if pend and pend.get('to') in st.usable():
        if pend['to'] == s['cur']:
            return dict(out, kind='pending', to=pend['to'], why=pend.get('why') or '직접 선택')
        return dict(out, kind='pending', to=pend['to'], why=pend.get('why') or '직접 선택')
    if not cfg.get('enabled'):
        return out
    use = st.usable()
    cur = s['cur']
    if cur is None or len(use) < 2 or cur not in use:
        return out                                  # 등록 안 된 전술 사용 중 / 전술 1개뿐 -> 그대로
    res = run_results(st)
    n_min = max(5, int(cfg.get('min_games') or 30))
    thr = float(cfg.get('rate') or 0)
    streak_n = int(cfg.get('streak') or 0)
    streak = lose_streak(res)
    streak_hit = bool(cfg.get('streak_on')) and streak_n >= 2 and streak >= streak_n
    # ── 고정 중 ──
    if s.get('locked') is not None and s['locked'] == cur:
        if len(res) >= int(cfg.get('unlock_after') or 100):
            return dict(out, kind='unlock', to=cur, why='고정 %d판 지남 - 처음부터 다시 평가' % len(res))
        if streak_hit:
            if cfg.get('lock_streak') == 'switch':
                return dict(out, kind='lock_switch', to=next_slot(st, cur), why='고정 중 %d연패 - 고정 풀고 다음 전술로' % streak)
            noted = s.get('streak_noted', 0) if s.get('streak_noted', 0) <= streak else 0   # 연패가 끊겼으면 다시 셈
            if streak >= noted + streak_n:                  # N연패 때 한 번, 계속 지면 N판마다 한 번
                return dict(out, kind='lock_alert', to=cur, why='고정 중 %d연패 (설정: 알림만)' % streak)
        return out
    # ── 평소 ──
    if streak_hit:
        return dict(out, kind='streak', to=next_slot(st, cur), why='%d연패' % streak)
    if len(res) >= n_min:
        last = res[-n_min:]
        rate = last.count('승') * 100.0 / len(last)
        if rate < thr:
            ev = dict(s.get('evals') or {})
            ev[cur] = rate
            if cfg.get('lock_on') and all(i in ev for i in use):
                best = sorted(use, key=lambda i: (-ev[i], -len(st.results(i)), i))[0]
                return dict(out, kind='lock', to=best, eval=(cur, rate),
                            why='최근 %d판 승률 %d%% < %d%% · 모든 전술이 기준 미만 -> 가장 좋았던 %s(%d%%)로 고정' % (
                                n_min, round(rate), thr, st.name(best), round(ev[best])))
            return dict(out, kind='rate', to=next_slot(st, cur), eval=(cur, rate),
                        why='최근 %d판 승률 %d%% < %d%%' % (n_min, round(rate), thr))
    return out


def apply_decision(st, d, done_to=None):
    """판단(d)을 실행한 뒤 상태 정리. done_to = 실제로 바뀐 전술 (전환 실패면 None)"""
    s = st.s
    k = d['kind']
    frm = s['cur']
    if k == 'lock_alert':
        s['streak_noted'] = lose_streak(run_results(st))
        st.save()
        return
    if k == 'unlock':
        s['locked'] = None
        s['evals'] = {}
        s['run'] = []
        st.add_log('%s %s' % (st.name(frm), d['why']))
        st.save()
        return
    if d.get('eval'):
        s['evals'][d['eval'][0]] = d['eval'][1]
    if done_to is None:                             # 전환 실패 -> 판단만 기록 (평가 결과는 남김)
        st.save()
        return
    if k == 'lock':
        s['locked'] = done_to
    elif k == 'lock_switch':
        s['locked'] = None
        s['evals'] = {}
    elif k == 'pending':
        s['locked'] = None                          # 사람이 직접 고르면 고정 풀림
    s['pending'] = None
    s['streak_noted'] = 0
    s['run'] = []
    if done_to != frm:
        s['cur'] = done_to
        st.add_log('%s → %s  (%s)' % (st.name(frm), st.name(done_to), d['why']))
    else:
        st.add_log('%s 그대로  (%s)' % (st.name(done_to), d['why']))
    st.save()


def observe(st, i):
    """스쿼드 화면에서 지금 전술 칸을 읽은 결과 반영. 바뀌었으면(사람이 직접 바꿈) 새로 셈. 반환: 바뀌었는지"""
    s = st.s
    if i == s['cur']:
        if i is not None:
            s['unknown_note'] = False
        return False
    old = s['cur']
    s['cur'] = i
    s['run'] = []
    if i is not None and s.get('locked') is not None and s['locked'] != i:
        s['locked'] = None
    if i is None:
        st.add_log('등록 안 된 전술로 바뀜 -> 자동 변경 멈춤')
    else:
        st.add_log('게임에서 %s 사용 확인' % st.name(i))
        s['unknown_note'] = False
    st.save()
    return True


def status_line(st):
    """매크로 창/텔레그램용 한 줄"""
    s = st.s
    cfg = st.settings
    if not st.registered():
        return '전술 등록 안 됨'
    i = s['cur']
    if i is None:
        return '등록 안 된 전술 사용 중 - 자동 변경 멈춤' if cfg.get('enabled') else '지금 전술 모름 (스쿼드 화면을 지나면 확인)'
    res = run_results(st)
    n = len(res)
    w = res.count('승')
    txt = '%s · 이 전술로 %d판' % (st.name(i), n)
    if n:
        txt += ' · 승률 %d%%' % round(w * 100 / n)
    if not cfg.get('enabled'):
        return txt + ' · 자동 변경 꺼짐'
    if s.get('locked') == i:
        left = int(cfg.get('unlock_after') or 100) - n
        return txt + ' · 고정 (%d판 뒤 다시 평가)' % max(0, left)
    n_min = max(5, int(cfg.get('min_games') or 30))
    if n < n_min:
        txt += ' · 평가까지 %d판' % (n_min - n)
    st_n = lose_streak(res)
    if st_n >= 2:
        txt += ' · %d연패' % st_n
    return txt


# ───────────────────── 화면: 전술 칸 읽기 / 바꾸기 / 등록 ─────────────────────
def field_region(anchor):
    """anchor = 진행 버튼(squad.png) Box -> 전술 칸 화면 영역"""
    return (int(anchor.left) + FIELD_DX, int(anchor.top) + FIELD_DY, FIELD_W, FIELD_H)


def text_of(field_rgb):
    if field_rgb is None:
        return None
    g = cv2.cvtColor(field_rgb, cv2.COLOR_RGB2GRAY) if field_rgb.ndim == 3 else field_rgb
    return g[2:FIELD_H - 2, TEXT_X0:TEXT_X1]


def looks_like_field(field_rgb):
    """닫힌 전술 칸 모양인지 (회색 바탕 + 밝은 글자)"""
    if field_rgb is None:
        return False
    g = cv2.cvtColor(field_rgb, cv2.COLOR_RGB2GRAY).astype(np.int32)
    bg = np.median(g)
    return 30 <= bg <= 80 and (g > 150).mean() > 0.04


WIDE_X, WIDE_Y = 10, 5                  # v3.2.1: 전술 칸 주변까지 넓게 잘라 위치가 몇 픽셀 어긋나도 찾음


def wide_region(anchor):
    fx, fy, fw, fh = field_region(anchor)
    return (fx - WIDE_X, fy - WIDE_Y, fw + 2 * WIDE_X, fh + 2 * WIDE_Y)


def scores(st, field_rgb, wide_rgb=None):
    """등록 전술별 비슷한 정도 {번호: 0~1}. wide_rgb(전술 칸 주변 넓게)가 있으면 그 안에서 위치를 찾아 비교"""
    out = {}
    if wide_rgb is not None and wide_rgb.shape[0] >= FIELD_H and wide_rgb.shape[1] >= FIELD_W:
        g = cv2.cvtColor(wide_rgb, cv2.COLOR_RGB2GRAY)
    else:
        t = text_of(field_rgb)
        g = cv2.copyMakeBorder(t, 2, 2, 3, 3, cv2.BORDER_REPLICATE) if t is not None else None
    if g is None:
        return out
    for i in st.registered():
        ref = st.image(i, 'text')
        if ref is None or g.shape[0] < ref.shape[0] or g.shape[1] < ref.shape[1]:
            continue
        out[i] = float(cv2.minMaxLoc(cv2.matchTemplate(g, ref, cv2.TM_CCOEFF_NORMED))[1])
    return out


def identify(st, field_rgb, wide_rgb=None, detail=None):
    """전술 칸 모습 -> 등록된 전술 번호 / None(등록 안 된 전술) / -1(전술 칸이 안 보임)
    detail(dict)을 주면 비슷한 정도를 채워 줌 (로그용)"""
    if not looks_like_field(field_rgb):
        return -1
    sc = scores(st, field_rgb, wide_rgb)
    if detail is not None:
        detail.update(sc)
    if not sc:
        return None
    bi = max(sc, key=sc.get)
    return bi if sc[bi] >= SAME_MIN else None


def read(st, io, f, anchor, detail=None):
    """화면(f)에서 전술 칸을 읽음 (넓게 잘라 위치 어긋남 허용)"""
    wide = io.crop(f, wide_region(anchor))
    if wide is None:
        return identify(st, io.crop(f, field_region(anchor)), None, detail)
    fr = wide[WIDE_Y:WIDE_Y + FIELD_H, WIDE_X:WIDE_X + FIELD_W]
    return identify(st, fr, wide, detail)


def score_text(st, detail):
    return ' · '.join('%s %d%%' % (MARK[i], round(v * 100)) for i, v in sorted(detail.items())) or '등록 그림 없음'


def list_region(anchor):
    fx, fy, _w, _h = field_region(anchor)
    return (fx + 2, fy + 26, 123, 44)


def list_open(rgb):
    """전술 칸 아래가 열린 목록인지 (목록: 무채색 어두운 바탕 + 흰 글자 / 닫힘: 푸른빛 어두운 판, 측정 채도 9 vs 40)"""
    if rgb is None:
        return False
    hsv = cv2.cvtColor(rgb, cv2.COLOR_RGB2HSV)
    return float(np.median(hsv[..., 1])) < 22 and float((hsv[..., 2] > 200).mean()) > 0.01


def _state(io, anchor):
    f = io.grab()
    a = io.anchor(f) or anchor
    return a, list_open(io.crop(f, list_region(a))), read(st_ref[0], io, f, a)


st_ref = [None]


def switch(st, io, anchor, to, log=None):
    """전술 칸 클릭(목록 열기) -> 등록한 위치 클릭 -> 목록 닫힘·전술 칸 확인.
    반환 (성공 여부, 지금 전술 번호(None 등록 안 됨, -1 모름), 설명)"""
    log = log or (lambda *a: None)
    st_ref[0] = st
    sl = st.slot(to)
    a, opened, got = _state(io, anchor)
    before = got
    for attempt in (1, 2):
        fx, fy, fw, fh = field_region(a)
        if not opened:
            io.click(fx + fw // 2, fy + fh // 2)                 # 목록 열기
            io.sleep(0.7)
            a, opened, got = _state(io, a)
            if not opened:
                log('전술 전환 %d차: 목록이 열리지 않음', attempt)
                continue
        io.hover(fx + fw // 2, fy - 30)                          # 마우스를 목록 밖으로
        io.sleep(0.2)
        io.click(fx + sl['dx'], fy + sl['dy'])                   # 등록할 때 누른 자리
        io.sleep(0.9)
        a, opened, got = _state(io, a)
        if opened:                                               # 아직 열려 있음 -> 닫기
            io.click(fx + fw // 2, fy + fh // 2)
            io.sleep(0.6)
            a, opened, got = _state(io, a)
        log('전술 전환 %d차: %s 자리 누름 -> 전술 칸 %s', attempt, st.name(to), '모름' if got == -1 else st.name(got))
        if got == to and not opened:
            return True, to, ''
        if got not in (to, -1, before) and not opened:
            break                                                # 다른 전술이 선택됨 -> 같은 자리 다시 눌러도 같음 (그대로면 한 번 더)
    if opened:
        fx, fy, fw, fh = field_region(a)
        io.click(fx + fw // 2, fy + fh // 2)
        io.sleep(0.6)
        a, opened, got = _state(io, a)
    return False, got, ('%s 자리를 눌렀는데 다른 전술이 선택됨 (게임에서 전술 목록 순서가 바뀌었을 수 있음 - 다시 등록해 주세요)' % st.name(to)
                        if got not in (-1, to, before) else '전술 목록을 열거나 고르지 못함 (클릭이 안 먹힘)')


def capture_registration(io, timeout=40.0, stop=None, log=None):
    """등록: 사용자가 [전술 ▼] 목록을 열고 전술을 클릭할 때까지 기다림 -> {'dx','dy','field','text','item'} 또는 오류 문구"""
    log = log or (lambda *a: None)
    stop = stop or (lambda: False)
    end = time.time() + timeout
    anchor = None
    last = None
    was_down = io.mouse_down()
    while time.time() < end:
        if stop():
            return '취소했어요'
        f = io.grab()
        a = io.anchor(f)
        if a is not None:
            anchor = a
            last = f
        down = io.mouse_down()
        if down and not was_down and anchor is not None:
            x, y = io.mouse_pos()
            fx, fy, fw, fh = field_region(anchor)
            if fx - 4 <= x <= fx + fw + 6 and fy + LIST_Y0 <= y <= fy + LIST_Y1:
                item = io.crop(last, (fx, y - 11, fw, 22)) if last is not None else None
                while io.mouse_down() and time.time() < end:
                    io.sleep(0.03)
                io.sleep(0.9)
                f2 = io.grab()
                a2 = io.anchor(f2) or anchor
                fr = io.crop(f2, field_region(a2))
                if not looks_like_field(fr):
                    return '전술을 고른 뒤 전술 칸을 읽지 못했어요 - 다시 해 주세요'
                log('전술 등록: 클릭 위치 전술 칸 기준 (%d, %d)', x - fx, y - fy)
                return {'dx': x - fx, 'dy': y - fy, 'field': fr, 'text': text_of(fr), 'item': item}
        was_down = down
        io.sleep(0.05 if anchor is not None else 0.3)
    if anchor is None:
        return '게임 스쿼드 화면(경기 전 [진행] 버튼이 있는 화면)을 찾지 못했어요'
    return '시간이 지났어요 - 목록을 열고 전술을 클릭해 주세요'
