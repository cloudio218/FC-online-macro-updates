# -*- coding: utf-8 -*-
"""v3.1: 매크로를 항상 관리자 권한으로 켜기

왜: FC온라인(넥슨 런처·보안 프로그램)은 관리자 권한으로 돌아간다. Windows는 권한이 낮은 프로그램이
    높은 프로그램에 보내는 마우스·키 입력을 조용히 버리므로(UIPI), 매크로가 일반 권한이면
    화면 인식은 되는데 클릭이 하나도 안 먹는다. (2026-11-14 새 PC에서 확인)
어떻게: 켜지자마자 관리자인지 확인 -> 아니면 같은 exe를 'runas'로 다시 띄우고(Windows의 [예] 창 1번)
    지금 것은 종료. [아니요]를 누르면 일반 권한으로 그대로 켜고 경고만 띄운다.
주의:
  - 실행기(launcher)는 새 버전 설치 직후 pending.txt 를 남겨서, 다음 실행 때 그게 남아 있으면 '켜지지 않았다'고
    보고 이전 버전으로 되돌린다. 다시 켜기 전에 반드시 지운다 (안 지우면 방금 받은 업데이트가 되돌려짐).
  - runas 로 띄운 프로세스는 환경변수를 물려받지 않는다 -> 업데이트 안내 문구는 파일로 넘긴다.
  - 다시 켠 쪽은 명령줄에 FLAG 가 붙는다. 그래도 관리자가 아니면(계정 문제 등) 또 띄우지 않는다 (무한 반복 방지).
"""
import os
import sys
import json
import ctypes
import subprocess

FLAG = '--fc-elevated'
STATE = {'admin': None, 'tried': False, 'declined': False, 'off': False, 'failed': False, 'why': ''}


def is_admin():
    """True/False, Windows가 아니면 None"""
    if os.name != 'nt':
        return None
    try:
        return bool(ctypes.windll.shell32.IsUserAnAdmin())
    except Exception:
        return None


def _msg_file(data):
    return os.path.join(data, 'app', 'relaunch_msg.txt')


def _target():
    """다시 띄울 프로그램과 인자. exe면 exe 그대로(실행기부터 다시), 개발 환경이면 파이썬 + 스크립트"""
    if os.environ.get('FCMACRO_RESTART_CMD'):           # 실행기 테스트용 (launcher.restart 와 같은 방식)
        cmd = json.loads(os.environ['FCMACRO_RESTART_CMD'])
        return cmd[0], cmd[1:]
    if getattr(sys, 'frozen', False):
        return sys.executable, []
    return sys.executable, [os.path.abspath(sys.argv[0])]


def _shell_runas(exe, params, cwd):
    """Windows [예/아니요] 창을 띄워 관리자로 실행. 성공이면 True"""
    r = ctypes.windll.shell32.ShellExecuteW(None, 'runas', exe, params, cwd, 1)
    return int(r) > 32, int(r)


def take_relaunch_msg(data):
    """다시 켜진 쪽: 처음 켜졌을 때의 업데이트 안내 문구를 이어받음"""
    p = _msg_file(data)
    try:
        if os.path.exists(p):
            with open(p, encoding='utf-8') as f:
                msg = f.read().strip()
            os.remove(p)
            if msg and not os.environ.get('FCMACRO_UPDATE_MSG'):
                os.environ['FCMACRO_UPDATE_MSG'] = msg
    except OSError:
        pass


def ensure(data, enabled=True, mark_ok=None, runas=None, exit_fn=None):
    """관리자가 아니면 관리자로 다시 켜고 지금 것은 끝냄. 이어서 실행해야 하면 STATE 를 돌려줌"""
    runas = runas or _shell_runas
    exit_fn = exit_fn or (lambda: os._exit(0))
    adm = is_admin()
    STATE['admin'] = adm
    if adm is None:
        STATE['why'] = 'Windows 아님'
        return STATE
    if adm:
        take_relaunch_msg(data)
        STATE['why'] = '관리자 권한으로 실행 중'
        return STATE
    if not enabled:
        STATE['off'] = True
        STATE['why'] = "설정에서 '관리자 권한으로 켜기'가 꺼져 있음"
        return STATE
    if FLAG in sys.argv:
        STATE['failed'] = True
        STATE['why'] = '관리자로 다시 켰는데도 관리자 권한이 아님 (이 Windows 계정에 관리자 권한이 없을 수 있음)'
        return STATE
    if os.environ.get('FCMACRO_NO_ELEVATE'):
        STATE['off'] = True
        STATE['why'] = '테스트 모드'
        return STATE
    STATE['tried'] = True
    msg = os.environ.get('FCMACRO_UPDATE_MSG', '')
    try:
        if msg:
            os.makedirs(os.path.dirname(_msg_file(data)), exist_ok=True)
            with open(_msg_file(data), 'w', encoding='utf-8') as f:
                f.write(msg)
    except OSError:
        pass
    if mark_ok:
        mark_ok(data)            # 업데이트 직후라도 '정상 켜짐'으로 표시해야 다시 켠 쪽에서 되돌리지 않음
    exe, args = _target()
    params = subprocess.list2cmdline(args + [a for a in sys.argv[1:] if a != FLAG] + [FLAG])
    try:
        ok, code = runas(exe, params, os.path.dirname(exe))
    except Exception as e:
        ok, code = False, str(e)
    if ok:
        exit_fn()
        return STATE             # (테스트에서 exit_fn 이 끝내지 않을 때)
    try:
        os.remove(_msg_file(data))
    except OSError:
        pass
    STATE['declined'] = True
    STATE['why'] = ('[아니요]를 눌러 일반 권한으로 켜짐' if code in (5, '5') else '관리자로 다시 켜지 못함 (%s)' % code)
    return STATE


def check_line():
    """F7 점검 줄: (OK여부, 문구)"""
    a = STATE['admin']
    if a is None:
        return None
    if a:
        return (True, '관리자 권한으로 실행 중 (게임 클릭 가능)')
    return (False, '관리자 권한 아님 - 게임이 클릭을 무시할 수 있어요 (%s). 매크로를 다시 켜고 [예]를 눌러 주세요'
            % STATE['why'])


# ── v3.4.1: 매크로 두 개 동시 실행 막기 ─────────────────────────────
# 왜: 2026-11-17 지인 PC - 09:40에 F12로 멈춘 매크로가 안 꺼진 채 남아 있는데 매크로를 또 켬.
#     새 매크로는 정상 진행, 하지만 텔레그램 봇은 하나의 연결만 받아서 예전(멈춘) 매크로가 대답 ->
#     '대기 중 · F12로 종료됨 09:40' 상태만 계속 옴, 새 매크로 창엔 '텔레그램 ✖'
MUTEX_NAME = 'Local\\FCOnlineManagerMacro_single'
_mutex = [None]
SINGLE = {'other': False, 'killed': None, 'why': ''}


def _pid_file(data):
    return os.path.join(data, 'app', 'macro.pid')


def _image_name(pid):
    """그 프로세스의 실행 파일 이름 (모르면 '')"""
    try:
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x1000, False, int(pid))         # PROCESS_QUERY_LIMITED_INFORMATION
        if not h:
            return ''
        try:
            buf = ctypes.create_unicode_buffer(1024)
            n = ctypes.c_ulong(1024)
            if k.QueryFullProcessImageNameW(h, 0, buf, ctypes.byref(n)):
                return os.path.basename(buf.value).lower()
        finally:
            k.CloseHandle(h)
    except Exception:
        pass
    return ''


def _kill(pid):
    """예전 매크로 끝내기 -> True/False"""
    try:
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x0001 | 0x00100000, False, int(pid))   # PROCESS_TERMINATE | SYNCHRONIZE
        if not h:
            return False
        try:
            k.TerminateProcess(h, 1)
            return k.WaitForSingleObject(h, 5000) == 0
        finally:
            k.CloseHandle(h)
    except Exception:
        return False


def _gone_soon(pid, ms=3000):
    """예전 매크로가 곧 끝나는 중이면(다시 켜기 직후 등) 기다려 봄 -> 끝났으면 True"""
    try:
        k = ctypes.windll.kernel32
        h = k.OpenProcess(0x00100000, False, int(pid))         # SYNCHRONIZE
        if not h:
            return True                                     # 이미 없음
        try:
            return k.WaitForSingleObject(h, ms) == 0
        finally:
            k.CloseHandle(h)
    except Exception:
        return False


def _ask(text):
    try:
        # MB_YESNO | MB_ICONWARNING | MB_SETFOREGROUND | MB_TOPMOST  -> [예]=6
        return ctypes.windll.user32.MessageBoxW(None, text, 'FC 딸깍이 Pro - 이미 켜져 있음', 0x4 | 0x30 | 0x10000 | 0x40000) == 6
    except Exception:
        return True


def _is_macro(name):
    me = os.path.basename(sys.executable).lower()
    return bool(name) and (name == me or 'fifa' in name or 'macro' in name or name.startswith('python'))


def single_instance(data, mutex=None, ask=None, kill=None, image=None, exit_fn=None, pid=None, gone=None):
    """이미 켜진 매크로가 있으면 물어보고 예전 것을 끄거나(예) 새로 켜지 않음(아니요). 이어서 실행하면 True"""
    exit_fn = exit_fn or (lambda: os._exit(0))
    ask, kill, image, gone = ask or _ask, kill or _kill, image or _image_name, gone or _gone_soon
    pid = os.getpid() if pid is None else pid
    if mutex is None:
        if os.name != 'nt':
            return True
        try:
            k = ctypes.windll.kernel32
            _mutex[0] = k.CreateMutexW(None, False, MUTEX_NAME)
            err = k.GetLastError()
            other = err == 183 or (not _mutex[0] and err == 5)  # 이미 있음 / 관리자 매크로가 만든 것
        except Exception:
            return True
    else:
        other = mutex()
    pf = _pid_file(data)
    if other:
        SINGLE['other'] = True
        old = None
        try:
            with open(pf, encoding='utf-8') as f:
                old = int(f.read().strip() or 0) or None
        except (OSError, ValueError):
            old = None
        name = image(old) if old and old != pid else ''
        if old and old != pid and (not name or _is_macro(name)) and gone(old):
            SINGLE['why'] = '예전 매크로(%s)가 막 꺼지는 중이었음 - 그대로 켬' % old
            old = None
        if SINGLE['why']:
            pass
        elif not ask('FC 딸깍이 Pro가 이미 켜져 있어요.\n'
                   '(작업표시줄 오른쪽 숨은 아이콘이나 뒤에 가려진 창을 확인해 보세요)\n\n'
                   '두 개가 같이 켜져 있으면 클릭이 겹치고, 텔레그램 봇이 예전 매크로 상태로 대답합니다.\n\n'
                   '[예]  예전 매크로를 끄고 새로 켜기\n[아니요]  새로 켜지 않기'):
            SINGLE['why'] = '새로 켜지 않음'
            exit_fn()
            return False
        elif old and _is_macro(name) and kill(old):
            SINGLE['killed'] = old
            SINGLE['why'] = '예전 매크로(%s) 끄고 새로 켬' % old
        else:
            SINGLE['why'] = '예전 매크로를 못 찾음 (pid %s %s) - 그대로 켬' % (old, name or '-')
    try:
        os.makedirs(os.path.dirname(pf), exist_ok=True)
        with open(pf, 'w', encoding='utf-8') as f:
            f.write(str(pid))
    except OSError:
        pass
    return True
