# -*- coding: utf-8 -*-
"""v4.1 사용법 팝업 (시안 mock7)

매크로 창 맨 위 [? 사용법] -> 지금 보고 있는 화면(감독모드 / 이적시장 갱신꾼)의 단계별 사용법
- 왼쪽: 단계 목록 (끝낸 단계는 초록 ✓ - 실제 지정 상태를 보고 자동으로)
- 가운데: 실제 화면 캡처 위에 형광 노랑 테두리·번호 (images/guide/*.jpg) + 따라 하기 + 도움말
- 아래: ← 이전 · [이 단계 바로 하기] · 점 · '처음 켤 때 안 보기' · 다음 →
글자는 Tk 로 (선명하게), 그림만 jpg
"""
import os
import re
import tkinter as tk

import gui as G
import paths

NEON_Y = G.NEON_Y
NEON_B = G.NEON_B
F = lambda size, bold=False: (G.FONT, size, 'bold') if bold else (G.FONT, size)      # noqa: E731
PX = G.px
TIPBG = {'tip': ('#2a2615', '#5a5020', '#f3dc8a'), 'warn': ('#2e1c1f', '#6b2a33', '#ffb3ba'),
         'ok': ('#173026', '#2a5a44', '#b5f0d4')}
TIPHEAD = {'tip': 'TIP', 'warn': '주의', 'ok': '참고'}

# ── 내용 ─────────────────────────────────────────────
# 글자 표시: **굵게**  [[버튼·키]]  {g:초록}
P = lambda **k: k        # noqa: E731

TR_PRE = P(rail='예전 갱신 매크로를 썼다면', kicker='먼저 확인', img='tr_0',
           title='예전 갱신 매크로 설정을 한 번에 가져와요',
           how=['갱신꾼 화면 아래 [[⚙ 갱신 설정]] 을 눌러요',
                "맨 아래 **'예전 갱신 매크로'** 칸의 [[기존 설정 가져오기…]] 를 눌러요",
                '예전 매크로 폴더(**TransferMacro.exe** 가 있는 폴더)를 고르면 **프리셋 · 위치 · 텔레그램 · 기록**이 한 번에 옮겨져요'],
           tip=('ok', '가져오면 1~5단계가 끝나요. 바로 6단계 [테스트]로 넘어가세요.\n'
                    '예전 갱신 매크로는 같이 켜지 마세요 (같은 텔레그램 봇을 써서 서로 꼬여요).'),
           act=('tr_settings', '⚙ 갱신 설정 창 열기'))
TR_STEPS = [
    P(rail='게임 준비 · 거래 목록', img='tr_1', title='게임을 창 모드로 켜고 이적시장 › 거래 목록을 열어요',
      how=['FC온라인 설정에서 **창 모드 · 1280×720** 으로 (다른 크기면 위치가 안 맞아요)',
           '로비 아래 **이적시장** 을 열고, 위쪽 [[거래 목록]] 탭을 눌러요',
           '갱신할 선수(**구매 대기 / 판매 대기**)가 목록에 보이면 준비 끝'],
      tip=('tip', '위치 지정은 로비 이적시장에서 한 번만 하면 돼요. 감독모드 경기 중 이적시장은 자동으로 맞춰져요.')),
    P(rail='① 창 범위 지정', img='tr_2', title='이적시장 창 테두리를 드래그해요',
      how=['매크로 [[⌖ 위치 지정]] → **‘① 창 범위 (필수)’** 옆 [[지정]] 을 눌러요',
           '화면이 살짝 어두워지면, 이적시장 창의 **왼쪽 위 모서리에서 오른쪽 아래 모서리까지** 마우스로 끌어요',
           '위치 지정 창에 {g:✓ 지정됨} 이 뜨면 끝'],
      tip=('warn', '게임은 창 모드 1280×720 이어야 해요. 잘못 끌었으면 다시 [지정]을 누르면 돼요.\n'
                   '감독모드 경기 중 이적시장 크기가 로비와 다를 때만 ②③ 도 해 주세요.'),
      act=('tr_pos', '⌖ 위치 지정 창 열기')),
    P(rail='구매 창 · 상한가/하한가', img='tr_3', title='구매 창 · 상한가 · 하한가를 알려 줘요',
      how=['거래 목록에서 **구매 중인 선수**의 [[재등록]] 을 눌러 구매 창을 띄워 둬요',
           "[[⌖ 위치 지정]] **'구매 창 표시'** [[지정]] → 왼쪽 위 **'구매' 글자**만 드래그",
           "**'상한가 숫자'** [[지정]] → 오른쪽 상한가 **숫자만** 드래그 (예: 119만)",
           "**'하한가 숫자'** [[지정]] → 오른쪽 하한가 **숫자만** 드래그 (예: 117만)"],
      tip=('tip', '숫자 칸은 숫자보다 조금 넉넉하게. 가격이 바뀌는 걸 이 칸으로 알아채요.\n'
                  '판매 중인 선수도 갱신하면 오른쪽 판매 창 칸도 같은 방법으로 (판매 창 표시만 해도 돼요).'),
      act=('tr_pos', '⌖ 위치 지정 창 열기')),
    P(rail='프리셋에 선수 넣기', img='tr_4', title='프리셋 한 줄 = 갱신할 선수 한 명',
      how=['[[☰ 프리셋]] 을 열고 그 줄의 **사용** 을 켜요',
           '**선수** 칸에 알아보기 쉬운 이름 (예: 알리송)',
           "**구매 / 판매** : 거래 목록에서 그 선수가 '구매 대기'면 구매, '판매 대기'면 판매",
           '**갱신 시간** : 이 선수 가격을 갱신할 때 — **짝수시 / 홀수시 / 매시 + 분** (예: 짝수시 06분 = 18:06, 20:06 …)',
           '**누를 가격** : 상한가로 올릴지, 하한가로 내릴지'],
      tip=('tip', '시간이 겹치면 [우선] 숫자가 작은 선수부터 해요. ★ 최우선은 7단계에서 설명해요.'),
      act=('tr_presets', '☰ 프리셋 창 열기')),
    P(rail='선수 위치 3곳', img='tr_5', title='그 선수의 [재등록] [선수이름] [등록가] 위치를 알려 줘요',
      how=['프리셋 그 줄의 [[재등록]] 칸 → 거래 목록에서 그 선수 줄의 **재등록 버튼 자리를 한 번 클릭**',
           '[[선수이름]] 칸 → 그 선수의 **시즌 아이콘 + 이름을 드래그** (줄이 바뀌어도 이 이름을 찾아가요)',
           '[[등록가]] 칸 → 내가 건 **가격 숫자를 드래그** (선택 · 성공 확인에 써요)'],
      tip=('ok', '셋 다 하면 칸이 초록 ✓ 로 바뀌어요. 선수마다 한 번씩만 하면 돼요.\n'
                 '재등록 버튼이 마우스를 올려야 보이면, 버튼이 뜨는 그 자리를 클릭하면 돼요.'),
      act=('tr_presets', '☰ 프리셋 창 열기')),
    P(rail='[테스트]로 확인', img='tr_6', title='[테스트]로 제대로 되는지 짧게 시험해요',
      how=['게임에 **거래 목록**을 띄워 둔 채로, 프리셋 그 줄의 [[테스트]] 를 눌러요',
           '매크로가 재등록 → 구매 창을 열고 가격을 보고, **확정은 안 하고** 닫아요',
           '갱신꾼 화면 **캡처 확인** 칸에 구매 창 사진이 보이면 성공'],
      tip=('warn', '안 되면 갱신꾼 화면 아래 기록 줄에 이유가 떠요 (예: 구매 창을 못 찾음 → 3단계 다시).\n'
                   '테스트 시간은 [⚙ 갱신 설정] › 테스트 시간에서 바꿔요.'),
      act=('tr_presets', '☰ 프리셋 창 열기')),
    P(rail='예약 시작', img='tr_7', title='[▶ 예약 시작] 하면 갱신 시간에 알아서 해요',
      how=['갱신꾼 화면 [[▶ 예약 시작]] (또는 [[Ctrl+F9]]) — 켜진 선수들의 다음 갱신 시각을 기다려요',
           '멈출 때는 [[■ 정지]] (또는 [[Ctrl+F10]])',
           '감독모드는 따로 [[F9]] 로 같이 돌리면 돼요. 경기 중엔 **매 분 0~20초만** 이적시장을 열었다 닫아요'],
      tip=('tip', '★ 최우선 선수는 갱신 시간과 경기가 겹칠 것 같으면 로비에서 기다렸다가 로비 이적시장으로 갱신하고,\n'
                  '끝나면 감독모드를 다시 시작해요 (가장 안정적). 프리셋의 ★ 를 눌러 켜요.'),
      act=('tr_start', '▶ 지금 예약 시작')),
]
GM_STEPS = [
    P(rail='게임 준비', img='gm_1', title='창 모드 1280×720 · 감독모드 홈에서 시작해요',
      how=['FC온라인 설정에서 **창 모드 + 1280×720**',
           '**공식경기 감독모드 홈** 화면까지 들어가요',
           '매크로를 켤 때 뜨는 Windows 확인 창에서 꼭 **[예]**'],
      tip=('warn', '[아니요]를 누르면 화면은 알아보는데 게임이 클릭을 무시해서 아무것도 안 눌려요.')),
    P(rail='창 배치 저장', img='gm_2', title='게임과 매크로 창을 겹치지 않게 두고 저장해요',
      how=['게임 창과 매크로 창을 **서로 겹치지 않게 나란히** 둬요',
           '매크로 창 맨 위 오른쪽 [[▣ 배치 저장]] 을 한 번 눌러요',
           '다음부터 켤 때마다 그 자리로 알아서 옮겨 줘요'],
      tip=('tip', "매크로는 게임 화면을 '보고' 눌러요. 다른 창에 가려지면 못 눌러요."),
      act=('layout', '▣ 지금 배치 저장')),
    P(rail='시작', img='gm_3', title='[▶ 시작] (F9) → 목표만 정하고 시작',
      how=['[[▶ 시작]] 또는 [[F9]]',
           '설정 창에서 원하는 것만: **목표 점수 · 목표 순위 · 종료 시각** (비워 두면 계속)',
           '끝! 매판 기록하면서 알아서 진행해요'],
      tip=('warn', '시작 직후 아래 [알림·점검]에 빨간 ✖ 가 있으면 그것부터 해결하세요.'),
      act=('start', '▶ 지금 시작 (F9)')),
    P(rail='멈추기 · 막판종료', img='gm_4', title='잠깐 멈춤 · 바로 끝 · 이번 판까지만',
      how=['[[❚❚ 일시정지]] [[F10]] 잠깐 멈춤 (다시 누르면 이어서) — 직접 이적시장을 볼 때',
           '[[■ 종료]] [[F12]] 바로 멈춤 (경기 중이면 그 판은 질 수 있어요)',
           '[[⚑ 막판종료]] [[Ctrl+F12]] 이번 판까지만 하고 끝 (밖에 나갈 때)'],
      tip=('tip', '단축키는 게임 화면을 보고 있어도 먹혀요. [⌨ 단축키]에서 원하는 키로 바꿀 수 있어요.')),
    P(rail='점검 · 설정 · 알림', img='gm_5', title='문제가 있으면 점검부터',
      how=['아래 **알림·점검** 줄을 누르면 지금 상태를 자세히 보여 줘요',
           '[[✔ 점검]] [[F7]] 지금 잘 돌아갈 수 있는지 검사',
           '[[⚙ 설정]] [[F8]] 목표 · 종료 시각 · 휴대폰 알림(텔레그램 / 디스코드)'],
      tip=('ok', '더 자세한 설명은 매크로 폴더의 사용법.txt 에 있어요 (전술 자동 변경 · 쉬는 시간 · 친구 랭킹 등).'),
      act=('check', '✔ 지금 점검 (F7)')),
]
GUIDES = {'tr': dict(name='이적시장 갱신꾼', color=NEON_Y, ink='#141400', pre=TR_PRE, steps=TR_STEPS),
          'gm': dict(name='감독모드', color=NEON_B, ink='#04131c', pre=None, steps=GM_STEPS)}

_TOK = re.compile(r'(\*\*.+?\*\*|\[\[.+?\]\]|\{g:.+?\})')


def parse(s):
    """-> [(글자, 꾸밈)]  꾸밈: '' / 'b' / 'k' / 'g'"""
    out = []
    for t in _TOK.split(s):
        if not t:
            continue
        if t.startswith('**'):
            out.append((t[2:-2], 'b'))
        elif t.startswith('[['):
            out.append((t[2:-2], 'k'))
        elif t.startswith('{g:'):
            out.append((t[3:-1], 'g'))
        else:
            out.append((t, ''))
    return out


def plain(s):
    return ''.join(x for x, _ in parse(s))


# ── 창 ──────────────────────────────────────────────
_st = {'win': None, 'obj': None}


def _circle(parent, text, fill, ink, size=24, outline=None, bg=G.BG, font=None):
    c = tk.Canvas(parent, width=PX(size), height=PX(size), bg=bg, highlightthickness=0, bd=0)
    c.create_oval(1, 1, PX(size) - 1, PX(size) - 1, fill=fill, outline=outline or fill, width=1.5)
    c.create_text(PX(size) // 2, PX(size) // 2, text=text, fill=ink, font=font or F(9, True))
    return c


class Guide:
    def __init__(self, kind, status, action, opt_get, opt_set):
        self.kind = kind
        self.status = status or (lambda k: set())
        self.action = action or (lambda a: None)
        self.opt_get, self.opt_set = opt_get, opt_set
        self.idx = 0
        self.done = set()
        self.photo = None
        self._img_key = None
        w = self.w = tk.Toplevel(G._root)
        w.title('FC 딸깍이 Pro · 사용법')
        w.configure(bg=G.BG)
        w.minsize(PX(860), PX(560))
        try:
            if G._root.attributes('-topmost'):
                w.attributes('-topmost', True)
        except tk.TclError:
            pass
        self._place()
        try:
            G._remember_pop(w, 'guide')
        except Exception:
            pass
        w.protocol('WM_DELETE_WINDOW', self.close)
        w.bind('<Left>', lambda e: self.go(self.idx - 1))
        w.bind('<Right>', lambda e: self.go(self.idx + 1))
        w.bind('<Escape>', lambda e: self.close())
        self._build()
        self.set_kind(kind, first=True)
        self._tick()

    # 창 자리: 매크로 창 오른쪽 (모자라면 왼쪽 · 가운데)
    def _place(self):
        ww, wh = PX(1040), PX(800)
        try:
            sw, sh = G._root.winfo_screenwidth(), G._root.winfo_screenheight()
            wh = min(wh, sh - PX(80))
            rx, ry, rw = G._root.winfo_rootx(), G._root.winfo_rooty(), G._root.winfo_width()
            if rx + rw + 12 + ww <= sw:
                x = rx + rw + 12
            elif rx - 12 - ww >= 0:
                x = rx - 12 - ww
            else:
                x = max(0, (sw - ww) // 2)
            y = max(0, min(ry, sh - wh - PX(50)))
            self.w.geometry('%dx%d+%d+%d' % (ww, wh, x, y))
        except Exception:
            self.w.geometry('%dx%d' % (ww, wh))

    def _build(self):
        w = self.w
        hd = tk.Frame(w, bg=G.BG, padx=PX(18), pady=PX(12))
        hd.pack(fill='x')
        tk.Label(hd, text='사용법', font=F(15, True), fg=G.FG, bg=G.BG).pack(side='left')
        seg = tk.Frame(hd, bg=G.LINE)
        seg.pack(side='left', padx=PX(14))
        self.seg = {}
        for k in ('tr', 'gm'):
            b = tk.Label(seg, text=GUIDES[k]['name'], font=F(10, True), padx=PX(14), pady=PX(4), cursor='hand2')
            b.pack(side='left', padx=(0 if k == 'tr' else 1, 0))
            b.bind('<Button-1>', lambda e, k=k: self.set_kind(k))
            self.seg[k] = b
        self.w_prog = tk.Label(hd, text='', font=F(9), fg=G.DIM, bg=G.BG)
        self.w_prog.pack(side='right')
        tk.Frame(w, bg=G.LINE, height=1).pack(fill='x')
        # 아래 (먼저 붙여야 창이 작아도 안 잘림)
        ft = tk.Frame(w, bg=G.BG, padx=PX(18), pady=PX(10))
        ft.pack(side='bottom', fill='x')
        tk.Frame(w, bg=G.LINE, height=1).pack(side='bottom', fill='x')
        self.w_prev = self._btn(ft, '← 이전', lambda: self.go(self.idx - 1))
        self.w_prev.pack(side='left')
        self.w_act = self._btn(ft, '', self._do_act, fg=G.CYAN, bg='#1c2a33', bd='#2c5560')
        self.w_act.pack(side='left', padx=PX(10))
        self.w_next = self._btn(ft, '다음 →', lambda: self.go(self.idx + 1))
        self.w_next.pack(side='right')
        self.v_noauto = tk.BooleanVar(value=bool(self.opt_get('guide_auto_off', False)) if self.opt_get else False)
        ck = tk.Checkbutton(ft, text='처음 켤 때 안 보기', variable=self.v_noauto, command=self._noauto,
                            font=F(9), fg=G.DIM, bg=G.BG, activebackground=G.BG, activeforeground=G.FG,
                            selectcolor=G.CARD2, highlightthickness=0, bd=0)
        ck.pack(side='right', padx=PX(12))
        self.w_dots = tk.Canvas(ft, height=PX(10), bg=G.BG, highlightthickness=0)
        self.w_dots.pack(side='left', fill='x', expand=True)
        # 가운데
        body = tk.Frame(w, bg=G.BG)
        body.pack(fill='both', expand=True)
        self.rail = tk.Frame(body, bg='#191920', width=PX(250))
        self.rail.pack(side='left', fill='y')
        self.rail.pack_propagate(False)
        tk.Frame(body, bg=G.LINE, width=1).pack(side='left', fill='y')
        outer = tk.Frame(body, bg=G.BG)
        outer.pack(side='left', fill='both', expand=True)
        cv = self.cv = tk.Canvas(outer, bg=G.BG, highlightthickness=0)
        vs = tk.Scrollbar(outer, orient='vertical', command=cv.yview)
        cv.configure(yscrollcommand=vs.set)
        vs.pack(side='right', fill='y')
        cv.pack(side='left', fill='both', expand=True)
        self.main = tk.Frame(cv, bg=G.BG, padx=PX(20), pady=PX(14))
        self._mid = cv.create_window((0, 0), window=self.main, anchor='nw')
        self.main.bind('<Configure>', lambda e: cv.configure(scrollregion=cv.bbox('all')))
        cv.bind('<Configure>', self._on_resize)
        cv.bind('<Enter>', lambda e: w.bind_all('<MouseWheel>', lambda ev: cv.yview_scroll(-1 if ev.delta > 0 else 1, 'units')))
        cv.bind('<Leave>', lambda e: w.unbind_all('<MouseWheel>'))
        self._rw = [0]

    def _btn(self, parent, text, cmd, fg=G.FG, bg=G.CARD2, bd=G.LINE):
        f = tk.Frame(parent, bg=bd, padx=1, pady=1)
        b = tk.Label(f, text=text, font=F(10, True), fg=fg, bg=bg, padx=PX(14), pady=PX(6), cursor='hand2')
        b.pack()
        b.bind('<Button-1>', lambda e: cmd() if b.cget('state') != 'disabled' else None)
        f.lbl = b
        return f

    def _on_resize(self, e):
        self.cv.itemconfigure(self._mid, width=e.width)
        if abs(e.width - self._rw[0]) > 30:
            self._rw[0] = e.width
            try:
                self.w.after_cancel(getattr(self, '_rs', None))
            except Exception:
                pass
            self._rs = self.w.after(150, self.render)

    # ── 내용 ──
    @property
    def g(self):
        return GUIDES[self.kind]

    def pages(self):
        return ([self.g['pre']] if self.g['pre'] else []) + self.g['steps']

    def num(self, i):
        """페이지 번호 -> 단계 번호 (0 = 먼저 확인)"""
        return i if self.g['pre'] else i + 1

    def set_kind(self, kind, first=False):
        self.kind = kind
        for k, b in self.seg.items():
            on = k == kind
            b.config(bg=GUIDES[k]['color'] if on else G.CARD, fg=GUIDES[k]['ink'] if on else G.DIM)
        self.done = self._status()
        steps = len(self.g['steps'])
        start = next((n for n in range(1, steps + 1) if n not in self.done), steps)
        if self.g['pre'] and not self.done:
            start = 0                                   # 아무것도 안 했으면 '예전 설정 가져오기'부터
        self.idx = start if self.g['pre'] else start - 1
        self._build_rail()
        self.render()

    def _status(self):
        try:
            return set(self.status(self.kind) or ())
        except Exception:
            return set()

    def _build_rail(self):
        for c in self.rail.winfo_children():
            c.destroy()
        self.rail_rows = {}
        tk.Frame(self.rail, bg='#191920', height=PX(10)).pack(fill='x')
        if self.g['pre']:
            z = tk.Frame(self.rail, bg='#2c5560', padx=1, pady=1, cursor='hand2')
            z.pack(fill='x', padx=PX(12), pady=(0, PX(8)))
            zi = tk.Label(z, text='예전 갱신 매크로를 썼다면\n[⚙ 갱신 설정 › 기존 설정 가져오기]\n한 번이면 5단계까지 끝나요',
                          font=F(9), fg='#bfe9f2', bg='#1c2a33', justify='left', anchor='w', padx=PX(10), pady=PX(7), cursor='hand2')
            zi.pack(fill='x')
            for x in (z, zi):
                x.bind('<Button-1>', lambda e: self.go(0))
            self.rail_rows[0] = (z, zi, None)
        for n, st in enumerate(self.g['steps'], 1):
            r = tk.Frame(self.rail, bg='#191920', cursor='hand2')
            r.pack(fill='x')
            bar = tk.Frame(r, bg='#191920', width=PX(3))
            bar.pack(side='left', fill='y')
            c = tk.Canvas(r, width=PX(26), height=PX(26), bg='#191920', highlightthickness=0)
            c.pack(side='left', padx=(PX(13), PX(10)), pady=PX(7))
            lb = tk.Label(r, text=st['rail'], font=F(10), fg=G.DIM, bg='#191920', anchor='w', cursor='hand2')
            lb.pack(side='left', fill='x', expand=True)
            i = n if self.g['pre'] else n - 1
            for x in (r, c, lb):
                x.bind('<Button-1>', lambda e, i=i: self.go(i))
            self.rail_rows[i] = (r, lb, (c, bar, n))
        tk.Label(self.rail, text='← → 키로도 넘겨요', font=F(8), fg='#5d5d72', bg='#191920').pack(side='bottom', pady=PX(10))
        self._paint_rail()

    def _paint_rail(self):
        for i, (r, lb, extra) in self.rail_rows.items():
            now = i == self.idx
            if extra is None:                          # '먼저 확인' 칸
                r.config(bg=self.g['color'] if now else '#2c5560')
                continue
            c, bar, n = extra
            done = n in self.done
            bg = '#23232f' if now else '#191920'
            for x in (r, lb, c):
                x.config(bg=bg)
            bar.config(bg=self.g['color'] if now else bg)
            lb.config(fg=G.FG if now else ('#b9b9cc' if done else G.DIM), font=F(10, now))
            c.delete('all')
            s = PX(26)
            if now:
                c.create_oval(2, 2, s - 2, s - 2, fill=self.g['color'], outline=self.g['color'])
                c.create_text(s // 2, s // 2, text=str(n), fill=self.g['ink'], font=F(9, True))
            elif done:
                c.create_oval(2, 2, s - 2, s - 2, fill='#1f3a2e', outline=G.GREEN, width=1.5)
                c.create_text(s // 2, s // 2, text='✓', fill=G.GREEN, font=F(10, True))
            else:
                c.create_oval(2, 2, s - 2, s - 2, outline='#44445a', width=1.5)
                c.create_text(s // 2, s // 2, text=str(n), fill=G.DIM, font=F(9, True))
        steps = len(self.g['steps'])
        nd = len([n for n in range(1, steps + 1) if n in self.done])
        self.w_prog.config(text=('끝낸 단계 %d / %d' % (nd, steps)) if self.kind == 'tr' or nd else '%d단계' % steps,
                           fg=G.GREEN if nd == steps else G.DIM)

    def go(self, i):
        n = len(self.pages())
        if i < 0 or i >= n:
            if i >= n:
                self.close()
            return
        self.idx = i
        self.render()
        self.cv.yview_moveto(0)

    def render(self):
        if not self.w.winfo_exists():
            return
        pg = self.pages()[self.idx]
        n = self.num(self.idx)
        m = self.main
        for c in m.winfo_children():
            c.destroy()
        color = self.g['color']
        tk.Label(m, text=pg.get('kicker') or '%d단계' % n, font=F(9, True), fg=color, bg=G.BG).pack(anchor='w')
        tk.Label(m, text=pg['title'], font=F(15, True), fg=G.FG, bg=G.BG, anchor='w', justify='left',
                 wraplength=max(PX(400), self.cv.winfo_width() - PX(60))).pack(anchor='w', pady=(PX(2), PX(10)))
        self._image(m, pg['img'])
        how = tk.Frame(m, bg=G.BG)
        how.pack(fill='x', pady=(PX(12), 0))
        wrap = max(PX(380), self.cv.winfo_width() - PX(100))
        for k, line in enumerate(pg['how'], 1):
            r = tk.Frame(how, bg=G.BG)
            r.pack(fill='x', pady=PX(3))
            _circle(r, str(k), color, self.g['ink'], 24).pack(side='left', anchor='n', padx=(0, PX(10)), pady=(PX(2), 0))
            self._rich(r, line, wrap).pack(side='left', fill='x', expand=True)
        if pg.get('tip'):
            kind, text = pg['tip']
            bg, bd, fg = TIPBG[kind]
            tf = tk.Frame(m, bg=bd, padx=1, pady=1)
            tf.pack(fill='x', pady=(PX(12), PX(4)))
            ti = tk.Frame(tf, bg=bg, padx=PX(12), pady=PX(8))
            ti.pack(fill='x')
            tk.Label(ti, text=TIPHEAD[kind], font=F(8, True), fg=bg, bg=fg, padx=PX(5)).pack(side='left', anchor='n', pady=(PX(2), 0))
            tk.Label(ti, text=text, font=F(9), fg=fg, bg=bg, justify='left', anchor='w',
                     wraplength=wrap - PX(40)).pack(side='left', fill='x', padx=(PX(10), 0))
        # 아래 줄
        last = self.idx == len(self.pages()) - 1
        self.w_prev.lbl.config(state='normal' if self.idx > 0 else 'disabled', fg=G.FG if self.idx > 0 else '#55556a')
        self.w_next.lbl.config(text='끝 · 닫기' if last else '다음 →', bg=color, fg=self.g['ink'])
        self.w_next.config(bg=color)
        act = pg.get('act')
        if act:
            self.w_act.lbl.config(text=act[1])
            self.w_act.pack(side='left', padx=PX(10), after=self.w_prev)
        else:
            self.w_act.pack_forget()
        self._dots()
        self._paint_rail()

    def _rich(self, parent, line, wrap):
        t = tk.Text(parent, bg=G.BG, fg=G.FG, font=F(11), bd=0, highlightthickness=0, wrap='word',
                    height=1, cursor='arrow', padx=0, pady=PX(1), spacing2=PX(3))
        t.tag_configure('b', font=F(11, True))
        t.tag_configure('g', font=F(11, True), foreground=G.GREEN)
        t.tag_configure('k', font=F(10, True), background=G.CARD2, foreground=G.FG)
        for txt, kind in parse(line):
            if kind == 'k':
                t.insert('end', ' %s ' % txt, 'k')
            else:
                t.insert('end', txt, kind or ())
        t.config(state='disabled')

        def fit(e=None):
            try:
                lines = int(t.count('1.0', 'end', 'displaylines')[0])
            except Exception:
                lines = max(1, len(plain(line)) // 48 + 1)
            t.config(height=max(1, lines))
        t.bind('<Configure>', fit)
        t.after(30, fit)
        return t

    def _image(self, parent, name):
        box_w = max(PX(420), self.cv.winfo_width() - PX(44))
        box_h = PX(430)
        p = paths.img(os.path.join('guide', name + '.jpg'))
        try:
            from PIL import Image, ImageTk
            im = Image.open(p)
            sc = min(box_w / im.width, box_h / im.height, 1.0)
            key = (name, int(im.width * sc), int(im.height * sc))
            if key != self._img_key:
                self._img_key = key
                rs = getattr(Image, 'Resampling', Image).LANCZOS
                self.photo = ImageTk.PhotoImage(im.convert('RGB').resize(key[1:], rs))
            f = tk.Frame(parent, bg=G.LINE, padx=1, pady=1)
            f.pack(anchor='w')
            tk.Label(f, image=self.photo, bg='#101016', bd=0).pack()
        except Exception:
            tk.Label(parent, text='(그림을 못 불러왔어요: %s)' % name, font=F(9), fg=G.DIM, bg=G.CARD,
                     padx=PX(12), pady=PX(30)).pack(fill='x')

    def _dots(self):
        c = self.w_dots
        c.delete('all')
        steps = len(self.g['steps'])
        cur = self.num(self.idx)
        width = steps * PX(14) + PX(14)
        c.update_idletasks()
        x = max(0, (c.winfo_width() - width) // 2)
        y = PX(5)
        for n in range(1, steps + 1):
            if n == cur:
                c.create_rectangle(x, y - PX(4), x + PX(22), y + PX(4), fill=self.g['color'], outline='')
                x += PX(28)
            else:
                c.create_oval(x, y - PX(4), x + PX(8), y + PX(4), fill=G.GREEN if n in self.done else '#44445a', outline='')
                x += PX(14)

    def _do_act(self):
        act = self.pages()[self.idx].get('act')
        if act:
            try:
                self.action(act[0])
            except Exception:
                pass

    def _noauto(self):
        if self.opt_set:
            try:
                self.opt_set('guide_auto_off', bool(self.v_noauto.get()))
            except Exception:
                pass

    def _tick(self):
        """끝낸 단계를 1.5초마다 다시 봄 (위치 지정을 하면 바로 ✓)"""
        if not self.w.winfo_exists():
            return
        d = self._status()
        if d != self.done:
            self.done = d
            self._paint_rail()
            self._dots()
        self.w.after(1500, self._tick)

    def close(self):
        try:
            self.w.destroy()
        except tk.TclError:
            pass
        _st['win'] = _st['obj'] = None


def open_guide(kind='tr', status=None, action=None, opt_get=None, opt_set=None):
    """사용법 창 열기 (이미 열려 있으면 그 화면으로 바꿔서 앞으로)"""
    o = _st['obj']
    if o is not None:
        try:
            if o.w.winfo_exists():
                if o.kind != kind:
                    o.set_kind(kind)
                o.w.deiconify()
                o.w.lift()
                return o
        except tk.TclError:
            pass
    o = Guide(kind, status, action, opt_get, opt_set)
    _st['obj'], _st['win'] = o, o.w
    return o
