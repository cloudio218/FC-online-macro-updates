# -*- coding: utf-8 -*-
"""v4.2 원격 프로그램(리피시)이 앞에 있을 때도 단축키가 먹게

리피시는 키보드 입력을 원격 PC로 보내려고 먼저 가로채서, 매크로의 단축키(keyboard 라이브러리)까지 안 옴.
Windows 는 키보드를 엿보는 프로그램 중 '나중에 등록한 쪽'에 먼저 키를 줌 -> 리피시가 앞에 오면
우리 감시를 다시 등록해 순서를 앞으로 당김. 키는 막지 않고 그대로 넘김 (원격 PC에도 감).
"""
import os
import threading
import time

WM_KEYDOWN, WM_SYSKEYDOWN = 0x0100, 0x0104
WM_APP_REHOOK = 0x8000 + 41
WM_APP_QUIT = 0x8000 + 42
VK_NAMES = {0x70 + i: 'f%d' % (i + 1) for i in range(12)}
VK_NAMES.update({0x30 + i: str(i) for i in range(10)})
VK_NAMES.update({0x41 + i: chr(ord('a') + i) for i in range(26)})
MODS = ((0x11, 'ctrl'), (0x10, 'shift'), (0x12, 'alt'))


def key_name(vk, mods):
    """(가상 키, ['ctrl', ...]) -> 'ctrl+f12' / None"""
    n = VK_NAMES.get(vk)
    if n is None:
        return None
    return '+'.join(list(mods) + [n])


class RemoteKeys:
    """on_key('ctrl+f12') 를 부름. active() 가 True 일 때만 (리피시가 앞일 때)"""

    def __init__(self, on_key, active, log=None):
        self.on_key, self.active, self.log = on_key, active, log or (lambda m: None)
        self.tid = None
        self.hook = None
        self.ok = False
        self.err = ''
        self.n = 0
        self._proc = None

    def start(self):
        if os.name != 'nt':
            return False
        threading.Thread(target=self._loop, daemon=True, name='rkeys').start()
        return True

    def rehook(self):
        """감시 다시 등록 (맨 앞으로)"""
        if self.tid:
            try:
                import ctypes
                ctypes.windll.user32.PostThreadMessageW(self.tid, WM_APP_REHOOK, 0, 0)
            except Exception:
                pass

    def _loop(self):
        try:
            import ctypes
            import ctypes.wintypes as wt
            u = ctypes.WinDLL('user32', use_last_error=True)
            k = ctypes.WinDLL('kernel32', use_last_error=True)
            LRESULT = ctypes.c_ssize_t
            PROC = ctypes.WINFUNCTYPE(LRESULT, ctypes.c_int, wt.WPARAM, wt.LPARAM)

            class KB(ctypes.Structure):
                _fields_ = [('vkCode', wt.DWORD), ('scanCode', wt.DWORD), ('flags', wt.DWORD),
                            ('time', wt.DWORD), ('dwExtraInfo', ctypes.c_size_t)]
            u.SetWindowsHookExW.argtypes = [ctypes.c_int, PROC, wt.HINSTANCE, wt.DWORD]
            u.SetWindowsHookExW.restype = wt.HHOOK
            u.CallNextHookEx.argtypes = [wt.HHOOK, ctypes.c_int, wt.WPARAM, wt.LPARAM]
            u.CallNextHookEx.restype = LRESULT
            u.UnhookWindowsHookEx.argtypes = [wt.HHOOK]
            u.GetMessageW.argtypes = [ctypes.POINTER(wt.MSG), wt.HWND, wt.UINT, wt.UINT]
            u.GetAsyncKeyState.argtypes = [ctypes.c_int]
            u.GetAsyncKeyState.restype = ctypes.c_short
            k.GetModuleHandleW.argtypes = [wt.LPCWSTR]
            k.GetModuleHandleW.restype = wt.HMODULE
            self.tid = k.GetCurrentThreadId()

            def proc(code, wparam, lparam):
                try:
                    if code == 0 and wparam in (WM_KEYDOWN, WM_SYSKEYDOWN):
                        kb = ctypes.cast(lparam, ctypes.POINTER(KB)).contents
                        vk = int(kb.vkCode)
                        if vk in VK_NAMES and self.active():
                            mods = [n for v, n in MODS if u.GetAsyncKeyState(v) & 0x8000]
                            name = key_name(vk, mods)
                            if name:
                                threading.Thread(target=self.on_key, args=(name,), daemon=True).start()
                except Exception:
                    pass
                return u.CallNextHookEx(None, code, wparam, lparam)
            self._proc = PROC(proc)                  # 지워지지 않게 붙잡아 둠
            hmod = k.GetModuleHandleW(None)

            def install():
                if self.hook:
                    u.UnhookWindowsHookEx(self.hook)
                self.hook = u.SetWindowsHookExW(13, self._proc, hmod, 0)    # WH_KEYBOARD_LL
                self.ok = bool(self.hook)
                self.n += 1
                if not self.ok:
                    self.err = '등록 실패 %s' % ctypes.get_last_error()
            install()
            self.log('원격 단축키 감시 시작 (%s)' % ('됨' if self.ok else self.err))
            msg = wt.MSG()
            while u.GetMessageW(ctypes.byref(msg), None, 0, 0) > 0:
                if msg.message == WM_APP_REHOOK:
                    install()
                elif msg.message == WM_APP_QUIT:
                    break
        except Exception as e:
            self.err = str(e)
            self.log('원격 단축키 감시 오류: %s' % e)


def watch(rk, fg_is_viewer, every=15.0, stop=None):
    """리피시가 앞에 새로 오거나 앞에 있는 동안 15초마다 다시 등록"""
    last_fg, last_t = False, 0.0
    while not (stop and stop()):
        try:
            fg = bool(fg_is_viewer())
            now = time.time()
            if fg and (not last_fg or now - last_t >= every):
                rk.rehook()
                last_t = now
            last_fg = fg
        except Exception:
            pass
        time.sleep(1.0)
