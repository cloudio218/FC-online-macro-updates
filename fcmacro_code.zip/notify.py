# -*- coding: utf-8 -*-
"""디스코드 웹훅 알림 (추가 설치 없음: 파이썬 기본 urllib 사용). 이미지 1장 첨부 가능."""
import json
import threading
import time
import uuid
import urllib.request
import urllib.error

COLORS = {'done': 0x3DDC84, 'stop': 0xFF5D7A, 'warn': 0xFFB020, 'info': 0x4AA8FF}
USER_AGENT = 'FCMacroNotifier (https://discord.com, 1.2)'   # 디스코드는 기본 urllib UA를 막는 경우가 있어 지정


def is_webhook_url(url):
    u = (url or '').strip()
    return u.startswith('https://') and '/api/webhooks/' in u


def _payload(title, lines, kind, image_name=None):
    embed = {
        'description': '\n'.join(lines)[:3900] or '-',
        'color': COLORS.get(kind, COLORS['info']),
        'footer': {'text': time.strftime('%Y-%m-%d %H:%M:%S')},
    }
    if image_name:
        embed['image'] = {'url': 'attachment://' + image_name}
    return {'username': 'FC 매크로', 'content': title, 'embeds': [embed]}


def _multipart(payload, image_bytes, image_name):
    boundary = 'fcmacro' + uuid.uuid4().hex
    ctype = 'image/jpeg' if image_name.lower().endswith(('.jpg', '.jpeg')) else 'image/png'
    parts = [
        ('--%s\r\nContent-Disposition: form-data; name="payload_json"\r\n'
         'Content-Type: application/json\r\n\r\n' % boundary).encode('utf-8'),
        json.dumps(payload).encode('utf-8'), b'\r\n',
        ('--%s\r\nContent-Disposition: form-data; name="files[0]"; filename="%s"\r\n'
         'Content-Type: %s\r\n\r\n' % (boundary, image_name, ctype)).encode('utf-8'),
        image_bytes, b'\r\n',
        ('--%s--\r\n' % boundary).encode('utf-8'),
    ]
    return b''.join(parts), 'multipart/form-data; boundary=' + boundary


def send_now(url, title, lines=(), kind='info', timeout=10, image=None, image_name='image.png'):
    """바로 전송하고 (성공 여부, 메시지) 반환. image = PNG/JPG 바이트 (선택)"""
    if not is_webhook_url(url):
        return False, '웹훅 주소 형식이 아닙니다 (https://discord.com/api/webhooks/... )'
    if image:
        data, ctype = _multipart(_payload(title, list(lines), kind, image_name), image, image_name)
    else:
        data, ctype = json.dumps(_payload(title, list(lines), kind)).encode('utf-8'), 'application/json'
    req = urllib.request.Request(url.strip(), data=data, method='POST',
                                 headers={'Content-Type': ctype, 'User-Agent': USER_AGENT})
    try:
        with urllib.request.urlopen(req, timeout=timeout) as r:
            code = r.getcode()
        return (200 <= code < 300), ('전송 성공' if 200 <= code < 300 else '응답 코드 %s' % code)
    except urllib.error.HTTPError as e:
        hint = ' (웹훅이 삭제되었거나 주소가 틀림)' if e.code in (401, 404) else ''
        return False, '전송 실패: HTTP %s%s' % (e.code, hint)
    except Exception as e:
        return False, '전송 실패: %s' % e


def send(url, title, lines=(), kind='info', on_done=None, image_fn=None, image_name='image.png'):
    """
    백그라운드로 전송 (매크로 진행을 막지 않음). 주소가 비어 있으면 아무것도 안 함.
    image_fn: 이미지 바이트를 만들어 주는 함수 (전송 스레드에서 호출, 실패하면 이미지 없이 전송)
    """
    if not (url or '').strip():
        return

    def run():
        image = None
        if image_fn is not None:
            try:
                image = image_fn()
            except Exception:
                image = None
        res = send_now(url, title, lines, kind, image=image, image_name=image_name)
        if on_done is not None:
            try:
                on_done(*res)
            except Exception:
                pass
    threading.Thread(target=run, daemon=True).start()
